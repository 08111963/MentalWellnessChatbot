import { users, type User, type InsertUser } from "@shared/schema";
import * as crypto from 'crypto';

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserSubscription(
    userId: number, 
    subscriptionData: {
      isPremium: boolean;
      subscriptionPlan?: string;
      stripeCustomerId?: string;
      stripeSubscriptionId?: string;
      subscriptionStart?: Date;
      subscriptionEnd?: Date;
      subscriptionStatus?: string;
    }
  ): Promise<User | undefined>;
  authenticateUser(username: string, password: string): Promise<User | undefined>;
  getUserByStripeCustomerId(customerId: string): Promise<User | undefined>;
}

// Semplice funzione per hashing delle password
function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.currentId = 1;
    
    // Creiamo un utente di test direttamente senza chiamare createUser
    // per evitare chiamate a metodi prima che siano definiti
    const id = this.currentId++;
    const hashedPwd = `sha256:${hashPassword('password')}`;
    
    const testUser: User = {
      id,
      username: 'test',
      password: hashedPwd,
      isPremium: false,
      subscriptionStart: null,
      subscriptionEnd: null,
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      subscriptionStatus: null,
      subscriptionPlan: null
    };
    
    // Creiamo un secondo utente di test con abbonamento premium
    const premiumId = this.currentId++;
    const premiumUser: User = {
      id: premiumId,
      username: 'premium',
      password: hashedPwd, // stessa password: 'password'
      isPremium: true,
      subscriptionStart: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 giorni fa
      subscriptionEnd: new Date(Date.now() + 23 * 24 * 60 * 60 * 1000), // 23 giorni nel futuro
      stripeCustomerId: 'cus_test_premium',
      stripeSubscriptionId: 'sub_test_premium',
      subscriptionStatus: 'active',
      subscriptionPlan: 'monthly'
    };
    
    this.users.set(premiumId, premiumUser);
    console.log(`Utente premium di test creato: ${premiumUser.username} (ID: ${premiumUser.id})`);
    
    this.users.set(id, testUser);
    console.log(`Utente di test creato: ${testUser.username} (ID: ${testUser.id})`);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }
  
  async getUserByStripeCustomerId(customerId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.stripeCustomerId === customerId
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Verifica se l'utente esiste già
    const existingUser = await this.getUserByUsername(insertUser.username);
    if (existingUser) {
      console.error(`ERRORE: Tentativo di creare un utente già esistente: ${insertUser.username}`);
      throw new Error('Utente già esistente');
    }
    
    const id = this.currentId++;
    
    // Hash della password prima di salvare
    const hashedPassword = insertUser.password.startsWith('sha256:') 
      ? insertUser.password 
      : `sha256:${hashPassword(insertUser.password)}`;
    
    // Assicuriamoci che tutti i campi siano definiti
    const user: User = { 
      id,
      username: insertUser.username,
      password: hashedPassword,
      isPremium: insertUser.isPremium ?? false,
      subscriptionStart: insertUser.subscriptionStart ?? null,
      subscriptionEnd: insertUser.subscriptionEnd ?? null,
      stripeCustomerId: insertUser.stripeCustomerId ?? null,
      stripeSubscriptionId: insertUser.stripeSubscriptionId ?? null,
      subscriptionStatus: insertUser.subscriptionStatus ?? null,
      subscriptionPlan: insertUser.subscriptionPlan ?? null
    };
    
    this.users.set(id, user);
    console.log(`Utente creato: ${user.username} (ID: ${user.id})`);
    return user;
  }
  
  async updateUserSubscription(
    userId: number, 
    subscriptionData: {
      isPremium: boolean;
      subscriptionPlan?: string;
      stripeCustomerId?: string;
      stripeSubscriptionId?: string;
      subscriptionStart?: Date;
      subscriptionEnd?: Date;
      subscriptionStatus?: string;
    }
  ): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) {
      return undefined;
    }
    
    const updatedUser: User = {
      ...user,
      isPremium: subscriptionData.isPremium,
      subscriptionPlan: subscriptionData.subscriptionPlan ?? user.subscriptionPlan,
      stripeCustomerId: subscriptionData.stripeCustomerId ?? user.stripeCustomerId,
      stripeSubscriptionId: subscriptionData.stripeSubscriptionId ?? user.stripeSubscriptionId,
      subscriptionStart: subscriptionData.subscriptionStart ?? user.subscriptionStart,
      subscriptionEnd: subscriptionData.subscriptionEnd ?? user.subscriptionEnd,
      subscriptionStatus: subscriptionData.subscriptionStatus ?? user.subscriptionStatus
    };
    
    this.users.set(userId, updatedUser);
    console.log(`Abbonamento aggiornato per l'utente ${user.username} (ID: ${user.id})`);
    console.log(`  Premium: ${updatedUser.isPremium}`);
    console.log(`  Piano: ${updatedUser.subscriptionPlan}`);
    console.log(`  Scadenza: ${updatedUser.subscriptionEnd}`);
    
    return updatedUser;
  }
  
  async authenticateUser(username: string, password: string): Promise<User | undefined> {
    const user = await this.getUserByUsername(username);
    if (!user) {
      return undefined;
    }
    
    const hashedPassword = `sha256:${hashPassword(password)}`;
    
    // Supporto per password già hashate
    if (user.password === password || user.password === hashedPassword) {
      console.log(`Autenticazione riuscita per l'utente ${user.username}`);
      return user;
    }
    
    return undefined;
  }
}

export const storage = new MemStorage();
