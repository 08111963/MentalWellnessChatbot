import { type Reflection } from '@shared/schema';

// In-memory reflections data
export const reflections: Reflection[] = [
  {
    id: 1,
    prompt: "Quali sono tre piccole cose per cui sei grato oggi?",
    category: "gratitudine",
    isPremium: true
  },
  {
    id: 2,
    prompt: "Quale situazione hai gestito bene oggi, anche se difficile?",
    category: "resilienza",
    isPremium: false
  },
  {
    id: 3,
    prompt: "Che cosa hai imparato su te stesso negli ultimi giorni?",
    category: "auto-consapevolezza",
    isPremium: true
  },
  {
    id: 4,
    prompt: "Qual è una qualità che apprezzi in te stesso?",
    category: "auto-stima",
    isPremium: true
  },
  {
    id: 5,
    prompt: "Come puoi essere più gentile con te stesso domani?",
    category: "auto-compassione",
    isPremium: true
  },
  {
    id: 6,
    prompt: "Quali pensieri ricorrenti occupano la tua mente ultimamente?",
    category: "consapevolezza",
    isPremium: true
  },
  {
    id: 7,
    prompt: "Quale piccolo passo puoi fare domani verso un tuo obiettivo?",
    category: "crescita",
    isPremium: true
  },
  {
    id: 8,
    prompt: "Come hai aiutato qualcuno recentemente? Come ti ha fatto sentire?",
    category: "connessione",
    isPremium: false
  },
  {
    id: 9,
    prompt: "Quale attività ti fa perdere il senso del tempo in modo positivo?",
    category: "flow",
    isPremium: true
  },
  {
    id: 10,
    prompt: "Rifletti su un momento di calma che hai sperimentato oggi.",
    category: "consapevolezza",
    isPremium: true
  }
];

export function getReflectionById(id: number): Reflection | undefined {
  return reflections.find(r => r.id === id);
}

export function getRandomReflection(isPremiumUser: boolean = false): Reflection {
  const availableReflections = isPremiumUser 
    ? reflections 
    : reflections.filter(r => !r.isPremium);
  
  const randomIndex = Math.floor(Math.random() * availableReflections.length);
  return availableReflections[randomIndex];
}

export function getReflectionsByCategory(category: string, isPremiumUser: boolean = false): Reflection[] {
  const filteredByCategory = reflections.filter(r => 
    r.category.toLowerCase() === category.toLowerCase()
  );
  
  return isPremiumUser 
    ? filteredByCategory 
    : filteredByCategory.filter(r => !r.isPremium);
}

export function getAllReflections(isPremiumUser: boolean = false): Reflection[] {
  return isPremiumUser 
    ? reflections 
    : reflections.filter(r => !r.isPremium);
}

export function getFreeReflections(): Reflection[] {
  return reflections.filter(r => !r.isPremium);
}

export function getPremiumReflections(): Reflection[] {
  return reflections.filter(r => r.isPremium);
}
