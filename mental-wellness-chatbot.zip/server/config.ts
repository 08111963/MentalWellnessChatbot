/**
 * Configurazione globale dell'applicazione
 * Contiene flag e impostazioni che controllano il comportamento del sistema
 */

// Modalità di pagamento: 'simulated' per test senza Stripe, 'production' per integrazione reale
// Se esistono le chiavi di Stripe, usa la modalità di produzione
// MODIFICATO: Usa la modalità di production se sono disponibili le chiavi di Stripe, altrimenti usa simulated
export const PAYMENT_MODE = process.env.STRIPE_SECRET_KEY ? 'production' : 'simulated';

// Configurazione domini e URL per distribuzione multi-piattaforma
export const PLATFORM_CONFIG = {
  // Domini autorizzati per gestire pagamenti (utilizzati nei webhook e redirect)
  ALLOWED_DOMAINS: [
    'auralis.replit.app',            // Dominio Replit principale
    'auralis.app',                   // Potenziale dominio personalizzato
    'auralis.it',                    // Potenziale dominio personalizzato italiano
    'auralis.vercel.app',            // Deployment su Vercel
    'auralis.netlify.app',           // Deployment su Netlify
    'localhost'                      // Sviluppo locale
  ],
  
  // URL base per i pagamenti (usato per centralizzare i pagamenti)
  // Se vuoi che tutti i pagamenti vengano gestiti da un solo dominio
  PAYMENT_BASE_URL: process.env.PAYMENT_BASE_URL || '',
  
  // Flag per indicare se usare un dominio centralizzato per i pagamenti
  USE_CENTRALIZED_PAYMENTS: process.env.USE_CENTRALIZED_PAYMENTS === 'true'
};

// Configurazione Stripe
export const STRIPE_CONFIG = {
  // Chiavi API
  SECRET_KEY: process.env.STRIPE_SECRET_KEY || '',
  WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET || '',
  
  // ID dei prezzi dei prodotti
  PRICES: {
    MONTHLY: process.env.STRIPE_PRICE_MONTHLY || 'price_1R6rKkJiRRPU3UNS2AMCdA2o',
    YEARLY: process.env.STRIPE_PRICE_YEARLY || 'price_1R6rO0JiRRPU3UNSdtrPP6K8'
  },
  
  // URL per il checkout (usati in modalità simulata)
  DIRECT_CHECKOUT_URLS: {
    MONTHLY: '/api/stripe/checkout/monthly-plan',
    YEARLY: '/api/stripe/checkout/yearly-plan'
  },
  
  // URL per success e cancel - ora configurati per supportare più domini
  REDIRECT_URLS: {
    SUCCESS: '/payment-success',
    CANCEL: '/subscription'
  }
};

// Configurazione simulazione pagamenti
export const SIMULATION_CONFIG = {
  // Durata simulata degli abbonamenti in giorni
  SUBSCRIPTION_DURATION: {
    MONTHLY: 30,
    YEARLY: 365
  },
  
  // Prezzi simulati
  PRICES: {
    MONTHLY: 4.99,
    YEARLY: 39.99
  },
  
  // Ritardo simulato per le operazioni di pagamento (ms)
  PROCESSING_DELAY: 1500
};