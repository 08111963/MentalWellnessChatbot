import { Request, Response } from 'express';
import { 
  getAllResources, 
  getResourceById, 
  getResourcesByCategory, 
  getResourcesByTags,
  getPersonalizedResources
} from '../resources-data-translated';
import { analyzeUserMessage } from '../openai';

/**
 * Controller per le raccomandazioni delle risorse
 */

// Ottieni tutte le risorse
export async function getAllResourcesHandler(req: Request, res: Response) {
  try {
    const language = req.query.language as string || 'it';
    console.log(`Getting resources with language: ${language}`);
    const resources = getAllResources(language);
    res.json(resources);
  } catch (error) {
    console.error('Errore nel recupero delle risorse:', error);
    res.status(500).json({ error: 'Errore nel recupero delle risorse' });
  }
}

// Ottieni una risorsa singola per ID
export async function getResourceByIdHandler(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID risorsa non valido' });
    }
    
    const language = req.query.language as string || 'it';
    const resource = getResourceById(id, language);
    if (!resource) {
      return res.status(404).json({ error: 'Risorsa non trovata' });
    }
    
    res.json(resource);
  } catch (error) {
    console.error('Errore nel recupero della risorsa:', error);
    res.status(500).json({ error: 'Errore nel recupero della risorsa' });
  }
}

// Ottieni risorse per categoria
export async function getResourcesByCategoryHandler(req: Request, res: Response) {
  try {
    const { category } = req.params;
    
    // Verifica se la categoria è specificata
    if (!category) {
      return res.status(400).json({ error: 'Categoria non specificata' });
    }
    
    const language = req.query.language as string || 'it';
    console.log(`API: Cercando risorse per categoria: ${category}, lingua: ${language}`);
    const resources = getResourcesByCategory(category, language);
    console.log(`API: Trovate ${resources.length} risorse`);
    res.json(resources);
  } catch (error) {
    console.error('Errore nel recupero delle risorse per categoria:', error);
    res.status(500).json({ error: 'Errore nel recupero delle risorse per categoria' });
  }
}

// Ottieni tutte le categorie disponibili
export async function getAllCategoriesHandler(req: Request, res: Response) {
  try {
    const language = req.query.language as string || 'it';
    // Estrai tutte le categorie uniche dalle risorse
    const allResources = getAllResources(language);
    // Ottieni tutte le categorie uniche
    const uniqueCategories = new Set<string>();
    allResources.forEach(resource => {
      uniqueCategories.add(resource.category);
    });
    // Converti il Set in array
    const categories = Array.from(uniqueCategories);
    res.json(categories);
  } catch (error) {
    console.error('Errore nel recupero delle categorie:', error);
    res.status(500).json({ error: 'Errore nel recupero delle categorie' });
  }
}

// Ottieni risorse consigliate per tags
export async function getResourcesByTagsHandler(req: Request, res: Response) {
  try {
    const { tags } = req.body;
    if (!tags || !Array.isArray(tags) || tags.length === 0) {
      return res.status(400).json({ error: 'Tags non specificati correttamente' });
    }
    
    const language = req.query.language as string || 'it';
    const resources = getResourcesByTags(tags, language);
    res.json(resources);
  } catch (error) {
    console.error('Errore nel recupero delle risorse per tags:', error);
    res.status(500).json({ error: 'Errore nel recupero delle risorse per tags' });
  }
}

// Ottieni risorse personalizzate in base a vari parametri
export async function getPersonalizedResourcesHandler(req: Request, res: Response) {
  try {
    const { userId, categories, tags, excludeTypes, onlyPremium, limit } = req.body;
    const language = req.query.language as string || 'it';
    
    const resources = getPersonalizedResources({
      userId,
      categories,
      tags,
      excludeTypes,
      onlyPremium,
      limit,
      language
    });
    
    res.json(resources);
  } catch (error) {
    console.error('Errore nel recupero delle risorse personalizzate:', error);
    res.status(500).json({ error: 'Errore nel recupero delle risorse personalizzate' });
  }
}

// Ottieni risorse consigliate in base al messaggio dell'utente
export async function getRecommendationsByMessageHandler(req: Request, res: Response) {
  try {
    const { message } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Messaggio non specificato' });
    }
    
    const language = req.query.language as string || 'it';
    console.log(`API: Raccomandazioni per messaggio, lingua: ${language}`);
    
    // Analizza il messaggio dell'utente per capire il suo stato emotivo e le sue esigenze
    const analysis = await analyzeUserMessage(message);
    
    // Usa i risultati dell'analisi per trovare risorse rilevanti
    const tags: string[] = [];
    
    // Aggiungi tag in base all'intento
    if (analysis.intent) {
      switch (analysis.intent.toLowerCase()) {
        case 'anxiety':
        case 'ansia':
          tags.push('ansia', 'respirazione', 'panico');
          break;
        case 'depression':
        case 'depressione':
          tags.push('depressione', 'umore', 'positività');
          break;
        case 'stress':
          tags.push('stress', 'rilassamento', 'mindfulness');
          break;
        case 'sleep':
        case 'sonno':
          tags.push('sonno', 'rilassamento', 'meditazione');
          break;
        case 'relationships':
        case 'relazioni':
          tags.push('relazioni', 'comunicazione', 'sociale');
          break;
      }
    }
    
    // Aggiungi tag in base allo stato emotivo
    if (analysis.emotionalState && typeof analysis.emotionalState === 'string') {
      switch (analysis.emotionalState.toLowerCase()) {
        case 'anxious':
        case 'ansioso':
          tags.push('ansia', 'panico', 'stress');
          break;
        case 'sad':
        case 'triste':
          tags.push('depressione', 'tristezza', 'umore');
          break;
        case 'angry':
        case 'arrabbiato':
          tags.push('rabbia', 'emozioni', 'regolazione');
          break;
        case 'worried':
        case 'preoccupato':
          tags.push('preoccupazione', 'ansia', 'pensieri');
          break;
        case 'hopeless':
        case 'disperato':
          tags.push('speranza', 'depressione', 'supporto');
          break;
      }
    }
    
    // Rimuovi eventuali duplicati dai tag
    const uniqueTags = Array.from(new Set(tags));
    
    // Ottieni risorse pertinenti in base ai tag identificati
    const resources = getResourcesByTags(uniqueTags, language);
    
    // Limita a 5 risorse
    const limitedResources = resources.slice(0, 5);
    
    res.json({
      analysis,
      resources: limitedResources
    });
  } catch (error) {
    console.error('Errore nell\'analisi del messaggio e nella raccomandazione di risorse:', error);
    res.status(500).json({ error: 'Errore nel sistema di raccomandazione' });
  }
}