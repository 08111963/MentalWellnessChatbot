import { type MoodEntry, type InsertMoodEntry } from '@shared/schema';

// In-memory mood entries
const moodEntries: MoodEntry[] = [];
let currentId = 1;

export function getMoodEntriesByUserId(userId: number): MoodEntry[] {
  return moodEntries.filter(entry => entry.userId === userId);
}

export function getMoodEntryById(id: number): MoodEntry | undefined {
  return moodEntries.find(entry => entry.id === id);
}

export function createMoodEntry(entry: InsertMoodEntry): MoodEntry {
  const newEntry: MoodEntry = {
    ...entry,
    id: currentId++
  };
  moodEntries.push(newEntry);
  return newEntry;
}

export function updateMoodEntry(id: number, entry: Partial<InsertMoodEntry>): MoodEntry | null {
  const index = moodEntries.findIndex(e => e.id === id);
  if (index === -1) return null;
  
  moodEntries[index] = {
    ...moodEntries[index],
    ...entry
  };
  
  return moodEntries[index];
}

export function deleteMoodEntry(id: number): boolean {
  const index = moodEntries.findIndex(e => e.id === id);
  if (index === -1) return false;
  
  moodEntries.splice(index, 1);
  return true;
}

export function getMoodStatsByUserId(userId: number, dateFrom?: Date, dateTo?: Date): any {
  let entries = moodEntries.filter(entry => entry.userId === userId);
  
  // Filtra per intervallo di date se specificato
  if (dateFrom) {
    entries = entries.filter(entry => new Date(entry.date) >= dateFrom);
  }
  if (dateTo) {
    entries = entries.filter(entry => new Date(entry.date) <= dateTo);
  }
  
  // Ordina per data
  entries.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  if (entries.length === 0) {
    return {
      average: 0,
      highest: 0,
      lowest: 0,
      entries: [],
      topEmotions: [],
      topActivities: []
    };
  }
  
  // Calcola statistiche
  const scores = entries.map(e => e.score);
  const average = scores.reduce((sum, curr) => sum + curr, 0) / scores.length;
  const highest = Math.max(...scores);
  const lowest = Math.min(...scores);
  
  // Analisi delle emozioni
  const emotionCounts: Record<string, number> = {};
  entries.forEach(entry => {
    if (entry.emotions) {
      entry.emotions.forEach(emotion => {
        emotionCounts[emotion] = (emotionCounts[emotion] || 0) + 1;
      });
    }
  });
  
  // Ordina le emozioni per frequenza
  const topEmotions = Object.entries(emotionCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([emotion, count]) => ({ emotion, count }));
  
  // Analisi delle attività
  const activityCounts: Record<string, number> = {};
  entries.forEach(entry => {
    if (entry.activities) {
      entry.activities.forEach(activity => {
        activityCounts[activity] = (activityCounts[activity] || 0) + 1;
      });
    }
  });
  
  // Ordina le attività per frequenza
  const topActivities = Object.entries(activityCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([activity, count]) => ({ activity, count }));
  
  return {
    average,
    highest,
    lowest,
    entries: entries.map(e => ({
      id: e.id,
      date: e.date,
      score: e.score
    })),
    topEmotions,
    topActivities
  };
}

// Dati predefiniti per il test
export function seedMoodData(userId: number = 1) {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - 30); // Inizia da 30 giorni fa
  
  const emotions = [
    'felicità', 'tristezza', 'ansia', 'calma', 'stress', 
    'gratitudine', 'frustrazione', 'speranza', 'paura', 'gioia'
  ];
  
  const activities = [
    'esercizio fisico', 'meditazione', 'lavoro', 'socializzazione', 
    'hobby', 'riposo', 'studio', 'natura', 'lettura', 'cucina'
  ];
  
  for (let i = 0; i < 30; i++) {
    const date = new Date(startDate);
    date.setDate(date.getDate() + i);
    
    // Genera un punteggio random tra 1 e 5
    const score = Math.floor(Math.random() * 5) + 1;
    
    // Seleziona 1-3 emozioni random
    const entryEmotions = [];
    const numEmotions = Math.floor(Math.random() * 3) + 1;
    for (let j = 0; j < numEmotions; j++) {
      const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
      if (!entryEmotions.includes(randomEmotion)) {
        entryEmotions.push(randomEmotion);
      }
    }
    
    // Seleziona 1-2 attività random
    const entryActivities = [];
    const numActivities = Math.floor(Math.random() * 2) + 1;
    for (let j = 0; j < numActivities; j++) {
      const randomActivity = activities[Math.floor(Math.random() * activities.length)];
      if (!entryActivities.includes(randomActivity)) {
        entryActivities.push(randomActivity);
      }
    }
    
    // Crea l'entry
    createMoodEntry({
      userId,
      date,
      score,
      emotions: entryEmotions,
      activities: entryActivities,
      notes: score > 3 ? 'Giornata positiva' : 'Giornata difficile',
      triggerEvents: score < 3 ? 'Stress al lavoro' : null,
      sleepQuality: Math.floor(Math.random() * 5) + 1,
      energyLevel: Math.floor(Math.random() * 5) + 1
    });
  }
}