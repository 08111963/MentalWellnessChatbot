import { Resource } from '../shared/schema';

// Interface for resources with translations
interface ResourceWithTranslations extends Omit<Resource, 'title' | 'description' | 'content'> {
  translations: {
    [lang: string]: {
      title: string;
      description: string;
      content?: string;
    }
  }
}

// Creates default content HTML based on language
const createContentHTML = (resource: any, language: string = 'it'): string => {
  const isItalian = language === 'it';
  
  // Get translated values
  const title = resource.translations?.[language]?.title || resource.translations?.['it']?.title || '';
  const description = resource.translations?.[language]?.description || resource.translations?.['it']?.description || '';
  
  if (isItalian) {
    return `
      <h2>${title}</h2>
      <p class="lead">${description}</p>
      
      <h3>Panoramica</h3>
      <p>Questa risorsa su ${title.toLowerCase()} è pensata per aiutarti nel tuo percorso di benessere mentale.</p>
      
      <h3>Perché è importante</h3>
      <p>${description}</p>
      
      <h3>Punti chiave</h3>
      <ul>
        <li>Comprendi i tuoi pensieri e le tue emozioni</li>
        <li>Sviluppa strategie efficaci per affrontare situazioni difficili</li>
        <li>Pratica regolarmente per migliorare la tua resilienza</li>
        <li>Riconosci i progressi che fai nel tempo</li>
      </ul>
      
      <h3>Consigli pratici</h3>
      <p>La costanza è fondamentale. Dedica almeno 10 minuti al giorno a questa pratica per vedere risultati significativi nel tempo.</p>
      
      <h3>Nota importante</h3>
      <p>Ricorda che questa risorsa è pensata come supporto complementare e non sostituisce il consulto con professionisti della salute mentale.</p>
    `;
  } else {
    return `
      <h2>${title}</h2>
      <p class="lead">${description}</p>
      
      <h3>Overview</h3>
      <p>This resource on ${title.toLowerCase()} is designed to help you in your mental wellness journey.</p>
      
      <h3>Why it's important</h3>
      <p>${description}</p>
      
      <h3>Key points</h3>
      <ul>
        <li>Understand your thoughts and emotions</li>
        <li>Develop effective strategies to handle difficult situations</li>
        <li>Practice regularly to improve your resilience</li>
        <li>Recognize the progress you make over time</li>
      </ul>
      
      <h3>Practical tips</h3>
      <p>Consistency is key. Dedicate at least 10 minutes daily to this practice to see significant results over time.</p>
      
      <h3>Important note</h3>
      <p>Remember that this resource is intended as complementary support and does not replace consultation with mental health professionals.</p>
    `;
  }
}

// Transforms multilingual resources to single-language resources
function getTranslatedResource(resource: ResourceWithTranslations, language: string = 'it'): Resource {
  // Default to Italian if the requested language is not available
  const fallbackLang = 'it';
  const lang = resource.translations[language] ? language : fallbackLang;
  
  return {
    id: resource.id,
    title: resource.translations[lang].title,
    description: resource.translations[lang].description,
    type: resource.type,
    tags: resource.tags,
    url: resource.url,
    imageUrl: resource.imageUrl,
    isPremium: resource.isPremium,
    category: resource.category,
    estimatedTime: resource.estimatedTime,
    relevanceScore: resource.relevanceScore,
    content: resource.translations[lang].content || createContentHTML(resource, lang)
  };
}

// Dati delle risorse con traduzioni
const resourcesData: ResourceWithTranslations[] = [
  {
    id: 1,
    type: "exercise",
    tags: ["ansia", "respirazione", "rapido", "stress"],
    url: "/exercises/3", // ID di un esercizio correlato
    imageUrl: "/images/resources/breathing.svg",
    isPremium: true,
    category: "ansia",
    estimatedTime: "5 min",
    relevanceScore: 8,
    translations: {
      it: {
        title: "Tecniche di respirazione per l'ansia",
        description: "Impara 5 tecniche di respirazione efficaci per gestire gli attacchi d'ansia e ridurre lo stress quotidiano."
      },
      en: {
        title: "Breathing techniques for anxiety",
        description: "Learn 5 effective breathing techniques to manage anxiety attacks and reduce daily stress."
      }
    }
  },
  {
    id: 2,
    type: "article",
    tags: ["depressione", "informativo", "CBT", "terapia"],
    url: "https://www.fondazioneveronesi.it/magazine/articoli/neuroscienze/depressione-curare-presto-e-bene",
    imageUrl: "/images/resources/depression.svg",
    isPremium: true,
    category: "depressione",
    estimatedTime: "12 min",
    relevanceScore: 7,
    translations: {
      it: {
        title: "Comprensione e gestione della depressione",
        description: "Un articolo completo che spiega le cause della depressione e strategie efficaci per affrontarla."
      },
      en: {
        title: "Understanding and managing depression",
        description: "A comprehensive article explaining the causes of depression and effective strategies to deal with it."
      }
    }
  },
  {
    id: 3,
    type: "meditation",
    tags: ["sonno", "rilassamento", "meditazione", "audio"],
    url: "/meditation/5", // ID di una meditazione correlata
    imageUrl: "/images/resources/sleep.svg",
    isPremium: true,
    category: "sonno",
    estimatedTime: "15 min",
    relevanceScore: 9,
    translations: {
      it: {
        title: "Meditazione guidata per il sonno",
        description: "Una meditazione rilassante progettata per aiutarti ad addormentarti più facilmente."
      },
      en: {
        title: "Guided sleep meditation",
        description: "A relaxing meditation designed to help you fall asleep more easily."
      }
    }
  },
  {
    id: 4,
    type: "exercise",
    tags: ["pensieri", "CBT", "negatività", "pratico"],
    url: "/exercises/7", // ID di un esercizio correlato
    imageUrl: "/images/resources/thoughts.svg",
    isPremium: true,
    category: "depressione",
    estimatedTime: "10 min",
    relevanceScore: 8,
    translations: {
      it: {
        title: "Riconoscere e gestire i pensieri negativi",
        description: "Esercizio pratico basato sulla CBT per identificare e trasformare i pensieri negativi."
      },
      en: {
        title: "Recognize and manage negative thoughts",
        description: "Practical CBT-based exercise to identify and transform negative thoughts."
      }
    }
  },
  {
    id: 5,
    type: "article",
    tags: ["mindfulness", "app", "tecnologia", "pratica quotidiana"],
    url: "https://www.stateofmind.it/2016/03/app-mindfulness-psicologia/",
    imageUrl: "/images/resources/mindfulness_apps.svg",
    isPremium: true,
    category: "mindfulness",
    estimatedTime: "8 min",
    relevanceScore: 6,
    translations: {
      it: {
        title: "Le migliori app per la mindfulness",
        description: "Una selezione delle 5 migliori app gratuite per praticare la mindfulness quotidianamente."
      },
      en: {
        title: "The best mindfulness apps",
        description: "A selection of the 5 best free apps to practice mindfulness daily."
      }
    }
  },
  {
    id: 6,
    type: "exercise",
    tags: ["panico", "emergenza", "rapido", "tecniche"],
    url: "/exercises/11", // ID di un esercizio correlato
    imageUrl: "/images/resources/panic.svg",
    isPremium: false,
    category: "ansia",
    estimatedTime: "3 min",
    relevanceScore: 10,
    translations: {
      it: {
        title: "Gestire il panico: strategie immediate",
        description: "Metodi rapidi ed efficaci per gestire gli attacchi di panico quando si presentano."
      },
      en: {
        title: "Managing panic: immediate strategies",
        description: "Quick and effective methods to manage panic attacks when they occur."
      }
    }
  }
];

// Ottieni tutte le risorse, tradotte nella lingua specificata
export function getAllResources(language: string = 'it'): Resource[] {
  return resourcesData.map(resource => getTranslatedResource(resource, language));
}

// Ottieni risorse per categoria, tradotte nella lingua specificata
export function getResourcesByCategory(category: string, language: string = 'it'): Resource[] {
  if (!category) {
    return getAllResources(language);
  }
  
  const lowerCategory = category.toLowerCase();
  const allResources = getAllResources(language);
  return allResources.filter(resource => 
    resource.category.toLowerCase() === lowerCategory
  );
}

// Ottieni risorse per tipo, tradotte nella lingua specificata
export function getResourcesByType(type: string, language: string = 'it'): Resource[] {
  const allResources = getAllResources(language);
  return allResources.filter(resource => resource.type === type);
}

// Ottieni risorse premium, tradotte nella lingua specificata
export function getPremiumResources(language: string = 'it'): Resource[] {
  const allResources = getAllResources(language);
  return allResources.filter(resource => resource.isPremium);
}

// Ottieni risorse gratuite, tradotte nella lingua specificata
export function getFreeResources(language: string = 'it'): Resource[] {
  const allResources = getAllResources(language);
  return allResources.filter(resource => !resource.isPremium);
}

// Ottieni una risorsa per ID, tradotta nella lingua specificata
export function getResourceById(id: number, language: string = 'it'): Resource | undefined {
  const allResources = getAllResources(language);
  return allResources.find(resource => resource.id === id);
}

// Ottieni risorse per tag, tradotte nella lingua specificata
export function getResourcesByTags(tags: string[], language: string = 'it'): Resource[] {
  if (!tags || tags.length === 0) {
    return [];
  }
  
  const allResources = getAllResources(language);
  return allResources.filter(resource => 
    resource.tags?.some(tag => tags.includes(tag))
  );
}

// Ottieni risorse personalizzate, tradotte nella lingua specificata
export function getPersonalizedResources(params: {
  userId?: number; 
  categories?: string[]; 
  tags?: string[]; 
  excludeTypes?: string[];
  onlyPremium?: boolean;
  limit?: number;
  language?: string;
}): Resource[] {
  
  const language = params.language || 'it';
  let filteredResources = [...getAllResources(language)];
  
  // Filtra per categoria se specificata
  if (params.categories && params.categories.length > 0) {
    filteredResources = filteredResources.filter(resource => 
      params.categories?.includes(resource.category)
    );
  }
  
  // Filtra per tag se specificati
  if (params.tags && params.tags.length > 0) {
    filteredResources = filteredResources.filter(resource => 
      resource.tags?.some(tag => params.tags?.includes(tag))
    );
  }
  
  // Escludi tipi specifici se richiesto
  if (params.excludeTypes && params.excludeTypes.length > 0) {
    filteredResources = filteredResources.filter(resource => 
      !params.excludeTypes?.includes(resource.type)
    );
  }
  
  // Filtra solo risorse premium se richiesto
  if (params.onlyPremium) {
    filteredResources = filteredResources.filter(resource => resource.isPremium);
  }
  
  // Ordina per rilevanza (score più alto per primo)
  filteredResources.sort((a, b) => {
    return (b.relevanceScore || 0) - (a.relevanceScore || 0);
  });
  
  // Limita il numero di risultati se specificato
  if (params.limit && params.limit > 0) {
    filteredResources = filteredResources.slice(0, params.limit);
  }
  
  return filteredResources;
}