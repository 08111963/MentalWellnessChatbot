import { type Meditation } from '@shared/schema';

// Define an interface that extends Meditation with translations
interface MeditationWithTranslations extends Meditation {
  translations?: {
    [lang: string]: {
      title: string;
      description: string;
      content: string;
    }
  }
}

// In-memory meditation data
export const meditations: MeditationWithTranslations[] = [
  {
    id: 1,
    title: "Respirazione Consapevole",
    duration: 5,
    description: "Un breve esercizio di respirazione per calmare la mente e ridurre lo stress immediato.",
    content: `Trova una posizione comoda, seduta o sdraiata.

Chiudi gli occhi e porta l'attenzione al tuo respiro.

Inspira lentamente contando fino a 4, senti l'aria che riempie i polmoni.

Trattieni il respiro per un momento.

Espira lentamente contando fino a 6, lasciando andare ogni tensione.

Ripeti questo ciclo per 5 minuti, mantenendo l'attenzione sul flusso del respiro.

Se la mente vaga, gentilmente riportala al respiro senza giudizio.`,
    isPremium: false,
    translations: {
      en: {
        title: "Mindful Breathing",
        description: "A short breathing exercise to calm the mind and reduce immediate stress.",
        content: `Find a comfortable position, sitting or lying down.

Close your eyes and bring your attention to your breath.

Inhale slowly counting to 4, feel the air filling your lungs.

Hold your breath for a moment.

Exhale slowly counting to 6, letting go of any tension.

Repeat this cycle for 5 minutes, keeping your attention on the flow of your breath.

If your mind wanders, gently bring it back to your breath without judgment.`
      }
    }
  },
  {
    id: 2,
    title: "Body Scan Rilassante",
    duration: 10,
    description: "Esplorazione guidata delle sensazioni corporee per rilassamento profondo e maggiore consapevolezza.",
    content: `Sdraiati in una posizione comoda, con le braccia lungo i fianchi e le gambe leggermente divaricate.

Chiudi gli occhi e porta l'attenzione al respiro per qualche istante, stabilizzando la mente.

Porta ora l'attenzione ai piedi. Nota qualsiasi sensazione: calore, freddo, formicolio o forse nessuna sensazione particolare.

Lentamente sposta l'attenzione su per le gambe, notando le sensazioni in ciascuna parte: polpacci, ginocchia, cosce.

Prosegui verso il bacino, la pancia e il torace, osservando il movimento del respiro in queste aree.

Continua con la schiena, le spalle e le braccia fino alle dita delle mani.

Infine, porta l'attenzione al collo, al viso e alla testa.

Per concludere, prendi consapevolezza dell'intero corpo come un'unità integrata, restando in questo stato di consapevolezza per qualche minuto.`,
    isPremium: false,
    translations: {
      en: {
        title: "Relaxing Body Scan",
        description: "Guided exploration of bodily sensations for deep relaxation and increased awareness.",
        content: `Lie down in a comfortable position, with your arms at your sides and legs slightly apart.

Close your eyes and bring your attention to your breath for a few moments, stabilizing your mind.

Now bring your attention to your feet. Notice any sensation: warmth, cold, tingling, or perhaps no particular sensation.

Slowly move your attention up through your legs, noticing the sensations in each part: calves, knees, thighs.

Continue toward your pelvis, belly, and chest, observing the movement of breath in these areas.

Continue with your back, shoulders, and arms down to your fingertips.

Finally, bring your attention to your neck, face, and head.

To conclude, become aware of your entire body as an integrated unit, remaining in this state of awareness for a few minutes.`
      }
    }
  },
  {
    id: 3,
    title: "Meditazione della Montagna",
    duration: 15,
    description: "Sviluppa stabilità interiore e resilienza attraverso la visualizzazione della montagna.",
    content: `Siediti in una posizione comoda con la schiena dritta ma non rigida. Chiudi gli occhi.

Inizia respirando profondamente alcune volte, rilasciando ogni tensione con l'espirazione.

Visualizza ora una maestosa montagna davanti a te. Osserva la sua forma, la base solida, la vetta che si innalza verso il cielo.

Immagina di diventare questa montagna. La tua testa è la vetta, il tuo corpo il corpo della montagna, le gambe e i glutei sono la base solida che si radica nella terra.

Come la montagna, tu rimani stabile attraverso i cambiamenti: il sole, la pioggia, il vento, la neve.

Le stagioni cambiano intorno a te, ma tu, come la montagna, mantieni la tua essenza e stabilità.

Anche quando nuvole o nebbia circondano la vetta, sopra di esse c'è sempre il cielo sereno. Così anche quando pensieri ed emozioni difficili ti circondano, la consapevolezza rimane chiara e serena.

Porta con te questa forza e stabilità della montagna mentre concludi la meditazione, sapendo di poter tornare a questa immagine ogni volta che hai bisogno di trovare equilibrio e resilienza.`,
    isPremium: true,
    translations: {
      en: {
        title: "Mountain Meditation",
        description: "Develop inner stability and resilience through mountain visualization.",
        content: `Sit in a comfortable position with your back straight but not rigid. Close your eyes.

Begin by breathing deeply a few times, releasing any tension with the exhalation.

Now visualize a majestic mountain in front of you. Observe its shape, the solid base, the peak rising toward the sky.

Imagine becoming this mountain. Your head is the peak, your body is the mountain body, your legs and buttocks are the solid base rooted in the earth.

Like the mountain, you remain stable through changes: the sun, rain, wind, snow.

The seasons change around you, but you, like the mountain, maintain your essence and stability.

Even when clouds or fog surround the peak, above them there is always a clear sky. Similarly, when difficult thoughts and emotions surround you, awareness remains clear and serene.

Take this strength and stability of the mountain with you as you conclude the meditation, knowing you can return to this image whenever you need to find balance and resilience.`
      }
    }
  },
  {
    id: 4,
    title: "Meditazione di Autocompassione",
    duration: 20,
    description: "Coltiva gentilezza verso te stesso per affrontare l'autocritica e la sofferenza emotiva.",
    content: `Trova una posizione comoda, seduta o sdraiata, e chiudi gli occhi. Permetti al corpo di rilassarsi.

Porta l'attenzione al respiro, seguendone il naturale ritmo per alcuni minuti.

Ora, pensa ad una situazione nella tua vita che ti sta causando un livello moderato di stress o difficoltà.

Riconosci che questo è un momento di sofferenza. Silenziosamente, ripeti a te stesso: "Questo è un momento difficile" o "Sto soffrendo ora".

Ricorda a te stesso che la sofferenza è parte dell'esperienza umana condivisa. Tutti soffrono a volte. Puoi dirlo a te stesso: "La sofferenza fa parte della vita" o "Non sono solo in questa esperienza".

Ora, metti delicatamente le mani sul cuore o dove senti più confortevole. Senti il calore e il tocco gentile delle tue mani.

Offriti parole di gentilezza, come diresti ad un caro amico in difficoltà. Per esempio: "Possa io essere gentile con me stesso" o "Possa io darmi la compassione di cui ho bisogno" o "Possa io imparare ad accettarmi esattamente come sono".

Resta così per alcuni minuti, sentendo il calore della gentilezza fluire in te.

Prima di concludere, nota come ti senti ora rispetto a prima della pratica. Concludi con qualche respiro profondo.`,
    isPremium: true,
    translations: {
      en: {
        title: "Self-Compassion Meditation",
        description: "Cultivate kindness toward yourself to address self-criticism and emotional suffering.",
        content: `Find a comfortable position, sitting or lying down, and close your eyes. Allow your body to relax.

Bring your attention to your breath, following its natural rhythm for a few minutes.

Now, think of a situation in your life that is causing you a moderate level of stress or difficulty.

Acknowledge that this is a moment of suffering. Silently, repeat to yourself: "This is a difficult moment" or "I am suffering now."

Remind yourself that suffering is part of the shared human experience. Everyone suffers sometimes. You can say to yourself: "Suffering is part of life" or "I am not alone in this experience."

Now, gently place your hands on your heart or wherever feels most comfortable. Feel the warmth and gentle touch of your hands.

Offer yourself words of kindness, as you would say to a dear friend in difficulty. For example: "May I be kind to myself" or "May I give myself the compassion I need" or "May I learn to accept myself exactly as I am."

Stay like this for a few minutes, feeling the warmth of kindness flowing into you.

Before concluding, notice how you feel now compared to before the practice. Conclude with a few deep breaths.`
      }
    }
  },
  {
    id: 5,
    title: "Meditazione del Lago",
    duration: 12,
    description: "Sviluppa chiarezza mentale e calma attraverso la visualizzazione di un lago sereno.",
    content: `Trova una posizione comoda e chiudi gli occhi. Prendi qualche respiro profondo.

Immagina di essere seduto accanto a un lago tranquillo, circondato da montagne. L'acqua è calma e cristallina, riflettendo perfettamente il cielo e il paesaggio circostante.

Osserva come il lago rispecchia tutto ciò che lo circonda quando è completamente calmo, proprio come la tua mente quando è tranquilla può riflettere chiaramente i pensieri e le emozioni.

Quando il vento soffia sull'acqua, la superficie si increspa e le immagini riflesse diventano distorte, come quando la tua mente è agitata da pensieri ed emozioni.

Ma sotto la superficie, il lago rimane sempre calmo e immutato, anche quando la superficie è agitata. Allo stesso modo, al di sotto del flusso dei pensieri, c'è una consapevolezza sempre calma.

Siediti con questa immagine, osservando la superficie del lago che gradualmente si calma di nuovo dopo ogni increspatura. Senti come la tua mente segue lo stesso processo, tornando naturalmente alla calma.

Ricorda che, proprio come il lago ha una profondità calma che resta invariata dalle condizioni sulla superficie, anche tu hai una calma interiore che è sempre accessibile, indipendentemente dalle turbolenze momentanee della vita.`,
    isPremium: false,
    translations: {
      en: {
        title: "Lake Meditation",
        description: "Develop mental clarity and calmness through serene lake visualization.",
        content: `Find a comfortable position and close your eyes. Take a few deep breaths.

Imagine sitting beside a calm lake, surrounded by mountains. The water is still and crystal clear, perfectly reflecting the sky and surrounding landscape.

Notice how the lake mirrors everything around it when it's completely calm, just like your mind when it's peaceful can clearly reflect thoughts and emotions.

When wind blows across the water, the surface ripples and the reflected images become distorted, like when your mind is agitated by thoughts and emotions.

But beneath the surface, the lake always remains calm and unchanged, even when the surface is disturbed. Similarly, beneath the flow of thoughts, there is an awareness that is always calm.

Sit with this image, watching the lake's surface gradually become calm again after each ripple. Feel how your mind follows the same process, naturally returning to stillness.

Remember that, just as the lake has a calm depth that remains unaffected by conditions on the surface, you too have an inner calmness that is always accessible, regardless of momentary turbulence in life.`
      }
    }
  },
  {
    id: 6,
    title: "Radici del Presente",
    duration: 8,
    description: "Una pratica di radicamento per riconnettersi con il momento presente attraverso i sensi.",
    content: `Trova una posizione seduta comoda, con i piedi ben appoggiati a terra. Senti il contatto dei piedi con il pavimento.

Ora chiudi gli occhi e porta l'attenzione al respiro. Fai tre respiri profondi, sentendo come l'aria entra ed esce dal corpo.

Diventa consapevole di 5 cose che puoi VEDERE intorno a te (apri brevemente gli occhi se necessario, poi richiudili).

Ora nota 4 cose che puoi SENTIRE al tatto: il contatto con la sedia, i vestiti sulla pelle, l'aria sul viso...

Concentrati su 3 suoni che puoi UDIRE in questo momento, sia vicini che lontani.

Ora nota 2 odori che puoi ANNUSARE nel tuo ambiente.

Infine, porta l'attenzione a 1 SAPORE presente nella tua bocca.

Con ogni percezione sensoriale, ti sei ancorato più profondamente al momento presente. Senti come il tuo corpo è completamente qui, in questo spazio e tempo.

Immagina di avere delle radici invisibili che partono dai tuoi piedi e si estendono nel terreno sotto di te, ancorandoti saldamente al presente.

Resta così per qualche momento, sentendoti stabile, presente e radicato.`,
    isPremium: false,
    translations: {
      en: {
        title: "Roots of the Present",
        description: "A grounding practice to reconnect with the present moment through the senses.",
        content: `Find a comfortable seated position, with your feet firmly on the ground. Feel the contact of your feet with the floor.

Now close your eyes and bring attention to your breath. Take three deep breaths, feeling the air entering and leaving your body.

Become aware of 5 things you can SEE around you (briefly open your eyes if necessary, then close them again).

Now notice 4 things you can FEEL through touch: the contact with the chair, clothes on your skin, air on your face...

Focus on 3 sounds you can HEAR at this moment, both near and far.

Now notice 2 smells you can SMELL in your environment.

Finally, bring attention to 1 TASTE present in your mouth.

With each sensory perception, you have anchored yourself more deeply in the present moment. Feel how your body is completely here, in this space and time.

Imagine having invisible roots extending from your feet into the ground beneath you, firmly anchoring you to the present.

Stay like this for a few moments, feeling stable, present, and grounded.`
      }
    }
  },
  {
    id: 7,
    title: "Giardino del Cuore",
    duration: 18,
    description: "Coltiva emozioni positive attraverso questa meditazione di visualizzazione guidata.",
    content: `Siediti comodamente e chiudi gli occhi. Prendi qualche respiro profondo per stabilizzare la mente.

Immagina di entrare in un giardino bellissimo - il giardino del tuo cuore. È un luogo sicuro, personale e completamente tuo.

Guarda intorno a te. Cosa vedi? Ci sono fiori colorati, alberi, forse un piccolo ruscello? Osserva i colori, le forme, la luce.

Senti i profumi del giardino - l'erba fresca, i fiori, forse il sentore della terra umida o della frutta matura.

Ascolta i suoni - il canto degli uccelli, il fruscio delle foglie, il suono dell'acqua che scorre.

Mentre cammini nel giardino, arrivi al suo centro dove trovi una panchina o un posto dove sederti. Siediti e senti che questo è un luogo dove puoi nutrire il tuo cuore.

Ora, pensa a una qualità che vorresti coltivare: amore, pace, gioia, gratitudine, coraggio o qualsiasi altra qualità.

Immagina che questa qualità sia come un seme. Tienilo nel palmo della mano e osservalo.

Ora, pianta questo seme nel terreno del tuo giardino. Mentre lo fai, senti l'intenzione di coltivare questa qualità nella tua vita.

Osserva come, magicamente in questo giardino speciale, il seme germoglia rapidamente e inizia a crescere, diventando una pianta splendida e forte che rappresenta questa qualità.

Prendi un momento per sentirti connesso con questa qualità, sapendo che è già dentro di te, aspettando solo di essere nutrita e coltivata.

Prima di lasciare il giardino, sappi che puoi tornarci in qualsiasi momento per trovare pace e per continuare a coltivare le qualità che desideri nella tua vita.

Lentamente, torna consapevole del tuo respiro e del tuo corpo. Quando sei pronto, apri gli occhi e porta con te la sensazione di pace e la qualità che hai coltivato.`,
    isPremium: true,
    translations: {
      en: {
        title: "Heart Garden",
        description: "Cultivate positive emotions through this guided visualization meditation.",
        content: `Sit comfortably and close your eyes. Take a few deep breaths to steady your mind.

Imagine entering a beautiful garden—the garden of your heart. It's a safe, personal place that is completely yours.

Look around you. What do you see? Are there colorful flowers, trees, perhaps a small stream? Notice the colors, shapes, and light.

Smell the fragrances of the garden—fresh grass, flowers, perhaps the scent of moist earth or ripe fruit.

Listen to the sounds—birdsong, rustling leaves, the sound of flowing water.

As you walk through the garden, you arrive at its center where you find a bench or a place to sit. Sit down and feel that this is a place where you can nourish your heart.

Now, think of a quality you would like to cultivate: love, peace, joy, gratitude, courage, or any other quality.

Imagine that this quality is like a seed. Hold it in the palm of your hand and observe it.

Now, plant this seed in the soil of your garden. As you do so, feel the intention to cultivate this quality in your life.

Watch as, magically in this special garden, the seed sprouts quickly and begins to grow, becoming a splendid and strong plant that represents this quality.

Take a moment to feel connected to this quality, knowing that it is already within you, just waiting to be nourished and cultivated.

Before leaving the garden, know that you can return here at any time to find peace and to continue cultivating the qualities you desire in your life.

Slowly, become aware of your breath and your body. When you're ready, open your eyes and carry with you the feeling of peace and the quality you've cultivated.`
      }
    }
  },
  {
    id: 8,
    title: "Meditazione Camminata",
    duration: 15,
    description: "Una pratica di mindfulness in movimento che coltiva la consapevolezza attraverso il semplice atto di camminare.",
    content: `Trova uno spazio dove puoi camminare avanti e indietro per almeno 10-15 passi. Può essere all'interno o all'esterno.

Inizia stando in piedi, con i piedi paralleli e leggermente distanziati. Distribuisci il peso equamente su entrambi i piedi.

Porta l'attenzione alle sensazioni nei piedi e nelle gambe. Nota il contatto dei piedi con il suolo, il peso del corpo, la temperatura.

Ora, inizia a camminare molto lentamente, più lentamente di quanto faresti normalmente. L'obiettivo è notare ogni sensazione associata al movimento.

Mentre sollevi un piede, sii consapevole del cambiamento di peso e delle sensazioni nel piede che si solleva. Nota come i muscoli lavorano per sollevare il piede, come si muove la caviglia, il ginocchio.

Mentre il piede si sposta in avanti, osserva il movimento attraverso lo spazio. Non c'è fretta.

Quando poggi il piede a terra, nota il momento in cui tocca il suolo, come il peso si trasferisce a questo piede.

Continua a camminare lentamente, prestando attenzione a ogni aspetto del movimento. Se la mente vaga, gentilmente riportala all'esperienza del camminare.

Dopo aver raggiunto la fine del percorso, fermati consapevolmente, nota le sensazioni di stare fermi, poi girati lentamente per continuare nella direzione opposta.

Continua questa pratica per la durata desiderata, restando presente con ogni passo, trattando ogni passo come un nuovo inizio, un nuovo momento di consapevolezza.`,
    isPremium: false,
    translations: {
      en: {
        title: "Walking Meditation",
        description: "A mindfulness practice in motion that cultivates awareness through the simple act of walking.",
        content: `Find a space where you can walk back and forth for at least 10-15 steps. It can be indoors or outdoors.

Begin by standing, with your feet parallel and slightly apart. Distribute your weight evenly on both feet.

Bring attention to the sensations in your feet and legs. Notice the contact of your feet with the ground, the weight of your body, the temperature.

Now, begin walking very slowly, more slowly than you normally would. The goal is to notice every sensation associated with movement.

As you lift one foot, be aware of the weight shift and the sensations in the lifting foot. Notice how the muscles work to lift the foot, how the ankle, the knee moves.

As your foot moves forward, observe the movement through space. There's no rush.

When you place your foot on the ground, notice the moment it touches the ground, how the weight transfers to this foot.

Continue walking slowly, paying attention to every aspect of movement. If your mind wanders, gently bring it back to the experience of walking.

After reaching the end of your path, consciously stop, notice the sensations of standing still, then slowly turn to continue in the opposite direction.

Continue this practice for your desired duration, staying present with each step, treating each step as a new beginning, a new moment of awareness.`
      }
    }
  },
  {
    id: 9,
    title: "Meditazione per il Sonno Profondo",
    duration: 25,
    description: "Rilassamento progressivo per facilitare un sonno ristoratore e profondo.",
    content: `Sdraiati comodamente sul tuo letto, in posizione supina. Porta le braccia leggermente distanziate dal corpo con i palmi delle mani rivolti verso l'alto.

Chiudi gli occhi e inizia a notare il tuo respiro naturale, senza cercare di cambiarlo. Osserva semplicemente come l'aria entra ed esce dal corpo.

Fai tre respiri profondi, inspirando dal naso ed espirando lentamente dalla bocca.

Ora, porta l'attenzione ai piedi. Contrai i muscoli dei piedi, tieni la tensione per 3 secondi, poi rilascia completamente. Senti il calore e il rilassamento diffondersi nei piedi.

Sposta l'attenzione alle gambe. Contrai i muscoli delle gambe, tieni per 3 secondi, poi rilascia. Senti le gambe diventare pesanti e rilassate.

Continua questo processo di tensione e rilascio con l'addome, il petto, le mani, le braccia, le spalle, il collo e infine il viso.

Ora, con tutto il corpo rilassato, immagina una luce calda e dorata che parte dalla testa e lentamente scende attraverso tutto il corpo, rilassando ulteriormente ogni parte che incontra.

Mentre questa luce rilassante raggiunge i piedi, senti tutto il corpo completamente rilassato, pesante e confortevole.

Ora, immagina di trovarti in un luogo tranquillo e sicuro - una spiaggia serena, un prato fiorito, o qualsiasi luogo ti faccia sentire in pace.

Esplora questo luogo con i tuoi sensi. Nota i colori, i suoni, i profumi, e la sensazione di completa tranquillità che ti circonda.

Con ogni respiro, affonda più profondamente nel rilassamento, permettendo alla mente di diventare sempre più calma.

Mentre ti avvicini al sonno, lascia andare ogni pensiero, ogni preoccupazione. Affidati completamente al riposo, sapendo che questo momento è dedicato al rinnovamento e alla guarigione.

Continua a respirare dolcemente, scivolando sempre più profondamente verso un sonno ristoratore e pacifico.`,
    isPremium: true,
    translations: {
      en: {
        title: "Deep Sleep Meditation",
        description: "Progressive relaxation to facilitate restful and deep sleep.",
        content: `Lie comfortably on your bed, in a supine position. Place your arms slightly away from your body with your palms facing upward.

Close your eyes and begin to notice your natural breath, without trying to change it. Simply observe how air enters and leaves your body.

Take three deep breaths, inhaling through your nose and exhaling slowly through your mouth.

Now, bring your attention to your feet. Tense the muscles in your feet, hold the tension for 3 seconds, then completely release. Feel the warmth and relaxation spreading throughout your feet.

Move your attention to your legs. Tense your leg muscles, hold for 3 seconds, then release. Feel your legs becoming heavy and relaxed.

Continue this process of tensing and releasing with your abdomen, chest, hands, arms, shoulders, neck, and finally your face.

Now, with your entire body relaxed, imagine a warm, golden light starting at your head and slowly descending through your entire body, further relaxing each part it encounters.

As this relaxing light reaches your feet, feel your entire body completely relaxed, heavy, and comfortable.

Now, imagine yourself in a peaceful and safe place—a serene beach, a flowery meadow, or any place that makes you feel at peace.

Explore this place with your senses. Notice the colors, sounds, smells, and the feeling of complete tranquility surrounding you.

With each breath, sink deeper into relaxation, allowing your mind to become increasingly calm.

As you approach sleep, let go of every thought, every worry. Surrender completely to rest, knowing that this moment is dedicated to renewal and healing.

Continue to breathe gently, drifting deeper and deeper toward restful and peaceful sleep.`
      }
    }
  },
  {
    id: 10,
    title: "Meditazione della Gratitudine",
    duration: 10,
    description: "Coltiva un atteggiamento di apprezzamento e riconoscenza per arricchire il tuo benessere emotivo.",
    content: `Trova una posizione comoda, seduta o sdraiata. Chiudi gli occhi e prendi qualche respiro profondo per centrarti.

Porta l'attenzione al tuo cuore. Puoi posizionare delicatamente una mano sul petto per connetterti con questa area.

Inizia ricordando qualcosa di semplice per cui sei grato oggi. Potrebbe essere il calore del sole, un buon pasto, o il sorriso di uno sconosciuto. Qualsiasi cosa, grande o piccola.

Mentre pensi a questa prima cosa, cerca di sentire veramente la gratitudine nel tuo corpo. Nota come si manifesta - forse come calore nel petto, un sorriso che si forma, o un senso di apertura.

Ora, pensa a una persona nella tua vita per cui sei grato. Rifletti su come questa persona arricchisce la tua vita, cosa apprezzi di lei.

Mentre ti concentri su questa persona, invia mentalmente un messaggio di ringraziamento. Nota come questa sensazione di apprezzamento si espande nel tuo corpo.

Ora, rifletti su un aspetto di te stesso per cui sei grato. Potrebbe essere una qualità personale, un talento o semplicemente la tua capacità di crescere e imparare.

Apprezza questo aspetto di te e nota come l'atto di riconoscere il tuo valore influisce sul tuo stato emotivo.

Infine, considera una sfida o una difficoltà nella tua vita per cui potresti trovare gratitudine. Forse ti ha insegnato qualcosa, ti ha reso più forte, o ti ha portato a una nuova comprensione.

Concludi la meditazione prendendo un momento per assorbire tutti questi sentimenti di gratitudine, permettendo loro di nutrire il tuo essere.

Quando sei pronto, prendi tre respiri profondi e apri dolcemente gli occhi, portando con te questo senso di gratitudine nella tua giornata.`,
    isPremium: false,
    translations: {
      en: {
        title: "Gratitude Meditation",
        description: "Cultivate an attitude of appreciation and thankfulness to enrich your emotional well-being.",
        content: `Find a comfortable position, sitting or lying down. Close your eyes and take a few deep breaths to center yourself.

Bring your attention to your heart. You can gently place a hand on your chest to connect with this area.

Begin by recalling something simple you are grateful for today. It might be the warmth of the sun, a good meal, or a stranger's smile. Anything, big or small.

As you think of this first thing, try to really feel the gratitude in your body. Notice how it manifests—perhaps as warmth in your chest, a smile forming, or a sense of openness.

Now, think of a person in your life for whom you are grateful. Reflect on how this person enriches your life, what you appreciate about them.

As you focus on this person, mentally send a message of thanks. Notice how this feeling of appreciation expands in your body.

Now, reflect on an aspect of yourself for which you are grateful. It might be a personal quality, a talent, or simply your capacity to grow and learn.

Appreciate this aspect of yourself and notice how the act of acknowledging your worth affects your emotional state.

Finally, consider a challenge or difficulty in your life for which you might find gratitude. Perhaps it taught you something, made you stronger, or led you to a new understanding.

Conclude the meditation by taking a moment to absorb all these feelings of gratitude, allowing them to nourish your being.

When you're ready, take three deep breaths and gently open your eyes, carrying this sense of gratitude with you into your day.`
      }
    }
  }
];

// Function to get a translated meditation based on language
export function getTranslatedMeditation(meditation: MeditationWithTranslations, language: string = 'en'): Meditation {
  // If no translations available
  if (!meditation.translations) {
    return meditation;
  }
  
  // If requested language is Italian and we don't have Italian translation
  // (assuming original data is already in Italian)
  if (language === 'it' && !meditation.translations['it']) {
    return meditation;
  }
  
  // If requested language is English but no English translation available
  if (language === 'en' && !meditation.translations['en']) {
    // Use Italian translation if available (but this should not happen since we're adding English translations)
    if (meditation.translations['it']) {
      const translation = meditation.translations['it'];
      return {
        ...meditation,
        title: translation.title,
        description: translation.description,
        content: translation.content
      };
    }
    return meditation;
  }
  
  // Check if translation exists for the requested language
  if (meditation.translations[language]) {
    const translation = meditation.translations[language];
    
    // Return a new object with translated fields
    return {
      ...meditation,
      title: translation.title,
      description: translation.description,
      content: translation.content
    };
  }
  
  // Fallback to original if translation not available for requested language
  return meditation;
}

export function getMeditationById(id: number, language: string = 'en'): Meditation | undefined {
  const meditation = meditations.find(med => med.id === id);
  if (!meditation) return undefined;
  
  return getTranslatedMeditation(meditation, language);
}

export function getAllMeditations(language: string = 'en'): Meditation[] {
  return meditations.map(meditation => getTranslatedMeditation(meditation, language));
}

export function getFreeMeditations(language: string = 'en'): Meditation[] {
  return meditations
    .filter(med => !med.isPremium)
    .map(meditation => getTranslatedMeditation(meditation, language));
}

export function getPremiumMeditations(language: string = 'en'): Meditation[] {
  return meditations
    .filter(med => med.isPremium)
    .map(meditation => getTranslatedMeditation(meditation, language));
}