import React from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import Header2 from '@/components/Header2';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function TermsPage() {
  return (
    <div className="flex flex-col min-h-screen bg-white">
      <Header2 title="Termini e Privacy" />
      
      <Tabs defaultValue="terms" className="w-full max-w-4xl mx-auto">
        <div className="flex justify-center pt-4">
          <TabsList className="mb-4">
            <TabsTrigger value="terms">Termini di Servizio</TabsTrigger>
            <TabsTrigger value="privacy">Informativa Privacy</TabsTrigger>
          </TabsList>
        </div>
        
        <ScrollArea className="flex-1 px-4 py-2 md:px-8 bg-white h-[calc(100vh-180px)]">
          <TabsContent value="terms" className="max-w-3xl mx-auto pt-4 pb-12">
            <h1 className="text-2xl font-bold mb-6 text-purple-700">Termini di Servizio</h1>
            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">1. Accettazione dei Termini</h2>
            <p className="mb-4">
              Utilizzando l'applicazione Auralis, l'utente accetta di essere vincolato dai presenti Termini di Servizio. 
              Se non si accettano tutti i termini e le condizioni, si prega di non utilizzare l'applicazione.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">2. Descrizione del Servizio</h2>
            <p className="mb-4">
              Auralis fornisce uno strumento di supporto per il benessere mentale attraverso varie funzionalità tra cui 
              meditazioni guidate, esercizi di consapevolezza, riflessioni quotidiane e risorse educative. L'applicazione 
              non intende sostituire la consulenza professionale medica o psicologica.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">3. Limitazione di Responsabilità</h2>
            <p className="mb-4">
              L'applicazione Auralis è fornita "così com'è" e "come disponibile" senza garanzie di alcun tipo. In nessun caso 
              i proprietari o i collaboratori dell'applicazione saranno responsabili per danni diretti, indiretti, incidentali, 
              speciali o consequenziali derivanti dall'uso o dall'impossibilità di utilizzare l'applicazione.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">4. Abbonamenti e Pagamenti</h2>
            <p className="mb-4">
              Auralis offre sia funzionalità gratuite che premium tramite abbonamento. I dettagli dei prezzi sono disponibili
              nella sezione abbonamenti dell'applicazione. I pagamenti sono elaborati tramite fornitori di servizi di 
              pagamento di terze parti e sono soggetti ai loro termini e condizioni.
            </p>
            <p className="mb-4">
              Gli abbonamenti si rinnovano automaticamente alla fine del periodo di abbonamento a meno che l'utente non annulli 
              il rinnovo automatico almeno 24 ore prima della fine del periodo corrente.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">5. Proprietà Intellettuale</h2>
            <p className="mb-4">
              Tutti i contenuti presenti in Auralis, inclusi testi, grafica, logo, icone, immagini, clip audio, download 
              digitali e compilazioni di dati sono di proprietà di Auralis o dei suoi fornitori di contenuti e sono 
              protetti dalle leggi sul copyright.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">6. Account Utente</h2>
            <p className="mb-4">
              Per accedere a determinate funzionalità dell'applicazione, potrebbe essere necessario creare un account. 
              L'utente è responsabile del mantenimento della riservatezza delle proprie credenziali di accesso e di tutte 
              le attività che si verificano sotto il proprio account.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">7. Modifiche ai Termini</h2>
            <p className="mb-4">
              Ci riserviamo il diritto di modificare questi Termini di Servizio in qualsiasi momento. Gli utenti saranno 
              informati delle modifiche sostanziali tramite notifica nell'applicazione o via email. L'uso continuato 
              dell'applicazione dopo tali modifiche costituisce l'accettazione dei nuovi termini.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">8. Legge Applicabile</h2>
            <p className="mb-4">
              Questi Termini di Servizio sono regolati dalle leggi italiane. Qualsiasi controversia derivante da o in 
              relazione ai presenti Termini sarà sottoposta alla giurisdizione esclusiva dei tribunali italiani.
            </p>

            <p className="mt-8 text-gray-500">
              Ultimo aggiornamento: 25 Marzo 2025
            </p>
          </TabsContent>
          
          <TabsContent value="privacy" className="max-w-3xl mx-auto pt-4 pb-12">
            <h1 className="text-2xl font-bold mb-6 text-purple-700">Informativa sulla Privacy</h1>
            
            <p className="mb-4">
              La presente Informativa sulla Privacy descrive come Auralis raccoglie, utilizza e condivide i dati personali 
              quando si utilizza la nostra applicazione. Utilizziamo i dati personali esclusivamente nelle modalità descritte 
              nella presente Informativa.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">1. Dati Raccolti</h2>
            <p className="mb-4">
              <strong>Dati forniti dall'utente:</strong> Possiamo raccogliere informazioni che ci fornisci direttamente, 
              come nome, email, e contenuti generati (riflessioni, note personali, dati relativi all'umore).
            </p>
            <p className="mb-4">
              <strong>Dati raccolti automaticamente:</strong> Quando utilizzi l'applicazione, potremmo raccogliere 
              automaticamente determinate informazioni, inclusi dati di utilizzo, informazioni sul dispositivo e 
              dati di log.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">2. Utilizzo dei Dati</h2>
            <p className="mb-4">
              Utilizziamo i dati raccolti per:
            </p>
            <ul className="list-disc ml-8 mb-4">
              <li className="mb-2">Fornire e mantenere il servizio</li>
              <li className="mb-2">Personalizzare l'esperienza dell'utente</li>
              <li className="mb-2">Comunicare con gli utenti</li>
              <li className="mb-2">Migliorare l'applicazione e sviluppare nuove funzionalità</li>
              <li className="mb-2">Analizzare come viene utilizzata l'applicazione</li>
              <li className="mb-2">Prevenire attività fraudolente e garantire la sicurezza</li>
            </ul>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">3. Condivisione dei Dati</h2>
            <p className="mb-4">
              Non vendiamo le informazioni personali degli utenti a terzi. Potremmo condividere le informazioni 
              nelle seguenti circostanze:
            </p>
            <ul className="list-disc ml-8 mb-4">
              <li className="mb-2">Con fornitori di servizi che ci aiutano a gestire l'applicazione</li>
              <li className="mb-2">Se richiesto dalla legge o per proteggere i nostri diritti</li>
              <li className="mb-2">In caso di fusione, vendita o altra cessione di attività aziendale</li>
              <li className="mb-2">Con il consenso esplicito dell'utente</li>
            </ul>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">4. Protezione dei Dati</h2>
            <p className="mb-4">
              Adottiamo misure di sicurezza appropriate per proteggere i dati personali da perdita, uso improprio, 
              accesso non autorizzato, divulgazione, alterazione e distruzione. Tuttavia, nessun metodo di 
              trasmissione su Internet o di archiviazione elettronica è sicuro al 100%.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">5. Conservazione dei Dati</h2>
            <p className="mb-4">
              Conserviamo i dati personali solo per il tempo necessario a fornire il servizio richiesto e per adempiere 
              agli obblighi legali. Quando elimini il tuo account, potremmo continuare a conservare alcuni dati per 
              adempiere ai nostri obblighi legali o per scopi commerciali legittimi.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">6. Diritti dell'Utente</h2>
            <p className="mb-4">
              Gli utenti hanno il diritto di:
            </p>
            <ul className="list-disc ml-8 mb-4">
              <li className="mb-2">Accedere ai propri dati personali</li>
              <li className="mb-2">Rettificare dati inesatti</li>
              <li className="mb-2">Cancellare i propri dati</li>
              <li className="mb-2">Limitare o opporsi al trattamento dei dati</li>
              <li className="mb-2">Ricevere i propri dati in un formato strutturato (portabilità)</li>
              <li className="mb-2">Revocare il consenso in qualsiasi momento</li>
            </ul>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">7. Cookie e Tecnologie Simili</h2>
            <p className="mb-4">
              L'applicazione può utilizzare cookie e tecnologie simili per raccogliere informazioni e migliorare 
              l'esperienza dell'utente. È possibile gestire le preferenze relative ai cookie attraverso le 
              impostazioni del browser.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">8. Modifiche alla Informativa</h2>
            <p className="mb-4">
              Potremmo aggiornare questa Informativa sulla Privacy periodicamente. Gli utenti saranno informati di 
              eventuali modifiche sostanziali tramite notifica nell'applicazione o via email. Si consiglia di 
              consultare regolarmente l'Informativa per eventuali aggiornamenti.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3 text-purple-600">9. Contatti</h2>
            <p className="mb-4">
              Per domande o preoccupazioni relative alla presente Informativa sulla Privacy o alle nostre pratiche 
              in materia di dati, contattare: privacy@auralis.app
            </p>

            <p className="mt-8 text-gray-500">
              Ultimo aggiornamento: 25 Marzo 2025
            </p>
          </TabsContent>
        </ScrollArea>
      </Tabs>
      
      <div className="p-4 mt-4 flex justify-center">
        <Button 
          variant="outline" 
          className="text-purple-600 border-purple-600"
          onClick={() => window.history.back()}
        >
          Torna indietro
        </Button>
      </div>
      
      <Separator />
      
      <div className="p-4 text-center text-sm text-gray-500">
        Auralis © {new Date().getFullYear()} - Tutti i diritti riservati
      </div>
    </div>
  );
}