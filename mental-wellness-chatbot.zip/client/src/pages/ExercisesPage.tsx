import React, { useState, useEffect, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import Header2 from '@/components/Header2';
import TabNavigation from '@/components/TabNavigation';
import BottomNavigation2 from '@/components/BottomNavigation2';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/auth-context';
import { useStripe } from '@/lib/stripe-context';
import { type Exercise, type Meditation } from '@/lib/types';
import { ExerciseDetail } from '@/components/ExerciseDetail';
import { PremiumBadge } from '@/components/PremiumBadge';
import { PremiumContent } from '@/components/PremiumContent';
import { EmergencyHomeButton } from '@/components/EmergencyHome';
import { ExerciseStructuredData } from '@/components/StructuredData';
import SocialMetaTags from '@/components/SocialMetaTags';
import { Link } from 'wouter';
import MeditationModule from '@/components/MeditationModule';
import MeditationModuleCard from '@/components/MeditationModuleCard';

// Key to store completed exercises
const COMPLETED_EXERCISES_KEY = 'mentebene_completed_exercises';
// Key to store exercise notes
const EXERCISE_NOTES_KEY = 'mentebene_exercise_notes';

const ExercisesPage: React.FC = () => {
  const { t } = useTranslation();
  
  // Reset scroll when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [completedExercises, setCompletedExercises] = useState<number[]>([]);
  const [exerciseNotes, setExerciseNotes] = useState<Record<number, string>>({});
  const [showSuggestions, setShowSuggestions] = useState<boolean>(false);
  
  // Suggested search terms based on exercise content
  const suggestionTerms = [
    "breathing", "anxiety", "thoughts", "mindfulness", 
    "grounding", "meditation", "stress", "body", "exposure", "cbt",
    "wellness", "gratitude", "routine", "relaxation", "awareness"
  ];
  
  const { toast } = useToast();
  
  // Authentication hooks
  const { isAdmin, hasReachedRequestLimit, incrementDailyUsageCount, dailyUsageCount } = useAuth();
  
  // Get the current language
  const currentLanguage = useTranslation().i18n.language;
  
  // Load exercises from server - always enabled for all users
  const { data: exercises, isLoading, error } = useQuery<Exercise[]>({
    queryKey: ['/api/exercises', currentLanguage],
    queryFn: async () => {
      const response = await fetch(`/api/exercises?language=${currentLanguage}`);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    },
    enabled: true, // Must always be enabled to allow viewing the list
  });
  
  // We increment the counter only when the user makes an intentional request
  // (will be done in the interface event handlers)
  
  // Load completed exercises and notes from localStorage
  useEffect(() => {
    // Retrieve completed exercises
    const savedCompleted = localStorage.getItem(COMPLETED_EXERCISES_KEY);
    if (savedCompleted) {
      try {
        setCompletedExercises(JSON.parse(savedCompleted));
      } catch (e) {
        console.error('Error parsing completed exercises:', e);
      }
    }
    
    // Retrieve exercise notes
    const savedNotes = localStorage.getItem(EXERCISE_NOTES_KEY);
    if (savedNotes) {
      try {
        setExerciseNotes(JSON.parse(savedNotes));
      } catch (e) {
        console.error('Error parsing exercise notes:', e);
      }
    }
  }, []);
  
  // Subscription handler
  const handleSubscribe = useCallback(() => {
    window.location.href = '/subscription';
  }, []);
  
  // Import Stripe subscription state
  const { isSubscriptionActive } = useStripe();

  // Handler for selecting an exercise
  const handleSelectExercise = useCallback((exercise: Exercise) => {
    // Debug subscription
    console.log('handleSelectExercise - Active subscription:', isSubscriptionActive());
    
    // Check legacy system too
    console.log('handleSelectExercise - isSubscriptionActive:', isSubscriptionActive());
    
    // Admins can access all content, including premium
    // Or users with active subscription
    if (exercise.isPremium && !isAdmin && !isSubscriptionActive()) {
      // Redirect to subscription page
      handleSubscribe();
      return;
    }

    // For non-admin users, increment daily usage counter
    // when accessing an exercise (only on first interaction)
    if (!isAdmin && exercises) {
      incrementDailyUsageCount();
    }
    
    // Fetch exercise details with current language
    fetch(`/api/exercises/${exercise.id}?language=${currentLanguage}`)
      .then(response => response.json())
      .then(exerciseData => {
        console.log('Fetched exercise details with language:', currentLanguage, exerciseData);
        
        // Prevent default navigation event that could interfere
        document.body.style.pointerEvents = 'none';
        setTimeout(() => {
          document.body.style.pointerEvents = 'auto';
          // Set the exercise with translated data
          setSelectedExercise(exerciseData);
        }, 50);
      })
      .catch(error => {
        console.error('Error fetching exercise details:', error);
        // Fallback to the exercise data we already have
        setSelectedExercise(exercise);
      });
  }, [isAdmin, handleSubscribe, exercises, incrementDailyUsageCount, currentLanguage]);
  
  // Handler for returning to the list
  const handleBackToList = useCallback(() => {
    setSelectedExercise(null);
  }, []);
  
  // Handler for completing an exercise
  const handleCompleteExercise = useCallback((exerciseId: number) => {
    setCompletedExercises(prev => {
      // If the exercise is already completed, we remove it (toggle)
      if (prev.includes(exerciseId)) {
        const updated = prev.filter(id => id !== exerciseId);
        localStorage.setItem(COMPLETED_EXERCISES_KEY, JSON.stringify(updated));
        return updated;
      }
      
      // Otherwise we add it
      const updated = [...prev, exerciseId];
      localStorage.setItem(COMPLETED_EXERCISES_KEY, JSON.stringify(updated));
      return updated;
    });
    
    // Show confirmation toast
    toast({
      title: t("exercises.complete_toast.title"),
      description: t("exercises.complete_toast.description"),
    });
  }, [toast]);
  
  // Handler for saving exercise notes
  const handleSaveNote = useCallback((exerciseId: number, note: string) => {
    setExerciseNotes(prev => {
      const updated = { ...prev, [exerciseId]: note };
      localStorage.setItem(EXERCISE_NOTES_KEY, JSON.stringify(updated));
      return updated;
    });
    
    // Show confirmation toast
    toast({
      title: t("exercises.note_toast.title"),
      description: t("exercises.note_toast.description"),
    });
  }, [toast]);
  
  // Filter exercises based on category and search
  const filteredExercises = React.useMemo(() => {
    if (!exercises) return [];
    
    let filtered = activeCategory === 'all'
      ? exercises
      : exercises.filter(ex => ex.category.toLowerCase() === activeCategory.toLowerCase());
    
    // If there's a search query, filter further
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(ex => 
        ex.title.toLowerCase().includes(query) || 
        ex.description.toLowerCase().includes(query) ||
        ex.category.toLowerCase().includes(query) ||
        ex.steps.some(step => step.toLowerCase().includes(query))
      );
    }
    
    return filtered;
  }, [exercises, activeCategory, searchQuery]);
  
  // Get unique categories
  const categories = React.useMemo(() => {
    if (!exercises) return ['all'];
    
    // Create an array of unique categories
    const uniqueCategories = ['all'];
    const seenCategories: Record<string, boolean> = {};
    
    exercises.forEach(ex => {
      if (!seenCategories[ex.category]) {
        seenCategories[ex.category] = true;
        uniqueCategories.push(ex.category);
      }
    });
    
    return uniqueCategories;
  }, [exercises]);
  
  // Calculate statistics
  const stats = React.useMemo(() => {
    if (!exercises) return { total: 0, completed: 0, percentage: 0 };
    
    const total = exercises.length;
    const completed = completedExercises.length;
    const percentage = total ? Math.round((completed / total) * 100) : 0;
    
    return { total, completed, percentage };
  }, [exercises, completedExercises]);
  
  // Metadati per la pagina
  const pageTitle = selectedExercise 
    ? `${selectedExercise.title} | ${t('exercises.title')} | Auralis` 
    : `${t('exercises.title')} | Auralis`;
  
  const pageDescription = selectedExercise
    ? selectedExercise.description
    : t('exercises.subtitle', 'Esercizi di CBT e tecniche di mindfulness per affrontare ansia, stress e pensieri negativi.');

  return (
    <div className="page-container min-h-screen flex flex-col bg-gradient-to-b from-teal-50 via-white to-emerald-50 pb-16 md:pb-0">
      <div id="page-top" className="absolute top-0 left-0"></div>
      
      {/* Meta tags per SEO e condivisioni social */}
      <SocialMetaTags 
        title={pageTitle}
        description={pageDescription}
        contentType={selectedExercise ? 'exercise' : undefined}
        contentObject={selectedExercise || undefined}
        type={selectedExercise ? 'article' : 'website'}
      />
      
      {/* Structured data per SEO */}
      {selectedExercise && <ExerciseStructuredData exercise={selectedExercise} />}
      
      <Header2 />
      
      {/* Decorative pattern */}
      <div className="absolute top-0 left-0 right-0 h-64 bg-gradient-to-br from-teal-600/10 to-green-600/10 pointer-events-none"></div>
      <div className="absolute top-0 left-0 right-0 h-64 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:20px_20px] opacity-20 pointer-events-none"></div>
      
      {/* Decorative elements */}
      <div className="absolute -top-20 right-0 w-96 h-96 bg-teal-200 rounded-full opacity-20 blur-3xl"></div>
      <div className="absolute top-1/3 left-0 w-80 h-80 bg-emerald-200 rounded-full opacity-20 blur-3xl"></div>
      
      <main className="flex-grow max-w-3xl mx-auto w-full px-4 py-6 relative z-10">
        <EmergencyHomeButton discreet={true} />
        
        <TabNavigation activeTab="exercises" />
        
        {/* Usage limit banner */}
        {!isAdmin && hasReachedRequestLimit && (
          <div className="mb-4 p-3 rounded-lg shadow-md bg-white border border-rose-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="rounded-full w-8 h-8 flex items-center justify-center bg-rose-100 text-rose-600">
                  <i className="ri-error-warning-line"></i>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-rose-800">
                    {t("exercises.limit_banner.title")}
                  </h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {t("exercises.limit_banner.subtitle")}
                  </p>
                </div>
              </div>
              <Link to="/subscription">
                <Button className="bg-purple-600 hover:bg-purple-700 text-white shadow-sm text-xs h-8">
                  {t("exercises.limit_banner.unlock_button")}
                </Button>
              </Link>
            </div>
          </div>
        )}
        
        {/* Exercise detail or list view */}
        {selectedExercise ? (
          <ExerciseDetail 
            exercise={selectedExercise}
            onBack={handleBackToList}
            isCompleted={completedExercises.includes(selectedExercise.id)}
            onComplete={handleCompleteExercise}
            note={exerciseNotes[selectedExercise.id] || ''}
            onSaveNote={handleSaveNote}
          />
        ) : (
          <div>
            {/* Page header */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center bg-teal-100 text-teal-800 px-3 py-1 rounded-full text-sm font-medium mb-2">
                <i className="ri-mental-health-line text-lg mr-2"></i> {t("exercises.badge")}
              </div>
              <h2 className="font-nunito font-bold text-3xl mb-3 bg-gradient-to-r from-teal-600 via-emerald-600 to-green-600 text-transparent bg-clip-text">{t("exercises.title")}</h2>
              <p className="text-neutral-600 max-w-2xl mx-auto">{t("exercises.subtitle")}</p>
            </div>
            
            {/* Progress statistics */}
            <Card className="mb-8 bg-white border-none shadow-md overflow-hidden">
              <div className="h-1.5 bg-gradient-to-r from-teal-400 to-emerald-500"></div>
              <CardContent className="p-6">
                <div className="flex flex-col space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-semibold flex items-center text-teal-800">
                      <div className="mr-2 bg-teal-100 text-teal-700 w-8 h-8 rounded-full flex items-center justify-center">
                        <i className="ri-award-line"></i>
                      </div>
                      {t("exercises.progress")}
                    </h3>
                    <Badge variant="outline" className="bg-teal-100 text-teal-800 font-medium">
                      {stats.completed}/{stats.total} {t("exercises.completed")}
                    </Badge>
                  </div>
                  
                  <Progress value={stats.percentage} className="h-2" />
                  
                  <div className="text-sm text-neutral-500">
                    {stats.percentage === 0 
                      ? t("exercises.progress_messages.start")
                      : stats.percentage < 30
                        ? t("exercises.progress_messages.beginner")
                        : stats.percentage < 70
                          ? t("exercises.progress_messages.intermediate")
                          : t("exercises.progress_messages.advanced")
                    }
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Search bar and filters */}
            <Card className="mb-8 bg-white border-none shadow-md overflow-hidden">
              <CardContent className="p-6">
                <div className="flex flex-col space-y-4">
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <i className="ri-search-line text-neutral-400"></i>
                    </div>
                    <Input
                      type="search"
                      placeholder={t("exercises.search_placeholder")}
                      className="pl-10 bg-neutral-50 border-neutral-200"
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  <Tabs defaultValue="all" value={activeCategory} onValueChange={setActiveCategory}>
                    <TabsList className="bg-neutral-100 p-1">
                      {categories.map(category => (
                        <TabsTrigger
                          key={category}
                          value={category}
                          className="data-[state=active]:bg-white data-[state=active]:text-teal-700"
                        >
                          {category === 'all' ? t("exercises.all_categories") : category}
                        </TabsTrigger>
                      ))}
                    </TabsList>
                  </Tabs>
                </div>
              </CardContent>
            </Card>
            
            {/* Status messages */}
            {hasReachedRequestLimit && !isAdmin ? (
              <div className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-rose-100 mb-4">
                  <i className="ri-lock-line text-rose-600 text-2xl"></i>
                </div>
                <h3 className="text-lg font-bold text-rose-700 mb-2">{t("exercises.daily_limit_reached")}</h3>
                <p className="text-neutral-600 mb-6">{t("exercises.daily_limit_message")}</p>
                <Link to="/subscription">
                  <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                    {t("subscription.upgrade_button")}
                  </Button>
                </Link>
              </div>
            ) : isLoading ? (
              <div className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-teal-100 mb-4">
                  <div className="animate-spin h-8 w-8 border-4 border-teal-500 rounded-full border-t-transparent"></div>
                </div>
                <h3 className="text-lg font-bold text-teal-700 mb-2">{t("exercises.loading_title")}</h3>
                <p className="text-neutral-600">{t("exercises.loading_message")}</p>
              </div>
            ) : error ? (
              <div className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-rose-100 mb-4">
                  <i className="ri-error-warning-line text-rose-600 text-2xl"></i>
                </div>
                <h3 className="text-lg font-bold text-rose-700 mb-2">{t("exercises.error_title")}</h3>
                <p className="text-neutral-600 mb-6">{t("exercises.error_message")}</p>
                <Button onClick={() => window.location.reload()} variant="outline" className="border-teal-300 text-teal-700">
                  {t("common.retry")}
                </Button>
              </div>
            ) : filteredExercises.length === 0 ? (
              <div className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-amber-100 mb-4">
                  <i className="ri-search-line text-amber-600 text-2xl"></i>
                </div>
                <h3 className="text-lg font-bold text-amber-700 mb-2">{t("exercises.no_results_title")}</h3>
                <p className="text-neutral-600 mb-4">{t("exercises.no_results_message")}</p>
                <Button onClick={() => {setSearchQuery(''); setActiveCategory('all');}} variant="outline" className="border-amber-300 text-amber-700">
                  {t("exercises.clear_filters")}
                </Button>
              </div>
            ) : (
              // Exercise grid
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredExercises.map((exercise) => (
                  <Card 
                    key={exercise.id} 
                    className={`bg-white border-none shadow-md overflow-hidden transition-all hover:shadow-lg cursor-pointer ${
                      completedExercises.includes(exercise.id) ? 'ring-2 ring-emerald-300' : ''
                    }`}
                    onClick={() => handleSelectExercise(exercise)}
                  >
                    <div className="h-1 bg-gradient-to-r from-teal-400 to-emerald-400"></div>
                    <CardHeader className="p-5 pb-3">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <Badge variant="outline" className="bg-teal-50 text-teal-700 mb-2">
                            {exercise.category}
                          </Badge>
                          <CardTitle className="text-lg">{exercise.title}</CardTitle>
                        </div>
                        <div className="flex space-x-1 items-center">
                          {exercise.isPremium && <PremiumBadge />}
                          {completedExercises.includes(exercise.id) && (
                            <Badge className="bg-emerald-100 text-emerald-700 w-8 h-8 rounded-full p-0 flex items-center justify-center">
                              <i className="ri-check-line"></i>
                            </Badge>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-5 pt-0">
                      <CardDescription className="line-clamp-2 mb-2 text-neutral-600">
                        {exercise.description}
                      </CardDescription>
                      <div className="flex items-center text-sm text-neutral-500">
                        <i className="ri-time-line mr-1"></i>
                        <span>{exercise.steps.length} {exercise.steps.length === 1 
                          ? t("exercises.step_singular") 
                          : t("exercises.step_plural")}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
        
        {/* Meditation Module - Related to Wellbeing */}
        {!selectedExercise && (
          <div className="mt-8 mb-12">
            <Card className="bg-white border-none shadow-md overflow-hidden">
              <CardContent className="p-6">
                <h3 className="font-nunito font-bold text-xl text-amber-700 mb-4 flex items-center">
                  <i className="ri-sun-line mr-2 text-xl"></i>
                  {t('exercises.related_meditations', 'Meditazioni per il benessere')}
                </h3>
                <p className="text-neutral-600 text-sm mb-6">
                  {t('exercises.meditations_description', 'Completa la tua pratica con queste meditazioni che supportano gli esercizi di CBT')}
                </p>
                
                <div className="grid grid-cols-2 gap-4">
                  <MeditationModule 
                    title=""
                    description=""
                    limit={2}
                    compact={true}
                    showViewAll={false}
                    category="mindfulness"
                  />
                </div>
                
                <div className="text-center mt-6">
                  <Link href="/meditation">
                    <Button variant="outline" className="text-amber-600 hover:text-amber-700 hover:bg-amber-50">
                      {t('meditation.viewAllMeditations', 'Visualizza tutte le meditazioni')}
                      <i className="ri-arrow-right-line ml-2"></i>
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
      
      <BottomNavigation2 />
    </div>
  );
};

export default ExercisesPage;