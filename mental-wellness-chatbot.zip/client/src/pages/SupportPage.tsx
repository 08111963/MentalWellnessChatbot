import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import SimpleHeader from '../components/SimpleHeader';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

const SupportPage: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('tech');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Verifica che i campi siano validi
    if (!name || !email || !subject || !message) {
      toast({
        title: i18n.language === 'it' ? 'Errore' : 'Error',
        description: i18n.language === 'it' 
          ? 'Per favore compila tutti i campi richiesti.'
          : 'Please fill in all required fields.',
        variant: 'destructive',
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Invia i dati al nuovo endpoint del server
      const response = await fetch('/api/support', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name,
          email,
          subject,
          message
        }),
      });
      
      const result = await response.json();
      
      if (response.ok && result.success) {
        // Reset del form
        setName('');
        setEmail('');
        setSubject('tech');
        setMessage('');
        
        // Mostra conferma
        toast({
          title: i18n.language === 'it' ? 'Richiesta inviata!' : 'Request sent!',
          description: i18n.language === 'it' 
            ? 'Grazie per averci contattato. Ti risponderemo al più presto.'
            : 'Thank you for contacting us. We will respond as soon as possible.',
          variant: 'default',
        });
      } else {
        throw new Error(result.error || 'Errore durante l\'invio della richiesta');
      }
    } catch (error) {
      console.error('Errore durante l\'invio del modulo:', error);
      toast({
        title: i18n.language === 'it' ? 'Errore' : 'Error',
        description: i18n.language === 'it'
          ? 'Si è verificato un errore durante l\'invio della richiesta. Riprova più tardi.'
          : 'An error occurred while sending your request. Please try again later.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-indigo-50 flex flex-col">
      <SimpleHeader />
      
      <div className="flex-grow">
        <div className="container mx-auto py-8 px-4 max-w-3xl">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold text-purple-900 mb-2">
              {i18n.language === 'it' ? 'Modulo di Supporto' : 'Support Form'}
            </h1>
            <p className="text-gray-600 mb-8">
              {i18n.language === 'it' 
                ? 'Hai bisogno di aiuto? Compila il modulo sottostante e ti risponderemo al più presto.'
                : 'Need help? Fill out the form below and we will get back to you as soon as possible.'}
            </p>
          </div>
          
          <Card className="border shadow-lg">
            <CardHeader className="bg-gray-50 border-b">
              <CardTitle>
                {i18n.language === 'it' ? 'Invia una richiesta' : 'Submit a request'}
              </CardTitle>
              <CardDescription>
                {i18n.language === 'it' 
                  ? 'Completa tutti i campi per inviare la tua richiesta di supporto.' 
                  : 'Complete all fields to submit your support request.'}
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-base">
                    {i18n.language === 'it' ? 'Nome completo' : 'Full name'}
                  </Label>
                  <Input 
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="p-3 h-12"
                    placeholder={i18n.language === 'it' ? 'Inserisci il tuo nome' : 'Enter your name'}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-base">
                    {i18n.language === 'it' ? 'Indirizzo email' : 'Email address'}
                  </Label>
                  <Input 
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="p-3 h-12"
                    placeholder={i18n.language === 'it' ? 'esempio@email.com' : 'example@email.com'}
                  />
                </div>
                
                <div className="space-y-3">
                  <div className="text-base font-medium">
                    {i18n.language === 'it' ? 'Tipo di richiesta' : 'Request type'}
                  </div>
                  <RadioGroup
                    value={subject}
                    onValueChange={setSubject}
                    className="space-y-2"
                  >
                    <div className="flex items-center space-x-2 border rounded-md p-3 cursor-pointer hover:bg-gray-50">
                      <RadioGroupItem value="tech" id="tech" />
                      <Label htmlFor="tech" className="cursor-pointer">
                        {i18n.language === 'it' ? 'Problema tecnico' : 'Technical issue'}
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 border rounded-md p-3 cursor-pointer hover:bg-gray-50">
                      <RadioGroupItem value="subscription" id="subscription" />
                      <Label htmlFor="subscription" className="cursor-pointer">
                        {i18n.language === 'it' ? 'Domanda sull\'abbonamento' : 'Subscription question'}
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 border rounded-md p-3 cursor-pointer hover:bg-gray-50">
                      <RadioGroupItem value="content" id="content" />
                      <Label htmlFor="content" className="cursor-pointer">
                        {i18n.language === 'it' ? 'Feedback sui contenuti' : 'Content feedback'}
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 border rounded-md p-3 cursor-pointer hover:bg-gray-50">
                      <RadioGroupItem value="other" id="other" />
                      <Label htmlFor="other" className="cursor-pointer">
                        {i18n.language === 'it' ? 'Altro' : 'Other'}
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="message" className="text-base">
                    {i18n.language === 'it' ? 'Messaggio' : 'Message'}
                  </Label>
                  <Textarea 
                    id="message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    required
                    className="min-h-[150px]"
                    rows={5}
                    placeholder={i18n.language === 'it' 
                      ? 'Descrivi il tuo problema o la tua richiesta in dettaglio...' 
                      : 'Describe your issue or request in detail...'}
                  />
                </div>
                
                <div className="pt-4">
                  <Button 
                    type="submit" 
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white py-6 text-lg"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center justify-center">
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        {i18n.language === 'it' ? 'Invio in corso...' : 'Sending...'}
                      </span>
                    ) : (
                      <span>
                        {i18n.language === 'it' ? 'Invia richiesta' : 'Submit request'}
                      </span>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
            <CardFooter className="flex-col space-y-4 items-start border-t pt-6 text-sm text-muted-foreground bg-gray-50">
              <p>
                {i18n.language === 'it' 
                  ? 'I tuoi dati saranno trattati in conformità con la nostra politica sulla privacy.' 
                  : 'Your information will be processed in accordance with our privacy policy.'}
              </p>
              <div className="w-full flex justify-end">
                <Button 
                  variant="outline" 
                  onClick={() => navigate('/')}
                  className="mt-2"
                >
                  {i18n.language === 'it' ? 'Torna alla home' : 'Back to home'}
                </Button>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SupportPage;