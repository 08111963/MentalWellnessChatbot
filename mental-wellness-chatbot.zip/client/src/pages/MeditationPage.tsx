import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import Header2 from '@/components/Header2';
import BottomNavigation2 from '@/components/BottomNavigation2';
import SocialMetaTags from '@/components/SocialMetaTags';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/lib/auth-context';
import { useStripe } from '@/lib/stripe-context';
import { type Meditation } from '@/lib/types';
import { PremiumBadge } from '@/components/PremiumBadge';
import { PremiumContent } from '@/components/PremiumContent';
import MeditationModuleCard from '@/components/MeditationModuleCard';
import MeditationModule from '@/components/MeditationModule';

interface MeditationDetailProps {
  meditation: Meditation;
  onBack: () => void;
}

const MeditationDetail: React.FC<MeditationDetailProps> = ({ meditation, onBack }) => {
  const { t } = useTranslation();
  const { isAdmin } = useAuth();
  const { isSubscriptionActive } = useStripe();
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [timer, setTimer] = useState<number | null>(null);
  
  const handleStart = useCallback(() => {
    if (meditation.isPremium && !isAdmin && !isSubscriptionActive()) {
      // Redirect to subscription for premium content
      window.location.href = '/subscription';
      return;
    }
    
    setIsPlaying(true);
    
    // Simula un timer per la meditazione (in una vera app avremmo un audio player)
    const duration = meditation.duration * 60; // Converte in secondi
    const startTime = Date.now();
    
    const id = window.setInterval(() => {
      const elapsed = (Date.now() - startTime) / 1000;
      const progressPercentage = Math.min((elapsed / duration) * 100, 100);
      
      setProgress(progressPercentage);
      
      if (progressPercentage >= 100) {
        clearInterval(id);
        setIsPlaying(false);
      }
    }, 1000);
    
    setTimer(id);
    
    // Log di debug
    console.log('Meditazione iniziata:', meditation.title);
    
    return () => {
      if (id) clearInterval(id);
    };
  }, [meditation, isAdmin, isSubscriptionActive]);
  
  const handleStop = useCallback(() => {
    if (timer) {
      clearInterval(timer);
      setTimer(null);
    }
    setIsPlaying(false);
    setProgress(0);
  }, [timer]);
  
  // Pulisci il timer quando il componente viene smontato
  useEffect(() => {
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [timer]);
  
  // Format progress time
  const formatTime = useMemo(() => {
    const totalSeconds = meditation.duration * 60;
    const currentSeconds = Math.floor((progress / 100) * totalSeconds);
    const remainingSeconds = totalSeconds - currentSeconds;
    
    const mins = Math.floor(remainingSeconds / 60);
    const secs = remainingSeconds % 60;
    
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }, [meditation.duration, progress]);
  
  return (
    <div className="meditation-detail">
      <div className="flex items-center mb-4">
        <Button variant="ghost" className="mr-2" onClick={onBack}>
          <i className="ri-arrow-left-line mr-1"></i> {t('common.back')}
        </Button>
        <h1 className="text-2xl font-bold text-neutral-800">{meditation.title}</h1>
      </div>
      
      <Card className="mb-6 bg-white border-0 shadow-lg overflow-hidden">
        <div className={`h-2 ${isPlaying ? 'bg-gradient-to-r from-amber-400 to-amber-500' : 'bg-amber-200'}`}></div>
        <CardHeader className="pt-6 pb-4">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <Badge className="bg-amber-100 text-amber-800 border-none">
                  {meditation.duration} {t('meditation.minutes', 'minuti')}
                </Badge>
                {meditation.isPremium && <PremiumBadge />}
              </div>
              <CardTitle className="text-xl font-nunito">{meditation.title}</CardTitle>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="pb-6">
          <CardDescription className="text-neutral-700 mb-6 whitespace-pre-line">
            {meditation.description}
          </CardDescription>
          
          <div className="border border-amber-100 rounded-lg p-4 bg-gradient-to-br from-amber-50 to-orange-50 mb-6">
            <h3 className="text-lg font-semibold text-amber-800 mb-3">{t('meditation.instructions', 'Istruzioni')}</h3>
            <p className="text-neutral-700 whitespace-pre-line">
              {meditation.content}
            </p>
          </div>
          
          {isPlaying ? (
            <div className="mb-6">
              <div className="relative h-2 bg-amber-100 rounded-full overflow-hidden mb-2">
                <div 
                  className="absolute top-0 left-0 h-full bg-gradient-to-r from-amber-500 to-yellow-500 transition-all duration-1000"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-sm text-neutral-500">
                <span>{formatTime} {t('meditation.remaining', 'rimanenti')}</span>
                <span>{meditation.duration}:00</span>
              </div>
            </div>
          ) : null}
          
          {meditation.isPremium && !isAdmin && !isSubscriptionActive() ? (
            <PremiumContent
              title={t('meditation.premium_title', 'Meditazione Premium')}
              description={t('meditation.premium_message', 'Sblocca questa meditazione e tutte le altre funzionalità premium con un abbonamento.')}
              onSubscribe={() => window.location.href = '/subscription'}
              type="meditation"
            />
          ) : (
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
              {isPlaying ? (
                <Button 
                  className="bg-rose-600 hover:bg-rose-700 text-white" 
                  onClick={handleStop}
                >
                  <i className="ri-stop-circle-line mr-2"></i> {t('meditation.stop', 'Interrompi')}
                </Button>
              ) : (
                <Button 
                  className="bg-amber-600 hover:bg-amber-700 text-white" 
                  onClick={handleStart}
                >
                  <i className="ri-play-circle-line mr-2"></i> {t('meditation.start', 'Inizia')}
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

const MeditationPage: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Parse URL parameters to get meditation ID
  const params = new URLSearchParams(window.location.search);
  const meditationId = parseInt(params.get('id') || '0');
  
  // Get authentication context
  const { isAdmin } = useAuth();
  
  // Get subscription context
  const { isSubscriptionActive } = useStripe();
  
  // Reset scroll when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  // State for selected meditation
  const [selectedMeditation, setSelectedMeditation] = useState<Meditation | null>(null);
  
  // Fetch all meditations
  const { data: meditations, isLoading, error } = useQuery<Meditation[]>({
    queryKey: ['/api/meditations', i18n.language],
    queryFn: () => fetch(`/api/meditations?language=${i18n.language}`).then(res => res.json()),
  });
  
  // Set the selected meditation if ID is provided
  useEffect(() => {
    if (meditationId && meditations) {
      const meditation = meditations.find(m => m.id === meditationId);
      if (meditation) {
        setSelectedMeditation(meditation);
      }
    }
  }, [meditationId, meditations]);
  
  // Handler for selecting a meditation
  const handleSelectMeditation = useCallback((meditation: Meditation) => {
    console.log('Selected meditation:', meditation);
    
    // If the meditation is premium and user is not premium or admin, redirect to subscription
    if (meditation.isPremium && !isAdmin && !isSubscriptionActive()) {
      console.log('Premium meditation, redirecting to subscription');
      window.location.href = '/subscription';
      return;
    }
    
    setSelectedMeditation(meditation);
    
    // Update URL with meditation ID without page reload
    const url = new URL(window.location.href);
    url.searchParams.set('id', meditation.id.toString());
    window.history.pushState({}, '', url);
  }, [isAdmin, isSubscriptionActive]);
  
  // Handler for going back to meditation list
  const handleBackToList = useCallback(() => {
    setSelectedMeditation(null);
    
    // Remove ID from URL
    const url = new URL(window.location.href);
    url.searchParams.delete('id');
    window.history.pushState({}, '', url);
  }, []);
  
  // Filter meditations by category
  const getMeditationsByCategory = useCallback((category: string, limit = 3) => {
    if (!meditations) return [];
    
    // Filter by title containing the category (simplified approach)
    return meditations
      .filter(m => m.title.toLowerCase().includes(category.toLowerCase()))
      .slice(0, limit);
  }, [meditations]);
  
  // Meta tags for SEO
  const pageTitle = selectedMeditation
    ? `${selectedMeditation.title} | ${t('meditation.title', 'Meditazioni')} | Auralis`
    : `${t('meditation.title', 'Meditazioni')} | Auralis`;
    
  const pageDescription = selectedMeditation
    ? selectedMeditation.description
    : t('meditation.subtitle', 'Meditazioni guidate per migliorare mindfulness, consapevolezza e benessere emotivo.');
    
  return (
    <div className="page-container min-h-screen flex flex-col bg-gradient-to-b from-amber-50 via-white to-orange-50 pb-16 md:pb-0">
      {/* Meta tags for SEO and social sharing */}
      <SocialMetaTags 
        title={pageTitle}
        description={pageDescription}
        contentType={selectedMeditation ? 'meditation' : undefined}
        contentObject={selectedMeditation || undefined}
        type={selectedMeditation ? 'article' : 'website'}
      />
      
      <Header2 />
      
      {/* Decorative pattern */}
      <div className="absolute top-0 left-0 right-0 h-64 bg-gradient-to-br from-amber-600/10 to-orange-600/10 pointer-events-none"></div>
      <div className="absolute top-0 left-0 right-0 h-64 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:20px_20px] opacity-20 pointer-events-none"></div>
      
      {/* Floating bubbles decoration */}
      <div className="absolute top-0 left-0 right-0 bottom-0 overflow-hidden pointer-events-none">
        <div className="absolute w-32 h-32 bg-gradient-to-br from-blue-500/20 to-blue-300/20 rounded-full blur-xl -left-10 top-64 animate-float"></div>
        <div className="absolute w-24 h-24 bg-gradient-to-br from-amber-500/20 to-yellow-300/20 rounded-full blur-xl right-10 top-96 animate-float-delay"></div>
        <div className="absolute w-40 h-40 bg-gradient-to-br from-teal-500/20 to-green-300/20 rounded-full blur-xl left-1/3 top-[70vh] animate-float-slow"></div>
        <div className="absolute w-28 h-28 bg-gradient-to-br from-purple-500/20 to-fuchsia-300/20 rounded-full blur-xl right-1/4 top-[40vh] animate-float-slow-delay"></div>
      </div>
      
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes float {
          0% { transform: translateY(0) translateX(0); }
          50% { transform: translateY(-20px) translateX(10px); }
          100% { transform: translateY(0) translateX(0); }
        }
        @keyframes float-delay {
          0% { transform: translateY(0) translateX(0); }
          50% { transform: translateY(-15px) translateX(-10px); }
          100% { transform: translateY(0) translateX(0); }
        }
        @keyframes float-slow {
          0% { transform: translateY(0) translateX(0); }
          50% { transform: translateY(-10px) translateX(5px); }
          100% { transform: translateY(0) translateX(0); }
        }
        @keyframes float-slow-delay {
          0% { transform: translateY(0) translateX(0); }
          50% { transform: translateY(-5px) translateX(-5px); }
          100% { transform: translateY(0) translateX(0); }
        }
        .animate-float {
          animation: float 10s ease-in-out infinite;
        }
        .animate-float-delay {
          animation: float-delay 8s ease-in-out infinite;
        }
        .animate-float-slow {
          animation: float-slow 15s ease-in-out infinite;
        }
        .animate-float-slow-delay {
          animation: float-slow-delay 12s ease-in-out infinite;
        }
      `}} />
      
      {/* Main content */}
      <main className="flex-grow max-w-3xl mx-auto w-full px-4 py-6 relative z-10">
        {selectedMeditation ? (
          <MeditationDetail 
            meditation={selectedMeditation}
            onBack={handleBackToList}
          />
        ) : (
          <div>
            {/* Page header */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm font-medium mb-2">
                <i className="ri-sun-line text-lg mr-2"></i> {t('meditation.badge', 'Mindfulness')}
              </div>
              <h2 className="font-nunito font-bold text-3xl mb-3 bg-gradient-to-r from-amber-600 via-orange-600 to-yellow-600 text-transparent bg-clip-text">
                {t('meditation.title', 'Meditazioni Guidate')}
              </h2>
              <p className="text-neutral-600 max-w-2xl mx-auto">
                {t('meditation.subtitle', 'Meditazioni guidate per migliorare mindfulness, consapevolezza e benessere emotivo.')}
              </p>
            </div>
            
            {/* Meditations by category */}
            <div className="grid gap-8">
              {/* All Meditations grid */}
              <div className="mb-6">
                <h3 className="text-xl font-nunito font-bold text-neutral-800 mb-4">
                  {t('meditation.all_meditations', 'All Meditations')}
                </h3>
                
                {isLoading ? (
                  <div className="text-center py-12">
                    <div className="inline-block w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
                    <p className="mt-2 text-neutral-600">{t('meditation.loading', 'Loading meditations...')}</p>
                  </div>
                ) : error ? (
                  <div className="bg-rose-50 text-rose-700 p-4 rounded-lg border border-rose-200">
                    <p>{t('meditation.error', 'Error loading meditations. Please try again later.')}</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {meditations?.map(meditation => (
                      <MeditationModuleCard 
                        key={meditation.id}
                        meditation={meditation}
                        onClick={handleSelectMeditation}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
      
      <BottomNavigation2 />
    </div>
  );
};

export default MeditationPage;