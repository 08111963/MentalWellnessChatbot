import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { AlertCircle, CheckCircle, Lock, CreditCard, Calendar, ArrowLeft } from 'lucide-react';
import { ScrollToTop } from '@/components/ScrollToTop';
import { Alert, AlertDescription } from '@/components/ui/alert';

/**
 * Pagina che simula il checkout di Stripe
 * Mostra un form di pagamento simulato con campi carta di credito
 */
export default function MockStripeCheckoutPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [formData, setFormData] = useState({
    cardNumber: '',
    cardExpiry: '',
    cardCvc: '',
    cardName: '',
  });
  
  // Recupera i parametri dall'URL
  const params = new URLSearchParams(window.location.search);
  const plan = params.get('plan') as 'monthly' | 'yearly' | null;
  
  // Verifica che ci sia un piano valido
  useEffect(() => {
    if (!plan || (plan !== 'monthly' && plan !== 'yearly')) {
      setError('Piano non valido. Torna alla pagina di abbonamento.');
    }
  }, [plan]);
  
  // Funzione per gestire i cambiamenti nei campi del form
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    // Validazione specifica per ogni campo
    let formattedValue = value;
    
    if (name === 'cardNumber') {
      // Rimuove tutti i caratteri non numerici
      formattedValue = value.replace(/\D/g, '');
      // Limita a 16 cifre
      formattedValue = formattedValue.substring(0, 16);
      // Aggiunge spazi ogni 4 cifre
      formattedValue = formattedValue.replace(/(\d{4})(?=\d)/g, '$1 ').trim();
    } else if (name === 'cardExpiry') {
      // Rimuove tutti i caratteri non numerici
      formattedValue = value.replace(/\D/g, '');
      // Limita a 4 cifre
      formattedValue = formattedValue.substring(0, 4);
      // Aggiunge / dopo le prime 2 cifre
      if (formattedValue.length > 2) {
        formattedValue = formattedValue.substring(0, 2) + '/' + formattedValue.substring(2);
      }
    } else if (name === 'cardCvc') {
      // Rimuove tutti i caratteri non numerici
      formattedValue = value.replace(/\D/g, '');
      // Limita a 3 cifre
      formattedValue = formattedValue.substring(0, 3);
    }
    
    setFormData(prev => ({ ...prev, [name]: formattedValue }));
  };
  
  // Funzione per gestire l'invio del form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Verifica che ci sia un piano valido
    if (!plan) {
      setError('Piano non valido');
      return;
    }
    
    // Validazione base
    if (!formData.cardNumber || !formData.cardExpiry || !formData.cardCvc) {
      setError('Completa tutti i campi obbligatori');
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      // Simulazione di un processo di pagamento
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // In un'implementazione reale, qui chiameremmo l'API di Stripe
      console.log('Simulazione pagamento completata');
      setSuccess(true);
      
      // Mostra un toast di successo
      toast({
        title: "Pagamento autorizzato",
        description: "La tua carta è stata autorizzata con successo.",
      });
      
      // Attendi un momento prima di reindirizzare
      setTimeout(() => {
        // Redirect alla pagina di successo
        window.location.href = `/payment-success?session_id=sim_session_${Date.now()}_${Math.random().toString(36).substring(2, 9)}&plan=${plan}`;
      }, 1500);
    } catch (err) {
      console.error('Errore simulazione pagamento:', err);
      setError('Si è verificato un errore durante l\'elaborazione del pagamento');
    } finally {
      setLoading(false);
    }
  };
  
  // Funzione per tornare alla pagina di abbonamento
  const handleBack = () => {
    navigate('/subscription');
  };
  
  // Determina il prezzo in base al piano
  const getPrice = () => {
    return plan === 'yearly' ? '49,99 €' : '5,99 €';
  };
  
  // Determina il periodo in base al piano
  const getPeriod = () => {
    return plan === 'yearly' ? 'anno' : 'mese';
  };
  
  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <ScrollToTop />
      
      <div className="max-w-md w-full mx-auto">
        {/* Logo e intestazione */}
        <div className="text-center mb-6">
          <h2 className="text-3xl font-extrabold text-amber-900">Guida Premium</h2>
          <p className="mt-2 text-sm text-gray-600">
            Completa il pagamento per attivare il tuo abbonamento
          </p>
        </div>
        
        {/* Contenuto principale */}
        <Card className="shadow-lg">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl">Pagamento sicuro</CardTitle>
            <CardDescription>Compila i dati della tua carta di credito</CardDescription>
          </CardHeader>
          
          <CardContent>
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            {success ? (
              <div className="text-center py-4">
                <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 mb-4">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">Pagamento autorizzato</h3>
                <p className="mt-2 text-sm text-gray-500">
                  La tua carta è stata autorizzata. Sarai reindirizzato alla pagina di conferma...
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Riepilogo ordine */}
                <div className="bg-amber-50 p-3 rounded-md mb-4">
                  <h3 className="text-sm font-medium text-amber-800 mb-2">Riepilogo ordine</h3>
                  <div className="flex justify-between text-sm">
                    <span>Piano {plan === 'yearly' ? 'Annuale' : 'Mensile'}</span>
                    <span className="font-medium">{getPrice()}/{getPeriod()}</span>
                  </div>
                </div>
                
                {/* Campi carta */}
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="cardName">Nome sulla carta</Label>
                    <Input
                      id="cardName"
                      name="cardName"
                      placeholder="Mario Rossi"
                      value={formData.cardName}
                      onChange={handleChange}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="cardNumber">Numero carta</Label>
                    <div className="relative">
                      <Input
                        id="cardNumber"
                        name="cardNumber"
                        placeholder="1234 5678 9012 3456"
                        value={formData.cardNumber}
                        onChange={handleChange}
                        className="pl-10"
                        required
                      />
                      <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    </div>
                  </div>
                  
                  <div className="flex space-x-4">
                    <div className="w-1/2">
                      <Label htmlFor="cardExpiry">Scadenza (MM/AA)</Label>
                      <div className="relative">
                        <Input
                          id="cardExpiry"
                          name="cardExpiry"
                          placeholder="12/25"
                          value={formData.cardExpiry}
                          onChange={handleChange}
                          className="pl-10"
                          required
                        />
                        <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      </div>
                    </div>
                    
                    <div className="w-1/2">
                      <Label htmlFor="cardCvc">CVC</Label>
                      <Input
                        id="cardCvc"
                        name="cardCvc"
                        placeholder="123"
                        value={formData.cardCvc}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>
                </div>
              </form>
            )}
          </CardContent>
          
          <Separator />
          
          <CardFooter className="flex-col space-y-4 pt-4">
            {!success && (
              <>
                <Button 
                  type="submit" 
                  className="w-full bg-amber-600 hover:bg-amber-700 text-white"
                  disabled={loading}
                  onClick={handleSubmit}
                >
                  {loading ? (
                    <>
                      <div className="mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                      Elaborazione...
                    </>
                  ) : (
                    <>
                      <Lock className="mr-2 h-4 w-4" /> Paga {getPrice()}
                    </>
                  )}
                </Button>
                
                <Button 
                  type="button" 
                  variant="ghost" 
                  className="text-gray-600 hover:text-gray-800"
                  onClick={handleBack}
                  disabled={loading}
                >
                  <ArrowLeft className="mr-2 h-4 w-4" /> Indietro
                </Button>
              </>
            )}
            
            <div className="text-center text-xs text-gray-500 flex items-center justify-center">
              <Lock className="mr-1 h-3 w-3" /> Pagamento sicuro simulato
            </div>
          </CardFooter>
        </Card>
        
        {/* Nota informativa */}
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>
            Questa è una simulazione di pagamento per scopi dimostrativi.
            <br />
            Nessun addebito verrà effettuato.
          </p>
        </div>
      </div>
    </div>
  );
}