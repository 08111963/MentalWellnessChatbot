import React, { useEffect, useState } from 'react';

import Header from '@/components/Header';
import BottomNavigation from '@/components/BottomNavigation';
import { AdminPanel } from '@/components/AdminPanel';
import { useAuth } from '@/lib/auth-context';
import { AdminAuthDialog } from '@/components/AdminAuthDialog';

const AdminPage: React.FC = () => {
  const { isAdmin, setAdmin } = useAuth();
  const [showAuthDialog, setShowAuthDialog] = useState(!isAdmin);
  
  // Se l'utente non è amministratore, mostra la finestra di dialogo di autenticazione
  useEffect(() => {
    if (!isAdmin) {
      setShowAuthDialog(true);
    }
  }, [isAdmin]);
  
  // Gestisce il risultato dell'autenticazione
  const handleAuthentication = (success: boolean) => {
    if (success) {
      // Se l'autenticazione ha successo, attiva i privilegi di amministratore
      setAdmin(true);
      setShowAuthDialog(false);
    } else {
      // Se l'autenticazione fallisce, reindirizza alla home page
      window.location.href = '/';
    }
  };
  
  return (
    <div className="page-container min-h-screen flex flex-col bg-neutral-50 pb-16 md:pb-0">
      <div id="page-top" style={{ position: 'absolute', top: 0, left: 0 }}></div>
      <Header />
      
      {/* Finestra di dialogo di autenticazione */}
      <AdminAuthDialog 
        open={showAuthDialog} 
        onOpenChange={(open) => {
          setShowAuthDialog(open);
          if (!open && !isAdmin) {
            // Se l'utente chiude la finestra di dialogo senza autenticarsi, reindirizza alla home
            window.location.href = '/';
          }
        }} 
        onAuthenticate={handleAuthentication} 
      />
      
      <main className="flex-grow max-w-4xl mx-auto w-full px-4 py-6">
        <h2 className="font-nunito font-bold text-2xl mb-4">Pannello di Amministrazione</h2>
        <p className="text-neutral-600 mb-6">
          Utilizza questo pannello per gestire le impostazioni di amministrazione dell'applicazione.
        </p>
        
        <AdminPanel />

        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
          <h3 className="font-semibold text-amber-800 mb-2 flex items-center">
            <i className="ri-information-line mr-2"></i> Informazioni utili
          </h3>
          <ul className="list-disc list-inside text-amber-700 space-y-2 text-sm">
            <li>Utilizzando questo pannello puoi attivare o disattivare l'accesso ai contenuti premium.</li>
            <li>Con l'accesso attivato, potrai utilizzare tutte le funzionalità e i contenuti premium dell'applicazione.</li>
            <li>Le impostazioni sono temporanee e verranno ripristinate al riavvio dell'applicazione.</li>
          </ul>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
};

export default AdminPage;