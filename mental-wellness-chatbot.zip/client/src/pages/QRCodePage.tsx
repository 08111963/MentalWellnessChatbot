import React from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { QRCodeSVG } from 'qrcode.react';
import Header from '@/components/Header';

const QRCodePage: React.FC = () => {
  const { t } = useTranslation();
  const appUrl = window.location.origin;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    alert(t('qrcode.link_copied', 'Link copiato negli appunti!'));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto p-4 pt-8">
        <h1 className="text-3xl font-bold text-center mb-6 text-purple-800">
          {t('qrcode.page_title', 'Scarica la nostra App')}
        </h1>
        
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <p className="text-center text-gray-700 mb-6">
            {t('qrcode.page_description', 'Scansiona il codice QR con il tuo smartphone per accedere facilmente all\'app su dispositivi mobili.')}
          </p>
          
          <div className="flex flex-col items-center">
            <Card className="p-8 bg-white shadow-md max-w-md mx-auto mb-6">
              <CardContent className="p-4 flex justify-center">
                <QRCodeSVG 
                  value={appUrl} 
                  size={250}
                  level="H"
                  includeMargin={true}
                  imageSettings={{
                    src: "/favicon.svg",
                    x: undefined,
                    y: undefined,
                    height: 40,
                    width: 40,
                    excavate: true,
                  }}
                />
              </CardContent>
            </Card>
            
            <p className="text-center text-gray-600 mb-6 max-w-md mx-auto">
              {t('qrcode.instructions', 'Punta la fotocamera del tuo smartphone verso il codice QR per aprire l\'app nel browser del tuo dispositivo.')}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                className="bg-purple-600 hover:bg-purple-700"
                onClick={handleCopyLink}
              >
                <i className="ri-clipboard-line mr-2"></i>
                {t('qrcode.copy_link', 'Copia Link')}
              </Button>
              
              {typeof navigator !== 'undefined' && 'share' in navigator && (
                <Button 
                  variant="outline" 
                  className="border-purple-600 text-purple-600"
                  onClick={() => {
                    navigator.share({
                      title: t('qrcode.share_title', 'Auralis - Benessere mentale'),
                      text: t('qrcode.share_text', 'Scarica l\'app Auralis per il tuo benessere mentale!'),
                      url: appUrl,
                    }).catch(err => console.error('Errore nella condivisione:', err));
                  }}
                >
                  <i className="ri-share-line mr-2"></i>
                  {t('qrcode.share', 'Condividi')}
                </Button>
              )}
            </div>
          </div>
        </div>
        
        <div className="bg-purple-50 border border-purple-200 p-6 rounded-lg">
          <h2 className="text-xl font-semibold text-purple-800 mb-4">
            {t('qrcode.benefits_title', 'Vantaggi dell\'app mobile')}
          </h2>
          
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>{t('qrcode.benefit_1', 'Accesso rapido ai contenuti di meditazione e benessere mentale')}</li>
            <li>{t('qrcode.benefit_2', 'Interfaccia ottimizzata per dispositivi mobili')}</li>
            <li>{t('qrcode.benefit_3', 'Possibilità di utilizzare l\'app offline')}</li>
            <li>{t('qrcode.benefit_4', 'Notifiche per i nuovi contenuti e promemoria')}</li>
          </ul>
        </div>
      </main>
    </div>
  );
};

export default QRCodePage;