import React, { useEffect, useState, useCallback } from 'react';
import Header from '@/components/Header2';
import DisclaimerBanner from '@/components/DisclaimerBanner';
import SocialMetaTags from '@/components/SocialMetaTags';
import BottomNavigation from '@/components/BottomNavigation2';
import DailyQuote from '@/components/DailyQuote';
// SubscriptionStatus rimosso
import { DebugSubscription } from '@/components/DebugSubscription';
import { AdminActivator } from '@/components/AdminActivator';
import MeditationModule from '@/components/MeditationModule';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/lib/auth-context';
import { useTranslation } from 'react-i18next';
import { useToast } from '@/hooks/use-toast';

import { useLocalStorage } from '@/hooks/use-local-storage';

const FeatureCard: React.FC<{
  icon: string;
  title: string;
  description: string;
  link: string;
  linkText: string;
  color: string;
}> = ({ icon, title, description, link, linkText, color }) => {
  return (
    <Card className="w-full h-full flex flex-col">
      <CardHeader>
        <div className={`w-12 h-12 rounded-full ${color} flex items-center justify-center mb-4`}>
          <i className={`${icon} text-white text-2xl`}></i>
        </div>
        <CardTitle className="text-xl font-nunito">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        <div className="space-y-2"></div>
      </CardContent>
      <CardFooter>
        <a href={link}>
          <Button className="w-full btn-action">
            {linkText} <i className="ri-arrow-right-line ml-2"></i>
          </Button>
        </a>
      </CardFooter>
    </Card>
  );
};

const TestimonialCard: React.FC<{
  text: string;
  author: string;
  benefit: string;
}> = ({ text, author, benefit }) => {
  return (
    <Card className="bg-white border border-neutral-200">
      <CardContent className="pt-6">
        <div className="mb-4">
          <i className="ri-double-quotes-l text-primary text-3xl opacity-20"></i>
        </div>
        <p className="text-neutral-700 italic mb-4">{text}</p>
        <div className="flex justify-between items-center">
          <p className="font-medium text-sm">{author}</p>
          <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
            {benefit}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
};



const HomePage: React.FC = () => {
  const { isAdmin, setAdmin } = useAuth();
  const { t, i18n } = useTranslation();
  const { toast } = useToast();
  
  // Aggiunta per comandare admin da tastiera
  const [adminCode, setAdminCode] = useState('');
  
  // Gestore per tasti admin
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    // Aggiunge il carattere premuto al codice
    setAdminCode(prev => {
      const newCode = prev + e.key;
      
      // Verifica se il codice ora contiene "admin1313"
      if (newCode.includes('admin1313')) {
        // Reset del codice
        setAdminCode('');
        
        // Attiva admin mode e salva in localStorage
        setAdmin(true);
        
        // Salva anche manualmente nel localStorage per sicurezza
        localStorage.setItem('auralis_is_admin', 'true');
        console.log('Stato admin attivato da keyboard shortcut e salvato nel localStorage');
        
        // Notifica all'utente
        const isEnglish = i18n.language === 'en';
        toast({
          title: isEnglish ? "Admin Mode activated" : "Modalità Admin attivata",
          description: isEnglish ? "You now have access to all premium content" : "Ora hai accesso a tutti i contenuti premium",
          variant: "default",
        });
        
        return '';
      }
      
      // Mantiene solo gli ultimi 20 caratteri per evitare che la stringa diventi troppo lunga
      return newCode.slice(-20);
    });
  }, [setAdmin, toast, i18n.language]);
  
  // Aggiunta keydown listener
  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleKeyDown]);
  
  // Assicurati che la pagina inizi sempre dall'alto
  useEffect(() => {
    // Funzione per forzare lo scroll all'inizio
    const forceScrollToTop = () => {
      window.scrollTo(0, 0);
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
      
      // Imposta altezza minima per il contenitore principale
      const pageContainer = document.querySelector('.page-container');
      if (pageContainer instanceof HTMLElement) {
        pageContainer.style.minHeight = '100vh';
        pageContainer.scrollTop = 0;
      }
    };
    
    // Esegui subito
    forceScrollToTop();
    
    // Esegui anche dopo un breve ritardo per assicurarci che funzioni
    const timeouts = [
      setTimeout(forceScrollToTop, 0),
      setTimeout(forceScrollToTop, 100),
      setTimeout(forceScrollToTop, 300),
      setTimeout(forceScrollToTop, 500)
    ];
    
    return () => {
      timeouts.forEach(t => clearTimeout(t));
    };
  }, []);
  
  // Metadati per la pagina home
  const pageTitle = t('app.name') + ' - ' + t('app.tagline');
  const pageDescription = t('app.description', 'Supporto psicologico personalizzato con CBT, meditazioni guidate e strumenti per il benessere mentale.');

  return (
    <div className="page-container min-h-screen flex flex-col bg-gradient-to-b from-sky-50 via-white to-teal-50 pb-16 md:pb-0">
      <div id="page-top" className="absolute top-0 left-0 -mt-1"></div>
      
      {/* Meta tags SEO e condivisione social */}
      <SocialMetaTags 
        title={pageTitle}
        description={pageDescription}
        type="website"
      />
      
      <Header />
      
      {/* Pattern decorativo */}
      <div className="absolute top-0 left-0 right-0 h-64 bg-[radial-gradient(#bae6fd_1px,transparent_1px)] [background-size:20px_20px] opacity-30 pointer-events-none"></div>
      
      <main className="flex-grow w-full relative">
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-gradient-to-br from-sky-500 via-teal-500 to-blue-600 text-white py-16 md:py-28">
          {/* Elementi decorativi */}
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMwLTkuOTQtOC4wNi0xOC0xOC0xOFYwYzkuOTQgMCAxOCA4LjA2IDE4IDE4aDEyYzAgOS45NCA4LjA2IDE4IDE4IDE4djEyYy05Ljk0IDAtMTgtOC4wNi0xOC0xOEgzNnoiIGZpbGwtb3BhY2l0eT0iLjA1IiBmaWxsPSIjZmZmIi8+PC9nPjwvc3ZnPg==')] opacity-10"></div>
          
          <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
            <div className="absolute top-1/3 left-10 w-64 h-64 bg-gradient-to-r from-sky-300 to-teal-300 opacity-20 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute top-20 right-20 w-80 h-80 bg-gradient-to-r from-blue-400 to-cyan-400 opacity-20 rounded-full blur-3xl"></div>
            <div className="absolute bottom-10 left-1/4 w-60 h-60 bg-gradient-to-r from-teal-400 to-blue-400 opacity-20 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-20 right-1/3 w-96 h-96 bg-white opacity-10 rounded-full blur-3xl"></div>
          </div>
          
          <div className="max-w-6xl mx-auto px-4 relative z-10">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="text-center md:text-left">
                <div className="inline-flex items-center px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-sm font-medium mb-6 animate-pulse shadow-lg shadow-blue-900/10">
                  <span className="mr-2 text-sky-200">✨</span> {t('homepage.welcomeBanner')}
                </div>
                <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                  <span className="block bg-gradient-to-r from-white to-sky-100 bg-clip-text text-transparent drop-shadow-sm">{t('homepage.welcomePrefix')}</span>
                  <span className="block text-white drop-shadow-md">{t('app.name')}</span>
                </h1>
                <p className="text-xl md:text-2xl mb-8 text-white/90 font-light leading-relaxed">
                  {t('homepage.tagline')}
                </p>
                <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                  <a href="/chat">
                    <Button className="bg-teal-500 border-teal-600 border-2 text-white hover:bg-teal-600 transition-all hover:scale-105 px-8 py-6 h-auto text-lg font-medium shadow-xl">
                      <i className="ri-chat-smile-3-line mr-2 text-2xl"></i>
                      {t('homepage.startChatting')}
                    </Button>
                  </a>
                  <a href="/exercises">
                    <Button className="bg-teal-500 border-teal-600 border-2 text-white hover:bg-teal-600 transition-all hover:scale-105 px-8 py-6 h-auto text-lg font-medium shadow-xl">
                      {t('homepage.exploreExercises')} <i className="ri-mental-health-line ml-2"></i>
                    </Button>
                  </a>
                </div>
              </div>
              
              <div className="hidden md:flex justify-center">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-sky-500 to-teal-500 rounded-full blur-3xl opacity-40 animate-pulse"></div>
                  <div className="w-80 h-80 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center relative z-10 border border-white/30 shadow-2xl">
                    <div className="absolute inset-2 rounded-full bg-gradient-to-br from-sky-500/10 to-blue-500/10 backdrop-blur-sm"></div>
                    <i className="ri-mental-health-line text-white text-9xl drop-shadow-lg"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Wave divider */}
          <div className="absolute bottom-0 left-0 right-0">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="w-full h-auto">
              <path fill="#ffffff" fillOpacity="1" d="M0,288L48,272C96,256,192,224,288,197.3C384,171,480,149,576,165.3C672,181,768,235,864,250.7C960,267,1056,245,1152,224C1248,203,1344,181,1392,170.7L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
            </svg>
          </div>
        </section>
        
        {/* Disclaimer - Posizionato in modo da essere ben visibile */}
        <div className="max-w-5xl mx-auto px-4 relative z-20 -mt-8">
          <DisclaimerBanner />
        </div>
        
        {/* Subscription Status rimosso */}
        
        {/* Daily Quote */}
        <div className="max-w-3xl mx-auto px-4 pt-6">
          <DailyQuote />
        </div>
        
        {/* Features Section */}
        <section className="py-20 max-w-6xl mx-auto px-4 relative">
          {/* Decorazioni */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full -translate-y-1/2 translate-x-1/4"></div>
          <div className="absolute bottom-0 left-0 w-40 h-40 bg-indigo-100 rounded-full translate-y-1/4 -translate-x-1/4"></div>
          
          <div className="text-center mb-16 relative z-10">
            <div className="inline-flex items-center bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium mb-4">
              <i className="ri-tools-line text-lg mr-2"></i> {t('homepage.tools')}
            </div>
            <h2 className="text-4xl font-nunito font-bold mb-4 relative">
              {t('homepage.toolsTitle')}
              <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full"></div>
            </h2>
            <p className="text-neutral-600 max-w-2xl mx-auto mt-6">
              {t('homepage.toolsDescription')}
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8">
            {/* Chat Card */}
            <div className="chat-card group relative bg-white rounded-2xl shadow-lg p-6 border border-indigo-50 transform transition-transform hover:-translate-y-1 overflow-hidden">
              <div className="absolute top-0 right-0 h-32 w-32 bg-gradient-to-br from-primary/20 to-purple-500/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-xl"></div>
              <div className="relative z-10">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-indigo-700 flex items-center justify-center text-white mb-5">
                  <i className="ri-chat-3-line text-2xl"></i>
                </div>
                <h3 className="text-xl font-nunito font-bold mb-2 text-primary">{t('homepage.chatSupport')}</h3>
                <p className="text-neutral-600 mb-4 text-sm">
                  {t('homepage.chatDescription')}
                </p>
                <a href="/chat">
                  <Button className="w-full bg-gradient-to-r from-primary to-indigo-700 text-white shadow-md group-hover:shadow-lg transition-all">
                    {t('homepage.startChatting')} <i className="ri-arrow-right-line ml-2 transition-transform group-hover:translate-x-1"></i>
                  </Button>
                </a>
              </div>
            </div>
            
            {/* Esercizi CBT Card */}
            <div className="exercises-card group relative bg-white rounded-2xl shadow-lg p-6 border border-emerald-50 transform transition-transform hover:-translate-y-1 overflow-hidden">
              <div className="absolute top-0 right-0 h-32 w-32 bg-gradient-to-br from-emerald-500/20 to-green-500/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-xl"></div>
              <div className="relative z-10">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-emerald-600 to-green-600 flex items-center justify-center text-white mb-5">
                  <i className="ri-mental-health-line text-2xl"></i>
                </div>
                <h3 className="text-xl font-nunito font-bold mb-2 text-emerald-600">{t('homepage.cbtExercises')}</h3>
                <p className="text-neutral-600 mb-4 text-sm">
                  {t('homepage.exercisesDescription')}
                </p>
                <a href="/exercises">
                  <Button className="w-full bg-gradient-to-r from-emerald-600 to-green-600 text-white shadow-md group-hover:shadow-lg transition-all">
                    {t('homepage.exploreExercises')} <i className="ri-arrow-right-line ml-2 transition-transform group-hover:translate-x-1"></i>
                  </Button>
                </a>
              </div>
            </div>
            
            {/* Meditazione Card */}
            <div className="meditation-card group relative bg-white rounded-2xl shadow-lg p-6 border border-amber-50 transform transition-transform hover:-translate-y-1 overflow-hidden">
              <div className="absolute top-0 right-0 h-32 w-32 bg-gradient-to-br from-amber-500/20 to-orange-500/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-xl"></div>
              <div className="relative z-10">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-amber-600 to-orange-600 flex items-center justify-center text-white mb-5">
                  <i className="ri-sun-line text-2xl"></i>
                </div>
                <h3 className="text-xl font-nunito font-bold mb-2 text-amber-600">{t('homepage.meditation')}</h3>
                <p className="text-neutral-600 mb-4 text-sm">
                  {t('homepage.meditationDescription')}
                </p>
                <a href="/meditation">
                  <Button className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-md group-hover:shadow-lg transition-all">
                    {t('homepage.meditateNow')} <i className="ri-arrow-right-line ml-2 transition-transform group-hover:translate-x-1"></i>
                  </Button>
                </a>
              </div>
            </div>
            
            {/* Riflessioni Card */}
            <div className="reflections-card group relative bg-white rounded-2xl shadow-lg p-6 border border-violet-50 transform transition-transform hover:-translate-y-1 overflow-hidden">
              <div className="absolute top-0 right-0 h-32 w-32 bg-gradient-to-br from-violet-500/20 to-purple-500/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-xl"></div>
              <div className="relative z-10">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center text-white mb-5">
                  <i className="ri-book-2-line text-2xl"></i>
                </div>
                <h3 className="text-xl font-nunito font-bold mb-2 text-violet-600">{t('homepage.reflections')}</h3>
                <p className="text-neutral-600 mb-4 text-sm">
                  {t('homepage.reflectionsDescription')}
                </p>
                <a href="/reflections">
                  <Button className="w-full bg-gradient-to-r from-violet-600 to-purple-600 text-white shadow-md group-hover:shadow-lg transition-all">
                    {t('homepage.reflectWithUs')} <i className="ri-arrow-right-line ml-2 transition-transform group-hover:translate-x-1"></i>
                  </Button>
                </a>
              </div>
            </div>
            
            {/* Monitoraggio Umore Card */}
            <div className="mood-card group relative bg-white rounded-2xl shadow-lg p-6 border border-rose-50 transform transition-transform hover:-translate-y-1 overflow-hidden">
              <div className="absolute top-0 right-0 h-32 w-32 bg-gradient-to-br from-rose-500/20 to-pink-500/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-xl"></div>
              <div className="relative z-10">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-rose-600 to-pink-600 flex items-center justify-center text-white mb-5">
                  <i className="ri-emotion-line text-2xl"></i>
                </div>
                <h3 className="text-xl font-nunito font-bold mb-2 text-rose-600">{t('homepage.moodTracking')}</h3>
                <p className="text-neutral-600 mb-4 text-sm">
                  {t('homepage.moodDescription')}
                </p>
                <a href="/mood">
                  <Button className="w-full bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-md group-hover:shadow-lg transition-all">
                    <span className="flex items-center justify-center">
                      {t('homepage.trackMood')} <i className="ri-vip-crown-fill ml-2 text-amber-300"></i>
                    </span>
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </section>
        
        {/* AI Modules Section */}
        <section className="py-16 relative overflow-hidden">
          {/* Sfondo decorativo */}
          <div className="absolute inset-0 bg-gradient-to-b from-white via-indigo-50 to-white opacity-50"></div>
          <div className="absolute inset-0 bg-[radial-gradient(#e0e7ff_1px,transparent_1px)] [background-size:20px_20px] opacity-30"></div>
          
          <div className="max-w-5xl mx-auto px-4 relative z-10">
            <div className="text-center mb-12">
              <div className="inline-flex items-center bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
                <i className="ri-ai-generate text-lg mr-2"></i> {t('homepage.poweredByAI')}
              </div>
              <h2 className="text-4xl font-nunito font-bold mb-4 bg-gradient-to-r from-indigo-600 via-primary to-purple-600 bg-clip-text text-transparent">
                {t('homepage.aiModulesTitle')}
              </h2>
              <p className="text-neutral-600 max-w-2xl mx-auto">
                {t('homepage.aiModulesDescription')}
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {/* Card Relazioni */}
              <div className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-2xl blur opacity-25 group-hover:opacity-40 transition-opacity"></div>
                <Card className="relative bg-white rounded-2xl shadow-lg border-0 overflow-hidden transform transition-transform group-hover:scale-[1.02]">
                  <CardContent className="p-0">
                    <div className="h-28 bg-gradient-to-r from-indigo-600 to-purple-600 flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 bg-[radial-gradient(#ffffff33_1px,transparent_1px)] [background-size:10px_10px]"></div>
                      <i className="ri-heart-line text-white text-5xl relative z-10"></i>
                    </div>
                    <div className="p-5">
                      <h3 className="font-nunito font-bold text-xl mb-2 text-indigo-900">{t('homepage.relationships')}</h3>
                      <p className="text-sm text-neutral-600 mb-5">
                        {t('homepage.relationshipsDescription')}
                      </p>
                      <a href="/ai-modules">
                        <Button className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white shadow-md">
                          {t('homepage.explore')} <i className="ri-arrow-right-line ml-2"></i>
                        </Button>
                      </a>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Card Scrittura */}
              <div className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-teal-500 to-emerald-500 rounded-2xl blur opacity-25 group-hover:opacity-40 transition-opacity"></div>
                <Card className="relative bg-white rounded-2xl shadow-lg border-0 overflow-hidden transform transition-transform group-hover:scale-[1.02]">
                  <CardContent className="p-0">
                    <div className="h-28 bg-gradient-to-r from-teal-600 to-emerald-600 flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 bg-[radial-gradient(#ffffff33_1px,transparent_1px)] [background-size:10px_10px]"></div>
                      <i className="ri-quill-pen-line text-white text-5xl relative z-10"></i>
                    </div>
                    <div className="p-5">
                      <h3 className="font-nunito font-bold text-xl mb-2 text-teal-900">{t('homepage.therapeuticWriting')}</h3>
                      <p className="text-sm text-neutral-600 mb-5">
                        {t('homepage.therapeuticWritingDescription')}
                      </p>
                      <a href="/ai-modules">
                        <Button className="w-full bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white shadow-md">
                          {t('homepage.explore')} <i className="ri-arrow-right-line ml-2"></i>
                        </Button>
                      </a>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Card Rilassamento */}
              <div className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl blur opacity-25 group-hover:opacity-40 transition-opacity"></div>
                <Card className="relative bg-white rounded-2xl shadow-lg border-0 overflow-hidden transform transition-transform group-hover:scale-[1.02]">
                  <CardContent className="p-0">
                    <div className="h-28 bg-gradient-to-r from-blue-600 to-cyan-600 flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 bg-[radial-gradient(#ffffff33_1px,transparent_1px)] [background-size:10px_10px]"></div>
                      <i className="ri-rest-time-line text-white text-5xl relative z-10"></i>
                    </div>
                    <div className="p-5">
                      <h3 className="font-nunito font-bold text-xl mb-2 text-blue-900">{t('homepage.muscleRelaxation')}</h3>
                      <p className="text-sm text-neutral-600 mb-5">
                        {t('homepage.muscleRelaxationDescription')}
                      </p>
                      <a href="/ai-modules">
                        <Button className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white shadow-md">
                          {t('homepage.explore')} <i className="ri-arrow-right-line ml-2"></i>
                        </Button>
                      </a>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Card Sonno */}
              <div className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl blur opacity-25 group-hover:opacity-40 transition-opacity"></div>
                <Card className="relative bg-white rounded-2xl shadow-lg border-0 overflow-hidden transform transition-transform group-hover:scale-[1.02]">
                  <CardContent className="p-0">
                    <div className="h-28 bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 bg-[radial-gradient(#ffffff33_1px,transparent_1px)] [background-size:10px_10px]"></div>
                      <i className="ri-moon-clear-line text-white text-5xl relative z-10"></i>
                    </div>
                    <div className="p-5">
                      <h3 className="font-nunito font-bold text-xl mb-2 text-purple-900">{t('homepage.sleepImprovement')}</h3>
                      <p className="text-sm text-neutral-600 mb-5">
                        {t('homepage.sleepImprovementDescription')}
                      </p>
                      <a href="/ai-modules">
                        <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-md">
                          {t('homepage.explore')} <i className="ri-arrow-right-line ml-2"></i>
                        </Button>
                      </a>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
        
        {/* Risorse Personalizzate */}
        <section className="py-16 relative overflow-hidden">
          {/* Sfondo decorativo */}
          <div className="absolute inset-0 bg-gradient-to-b from-white via-emerald-50 to-white opacity-50"></div>
          <div className="absolute inset-0 bg-[radial-gradient(#d1fae5_1px,transparent_1px)] [background-size:20px_20px] opacity-30"></div>
          
          <div className="max-w-5xl mx-auto px-4 relative z-10">
            <div className="text-center mb-12">
              <div className="inline-flex items-center bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
                <i className="ri-book-mark-line text-lg mr-2"></i> {t('homepage.customContent')}
              </div>
              <h2 className="text-4xl font-nunito font-bold mb-4 bg-gradient-to-r from-emerald-600 via-emerald-500 to-lime-500 bg-clip-text text-transparent">
                {t('homepage.personalizedResources')}
              </h2>
              <p className="text-neutral-600 max-w-2xl mx-auto">
                {t('homepage.personalizedResourcesDescription')}
              </p>
            </div>
            
            <div className="flex flex-col md:flex-row gap-8">
              <div className="w-full md:w-1/2">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-400 to-lime-400 rounded-2xl blur-lg opacity-30 transform scale-95"></div>
                  <div className="relative bg-white rounded-2xl shadow-xl overflow-hidden border border-emerald-100">
                    <div className="h-36 bg-gradient-to-r from-emerald-500 to-lime-500 flex items-center justify-center relative p-6">
                      <div className="absolute inset-0 bg-[radial-gradient(#ffffff33_1px,transparent_1px)] [background-size:10px_10px]"></div>
                      <i className="ri-book-mark-line text-white text-6xl relative z-10"></i>
                    </div>
                    <div className="p-6">
                      <h3 className="text-2xl font-nunito font-bold mb-3 text-emerald-700">{t('homepage.resourceLibrary')}</h3>
                      <p className="text-neutral-600 mb-6">
                        {t('homepage.resourceLibraryDescription')}
                      </p>
                      <ul className="space-y-3 mb-6">
                        <li className="flex items-center">
                          <i className="ri-check-line text-emerald-500 mr-2 text-lg"></i>
                          <span className="text-neutral-700">{t('homepage.articlesAndBooks')}</span>
                        </li>
                        <li className="flex items-center">
                          <i className="ri-check-line text-emerald-500 mr-2 text-lg"></i>
                          <span className="text-neutral-700">{t('homepage.educationalVideos')}</span>
                        </li>
                        <li className="flex items-center">
                          <i className="ri-check-line text-emerald-500 mr-2 text-lg"></i>
                          <span className="text-neutral-700">{t('homepage.wellnessPodcasts')}</span>
                        </li>
                      </ul>
                      <a href="/resources">
                        <Button className="w-full bg-gradient-to-r from-emerald-600 to-lime-600 text-white shadow-lg hover:shadow-emerald-200/50 transition-all">
                          {t('homepage.exploreAllResources')} <i className="ri-arrow-right-line ml-2"></i>
                        </Button>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="w-full md:w-1/2">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-teal-400 to-emerald-400 rounded-2xl blur-lg opacity-30 transform scale-95"></div>
                  <div className="relative bg-white rounded-2xl shadow-xl overflow-hidden border border-teal-100">
                    <div className="h-36 bg-gradient-to-r from-teal-500 to-emerald-500 flex items-center justify-center relative p-6">
                      <div className="absolute inset-0 bg-[radial-gradient(#ffffff33_1px,transparent_1px)] [background-size:10px_10px]"></div>
                      <i className="ri-sparkling-line text-white text-6xl relative z-10"></i>
                    </div>
                    <div className="p-6">
                      <h3 className="text-2xl font-nunito font-bold mb-3 text-teal-700">{t('homepage.personalizedSuggestions')}</h3>
                      <p className="text-neutral-600 mb-6">
                        {t('homepage.personalizedSuggestionsDescription')}
                      </p>
                      <div className="space-y-4 mb-6">
                        <div className="p-3 bg-teal-50 rounded-lg">
                          <div className="flex items-center mb-2">
                            <i className="ri-article-line text-teal-600 mr-2"></i>
                            <span className="text-teal-800 font-medium">{t('homepage.recommendedReadings')}</span>
                          </div>
                          <p className="text-neutral-600 text-sm">{t('homepage.contentBasedOnInterests')}</p>
                        </div>
                        <div className="p-3 bg-emerald-50 rounded-lg">
                          <div className="flex items-center mb-2">
                            <i className="ri-video-line text-emerald-600 mr-2"></i>
                            <span className="text-emerald-800 font-medium">{t('homepage.recommendedMedia')}</span>
                          </div>
                          <p className="text-neutral-600 text-sm">{t('homepage.mediaMatchingPreferences')}</p>
                        </div>
                      </div>
                      <a href="/resources">
                        <Button className="w-full bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-lg hover:shadow-teal-200/50 transition-all">
                          {t('homepage.discoverSuggestions')} <i className="ri-arrow-right-line ml-2"></i>
                        </Button>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Testimonials */}
        <section className="py-16 relative overflow-hidden">
          {/* Sfondo colorato */}
          <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-indigo-50"></div>
          <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-white to-transparent"></div>
          <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-white to-transparent"></div>
          
          {/* Decorazioni */}
          <div className="absolute top-20 right-10 w-72 h-72 rounded-full bg-indigo-100 opacity-40 blur-3xl"></div>
          <div className="absolute bottom-20 left-10 w-72 h-72 rounded-full bg-purple-100 opacity-40 blur-3xl"></div>
          
          <div className="max-w-5xl mx-auto px-4 relative z-10">
            <div className="text-center mb-12">
              <div className="inline-flex items-center bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
                <i className="ri-star-line text-lg mr-2"></i> {t('homepage.testimonials')}
              </div>
              <h2 className="text-4xl font-nunito font-bold mb-4 bg-gradient-to-r from-purple-600 via-primary to-indigo-600 bg-clip-text text-transparent">
                {t('homepage.whatUsersSay')}
              </h2>
              <p className="text-neutral-600 max-w-2xl mx-auto">
                {t('homepage.userExperiences')}
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              <div className="group">
                <div className="bg-white p-6 rounded-xl shadow-lg border border-indigo-50 transition-all duration-300 hover:shadow-xl group-hover:translate-y-[-4px]">
                  <div className="mb-4 text-indigo-500">
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"></path>
                      <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"></path>
                    </svg>
                  </div>
                  <p className="text-neutral-700 mb-4 italic">
                    {t('homepage.testimonial1')}
                  </p>
                  <div className="flex items-center mb-2">
                    <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold mr-3">M</div>
                    <div>
                      <h4 className="font-semibold">{t('homepage.testimonial1Name')}</h4>
                      <div className="text-sm font-medium text-indigo-600">{t('homepage.anxietyReduction')}</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="group">
                <div className="bg-white p-6 rounded-xl shadow-lg border border-emerald-50 transition-all duration-300 hover:shadow-xl group-hover:translate-y-[-4px]">
                  <div className="mb-4 text-emerald-500">
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"></path>
                      <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"></path>
                    </svg>
                  </div>
                  <p className="text-neutral-700 mb-4 italic">
                    {t('homepage.testimonial2')}
                  </p>
                  <div className="flex items-center mb-2">
                    <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 font-bold mr-3">M</div>
                    <div>
                      <h4 className="font-semibold">{t('homepage.testimonial2Name')}</h4>
                      <div className="text-sm font-medium text-emerald-600">{t('homepage.positiveThinking')}</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="group">
                <div className="bg-white p-6 rounded-xl shadow-lg border border-purple-50 transition-all duration-300 hover:shadow-xl group-hover:translate-y-[-4px]">
                  <div className="mb-4 text-purple-500">
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"></path>
                      <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"></path>
                    </svg>
                  </div>
                  <p className="text-neutral-700 mb-4 italic">
                    {t('homepage.testimonial3')}
                  </p>
                  <div className="flex items-center mb-2">
                    <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 font-bold mr-3">G</div>
                    <div>
                      <h4 className="font-semibold">{t('homepage.testimonial3Name')}</h4>
                      <div className="text-sm font-medium text-purple-600">{t('homepage.increasedAwareness')}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-24 relative overflow-hidden">
          {/* Sfondo colorato */}
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 via-primary to-purple-600"></div>
          
          {/* Pattern di sfondo */}
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMSIgY3k9IjEiIHI9IjEiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4yKSIvPjwvc3ZnPg==')] opacity-20"></div>
          
          {/* Elementi decorativi */}
          <div className="absolute -left-32 -top-32 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
          <div className="absolute -right-32 -bottom-32 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
          
          <div className="max-w-4xl mx-auto px-4 relative z-10 text-center">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-10 shadow-2xl">
              <h2 className="text-4xl font-nunito font-bold mb-4 text-white">{t('common.readyToStart')}</h2>
              <div className="w-16 h-1 bg-white/30 mx-auto mb-6"></div>
              <p className="text-white/90 max-w-2xl mx-auto mb-8 text-lg">
                {t('common.startYourJourney')}
              </p>
              <div className="flex justify-center gap-4 flex-wrap">
                <a href="/chat">
                  <Button className="bg-white hover:bg-opacity-90 text-primary px-8 py-6 h-auto text-lg shadow-lg shadow-indigo-900/30 hover:scale-105 transition-all">
                    {t('chat.startConversation')} <i className="ri-arrow-right-line ml-2"></i>
                  </Button>
                </a>
                <a href="/exercises">
                  <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20 px-8 py-6 h-auto text-lg transition-all">
                    {t('homepage.exploreExercises')} <i className="ri-mental-health-line ml-2"></i>
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      {/* Nessun pulsante Admin qui - accesso tramite pagina admin direttamente */}
      
      <div className="bottom-navigation">
        <BottomNavigation />
      </div>
      
      {/* Footer con link discreto ai termini di servizio */}
      <div className="py-4 bg-white text-center text-sm text-gray-500 border-t border-gray-100">
        <div className="max-w-4xl mx-auto px-4">
          <p>
            Auralis <span className="inline-block"><AdminActivator /></span> {new Date().getFullYear()} - {t('common.allRightsReserved')}
            <span className="mx-2">•</span>
            <a 
              href="/terms" 
              className="text-purple-500 hover:text-purple-700 transition-colors"
            >
              {t('common.termsAndPrivacy')}
            </a>
          </p>
        </div>
      </div>
      
    </div>
  );
};

export default HomePage;
