import React, { useEffect, useState } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import Header2 from '@/components/Header2';

export default function GuidaPage() {
  const [guidaContent, setGuidaContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Carica il file markdown dalla root del progetto
    fetch('/guida_app.md')
      .then(response => {
        if (!response.ok) {
          throw new Error('Errore nel caricamento della guida');
        }
        return response.text();
      })
      .then(text => {
        setGuidaContent(text);
        setIsLoading(false);
      })
      .catch(error => {
        console.error('Errore durante il caricamento della guida:', error);
        setGuidaContent('Si è verificato un errore durante il caricamento della guida. Riprova più tardi.');
        setIsLoading(false);
      });
  }, []);

  // Funzione per convertire il markdown in HTML basic
  const markdownToHtml = (markdown: string) => {
    // Converti i titoli
    let html = markdown
      .replace(/^# (.*$)/gm, '<h1 class="text-2xl font-bold mt-6 mb-4 text-purple-700">$1</h1>')
      .replace(/^## (.*$)/gm, '<h2 class="text-xl font-bold mt-5 mb-3 text-purple-600">$1</h2>')
      .replace(/^### (.*$)/gm, '<h3 class="text-lg font-bold mt-4 mb-2 text-purple-500">$1</h3>');
    
    // Converti paragrafi
    html = html.replace(/^(?!<h[1-6]|<ul|<ol|<li|<blockquote|<hr)(.*$)/gm, '<p class="mb-3">$1</p>');
    
    // Converti liste
    html = html.replace(/^- (.*$)/gm, '<li class="ml-6 list-disc">$1</li>');
    
    // Raggruppa elementi lista
    html = html.replace(/<li class="ml-6 list-disc">(.*?)<\/li>(?!\n<li)/gm, '<ul class="my-3">$&</ul>');
    
    // Evidenzia i vantaggi premium
    html = html.replace(/✨/g, '<span class="text-amber-500 font-bold">✨</span>');
    
    // Separa le sezioni
    html = html.replace(/^---/gm, '<hr class="my-8 border-t border-gray-200" />');
    
    return html;
  };

  return (
    <div className="flex flex-col min-h-screen bg-white">
      <Header2 title="Guida Completa" />
      
      <ScrollArea className="flex-1 px-4 py-6 md:py-8 md:px-8 bg-white">
        <div className="max-w-3xl mx-auto">
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-purple-700"></div>
            </div>
          ) : (
            <div 
              className="prose max-w-full" 
              dangerouslySetInnerHTML={{ __html: markdownToHtml(guidaContent) }}
            />
          )}
        </div>
      </ScrollArea>
      
      <Separator />
      
      <div className="p-4 text-center text-sm text-gray-500">
        Auralis © {new Date().getFullYear()} - Tutti i diritti riservati
      </div>
    </div>
  );
}