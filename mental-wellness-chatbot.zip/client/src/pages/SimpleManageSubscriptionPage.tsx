import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '../lib/auth-context';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollToTop } from '../components/ScrollToTop';
import { AlertTriangle, CreditCard, Calendar, Bookmark, ArrowLeft, ExternalLink, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useTranslation } from 'react-i18next';
import { useStripe } from '@/lib/stripe-context';

// Header semplificato senza selettori di lingua
const SimpleHeader: React.FC = () => {
  const { isAuthenticated, logout } = useAuth();
  const { t } = useTranslation();
  
  const handleHomeClick = (e: React.MouseEvent) => {
    e.preventDefault();
    window.location.href = '/';
  };
  
  const handleLogout = () => {
    logout();
    window.location.reload();
  };
  
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-5xl mx-auto px-4 py-4 flex justify-between items-center">
        {/* Logo e nome */}
        <div className="flex items-center space-x-2">
          <a 
            href="/" 
            className="flex items-center space-x-2 transition-transform hover:scale-105"
            onClick={handleHomeClick}
            aria-label="Torna alla Home"
          >
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <i className="ri-mental-health-line text-white text-xl"></i>
            </div>
            <h1 className="font-nunito font-bold text-2xl text-neutral-800">
              Auralis
            </h1>
          </a>
        </div>
        
        <div className="flex items-center space-x-2">
          {/* Pulsante Home */}
          <a 
            href="/"
            className="px-3 py-1.5 bg-purple-600 text-white text-sm rounded-md font-medium hover:bg-purple-700 shadow-md inline-flex items-center" 
            onClick={handleHomeClick}
            aria-label="Torna alla Home"
          >
            <i className="ri-home-4-line mr-1.5"></i> Home
          </a>
          
          {/* Pulsante Logout */}
          {isAuthenticated && (
            <Button 
              variant="outline" 
              size="sm"
              className="px-3 py-1.5 border-indigo-500 text-indigo-600 hover:bg-indigo-50"
              onClick={handleLogout}
            >
              <i className="ri-logout-box-line mr-1.5"></i> {t('auth.logout')}
            </Button>
          )}
        </div>
      </div>
    </header>
  );
};

// Pagina principale di gestione abbonamento
export default function SimpleManageSubscriptionPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { isAuthenticated, user, cancelSubscription } = useAuth();
  const { verifySubscription, isSubscriptionActive } = useStripe();
  const { t, i18n } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [subscriptionDetails, setSubscriptionDetails] = useState({
    plan: user?.subscriptionPlan || localStorage.getItem('auralis_plan') || 'monthly',
    status: user?.subscriptionStatus || 'active',
    nextPaymentDate: '',
    subscriptionId: user?.stripeSubscriptionId || localStorage.getItem('auralis_subscription_id') || '',
    customerId: user?.stripeCustomerId || localStorage.getItem('auralis_customer_id') || '',
    startDate: user?.subscriptionStart || localStorage.getItem('auralis_subscription_date') || new Date().toISOString(),
    price: 0
  });
  
  // Verifica l'accesso e recupera i dati dell'abbonamento
  useEffect(() => {
    const checkSubscription = async () => {
      setLoading(true);
      
      // Se l'utente non è autenticato, reindirizza alla pagina di login
      if (!isAuthenticated) {
        toast({
          title: "Accesso non autorizzato",
          description: "Effettua il login per accedere a questa pagina",
          variant: "destructive"
        });
        navigate('/subscription?openAuth=true');
        return;
      }
      
      try {
        // Verifica lo stato dell'abbonamento
        console.log('Verifica abbonamento dalla pagina di gestione...');
        
        // Verifica direttamente se l'utente ha un abbonamento attivo
        // Evita di chiamare verifySubscription che genererebbe un ciclo infinito
        if (!user?.isPremium && !isSubscriptionActive()) {
          setError('Nessun abbonamento attivo trovato.');
          setLoading(false);
          return;
        }
        
        // Determina i dettagli dell'abbonamento, prioritizzando i dati dal database dell'utente
        const subPlan = user?.subscriptionPlan || localStorage.getItem('auralis_plan') || 'monthly';
        
        // Calcola la data di inizio
        let subDate: Date;
        if (user?.subscriptionStart) {
          subDate = new Date(user.subscriptionStart);
        } else if (localStorage.getItem('auralis_subscription_date')) {
          subDate = new Date(localStorage.getItem('auralis_subscription_date') as string);
        } else {
          subDate = new Date();
        }
        
        // Calcola la data di scadenza (basandosi su subscriptionEnd o calcolandola)
        let nextPaymentDate: Date;
        if (user?.subscriptionEnd) {
          nextPaymentDate = new Date(user.subscriptionEnd);
        } else {
          nextPaymentDate = new Date(subDate);
          
          if (subPlan === 'yearly') {
            nextPaymentDate.setFullYear(nextPaymentDate.getFullYear() + 1);
          } else {
            nextPaymentDate.setMonth(nextPaymentDate.getMonth() + 1);
          }
        }
        
        // Imposta il prezzo in base al piano scelto
        const price = subPlan === 'yearly' ? 39.99 : 4.99;
        
        // Formatta la data in base alla lingua corrente
        const dateFormat = i18n.language === 'it' ? 'it-IT' : 'en-US';
        
        setSubscriptionDetails({
          plan: subPlan,
          status: user?.subscriptionStatus || 'active',
          startDate: subDate.toISOString(),
          nextPaymentDate: nextPaymentDate.toLocaleDateString(dateFormat),
          price: price,
          subscriptionId: user?.stripeSubscriptionId || localStorage.getItem('auralis_subscription_id') || 'sub_simulated',
          customerId: user?.stripeCustomerId || localStorage.getItem('auralis_customer_id') || 'cus_simulated'
        });
        
        setLoading(false);
      } catch (error) {
        console.error('Errore durante la verifica dell\'abbonamento:', error);
        setError('Si è verificato un errore durante il recupero dei dettagli dell\'abbonamento.');
        setLoading(false);
      }
    };
    
    checkSubscription();
  }, [navigate, toast, isAuthenticated, user, i18n.language]);
  
  const handleCancelSubscription = async () => {
    // Conferma con l'utente
    if (window.confirm('Sei sicuro di voler cancellare il tuo abbonamento? Avrai comunque accesso ai contenuti premium fino alla fine del periodo di fatturazione corrente.')) {
      try {
        setLoading(true);
        
        // Utilizziamo la funzione centralizzata per cancellare l'abbonamento
        const success = await cancelSubscription();
        
        if (success) {
          // Mostra un messaggio di conferma
          toast({
            title: "Abbonamento cancellato",
            description: "Il tuo abbonamento è stato cancellato con successo. Continuerai ad avere accesso ai contenuti premium fino a " + subscriptionDetails.nextPaymentDate,
          });
          
          // Reindirizza alla home dopo un breve ritardo
          setTimeout(() => {
            navigate('/');
            // Forza un ricaricamento della pagina per aggiornare lo stato dell'abbonamento
            window.location.reload();
          }, 2000);
        } else {
          toast({
            title: "Errore",
            description: "Si è verificato un errore durante la cancellazione dell'abbonamento. Riprova più tardi.",
            variant: "destructive"
          });
        }
      } catch (error) {
        console.error('Errore durante la cancellazione dell\'abbonamento:', error);
        toast({
          title: "Errore",
          description: "Si è verificato un errore durante la cancellazione dell'abbonamento. Riprova più tardi.",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    }
  };
  
  const handleUpdatePaymentMethod = () => {
    // In un'applicazione reale, questa funzione redirigerebbe al portale clienti Stripe
    toast({
      title: "Funzionalità demo",
      description: "In un'app reale, questa azione ti permetterebbe di aggiornare il metodo di pagamento",
    });
  };
  
  const handleChangePlan = () => {
    // In un'applicazione reale, questa funzione redirigerebbe a una pagina per cambiare piano
    toast({
      title: "Funzionalità demo",
      description: "In un'app reale, questa azione ti permetterebbe di cambiare piano (mensile/annuale)",
    });
    navigate('/subscription');
  };
  
  const handleBack = () => {
    // Utilizziamo la navigazione diretta per tornare alla home
    window.location.href = '/';
  };
  
  // Stato di caricamento
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50 flex flex-col items-center justify-center">
        <div className="text-center p-8">
          <div className="w-16 h-16 rounded-full bg-amber-100 mx-auto flex items-center justify-center mb-4">
            <div className="w-8 h-8 border-4 border-amber-400 border-t-amber-600 rounded-full animate-spin"></div>
          </div>
          <h1 className="text-2xl font-bold text-amber-800 mb-2">{t('subscriptionManager.loading')}</h1>
          <p className="text-amber-600">{t('subscriptionManager.verifying')}</p>
        </div>
      </div>
    );
  }

  // Stato di errore
  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
        <ScrollToTop />
        <SimpleHeader />
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="w-16 h-16 rounded-full bg-red-100 mx-auto flex items-center justify-center mb-4">
            <AlertTriangle className="h-8 w-8 text-red-500" />
          </div>
          <h1 className="text-2xl font-bold text-red-800 mb-4">{t('subscriptionManager.error')}</h1>
          <p className="text-neutral-600 mb-8 max-w-md mx-auto">{error}</p>
          <Button onClick={() => window.location.href = '/'} className="bg-amber-600 hover:bg-amber-700">
            {t('subscriptionManager.backToHome')}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      <ScrollToTop />
      <SimpleHeader />
      
      <div className="container mx-auto px-4 py-12 max-w-3xl">
        <Button 
          variant="ghost" 
          className="mb-6 text-amber-700 hover:text-amber-800 hover:bg-amber-100"
          onClick={handleBack}
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> {t('subscriptionManager.backToHome')}
        </Button>
        
        <h1 className="text-2xl md:text-3xl font-bold text-amber-800 mb-6">{t('subscriptionManager.manage')}</h1>
        
        <div className="grid gap-6 md:grid-cols-3 mb-8">
          {/* Dettagli Abbonamento */}
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="mr-2 h-5 w-5 text-amber-600" /> 
                {t('subscriptionManager.details')}
              </CardTitle>
              <CardDescription>{t('subscriptionManager.info')}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between py-2 border-b">
                  <span className="text-neutral-600">{t('subscriptionManager.plan')}</span>
                  <span className="font-medium">
                    {subscriptionDetails.plan === 'yearly' 
                      ? t('subscriptionManager.yearlyPlan')
                      : t('subscriptionManager.monthlyPlan')}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-neutral-600">{t('subscriptionManager.status')}</span>
                  <span className="px-2 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-medium">
                    {t('subscriptionManager.active')}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-neutral-600">{t('subscriptionManager.nextPayment')}</span>
                  <span className="font-medium">{subscriptionDetails.nextPaymentDate}</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-neutral-600">{t('subscriptionManager.price')}</span>
                  <span className="font-medium">
                    {subscriptionDetails.plan === 'yearly' 
                      ? `€${subscriptionDetails.price.toFixed(2)}${t('subscription.perYear')}` 
                      : `€${subscriptionDetails.price.toFixed(2)}${t('subscription.perMonth')}`}
                  </span>
                </div>
                
                {subscriptionDetails.subscriptionId && (
                  <div className="pt-4 text-xs text-neutral-500">
                    {t('subscriptionManager.subscriptionId')}: {subscriptionDetails.subscriptionId}
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="flex-col items-start gap-4">
              <Alert className="border-amber-200 bg-amber-50 text-amber-800">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>{t('subscriptionManager.demoAlert')}</AlertTitle>
                <AlertDescription>
                  {t('subscriptionManager.demoDescription')}
                </AlertDescription>
              </Alert>
            </CardFooter>
          </Card>
          
          {/* Azioni */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bookmark className="mr-2 h-5 w-5 text-amber-600" /> 
                {t('subscriptionManager.actions')}
              </CardTitle>
              <CardDescription>{t('subscriptionManager.manageSubscription')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                variant="outline" 
                className="w-full justify-start border-gray-200"
                onClick={handleChangePlan}
              >
                <Calendar className="mr-2 h-4 w-4" /> 
                {t('subscriptionManager.changePlan')}
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full justify-start border-gray-200"
                onClick={handleUpdatePaymentMethod}
              >
                <CreditCard className="mr-2 h-4 w-4" /> 
                {t('subscriptionManager.updatePayment')}
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full justify-start text-red-500 border-gray-200 hover:border-red-200 hover:bg-red-50"
                onClick={handleCancelSubscription}
              >
                <AlertTriangle className="mr-2 h-4 w-4" /> 
                {t('subscriptionManager.cancel')}
              </Button>
            </CardContent>
          </Card>
        </div>
        
        {/* Informazioni aggiuntive */}
        <Card className="bg-white/80 border-amber-100">
          <CardHeader>
            <CardTitle className="flex items-center text-base">
              <Shield className="mr-2 h-5 w-5 text-amber-600" /> 
              {t('subscriptionManager.importantInfo')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-sm">
              <p>
                {t('subscriptionManager.autoRenewal')}
              </p>
              <p>
                {t('subscriptionManager.cancelInfo')}
              </p>
              <p className="flex items-center text-amber-600 mt-4">
                <ExternalLink className="mr-2 h-4 w-4" /> 
                <a href="#" className="hover:underline">{t('subscriptionManager.termsLink')}</a>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}