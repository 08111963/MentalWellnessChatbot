import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import Header from '@/components/Header';
import { ScrollToTop } from '@/components/ScrollToTop';
import { CheckCircle, CreditCard, ArrowRight, Check, Info, Shield, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { STRIPE_PRICES } from '@/lib/stripe-constants';
import { getQueryFn } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from "@/lib/auth-context";
import { useTranslation } from 'react-i18next';

export default function SubscriptionPage() {
  const [loading, setLoading] = useState<{monthly: boolean, yearly: boolean}>({monthly: false, yearly: false});
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [, navigate] = useLocation();
  const [stripeConfig, setStripeConfig] = useState<any>(null);
  const [showConfig, setShowConfig] = useState(false);
  const [configLoading, setConfigLoading] = useState(false);
  const { toast } = useToast();
  const auth = useAuth();
  const { t } = useTranslation();
  
  // Definition of the interface for the Stripe configuration response
  interface StripeConfigResponse {
    mode: string;
    isProduction: boolean;
    stripe_keys: {
      secret_key_present: boolean;
      publishable_key_present: boolean;
      webhook_secret_present: boolean;
    };
    prices: {
      stripe: {
        monthly: string;
        yearly: string;
      };
      simulation: {
        monthly: number;
        yearly: number;
      };
      display: {
        monthly: string;
        yearly: string;
      };
    };
    checkout_urls: {
      MONTHLY: string;
      YEARLY: string;
    };
    webhook_endpoints: {
      main: string;
    };
  }

  // Verify Stripe configuration
  const checkStripeConfig = async () => {
    try {
      setConfigLoading(true);
      
      const response = await fetch('/api/stripe/test-config');
      
      if (response.ok) {
        const data: StripeConfigResponse = await response.json();
        setStripeConfig(data);
        setShowConfig(true);
        toast({
          title: "Stripe Configuration",
          description: data.isProduction ? 
            "✅ Production mode active with Stripe keys" : 
            "⚠️ Simulation mode active without Stripe keys",
          variant: data.isProduction ? "default" : "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: `Unable to get Stripe configuration (${response.status})`,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error checking configuration:", error);
      toast({
        title: "Error",
        description: "An error occurred while verifying the configuration",
        variant: "destructive",
      });
    } finally {
      setConfigLoading(false);
    }
  };

  // Handles the subscription process
  const handleSubscribe = (plan: 'monthly' | 'yearly') => {
    try {
      setLoading(prev => ({...prev, [plan]: true}));
      setErrorMessage(null);
      
      // Verifica se l'utente è autenticato
      if (!auth.isAuthenticated || !auth.user) {
        // Memorizza il piano selezionato per riprendere dopo il login
        localStorage.setItem('selectedSubscriptionPlan', plan);
        
        // Mostra un breve messaggio prima di reindirizzare
        toast({
          title: "Accesso richiesto",
          description: "Sarai reindirizzato alla pagina di login",
          variant: "default",
        });
        
        // Reindirizza immediatamente alla home page con finestra di login aperta
        // e parametro returnTo per tornare alla pagina dell'abbonamento dopo il login
        window.location.href = '/?openAuth=true&returnTo=subscription';
        // Non è necessario reimpostare lo stato di caricamento poiché verrà ricaricata l'intera pagina
        
        return;
      }
      
      // Ottieni l'ID dell'utente dall'auth context
      const userId = auth.user.id;
      
      // Include l'ID utente nei parametri (ora obbligatorio)
      const queryParams = new URLSearchParams();
      queryParams.append('plan', plan);
      queryParams.append('userId', userId.toString());
      
      // Directly redirect to the endpoint that will handle server-side redirection
      // This approach works better with 302 redirects
      window.location.href = `/api/stripe/redirect-to-subscription?${queryParams.toString()}`;
      
      // No need to reset loading state because the page will be completely reloaded
    } catch (error) {
      console.error("Payment error:", error);
      setErrorMessage("An error occurred while processing your request. Please try again later.");
      setLoading(prev => ({...prev, [plan]: false}));
    }
  };

  // Plan prices
  const prices = {
    monthly: {
      amount: 4.99,
      currency: "€",
      period: "month"
    },
    yearly: {
      amount: 39.99,
      currency: "€",
      period: "year"
    }
  };

  // Calculate percentage savings
  const monthlyCost = prices.monthly.amount;
  const yearlyCost = prices.yearly.amount / 12;
  const savingsPercentage = Math.round((1 - (yearlyCost / monthlyCost)) * 100);

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      <ScrollToTop />
      <Header />
      
      <div className="container max-w-5xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-amber-800 mb-4">{t('subscriptionPage.title')}</h1>
          <p className="text-lg text-amber-700 max-w-2xl mx-auto">
            {t('subscriptionPage.subtitle')}
          </p>
        </div>
        
        {/* Login notice */}
        <Alert variant={auth.isAuthenticated ? "default" : "destructive"} className="mb-8">
          <AlertDescription>
            {auth.isAuthenticated 
              ? <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  {t('subscriptionPage.alreadyLoggedIn')}
                </div>
              : <div className="flex items-center">
                  <Info className="h-5 w-5 text-amber-500 mr-2" />
                  <div>
                    <p className="font-medium">{t('subscriptionPage.loginRequired')}</p>
                    <p className="text-sm mt-1">{t('subscriptionPage.loginRequiredDetails')}</p>
                  </div>
                </div>
            }
          </AlertDescription>
        </Alert>
        
        {/* Show any errors */}
        {errorMessage && (
          <Alert variant="destructive" className="mb-8">
            <AlertDescription>{errorMessage}</AlertDescription>
          </Alert>
        )}
        
        {/* Plan cards */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Annual Plan - Featured */}
          <Card className="relative border-amber-200 shadow-lg overflow-hidden">
            {/* Popular plan tag */}
            <div className="absolute top-0 right-0">
              <div className="bg-amber-500 text-white px-4 py-1 text-xs font-medium transform rotate-45 translate-x-4 translate-y-2 shadow-sm">
                {t('subscriptionPage.recommended')}
              </div>
            </div>
            
            <CardHeader className="bg-gradient-to-r from-amber-100 to-amber-50">
              <CardTitle className="text-2xl font-bold text-amber-800">{t('subscriptionPage.annualPlan')}</CardTitle>
              <CardDescription className="text-amber-700 font-medium">{t('subscriptionPage.bestValue')}</CardDescription>
            </CardHeader>
            
            <CardContent className="pt-6">
              <div className="mb-6 text-center">
                <p className="text-4xl font-bold text-amber-800">
                  {prices.yearly.currency}{prices.yearly.amount}
                  <span className="text-base font-normal text-amber-600">/{prices.yearly.period}</span>
                </p>
                <p className="text-amber-600 mt-1">
                  {t('subscriptionPage.equivalentTo', { currency: prices.yearly.currency, cost: yearlyCost.toFixed(2) })}
                </p>
                <div className="inline-flex mt-2 items-center justify-center bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                  <Check className="mr-1 h-4 w-4" /> {t('subscriptionPage.savePercent', { percent: savingsPercentage })}
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <h3 className="font-medium text-amber-800 mb-3">{t('subscriptionPage.includes')}:</h3>
              
              <ul className="space-y-3 mb-4">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 shrink-0" />
                  <span>{t('subscriptionPage.features.premiumExercises')}</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 shrink-0" />
                  <span>{t('subscriptionPage.features.guidedMeditations')}</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 shrink-0" />
                  <span>{t('subscriptionPage.features.noLimits')}</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 shrink-0" />
                  <span>{t('subscriptionPage.features.priorityAccess')}</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 shrink-0" />
                  <span>{t('subscriptionPage.features.adFree')}</span>
                </li>
              </ul>
            </CardContent>
            
            <CardFooter className="flex-col pt-0">
              <Button 
                className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white shadow-md"
                size="lg"
                onClick={() => handleSubscribe("yearly")}
                disabled={loading.yearly}
              >
                {loading.yearly ? (
                  <div className="flex items-center">
                    <div className="mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                    {t('subscriptionPage.processing')}
                  </div>
                ) : (
                  <div className="flex items-center">
                    <CreditCard className="mr-2 h-5 w-5" /> {t('subscriptionPage.subscribeNow')}
                  </div>
                )}
              </Button>
              
              <p className="text-xs text-center text-amber-600 mt-3">
                <Info className="inline h-3 w-3 mr-1" /> 
                {t('subscriptionPage.autoRenewal')}
              </p>
            </CardFooter>
          </Card>
          
          {/* Monthly Plan */}
          <Card className="border-neutral-200">
            <CardHeader className="bg-gradient-to-r from-neutral-100 to-neutral-50">
              <CardTitle className="text-xl font-bold text-neutral-800">{t('subscriptionPage.monthlyPlan')}</CardTitle>
              <CardDescription className="text-neutral-600">{t('subscriptionPage.maxFlexibility')}</CardDescription>
            </CardHeader>
            
            <CardContent className="pt-6">
              <div className="mb-6 text-center">
                <p className="text-3xl font-bold text-neutral-800">
                  {prices.monthly.currency}{prices.monthly.amount}
                  <span className="text-base font-normal text-neutral-600">/{prices.monthly.period}</span>
                </p>
                <p className="text-neutral-500 mt-1">
                  {t('subscriptionPage.monthlyBilling')}
                </p>
              </div>
              
              <Separator className="my-6" />
              
              <h3 className="font-medium text-neutral-800 mb-3">{t('subscriptionPage.includes')}:</h3>
              
              <ul className="space-y-3 mb-4">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-neutral-500 mt-0.5 mr-2 shrink-0" />
                  <span>{t('subscriptionPage.features.allContent')}</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-neutral-500 mt-0.5 mr-2 shrink-0" />
                  <span>{t('subscriptionPage.features.unlimitedRequests')}</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-neutral-500 mt-0.5 mr-2 shrink-0" />
                  <span>{t('subscriptionPage.features.adFree')}</span>
                </li>
              </ul>
            </CardContent>
            
            <CardFooter className="flex-col pt-0">
              <Button 
                className="w-full bg-white text-neutral-800 border border-neutral-300 hover:bg-neutral-50"
                size="lg"
                onClick={() => handleSubscribe("monthly")}
                disabled={loading.monthly}
              >
                {loading.monthly ? (
                  <div className="flex items-center">
                    <div className="mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                    {t('subscriptionPage.processing')}
                  </div>
                ) : (
                  <div className="flex items-center">
                    {t('subscriptionPage.chooseMonthly')} <ArrowRight className="ml-2 h-4 w-4" />
                  </div>
                )}
              </Button>
              
              <p className="text-xs text-center text-neutral-500 mt-3">
                <Info className="inline h-3 w-3 mr-1" /> 
                {t('subscriptionPage.canCancel')}
              </p>
            </CardFooter>
          </Card>
        </div>
        
        {/* Additional information */}
        <div className="bg-white rounded-lg shadow-md border border-amber-100 p-6 mb-8">
          <div className="flex items-start">
            <Shield className="h-6 w-6 text-amber-500 mt-1 mr-3 shrink-0" />
            <div>
              <h3 className="text-lg font-medium text-amber-800 mb-2">{t('subscriptionPage.infoSection.title')}</h3>
              <p className="text-neutral-600 mb-2">
                {t('subscriptionPage.infoSection.description1')}
              </p>
              <p className="text-neutral-600">
                {t('subscriptionPage.infoSection.description2')}
              </p>
            </div>
          </div>
        </div>
        
        {/* FAQ */}
        <div className="bg-white rounded-lg shadow-md border border-amber-100 p-6 mb-8">
          <h3 className="text-xl font-bold text-amber-800 mb-6">{t('subscriptionPage.faqSection.title')}</h3>
          
          <div className="space-y-6">
            <div>
              <h4 className="font-medium text-amber-800 mb-1">{t('subscriptionPage.faqSection.cancel.question')}</h4>
              <p className="text-neutral-600">
                {t('subscriptionPage.faqSection.cancel.answer')}
              </p>
            </div>
            
            <div>
              <h4 className="font-medium text-amber-800 mb-1">{t('subscriptionPage.faqSection.changePlan.question')}</h4>
              <p className="text-neutral-600">
                {t('subscriptionPage.faqSection.changePlan.answer')}
              </p>
            </div>
            
            <div>
              <h4 className="font-medium text-amber-800 mb-1">{t('subscriptionPage.faqSection.paymentMethods.question')}</h4>
              <p className="text-neutral-600">
                {t('subscriptionPage.faqSection.paymentMethods.answer')}
              </p>
            </div>
          </div>
        </div>
        
        {/* Test Stripe Configuration - only visible in development mode */}
        {import.meta.env.DEV && (
          <div className="bg-gray-50 rounded-lg border border-gray-200 p-4 mb-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <ExternalLink className="h-5 w-5 text-gray-600 mr-2 shrink-0" />
                <span className="text-gray-700 font-medium">Verify Stripe configuration</span>
              </div>
              <Button
                variant="outline" 
                size="sm"
                onClick={checkStripeConfig}
                disabled={configLoading}
              >
                {configLoading ? (
                  <div className="flex items-center">
                    <div className="mr-2 h-3 w-3 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                    Verifying...
                  </div>
                ) : (
                  "Verify configuration"
                )}
              </Button>
            </div>
            
            {showConfig && stripeConfig && (
              <div className="mt-4 p-3 bg-gray-100 rounded text-xs font-mono overflow-auto max-h-64">
                <pre className="whitespace-pre-wrap break-words">
                  {JSON.stringify(stripeConfig, null, 2)}
                </pre>
                <div className="mt-3 flex justify-end">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setShowConfig(false)}
                  >
                    Close
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
        
        {/* Download App Button */}
        <div className="bg-white rounded-lg shadow-md border border-amber-100 p-6 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium text-amber-800 mb-2">{t('qrcode.dialog_title')}</h3>
              <p className="text-neutral-600">
                {t('qrcode.dialog_description')}
              </p>
            </div>
            <Button
              onClick={() => navigate('/qrcode')}
              className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white shadow-md"
            >
              <i className="ri-qr-code-line mr-2"></i>
              {t('qrcode.button_text')}
            </Button>
          </div>
        </div>
        
        {/* Footer navigation */}
        <div className="mt-8 text-center">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="text-amber-700 hover:text-amber-800 hover:bg-amber-100"
          >
            {t('common.back')}
          </Button>
        </div>
      </div>
    </div>
  );
}