import React from 'react';
import { type Module } from '@/lib/types';
import { Link } from 'wouter';

interface QuickAccessModulesProps {
  modules: Module[];
}

const QuickAccessModules: React.FC<QuickAccessModulesProps> = ({ modules }) => {
  // Funzione per ottenere le classi corrette in base al colore del modulo
  const getModuleClasses = (moduleColor: string) => {
    // Classi per gli header dei moduli
    const headerClasses = {
      'blue-600': 'bg-blue-600',
      'emerald-600': 'bg-emerald-600',
      'purple-600': 'bg-purple-600',
      'amber-600': 'bg-amber-600',
      'rose-600': 'bg-rose-600',
      'indigo-600': 'bg-indigo-600',
      'cyan-600': 'bg-cyan-600',
      'teal-600': 'bg-teal-600'
    };
    
    // Classi per gli bordi dei moduli al passaggio del mouse
    const borderClasses = {
      'blue-600': 'hover:border-blue-600',
      'emerald-600': 'hover:border-emerald-600',
      'purple-600': 'hover:border-purple-600',
      'amber-600': 'hover:border-amber-600',
      'rose-600': 'hover:border-rose-600',
      'indigo-600': 'hover:border-indigo-600',
      'cyan-600': 'hover:border-cyan-600',
      'teal-600': 'hover:border-teal-600'
    };
    
    return {
      header: headerClasses[moduleColor as keyof typeof headerClasses] || 'bg-primary',
      border: borderClasses[moduleColor as keyof typeof borderClasses] || 'hover:border-primary'
    };
  };

  return (
    <div>
      <h3 className="font-nunito font-semibold text-xl mb-4 text-neutral-800">Support Modules</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {modules.map((module) => {
          const moduleClasses = getModuleClasses(module.color);
          
          return (
            <div 
              key={module.id}
              className={`bg-white rounded-lg shadow-sm overflow-hidden border border-neutral-200 ${moduleClasses.border} transition-colors hover:shadow-md`}
            >
              <div className={`h-32 ${moduleClasses.header} flex items-center justify-center`}>
                <i className={`${module.icon} text-white text-5xl`}></i>
              </div>
              <div className="p-4">
                <h4 className="font-nunito font-semibold text-lg">{module.title}</h4>
                <p className="text-sm text-neutral-600 mt-1 mb-3">{module.description}</p>
                <Link 
                  to={module.route} 
                  className="btn-action bg-primary text-white px-4 py-2 rounded-md text-sm font-semibold flex items-center justify-center hover:bg-primary/90 transition-colors"
                >
                  {module.isPremium ? (
                    <span className="flex items-center">
                      Start now 
                      <i className="ri-vip-crown-fill ml-2 text-amber-300"></i>
                    </span>
                  ) : (
                    <span className="flex items-center">
                      Start now
                      <i className="ri-arrow-right-line ml-1"></i>
                    </span>
                  )}
                </Link>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default QuickAccessModules;
