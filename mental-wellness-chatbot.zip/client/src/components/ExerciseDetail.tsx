import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { type Exercise } from '@/lib/types';
import { useTranslation } from 'react-i18next';

interface ExerciseDetailProps {
  exercise: Exercise;
  onBack: () => void;
  isCompleted?: boolean;
  onComplete?: (id: number) => void;
  note?: string;
  onSaveNote?: (id: number, note: string) => void;
}

export function ExerciseDetail({ 
  exercise, 
  onBack,
  isCompleted = false,
  onComplete,
  note = '',
  onSaveNote
}: ExerciseDetailProps) {
  const { t } = useTranslation();
  const [noteText, setNoteText] = useState(note);
  const [timerActive, setTimerActive] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const timerRef = useRef<number | null>(null);
  
  // Log per debugging
  console.log("ExerciseDetail props:", { 
    id: exercise.id,
    title: exercise.title,
    isCompleted, 
    hasOnComplete: !!onComplete
  });
  
  useEffect(() => {
    // Clean up timer on unmount
    return () => {
      if (timerRef.current !== null) {
        window.clearInterval(timerRef.current);
      }
    };
  }, []);
  
  // Formatta i secondi in formato mm:ss
  function formatTime(seconds: number) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  
  // Avvia o mette in pausa il timer
  function toggleTimer() {
    if (timerActive) {
      if (timerRef.current !== null) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
      setTimerActive(false);
    } else {
      timerRef.current = window.setInterval(() => {
        setTimerSeconds(prev => prev + 1);
      }, 1000);
      setTimerActive(true);
    }
  }
  
  // Resetta il timer
  function resetTimer() {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setTimerActive(false);
    setTimerSeconds(0);
  }
  
  // Completa un esercizio
  function handleComplete() {
    console.log("Chiamata a handleComplete con ID:", exercise.id);
    if (onComplete) {
      onComplete(exercise.id);
    } else {
      console.error("La callback onComplete non è disponibile");
    }
  }
  
  // Salva una nota
  function handleSaveNote() {
    console.log("Chiamata a handleSaveNote con ID:", exercise.id);
    if (onSaveNote) {
      onSaveNote(exercise.id, noteText);
    } else {
      console.error("La callback onSaveNote non è disponibile");
    }
  }
  
  return (
    <div className="exercise-detail">
      <Button 
        variant="ghost" 
        className="mb-4 btn-secondary"
        onClick={onBack}
      >
        <i className="ri-arrow-left-line mr-2"></i> {t("exerciseDetail.backToList")}
      </Button>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>{exercise.title}</CardTitle>
              <CardDescription>
                {t("exerciseDetail.category")} {exercise.category}
              </CardDescription>
            </div>
            {isCompleted && (
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                <i className="ri-check-line mr-1"></i> {t("exerciseDetail.completed")}
              </Badge>
            )}
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="mb-6">
            <p className="text-neutral-600">{exercise.description}</p>
          </div>
          
          {exercise.category.toLowerCase().includes('mindful') && (
            <div className="mb-6 p-4 bg-primary/5 rounded-lg">
              <h3 className="font-semibold mb-2">{t("exerciseDetail.mindfulnessTimer")}</h3>
              <div className="flex items-center justify-between">
                <div className="text-2xl font-mono">{formatTime(timerSeconds)}</div>
                <div className="space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={toggleTimer}
                    className={timerActive ? "bg-red-50 text-red-600 hover:bg-red-100 hover:text-red-700" : "btn-action"}
                  >
                    {timerActive ? (
                      <><i className="ri-pause-fill mr-1"></i> {t("exerciseDetail.pause")}</>
                    ) : (
                      <><i className="ri-play-fill mr-1"></i> {t("exerciseDetail.start")}</>
                    )}
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={resetTimer}
                    disabled={timerSeconds === 0}
                    className="btn-secondary"
                  >
                    <i className="ri-restart-line mr-1"></i> {t("exerciseDetail.reset")}
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          <Separator className="my-4" />
          
          <div>
            <h3 className="font-semibold mb-4">{t("exerciseDetail.steps")}</h3>
            <ol className="list-decimal pl-5 space-y-2">
              {exercise.steps.map((step, index) => (
                <li key={index} className="text-neutral-700">{step}</li>
              ))}
            </ol>
          </div>
          
          <div className="mt-8 p-4 bg-secondary/10 rounded-lg">
            <div className="flex items-center">
              <i className="ri-lightbulb-line text-secondary text-xl mr-2"></i>
              <h4 className="font-semibold text-secondary">{t("exerciseDetail.tip")}</h4>
            </div>
            <p className="mt-2 text-sm">
              {t("exerciseDetail.tipText")}
            </p>
          </div>
          
          <div className="mt-6">
            <h3 className="font-semibold mb-2">{t("exerciseDetail.personalNotes")}</h3>
            <Textarea
              placeholder={t("exerciseDetail.notesPlaceholder")}
              className="min-h-[100px] resize-none"
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
            />
            <Button 
              variant="outline" 
              size="sm" 
              className="mt-2 btn-secondary"
              onClick={handleSaveNote}
            >
              <i className="ri-save-line mr-1"></i> {t("exerciseDetail.saveNote")}
            </Button>
          </div>
        </CardContent>
        
        <CardFooter>
          <div className="w-full">
            <Button 
              className={`w-full ${isCompleted 
                ? "bg-green-100 text-green-700 hover:bg-green-200" 
                : "btn-complete"
              }`}
              onClick={handleComplete}
            >
              {isCompleted ? (
                <><i className="ri-check-double-line mr-1"></i> {t("exerciseDetail.completed")}</>
              ) : (
                <><i className="ri-check-line mr-1"></i> {t("exerciseDetail.markAsCompleted")}</>
              )}
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}