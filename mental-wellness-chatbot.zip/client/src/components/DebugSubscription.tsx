import React from 'react';
import { useStripe } from '@/lib/stripe-context';
import { Button } from '@/components/ui/button';

export function DebugSubscription() {
  const { subscription, verifySubscription } = useStripe();

  const clearAllSubscriptionData = () => {
    // Rimuovi tutti i dati di abbonamento dal localStorage
    localStorage.removeItem('guida_subscription');
    localStorage.removeItem('auralis_premium');
    localStorage.removeItem('auralis_plan');
    localStorage.removeItem('auralis_subscription_id');
    localStorage.removeItem('auralis_customer_id');
    localStorage.removeItem('auralis_subscription_date');

    // Aggiorna lo stato verificando con il server
    verifySubscription();

    alert('Dati di abbonamento cancellati! La pagina sarà ricaricata.');
    window.location.reload();
  };

  return (
    <div className="p-4 border rounded-lg mb-4 bg-yellow-50">
      <h3 className="font-bold mb-2">Debug Abbonamento</h3>
      <div className="text-sm space-y-1 mb-3">
        <p>Stato: {subscription.isActive ? '✅ Attivo' : '❌ Non attivo'}</p>
        <p>Piano: {subscription.plan || 'Nessuno'}</p>
        <p>Scadenza: {subscription.expiresAt ? subscription.expiresAt.toLocaleString() : 'N/A'}</p>
        <p>Cliente ID: {subscription.customerId || 'N/A'}</p>
        <p>Abbonamento ID: {subscription.subscriptionId || 'N/A'}</p>
      </div>
      <div className="flex gap-2">
        <Button variant="destructive" size="sm" onClick={clearAllSubscriptionData}>
          Cancella tutti i dati abbonamento
        </Button>
        <Button size="sm" onClick={() => verifySubscription()}>
          Verifica stato abbonamento
        </Button>
      </div>
    </div>
  );
}