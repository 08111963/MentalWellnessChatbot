import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'wouter';
import { isProblematicPage } from '@/lib/home-navigation';

const BottomNavigation: React.FC = () => {
  // Usiamo useLocation di Wouter per ottenere e impostare il percorso corrente
  const [location, setLocation] = useLocation();
  const { t, i18n } = useTranslation();
  const [language, setLanguage] = useState(i18n.language);
  const isInProblematicPage = isProblematicPage();
  
  // Forza il rendering quando la lingua cambia
  useEffect(() => {
    const handleLanguageChange = () => {
      setLanguage(i18n.language);
      console.log("Language changed in BottomNavigation:", i18n.language);
    };
    
    i18n.on('languageChanged', handleLanguageChange);
    
    return () => {
      i18n.off('languageChanged', handleLanguageChange);
    };
  }, [i18n]);
  
  // Funzione per la navigazione che usa Wouter per migliorare le performance
  const navigateTo = (path: string) => {
    // SOLO se siamo in una pagina ESTREMAMENTE problematica E andiamo a casa, forziamo il refresh
    if (path === '/' && isInProblematicPage) {
      sessionStorage.setItem('force_home_navigation', 'true');
      window.location.replace('/');
      return;
    }
    
    // Per tutte le altre pagine, usiamo la navigazione Wouter che è più veloce
    setLocation(path);
  };
  
  // Aggiungiamo un pulsante Home
  const isHomePage = location === '/';
  
  return (
    <nav className="bg-white border-t border-neutral-200 fixed bottom-0 left-0 right-0 z-10 md:hidden">
      <div className="max-w-3xl mx-auto px-4">
        <div className="flex justify-around items-center h-16">
          {/* Pulsante Home */}
          <div 
            className="cursor-pointer" 
            onClick={() => { navigateTo('/'); }}
          >
            <div className={`flex flex-col items-center ${location === '/' ? 'text-primary' : 'text-neutral-500'}`}>
              <i className="ri-home-4-line text-xl"></i>
              <span className="text-xs mt-1">{t('navigation.home', 'Home')}</span>
            </div>
          </div>
          
          {/* Chat */}
          <div 
            className="cursor-pointer" 
            onClick={() => { navigateTo('/chat'); }}
          >
            <div className={`flex flex-col items-center ${location === '/chat' ? 'text-primary' : 'text-neutral-500'}`}>
              <i className="ri-chat-3-line text-xl"></i>
              <span className="text-xs mt-1">{t('navigation.chat', 'Chat')}</span>
            </div>
          </div>
          
          {/* Esercizi */}
          <div 
            className="cursor-pointer" 
            onClick={() => { navigateTo('/exercises'); }}
          >
            <div className={`flex flex-col items-center ${location === '/exercises' ? 'text-primary' : 'text-neutral-500'}`}>
              <i className="ri-mental-health-line text-xl"></i>
              <span className="text-xs mt-1">{t('navigation.exercises', 'Esercizi')}</span>
            </div>
          </div>
          
          {/* AI Moduli */}
          <div 
            className="cursor-pointer" 
            onClick={() => { navigateTo('/ai-modules'); }}
          >
            <div className={`flex flex-col items-center ${location === '/ai-modules' ? 'text-primary' : 'text-neutral-500'}`}>
              <i className="ri-robot-line text-xl"></i>
              <span className="text-xs mt-1">{t('navigation.aiModules', 'AI Moduli')}</span>
            </div>
          </div>
          
          {/* Riflessioni */}
          <div 
            className="cursor-pointer" 
            onClick={() => { navigateTo('/reflections'); }}
          >
            <div className={`flex flex-col items-center ${location === '/reflections' ? 'text-primary' : 'text-neutral-500'}`}>
              <i className="ri-book-2-line text-xl"></i>
              <span className="text-xs mt-1">{t('navigation.reflections', 'Riflessioni')}</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default BottomNavigation;
