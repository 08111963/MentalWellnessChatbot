import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

const DisclaimerBanner: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [language, setLanguage] = useState(i18n.language);
  
  // Forza il rendering quando la lingua cambia
  useEffect(() => {
    const handleLanguageChange = () => {
      setLanguage(i18n.language);
      console.log("Language changed in DisclaimerBanner:", i18n.language);
    };
    
    i18n.on('languageChanged', handleLanguageChange);
    
    return () => {
      i18n.off('languageChanged', handleLanguageChange);
    };
  }, [i18n]);
  
  return (
    <div className="bg-amber-50 border-l-4 border-amber-400 p-4 rounded-md mb-6 shadow-sm">
      <div className="flex">
        <div className="flex-shrink-0">
          <i className="ri-information-line text-amber-500 text-xl"></i>
        </div>
        <div className="ml-3">
          <p className="text-sm text-amber-800">
            <span className="font-medium">{t('disclaimer.notice')}:</span> {t('disclaimer.content')}
          </p>
        </div>
      </div>
    </div>
  );
};

export default DisclaimerBanner;
