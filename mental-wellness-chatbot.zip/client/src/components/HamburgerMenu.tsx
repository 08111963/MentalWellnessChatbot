import React, { useState, useEffect } from 'react';
import { isProblematicPage } from '@/lib/home-navigation';
import { useAuth } from '@/lib/auth-context';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'wouter';

interface HamburgerMenuProps {
  className?: string;
}

const HamburgerMenu: React.FC<HamburgerMenuProps> = ({ className = "" }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [location, setLocation] = useLocation();
  const currentPath = location;
  const isInProblematicPage = isProblematicPage();
  const { isAdmin } = useAuth();
  const { t } = useTranslation();

  // Forza chiusura del menu quando si cambia pagina
  useEffect(() => {
    setIsOpen(false);
  }, [currentPath]);
  
  // Funzione di navigazione ottimizzata con Wouter
  const navigateTo = (path: string) => {
    // Chiudi il menu
    setIsOpen(false);
    
    // Se andiamo alla home e siamo in una pagina problematica, forza il refresh
    // per evitare problemi specifici con alcune pagine
    if (path === '/' && isInProblematicPage) {
      sessionStorage.setItem('force_home_navigation', 'true');
      window.location.href = '/';
      return;
    }
    
    // Per tutte le altre pagine, utilizza il router per navigazione veloce
    setLocation(path);
  };

  // Lista dei moduli disponibili nell'app
  const modules = [
    { name: t('navigation.home', 'Home'), path: '/', icon: 'ri-home-4-line' },
    { name: t('navigation.chat', 'Chat'), path: '/chat', icon: 'ri-chat-3-line' },
    { name: t('navigation.exercises', 'Exercises'), path: '/exercises', icon: 'ri-mental-health-line' },
    { name: t('navigation.meditation', 'Meditation'), path: '/meditation', icon: 'ri-emotion-happy-line' },
    { name: t('navigation.reflections', 'Reflections'), path: '/reflections', icon: 'ri-book-2-line' },
    { name: t('navigation.mood', 'Mood'), path: '/mood', icon: 'ri-emotion-line' },
    { name: t('navigation.aiModules', 'AI Modules'), path: '/ai-modules', icon: 'ri-robot-line' },
    { name: t('navigation.resources', 'Resources'), path: '/resources', icon: 'ri-book-mark-line' },
    { name: t('navigation.premium', 'Premium'), path: '/subscription', icon: 'ri-vip-crown-line' },
    { name: t('navigation.downloadApp', 'Scarica App'), path: '/qrcode', icon: 'ri-qr-code-line' },
    { name: t('navigation.help', 'Help'), path: '/app-guide', icon: 'ri-question-line' },
  ];

  return (
    <div className={`relative z-50 ${className}`}>
      {/* Pulsante hamburger */}
      <button
        className="p-2 text-neutral-700 hover:text-purple-600 focus:outline-none transition-colors"
        onClick={() => setIsOpen(!isOpen)}
        aria-label={isOpen ? t('menu.close', 'Close menu') : t('menu.open', 'Open menu')}
      >
        {isOpen ? (
          <i className="ri-close-line text-2xl"></i>
        ) : (
          <i className="ri-menu-line text-2xl"></i>
        )}
      </button>

      {/* Menu dropdown */}
      {isOpen && (
        <>
          {/* Overlay per chiudere il menu cliccando fuori */}
          <div 
            className="fixed inset-0 bg-black/20 backdrop-blur-sm"
            onClick={() => setIsOpen(false)}
          ></div>
          
          {/* Menu contenuto */}
          <div className="absolute right-0 top-12 w-60 bg-white rounded-lg shadow-xl border border-neutral-200 overflow-hidden animate-in slide-in-from-top-5 duration-200">
            <div className="py-2">
              {modules.map((module) => (
                <div
                  key={module.path}
                  className={`flex items-center px-4 py-3 cursor-pointer transition-colors ${
                    currentPath === module.path
                      ? 'bg-purple-50 text-purple-700'
                      : 'hover:bg-neutral-50'
                  }`}
                  onClick={() => navigateTo(module.path)}
                >
                  <i className={`${module.icon} text-lg mr-3 ${
                    currentPath === module.path ? 'text-purple-600' : 'text-neutral-500'
                  }`}></i>
                  <span className="font-medium text-sm">{module.name}</span>
                  
                  {currentPath === module.path && (
                    <div className="ml-auto w-1.5 h-5 bg-purple-600 rounded-full"></div>
                  )}
                </div>
              ))}
            </div>
            
            {/* Sezione Admin */}
            {isAdmin && (
              <div className="border-t border-neutral-200 pt-2">
                <div
                  className={`flex items-center px-4 py-3 cursor-pointer transition-colors ${
                    currentPath === '/admin'
                      ? 'bg-amber-50 text-amber-700'
                      : 'hover:bg-neutral-50 text-amber-600'
                  }`}
                  onClick={() => navigateTo('/admin')}
                >
                  <i className={`ri-settings-3-line text-lg mr-3 ${
                    currentPath === '/admin' ? 'text-amber-600' : 'text-amber-500'
                  }`}></i>
                  <span className="font-medium text-sm">{t('navigation.admin', 'Administration')}</span>
                  
                  {currentPath === '/admin' && (
                    <div className="ml-auto w-1.5 h-5 bg-amber-500 rounded-full"></div>
                  )}
                </div>
              </div>
            )}
            
            {/* Tour direttamente nella versione */}
            
            <div className="border-t border-neutral-200 p-4">
              <div className="text-xs text-center text-neutral-500">
                Auralis v1.0
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default HamburgerMenu;