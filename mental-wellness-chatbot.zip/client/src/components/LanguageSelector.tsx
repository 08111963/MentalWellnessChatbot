import React, { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Globe } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const languages = [
  { code: 'it', name: 'Italiano' },
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
  { code: 'de', name: 'Deutsch' }
];

export function LanguageSelector() {
  const { i18n, t } = useTranslation();
  const { toast } = useToast();

  // Ottieni la lingua corrente (prime 2 lettere, es. 'it' da 'it-IT')
  const currentLang = i18n.language.substring(0, 2);

  // Funzione per cambiare lingua senza ricaricare la pagina
  const changeLanguage = useCallback((lang: string) => {
    if (lang === currentLang) return; // Se è già la lingua corrente, non fare nulla
    
    console.log('Changing language to:', lang);
    
    try {
      // Salva in localStorage
      localStorage.setItem('i18nextLng', lang);
      
      // Cambia la lingua in i18n
      i18n.changeLanguage(lang);
      
      // Non mostriamo più il toast di conferma
      // Il cambio avviene silenziosamente
      
    } catch (err) {
      console.error('Error changing language:', err);
      toast({
        title: t('languages.error', 'Error'),
        description: t('languages.errorChanging', 'Error changing language'),
        variant: 'destructive'
      });
    }
  }, [i18n, currentLang, t, toast]);

  return (
    <div className="inline-flex items-center">
      <Globe className="h-4 w-4 mr-1 text-blue-500" />
      <select
        value={currentLang}
        onChange={(e) => changeLanguage(e.target.value)}
        className="bg-blue-50 border border-blue-300 text-blue-800 font-medium text-xs rounded-md py-1 px-2 shadow focus:outline-none focus:ring-1 focus:ring-blue-500"
      >
        {languages.map((lang) => (
          <option key={lang.code} value={lang.code}>
            {lang.code.toUpperCase()}
          </option>
        ))}
      </select>
    </div>
  );
}