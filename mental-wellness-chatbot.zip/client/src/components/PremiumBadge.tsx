import React from 'react';
import { Badge } from './ui/badge';
import { Lock, Check } from 'lucide-react';
import { useStripe } from '../lib/stripe-context';
import { useAuth } from '../lib/auth-context';

interface PremiumBadgeProps {
  className?: string;
  alwaysShow?: boolean;
}

export function PremiumBadge({ className = '', alwaysShow = false }: PremiumBadgeProps) {
  const { isSubscriptionActive } = useStripe();
  const { isAdmin } = useAuth();
  
  // Se l'utente ha già l'abbonamento attivo o è admin, e non è forzato a mostrare il badge,
  // allora non mostriamo il badge premium (a meno che alwaysShow sia true)
  if ((isSubscriptionActive() || isAdmin) && !alwaysShow) {
    return null;
  }
  
  return (
    <Badge 
      variant="outline" 
      className={`bg-amber-500 text-white border-0 flex items-center gap-1 px-2 py-1 ${className}`}
    >
      <Lock className="h-3 w-3" />
      <span className="text-xs">Premium</span>
    </Badge>
  );
}