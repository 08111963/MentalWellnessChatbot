import React, { useCallback } from 'react';
import { Link } from 'wouter';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/lib/auth-context';
import { useStripe } from '@/lib/stripe-context';
import { type Meditation } from '@/lib/types';

interface MeditationModuleCardProps {
  meditation: Meditation;
  compact?: boolean;
  onClick?: (meditation: Meditation) => void;
}

export const MeditationModuleCard: React.FC<MeditationModuleCardProps> = ({ 
  meditation, 
  compact = false,
  onClick
}) => {
  const { t } = useTranslation();
  const { isAdmin } = useAuth();
  const { isSubscriptionActive } = useStripe();
  
  // Funzione per determinare il colore in base al titolo della meditazione
  const getCardColor = (title: string) => {
    // Assegnazione diretta di colori specifici per ogni titolo per massima differenziazione
    
    // Meditazioni specifiche
    if (title === "Respirazione Consapevole" || title === "Mindful Breathing") {
      return "bg-gradient-to-r from-sky-400 to-blue-500"; // Blu
    } else if (title === "Body Scan Rilassante" || title === "Relaxing Body Scan") {
      return "bg-gradient-to-r from-purple-600 to-fuchsia-500"; // Viola/fucsia
    } else if (title === "Radici del Presente" || title === "Roots of the Present") {
      return "bg-gradient-to-r from-emerald-600 to-green-500"; // Verde
    } else if (title === "Giardino del Cuore" || title === "Heart Garden") {
      return "bg-gradient-to-r from-red-500 to-rose-500"; // Rosso/rosa
    } else if (title === "Meditazione della Montagna" || title === "Mountain Meditation") {
      return "bg-gradient-to-r from-amber-500 to-yellow-400"; // Giallo/ambra
    } else if (title === "Meditazione di Autocompassione" || title === "Self-Compassion Meditation") {
      return "bg-gradient-to-r from-violet-600 to-indigo-600"; // Violetto/indaco
    } else if (title === "Meditazione del Lago" || title === "Lake Meditation") {
      return "bg-gradient-to-r from-teal-500 to-cyan-400"; // Teal/ciano
    } else if (title === "Meditazione per il Sonno Profondo" || title === "Deep Sleep Meditation") {
      return "bg-gradient-to-r from-indigo-900 to-blue-800"; // Blu scuro
    } else if (title === "Meditazione della Gratitudine" || title === "Gratitude Meditation") {
      return "bg-gradient-to-r from-lime-500 to-green-500"; // Verde lime
    } else if (title === "Meditazione Camminata" || title === "Walking Meditation") {
      return "bg-gradient-to-r from-orange-500 to-red-500"; // Arancione/rosso
    } 
    
    // Backup per eventuali nuove meditazioni future (basato su parole chiave)
    else {
      const lcTitle = title.toLowerCase();
      
      if (lcTitle.includes('respir') || lcTitle.includes('breath')) {
        return "bg-gradient-to-r from-blue-600 to-blue-400"; 
      } else if (lcTitle.includes('corpo') || lcTitle.includes('body')) {
        return "bg-gradient-to-r from-fuchsia-600 to-pink-400"; 
      } else if (lcTitle.includes('radici')) {
        return "bg-gradient-to-r from-green-700 to-green-500"; 
      } else if (lcTitle.includes('cuore') || lcTitle.includes('heart')) {
        return "bg-gradient-to-r from-rose-600 to-red-400"; 
      } else if (lcTitle.includes('montagna') || lcTitle.includes('mountain')) {
        return "bg-gradient-to-r from-yellow-500 to-amber-300"; 
      } else if (lcTitle.includes('compassion')) {
        return "bg-gradient-to-r from-indigo-700 to-purple-500"; 
      } else if (lcTitle.includes('lake') || lcTitle.includes('lago')) {
        return "bg-gradient-to-r from-cyan-600 to-blue-400"; 
      } else if (lcTitle.includes('sonno') || lcTitle.includes('sleep')) {
        return "bg-gradient-to-r from-blue-900 to-indigo-700"; 
      } else if (lcTitle.includes('gratitud') || lcTitle.includes('thank')) {
        return "bg-gradient-to-r from-green-600 to-lime-400"; 
      } else if (lcTitle.includes('cammin') || lcTitle.includes('walk')) {
        return "bg-gradient-to-r from-red-600 to-orange-400";
      } else {
        // Colore predefinito per eventuali altre meditazioni
        return "bg-gradient-to-r from-neutral-700 to-neutral-500";
      }
    }
  };
  
  // Ottieni il colore per questa meditazione
  const cardColor = getCardColor(meditation.title);
  
  // Colore del bottone - aggiornato per utilizzare colori più distinguibili con corrispondenza diretta alle intestazioni
  const getButtonClass = (title: string) => {
    // Bottone corrispondente alle meditazioni specifiche (stessa logica del colore card)
    if (title === "Respirazione Consapevole" || title === "Mindful Breathing") {
      return "text-sky-600 hover:text-sky-600 hover:bg-sky-50"; // Blu cielo
    } else if (title === "Body Scan Rilassante" || title === "Relaxing Body Scan") {
      return "text-fuchsia-600 hover:text-fuchsia-600 hover:bg-fuchsia-50"; // Fucsia
    } else if (title === "Radici del Presente" || title === "Roots of the Present") {
      return "text-emerald-600 hover:text-emerald-600 hover:bg-emerald-50"; // Smeraldo
    } else if (title === "Giardino del Cuore" || title === "Heart Garden") {
      return "text-red-600 hover:text-red-600 hover:bg-red-50"; // Rosso
    } else if (title === "Meditazione della Montagna" || title === "Mountain Meditation") {
      return "text-yellow-600 hover:text-yellow-600 hover:bg-yellow-50"; // Giallo
    } else if (title === "Meditazione di Autocompassione" || title === "Self-Compassion Meditation") {
      return "text-violet-600 hover:text-violet-600 hover:bg-violet-50"; // Viola
    } else if (title === "Meditazione del Lago" || title === "Lake Meditation") {
      return "text-teal-600 hover:text-teal-600 hover:bg-teal-50"; // Teal
    } else if (title === "Meditazione per il Sonno Profondo" || title === "Deep Sleep Meditation") {
      return "text-indigo-800 hover:text-indigo-800 hover:bg-indigo-50"; // Indaco scuro
    } else if (title === "Meditazione della Gratitudine" || title === "Gratitude Meditation") {
      return "text-lime-600 hover:text-lime-600 hover:bg-lime-50"; // Lime
    } else if (title === "Meditazione Camminata" || title === "Walking Meditation") {
      return "text-orange-600 hover:text-orange-600 hover:bg-orange-50"; // Arancione
    } 
    
    // Backup per eventuali nuove meditazioni future (basato su parole chiave)
    else {
      const lcTitle = title.toLowerCase();
      
      if (lcTitle.includes('respir') || lcTitle.includes('breath')) {
        return "text-blue-600 hover:text-blue-600 hover:bg-blue-50";
      } else if (lcTitle.includes('corpo') || lcTitle.includes('body')) {
        return "text-fuchsia-700 hover:text-fuchsia-700 hover:bg-fuchsia-50";
      } else if (lcTitle.includes('radici')) {
        return "text-green-700 hover:text-green-700 hover:bg-green-50";
      } else if (lcTitle.includes('cuore') || lcTitle.includes('heart')) {
        return "text-rose-600 hover:text-rose-600 hover:bg-rose-50";
      } else if (lcTitle.includes('montagna') || lcTitle.includes('mountain')) {
        return "text-amber-600 hover:text-amber-600 hover:bg-amber-50";
      } else if (lcTitle.includes('compassion')) {
        return "text-purple-600 hover:text-purple-600 hover:bg-purple-50";
      } else if (lcTitle.includes('lake') || lcTitle.includes('lago')) {
        return "text-cyan-600 hover:text-cyan-600 hover:bg-cyan-50";
      } else if (lcTitle.includes('sonno') || lcTitle.includes('sleep')) {
        return "text-blue-900 hover:text-blue-900 hover:bg-blue-50";
      } else if (lcTitle.includes('gratitud') || lcTitle.includes('thank')) {
        return "text-green-600 hover:text-green-600 hover:bg-green-50";
      } else if (lcTitle.includes('cammin') || lcTitle.includes('walk')) {
        return "text-red-500 hover:text-red-500 hover:bg-red-50";
      } else {
        // Colore predefinito
        return "text-gray-600 hover:text-gray-600 hover:bg-gray-50";
      }
    }
  };

  const handleCardClick = useCallback(() => {
    if (onClick) onClick(meditation);
  }, [meditation, onClick]);

  // Verifica se l'utente può accedere a questa meditazione
  const canAccess = !meditation.isPremium || isAdmin || isSubscriptionActive();
  
  return (
    <Card 
      key={meditation.id} 
      className={`meditation-card cursor-pointer hover:shadow-md transition-shadow ${compact ? 'h-full' : ''}`}
      onClick={handleCardClick}
    >
      <CardHeader 
        className={`${meditation.isPremium 
          ? 'bg-gradient-to-br from-yellow-400 via-amber-500 to-amber-700' 
          : cardColor} 
          text-white ${compact ? 'p-3' : 'p-4'}
        `}
      >
        <div className="flex items-center justify-between relative z-10">
          <div>
            <CardTitle className={`flex items-center font-bold ${compact ? 'text-sm' : 'text-base'}`}>
              {meditation.isPremium ? (
                <span className="text-yellow-100 drop-shadow-md">
                  {meditation.title === "Meditazione della Montagna" ? (
                    "Vette di Serenità"
                  ) : meditation.title === "Meditazione di Autocompassione" ? (
                    "Abbraccio Interiore"
                  ) : (
                    meditation.title
                  )}
                </span>
              ) : (
                <span className="text-white drop-shadow-[0px_1px_2px_rgba(0,0,0,0.6)]">
                  {meditation.title}
                </span>
              )}
              {(() => {
                // Verifichiamo se nascondere il badge PREMIUM
                const showPremiumBadge = meditation.isPremium && 
                  (!isSubscriptionActive() && !isAdmin);
                
                return showPremiumBadge ? (
                  <div className={`ml-2 bg-white text-amber-600 text-xs px-2 py-1 rounded-full font-bold flex items-center shadow-md ${compact ? 'text-[10px] px-1.5 py-0.5' : ''}`}>
                    <span className="mr-1 text-yellow-500">⭐</span>PREMIUM
                  </div>
                ) : null;
              })()}
            </CardTitle>
            <div className={`text-white opacity-90 flex items-center gap-2 ${compact ? 'text-xs' : 'text-sm'}`}>
              {meditation.duration} {t('meditation.minutes', 'minuti')}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className={compact ? 'p-3' : 'p-4'}>
        <p className={`text-neutral-600 ${compact ? 'text-xs line-clamp-2' : 'text-sm'}`}>
          {meditation.description}
        </p>
      </CardContent>
      <CardFooter className={`pt-0 ${compact ? 'pb-3 px-3' : 'pb-4 px-4'}`}>
        {/* Verifichiamo anche il sistema legacy per la visualizzazione del bottone */}
        {(() => {
          const needsPremium = meditation.isPremium && !isAdmin && !isSubscriptionActive();
          
          return (
            <Button 
              variant={needsPremium ? "default" : "ghost"}
              className={needsPremium
                ? "bg-amber-500 hover:bg-amber-600 text-white w-full"
                : `${getButtonClass(meditation.title)} btn-action`
              }
              size={compact ? "sm" : "default"}
            >
              {needsPremium ? t('meditation.unlockWithPremium', 'Sblocca con Premium') : t('meditation.startMeditation', 'Inizia meditazione')}
            </Button>
          );
        })()}
      </CardFooter>
    </Card>
  );
};

export default MeditationModuleCard;