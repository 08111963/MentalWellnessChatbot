import React, { useState, useEffect } from 'react';
import { Lock, Sparkles, RefreshCcw } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { useStripe } from '../lib/stripe-context';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../lib/auth-context';

interface PremiumContentProps {
  title: string;
  description: string;
  onSubscribe: () => void;
  type: 'exercise' | 'meditation' | 'mood';
}

export function PremiumContent({ title, description, onSubscribe, type }: PremiumContentProps) {
  const { isSubscriptionActive, subscription, verifySubscription } = useStripe();
  const { t, i18n } = useTranslation();
  const isEnglish = i18n.language === 'en';
  const { user } = useAuth();
  const [isVerifying, setIsVerifying] = useState(false);
  const [hasVerified, setHasVerified] = useState(false);
  
  // Debug
  console.log('PremiumContent - Stato abbonamento:', JSON.stringify(subscription));
  console.log('PremiumContent - isSubscriptionActive:', isSubscriptionActive());
  console.log('PremiumContent - User:', user);
  
  // Effetto per verificare lo stato dell'abbonamento all'apertura
  useEffect(() => {
    // Verifica se c'è un ID sessione memorizzato
    const sessionId = localStorage.getItem('auralis_session_id');
    const isPremium = user?.isPremium;
    
    // Se c'è un ID sessione o se l'utente è segnato come premium, ma isSubscriptionActive è falso
    // potrebbe esserci un problema di sincronizzazione - forza la verifica
    if ((sessionId || isPremium) && !isSubscriptionActive() && !hasVerified) {
      console.log('Tentativo di verifica forzata abbonamento con sessionId:', sessionId);
      const verifyStatus = async () => {
        setIsVerifying(true);
        try {
          const result = await verifySubscription(sessionId || undefined);
          console.log('Risultato verifica abbonamento forzata:', result);
          setHasVerified(true);
        } catch (error) {
          console.error('Errore durante la verifica forzata:', error);
        } finally {
          setIsVerifying(false);
        }
      };
      
      verifyStatus();
    }
  }, [isSubscriptionActive, user, verifySubscription, hasVerified]);
  
  // Se l'utente è già premium, mostra un messaggio amichevole invece del paywall
  if (isSubscriptionActive()) {
    return (
      <Card className="border-2 border-amber-200 bg-gradient-to-r from-amber-50 to-amber-100 shadow-sm my-4">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto mb-4 bg-amber-100 p-3 rounded-full">
            <Sparkles className="h-8 w-8 text-amber-500" />
          </div>
          <CardTitle className="text-xl font-semibold">
            {isEnglish ? "Unlocked Content" : "Contenuto Sbloccato"}
          </CardTitle>
          <CardDescription className="text-gray-700">
            {isEnglish 
              ? "Thank you for being a Premium user! Enjoy this exclusive content" 
              : "Grazie per essere un utente Premium! Goditi questo contenuto esclusivo"}
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center pb-2">
          <h3 className="font-medium text-lg">{title}</h3>
          <p className="text-sm text-gray-600 mt-1">{description}</p>
        </CardContent>
        <CardFooter className="flex flex-col items-center pb-4 gap-2">
          <p className="text-sm text-amber-700">
            {isEnglish 
              ? "Premium content is also available offline in the app" 
              : "I contenuti premium sono disponibili anche offline nell'app"}
          </p>
        </CardFooter>
      </Card>
    );
  }
  
  // Determinare il testo corretto in base al tipo
  const typeText = () => {
    if (isEnglish) {
      return type === 'exercise' ? 'This exercise' : 
             type === 'meditation' ? 'This meditation' : 
             'This feature';
    } else {
      return type === 'exercise' ? 'Questo esercizio' : 
             type === 'meditation' ? 'Questa meditazione' : 
             'Questa funzionalità';
    }
  };
  
  // Altrimenti, mostra il paywall standard
  return (
    <Card className="border-2 border-amber-300 bg-gradient-to-r from-amber-50 to-amber-100 shadow-lg my-4">
      <CardHeader className="text-center pb-2">
        <div className="mx-auto mb-4 bg-amber-100 p-3 rounded-full">
          <Lock className="h-8 w-8 text-amber-500" />
        </div>
        <CardTitle className="text-xl font-semibold">
          {type === 'mood' 
            ? (isEnglish ? t('moodTracking.premiumContent') : t('moodTracking.premiumContent'))
            : (isEnglish ? "Premium Content" : "Contenuto Premium")}
        </CardTitle>
        <CardDescription className="text-gray-700">
          {type === 'mood'
            ? (isEnglish ? t('moodTracking.premiumOnly') : t('moodTracking.premiumOnly'))
            : `${typeText()} ${isEnglish ? 'is only available for Premium users' : 'è disponibile solo per gli utenti Premium'}`}
        </CardDescription>
      </CardHeader>
      <CardContent className="text-center pb-2">
        <h3 className="font-medium text-lg">{title}</h3>
        <p className="text-sm text-gray-600 mt-1">{description}</p>
      </CardContent>
      <CardFooter className="flex flex-col items-center pb-4 gap-2">
        <Button 
          onClick={onSubscribe}
          className="bg-amber-500 hover:bg-amber-600 text-white border-0 px-8"
        >
          {type === 'mood'
            ? (isEnglish ? t('moodTracking.unlockWithPremium') : t('moodTracking.unlockWithPremium'))
            : (isEnglish ? "Unlock with Premium" : "Sblocca con Premium")}
        </Button>
        
        {/* Pulsante per verificare lo stato dell'abbonamento se l'utente pensa di avere un abbonamento attivo */}
        {isVerifying ? (
          <div className="flex items-center mt-2 text-sm text-amber-600">
            <RefreshCcw className="h-3 w-3 mr-1 animate-spin" />
            {isEnglish ? "Verifying subscription..." : "Verifica abbonamento in corso..."}
          </div>
        ) : user?.isPremium && !isSubscriptionActive() ? (
          <Button 
            onClick={() => {
              setHasVerified(false); // Resetta lo stato di verifica
              setIsVerifying(true);
              const sessionId = localStorage.getItem('auralis_session_id');
              
              verifySubscription(sessionId || undefined)
                .then(result => {
                  console.log('Verifica manuale abbonamento completata:', result);
                })
                .catch(error => {
                  console.error('Errore verifica manuale:', error);
                })
                .finally(() => {
                  setIsVerifying(false);
                  setHasVerified(true);
                });
            }}
            variant="outline"
            size="sm"
            className="mt-2 text-xs text-amber-700 border-amber-300"
          >
            {isEnglish ? "Sync Subscription Status" : "Sincronizza Stato Abbonamento"}
          </Button>
        ) : null}
        
        <p className="text-xs text-gray-500 mt-1">
          {type === 'mood'
            ? (isEnglish ? t('moodTracking.subscribeAccess') : t('moodTracking.subscribeAccess'))
            : (isEnglish ? "Access all content with a subscription" : "Accedi a tutti i contenuti con un abbonamento")}
        </p>
      </CardFooter>
    </Card>
  );
}