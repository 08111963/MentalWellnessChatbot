import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { useTranslation } from 'react-i18next';

interface PremiumBannerProps {
  onSubscribe: () => void;
}

export function PremiumBanner({ onSubscribe }: PremiumBannerProps) {
  const { t } = useTranslation();

  return (
    <Card className="border-none bg-gradient-to-br from-amber-50 via-amber-100 to-orange-50 shadow-xl my-6 overflow-hidden relative">
      {/* Pattern decorativo */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMwLTkuOTQtOC4wNi0xOC0xOC0xOFYwYzkuOTQgMCAxOCA4LjA2IDE4IDE4aDEyYzAgOS45NCA4LjA2IDE4IDE4IDE4djEyYy05Ljk0IDAtMTgtOC4wNi0xOC0xOEgzNnoiIGZpbGwtb3BhY2l0eT0iLjA1IiBmaWxsPSIjRkY4QTY1Ii8+PC9nPjwvc3ZnPg==')] opacity-50"></div>
      
      {/* Decorazione nell'angolo */}
      <div className="absolute -top-10 -right-10 w-40 h-40 bg-gradient-to-br from-amber-300 to-amber-500 opacity-20 rounded-full blur-xl"></div>
      <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-gradient-to-br from-orange-300 to-amber-500 opacity-20 rounded-full blur-xl"></div>
      
      <div className="h-1.5 bg-gradient-to-r from-amber-400 to-amber-600"></div>
      
      <CardHeader className="text-center relative z-10 pb-2">
        <Badge variant="outline" className="bg-gradient-to-r from-amber-500 to-amber-600 text-white border-0 mx-auto mb-2 px-3 py-1 text-sm font-medium shadow-sm">
          <span className="mr-1 text-amber-200">✨</span> {t('premiumBanner.badge')}
        </Badge>
        <CardTitle className="text-2xl font-bold bg-gradient-to-r from-amber-700 via-amber-600 to-orange-700 bg-clip-text text-transparent">
          {t('premiumBanner.title')}
        </CardTitle>
        <CardDescription className="text-amber-800">
          {t('premiumBanner.description')}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-3 relative z-10">
        <div className="flex items-start space-x-3 bg-white/60 p-3 rounded-lg shadow-sm">
          <div className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
            <i className="ri-mental-health-line text-sm"></i>
          </div>
          <p className="text-sm text-amber-900">{t('premiumBanner.feature1')}</p>
        </div>
        
        <div className="flex items-start space-x-3 bg-white/60 p-3 rounded-lg shadow-sm">
          <div className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
            <i className="ri-meditation-line text-sm"></i>
          </div>
          <p className="text-sm text-amber-900">{t('premiumBanner.feature2')}</p>
        </div>
        
        <div className="flex items-start space-x-3 bg-white/60 p-3 rounded-lg shadow-sm">
          <div className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
            <i className="ri-award-line text-sm"></i>
          </div>
          <p className="text-sm text-amber-900">{t('premiumBanner.feature3')}</p>
        </div>
        
        <div className="flex items-start space-x-3 bg-white/60 p-3 rounded-lg shadow-sm">
          <div className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
            <i className="ri-shield-check-line text-sm"></i>
          </div>
          <p className="text-sm text-amber-900">{t('premiumBanner.feature4')}</p>
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-center pb-6 relative z-10">
        <Button 
          onClick={onSubscribe}
          className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white border-0 px-8 py-2 h-auto text-base font-medium shadow-md transform transition-transform hover:scale-105"
        >
          <i className="ri-vip-crown-line mr-2"></i> {t('premiumBanner.subscribeButton')}
        </Button>
      </CardFooter>
    </Card>
  );
}