import React, { useEffect } from 'react';

/**
 * Componente per ottimizzare le immagini SVG e migliorare il caricamento delle immagini per SEO
 * Utilizza tecniche avanzate per garantire che le immagini siano ben ottimizzate per i motori di ricerca
 * e vengano caricate in modo efficiente per migliorare LCP e CLS.
 */
export const ImageOptimizer: React.FC = () => {
  useEffect(() => {
    // Aggiungiamo preload per le immagini critiche (favicon, logo, etc.)
    const addImagePreloads = () => {
      const criticalImages = [
        '/favicon.svg',
        '/app-image.svg',
        '/favicon.png', // Fallback
        '/app-image.png' // Fallback
      ];
      
      criticalImages.forEach(src => {
        const linkExists = document.querySelector(`link[rel="preload"][href="${src}"]`);
        if (!linkExists) {
          const link = document.createElement('link');
          link.rel = 'preload';
          link.href = src;
          link.as = 'image';
          link.type = src.endsWith('.svg') ? 'image/svg+xml' : 'image/png';
          link.setAttribute('fetchpriority', 'high');
          document.head.appendChild(link);
        }
      });
    };
    
    // Ottimizza tutte le immagini <img> presenti nella pagina aggiungendo attributi per SEO
    const optimizeExistingImages = () => {
      const images = document.querySelectorAll('img:not([data-seo-optimized])');
      
      images.forEach(img => {
        // Assicuriamoci che l'elemento sia un'immagine HTML
        if (!(img instanceof HTMLImageElement)) return;
        
        // Aggiungi attributi per lazy loading se non già presenti
        if (!img.getAttribute('loading')) {
          img.setAttribute('loading', 'lazy');
        }
        
        // Aggiungi attributi per decodifica asincrona se non già presenti
        if (!img.getAttribute('decoding')) {
          img.setAttribute('decoding', 'async');
        }
        
        // Impostiamo una dimensione minima per evitare CLS se mancano width e height
        if (!img.getAttribute('width') && !img.getAttribute('height')) {
          const width = img.naturalWidth || 0;
          const height = img.naturalHeight || 0;
          
          if (width > 0 && height > 0) {
            img.setAttribute('width', width.toString());
            img.setAttribute('height', height.toString());
          } else {
            // Impostiamo dimensioni di default solo per immagini senza dimensioni specificate
            img.setAttribute('width', '100');
            img.setAttribute('height', '100');
            img.style.aspectRatio = '1 / 1';
          }
        }
        
        // Copia il testo alternativo nel titolo per migliorare SEO
        const alt = img.getAttribute('alt');
        if (alt && !img.getAttribute('title')) {
          img.setAttribute('title', alt);
        }
        
        // Marca l'immagine come ottimizzata
        img.setAttribute('data-seo-optimized', 'true');
      });
    };
    
    // Ottimizza le SVG per renderle accessibili e SEO-friendly
    const optimizeSvgElements = () => {
      const svgs = document.querySelectorAll('svg:not([data-seo-optimized])');
      
      svgs.forEach(svg => {
        // Aggiungi role="img" per accessibilità
        if (!svg.getAttribute('role')) {
          svg.setAttribute('role', 'img');
        }
        
        // Aggiungi aria-label se manca un titolo
        if (!svg.querySelector('title') && !svg.getAttribute('aria-label')) {
          // Cerca di inferire un nome sensato dal contesto
          const parentTitle = svg.closest('[title]')?.getAttribute('title');
          const nearestAlt = svg.closest('figure')?.querySelector('figcaption')?.textContent;
          const ariaLabel = parentTitle || nearestAlt || 'Immagine grafica';
          
          svg.setAttribute('aria-label', ariaLabel);
        }
        
        // Marca l'SVG come ottimizzato
        svg.setAttribute('data-seo-optimized', 'true');
      });
    };
    
    // Avvia l'ottimizzazione delle immagini
    addImagePreloads();
    optimizeExistingImages();
    optimizeSvgElements();
    
    // Imposta un observer per ottimizzare dinamicamente le immagini caricate da AJAX o React
    const observer = new MutationObserver(() => {
      optimizeExistingImages();
      optimizeSvgElements();
    });
    
    observer.observe(document.body, { 
      childList: true, 
      subtree: true 
    });
    
    return () => {
      observer.disconnect();
    };
  }, []);
  
  // Questo componente non renderizza nulla nel DOM
  return null;
};

export default ImageOptimizer;