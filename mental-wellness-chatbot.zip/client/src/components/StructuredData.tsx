import React from 'react';
import { Meditation, Exercise } from '@/lib/types';

// Componente per generare Schema.org Structured Data per Meditazioni
export const MeditationStructuredData: React.FC<{ meditation: Meditation }> = ({ meditation }) => {
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'MedicalWebPage',
    'about': {
      '@type': 'MentalHealthConsideration',
      'name': meditation.title,
      'description': meditation.description
    },
    'audience': {
      '@type': 'MedicalAudience', 
      'audienceType': 'General Public'
    },
    'mainContentOfPage': {
      '@type': 'WebPageElement',
      'mainContentOfPage': meditation.content
    },
    'duration': `PT${meditation.duration}M`,
    'specialty': 'Mental Health',
    'significantLink': 'https://auralis.replit.app/meditations'
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
    />
  );
};

// Componente per generare Schema.org Structured Data per Esercizi
export const ExerciseStructuredData: React.FC<{ exercise: Exercise }> = ({ exercise }) => {
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'HowTo',
    'name': exercise.title,
    'description': exercise.description,
    'totalTime': 'PT20M', // Tempo stimato per completare l'esercizio
    'tool': {
      '@type': 'HowToTool',
      'name': 'Auralis Mental Wellness App'
    },
    'step': exercise.steps.map((step, index) => ({
      '@type': 'HowToStep',
      'position': index + 1,
      'name': `Step ${index + 1}`,
      'itemListElement': {
        '@type': 'HowToDirection',
        'text': step
      }
    })),
    'category': exercise.category
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
    />
  );
};

// Componente per generare Schema.org FAQ Page
export const FAQStructuredData: React.FC<{ 
  faqs: Array<{ question: string; answer: string }> 
}> = ({ faqs }) => {
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    'mainEntity': faqs.map(faq => ({
      '@type': 'Question',
      'name': faq.question,
      'acceptedAnswer': {
        '@type': 'Answer',
        'text': faq.answer
      }
    }))
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
    />
  );
};