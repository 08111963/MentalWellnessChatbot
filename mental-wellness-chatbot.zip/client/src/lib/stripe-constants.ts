/**
 * Costanti per i prezzi di Stripe
 * In un'app reale, queste ID dovrebbero essere recuperati dinamicamente dal backend
 * o iniettati durante il deployment
 */

// ID dei prezzi dei prodotti in Stripe
export const STRIPE_PRICES = {
  // Piano mensile
  MONTHLY: import.meta.env.VITE_STRIPE_PRICE_MONTHLY || 'price_1R6tUTJiRRPU3UNSogE3jdy1',
  
  // Piano annuale
  YEARLY: import.meta.env.VITE_STRIPE_PRICE_YEARLY || 'price_1R6tUYJiRRPU3UNSWO7LxAm8'
};