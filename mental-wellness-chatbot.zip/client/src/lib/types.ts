export interface ChatMessage {
  id?: string;
  content: string;
  role: 'user' | 'assistant' | 'system';
  timestamp?: Date;
}

export interface MessageAnalysis {
  intent: string;
  emotionalState: string;
  suggestedApproach: string;
}

export interface ChatResponse {
  message: string;
  analysis: MessageAnalysis;
}

export interface Suggestion {
  id: string;
  text: string;
}

export interface Module {
  id: number;
  title: string;
  description: string;
  icon: string;
  color: string;
  route: string;
  isPremium?: boolean;
}

export interface Meditation {
  id: number;
  title: string;
  duration: number;
  description: string;
  content: string;
  isPremium: boolean;
}

export interface Exercise {
  id: number;
  title: string;
  category: string;
  description: string;
  steps: string[];
  isPremium: boolean;
}

export interface Reflection {
  id: number;
  prompt: string;
  category: string;
  isPremium: boolean;
}

export interface QuoteCategory {
  id: string;
  name: string;
}

export interface Quote {
  id: number;
  text: string;
  author: string;
  categories: string[];
}

export type TabType = 'chat' | 'exercises' | 'meditation' | 'reflections' | 'mood' | 'ai-modules' | 'resources';

export interface MoodEntry {
  id: number;
  userId: number;
  date: Date;
  score: number; // 1-5
  notes?: string;
  activities?: string[];
  emotions?: string[];
  triggerEvents?: string;
  sleepQuality?: number; // 1-5
  energyLevel?: number; // 1-5
}

export interface MoodStats {
  average: number;
  highest: number;
  lowest: number;
  entries: {
    id: number;
    date: Date;
    score: number;
  }[];
  topEmotions: {
    emotion: string;
    count: number;
  }[];
  topActivities: {
    activity: string;
    count: number;
  }[];
}
