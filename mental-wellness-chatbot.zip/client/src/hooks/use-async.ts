import { useState, useCallback } from 'react';

type Status = 'idle' | 'pending' | 'success' | 'error';

export function useAsync<T, P extends any[]>(
  asyncFunction: (...args: P) => Promise<T>
) {
  const [status, setStatus] = useState<Status>('idle');
  const [value, setValue] = useState<T | null>(null);
  const [error, setError] = useState<Error | null>(null);

  const execute = useCallback(
    async (...args: P) => {
      setStatus('pending');
      setValue(null);
      setError(null);

      try {
        const result = await asyncFunction(...args);
        setValue(result);
        setStatus('success');
        return result;
      } catch (error) {
        setError(error as Error);
        setStatus('error');
        return null;
      }
    },
    [asyncFunction]
  );

  return { execute, status, value, error };
}