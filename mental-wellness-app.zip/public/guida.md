# Guida Completa all'App Auralis

## Introduzione

Benvenuto in Auralis – il tuo compagno personale per il benessere mentale. Questa guida completa ti accompagnerà attraverso tutte le funzionalità disponibili nella nostra applicazione, aiutandoti a sfruttare al meglio il tuo percorso verso una migliore salute mentale e benessere.

## Iniziare

### Creazione del tuo Account
Per accedere a tutte le funzionalità di Auralis, inizia creando un account:
1. Tocca il pulsante di accesso/registrazione nell'angolo in alto a destra
2. Inserisci il tuo nome utente e password
3. Completa la registrazione accettando i nostri termini di servizio
4. Una volta registrato, avrai immediatamente accesso a tutte le funzionalità gratuite

### Navigazione nell'App
Auralis è progettata con una navigazione intuitiva:
- La **barra di navigazione inferiore** fornisce accesso rapido alle sezioni principali
- Il **menu hamburger** (≡) in alto a destra dà accesso a tutte le funzionalità e impostazioni
- Il **pulsante home** ti riporterà sempre alla dashboard principale

### Accesso all'App su Più Dispositivi
Puoi accedere al tuo account Auralis da qualsiasi dispositivo:
- Utilizzando la funzione codice QR (dalla sezione "Scarica App" nel menu)
- Accedendo con le credenziali del tuo account su qualsiasi browser

## Funzionalità Principali Spiegate

### Dashboard Home
La dashboard home è il tuo hub centrale, che fornisce:
- Accesso rapido agli strumenti più utilizzati
- Citazioni di ispirazione quotidiana personalizzate in base alle tue preferenze
- Riepiloghi delle attività e approfondimenti
- Raccomandazioni personalizzate basate sui tuoi modelli di utilizzo

### Supporto Chat (Chat Assistente)
Il nostro assistente chat basato sull'intelligenza artificiale è progettato per fornire supporto psicologico attraverso conversazioni basate sulla CBT:

**Come Utilizzare:**
1. Naviga alla sezione Chat dalla barra inferiore o dal menu
2. Digita il tuo messaggio nel campo di testo in basso
3. Premi "Invia" per iniziare o continuare la conversazione
4. Utilizza gli argomenti suggeriti per orientarti quando non sei sicuro da dove iniziare

**Caratteristiche:**
- Conversazioni private, senza giudizio
- Approcci di terapia cognitivo-comportamentale basati su evidenze
- Memoria delle interazioni precedenti per un supporto contestuale
- Possibilità di reimpostare la conversazione quando necessario

**Limitazioni:**
- Gli utenti gratuiti sono limitati a 3 conversazioni al giorno
- Gli utenti premium godono di conversazioni illimitate

### Moduli di Meditazione (Meditazione)
La nostra sezione di meditazione offre sessioni guidate per il rilassamento e la consapevolezza:

**Come Accedere:**
1. Tocca "Meditazione" nella navigazione inferiore o nel menu
2. Sfoglia i moduli di meditazione disponibili per categoria o lunghezza
3. Seleziona una sessione di meditazione per visualizzare i dettagli
4. Premi "Play" per iniziare la sessione guidata

**Caratteristiche:**
- Diverse categorie di meditazione (sonno, ansia, stress, concentrazione, ecc.)
- Varie lunghezze di sessione (5-30 minuti)
- Suoni di sottofondo e visuali calmanti
- Monitoraggio dei progressi

**Categorie di Meditazione:**
- **Mindfulness** - Pratiche di consapevolezza del momento presente
- **Respirazione** - Tecniche per ridurre lo stress attraverso il controllo del respiro
- **Body Scan** - Metodi di rilassamento progressivo
- **Sonno** - Pratiche calmanti per migliorare la qualità del sonno
- **Sollievo dall'Ansia** - Sessioni specificamente progettate per ridurre l'ansia
- **Gratitudine** - Pratiche per coltivare la riconoscenza e una prospettiva positiva

### Esercizi CBT (Esercizi)
Esercizi di terapia cognitivo-comportamentale basati su evidenze per migliorare la salute mentale:

**Come Accedere:**
1. Seleziona "Esercizi" dal menu di navigazione
2. Sfoglia gli esercizi per categoria (ansia, depressione, stress, ecc.)
3. Tocca un esercizio per visualizzare istruzioni e benefici
4. Segui la guida passo-passo

**Caratteristiche:**
- Istruzioni dettagliate per ogni esercizio
- Monitoraggio dei progressi
- Sezione per note personali
- Marcatura di completamento
- Timer per esercizi temporizzati

**Categorie di Esercizi:**
- **Sfida ai pensieri** - Identificare e reinterpretare modelli di pensiero negativi
- **Attivazione comportamentale** - Aumentare il coinvolgimento in attività positive
- **Tecniche di esposizione** - Affrontare gradualmente le paure in modo controllato
- **Allenamento al rilassamento** - Metodi per rilassarsi fisicamente e mentalmente
- **Problem-solving** - Approcci strutturati per affrontare le sfide
- **Pratiche di mindfulness** - Esercizi per aumentare la consapevolezza del presente

### Riflessioni Quotidiane (Riflessioni)
Spunti di riflessione e contenuti ispiratori per incoraggiare la crescita personale:

**Come Accedere:**
1. Naviga a "Riflessioni" nel menu
2. Visualizza la riflessione quotidiana mostrata sullo schermo
3. Opzionale: Annota i tuoi pensieri in risposta alla riflessione

**Caratteristiche:**
- Contenuti aggiornati quotidianamente
- Salvataggio delle riflessioni preferite
- Capacità di tenere un diario
- Riflessioni tematiche basate sui tuoi interessi

### Monitoraggio dell'Umore (Umore)
Monitora e analizza il tuo benessere emotivo nel tempo:

**Come Utilizzare:**
1. Naviga alla sezione "Umore"
2. Seleziona il tuo umore attuale dalle opzioni disponibili
3. Aggiungi note su ciò che ha influenzato il tuo umore (opzionale)
4. Visualizza i tuoi modelli di umore nella sezione di analisi

**Caratteristiche:**
- Registrazione rapida dell'umore
- Capacità di aggiungere note dettagliate
- Grafici visivi che mostrano i modelli
- Approfondimenti e correlazioni
- Capacità di esportazione (premium)

### Moduli AI (Moduli AI)
Strumenti di intelligenza artificiale specializzati per esigenze specifiche di salute mentale:

**Moduli Disponibili:**
- **Miglioramento del Sonno** - Analizza i modelli di sonno e fornisce suggerimenti personalizzati
- **Gestione dello Stress** - Identifica i fattori di stress e sviluppa strategie di coping
- **Rafforzamento della Fiducia** - Esercizi e feedback per migliorare l'autostima
- **Aiuto Relazionale** - Strategie di comunicazione e risoluzione dei conflitti
- **Formazione di Abitudini** - Crea e mantieni abitudini positive
- **Crescita Personale** - Imposta e monitora obiettivi per il benessere mentale

**Come Utilizzare:**
1. Seleziona "Moduli AI" dal menu
2. Scegli un modulo specifico in base alle tue esigenze
3. Segui la guida interattiva fornita
4. Ricevi raccomandazioni personalizzate

### Biblioteca Risorse (Risorse)
Una collezione curata di articoli, video e materiali pratici:

**Come Accedere:**
1. Tocca "Risorse" nel menu
2. Sfoglia le categorie o utilizza la funzione di ricerca
3. Filtra per tipo (articolo, video, audio, ecc.)
4. Salva i preferiti per accedervi in seguito

**Caratteristiche:**
- Contenuti creati da esperti
- Categorizzati per una facile navigazione
- Funzionalità di segnalibro
- Stime del tempo di lettura
- Accesso offline (premium)

## Funzionalità Premium

Auralis offre un abbonamento premium che migliora la tua esperienza con:

### Benefici Premium
- **Conversazioni chat illimitate** - Nessun limite giornaliero
- **Biblioteca completa di esercizi** - Accesso a tutti gli esercizi CBT
- **Collezione completa di meditazioni** - Incluse sessioni estese e specializzate
- **Analisi avanzate dell'umore** - Approfondimenti dettagliati e opzioni di esportazione
- **Accesso illimitato ai moduli AI** - Utilizza tutti gli strumenti specializzati senza restrizioni
- **Contenuti premium esclusivi** - Accesso a guide approfondite e risorse
- **Esperienza senza pubblicità** - Utilizzo ininterrotto
- **Aggiornamenti prioritari dei contenuti** - Sii il primo ad accedere alle nuove funzionalità

### Opzioni di Abbonamento
- **Piano Mensile**: €4,99/mese con facile cancellazione
- **Piano Annuale**: €39,99/anno (risparmio oltre il 30%)
- Tutti gli abbonamenti includono una prova gratuita di 7 giorni

### Gestione del tuo Abbonamento
Per gestire il tuo abbonamento:
1. Accedi al tuo profilo dal menu
2. Seleziona "Gestisci Abbonamento"
3. Visualizza il tuo piano attuale, la data di rinnovo e le opzioni per modificare o cancellare

## Opzioni di Personalizzazione

### Impostazioni Lingua
Auralis supporta più lingue:
- Italiano (predefinito)
- Inglese
- Spagnolo
- Francese
- Tedesco

Per cambiare la tua lingua:
1. Tocca il selettore di lingua nell'angolo superiore dello schermo
2. Scegli la tua lingua preferita dal menu a tendina

### Tema e Aspetto
Mentre Auralis attualmente utilizza un tema chiaro per impostazione predefinita, puoi:
- Regolare la dimensione del testo attraverso le impostazioni di accessibilità del tuo dispositivo
- Utilizzare la modalità scura del tuo dispositivo per modificare l'aspetto

### Notifiche
Controlla come e quando Auralis ti ricorda:
1. Accedi alle impostazioni attraverso il tuo profilo
2. Attiva/disattiva le notifiche per:
   - Promemoria di riflessione quotidiana
   - Suggerimenti per la pratica di meditazione
   - Promemoria per il check-in dell'umore
   - Aggiornamenti dei contenuti

## Risoluzione dei Problemi e Supporto

### Problemi Comuni
- **App che non si carica**: Assicurati di avere una connessione internet stabile
- **Contenuti che non vengono visualizzati**: Prova ad aggiornare la pagina o riavviare l'app
- **Problemi di accesso**: Utilizza l'opzione di reimpostazione della password o contatta il supporto

### Ottenere Aiuto
Per assistenza con qualsiasi aspetto di Auralis:
- Email: aiuto@auralis.app
- Nell'app: Utilizza l'opzione "Contatta Supporto" nel menu
- Tempo di risposta: In genere entro 24 ore

## Privacy e Sicurezza

La tua privacy è la nostra priorità. Auralis garantisce:
- **Crittografia dei dati** per tutte le informazioni personali
- **Nessuna condivisione con terzi** delle tue conversazioni o dati di utilizzo
- **Conformità al GDPR** con le normative sulla protezione dei dati
- **Archiviazione locale** delle informazioni sensibili ove possibile

## Consigli per il Massimo Beneficio

1. **Usa regolarmente** - Il benessere mentale trae beneficio dalla pratica costante
2. **Prova diverse funzionalità** - Esplora vari strumenti per trovare ciò che funziona meglio per te
3. **Monitora i tuoi progressi** - La registrazione regolare dell'umore fornisce preziosi insight
4. **Combina gli approcci** - Ad esempio, abbina la meditazione agli esercizi CBT
5. **Imposta promemoria** - Programma regolari check-in con te stesso
6. **Sii paziente** - Il miglioramento del benessere mentale richiede tempo

Speriamo che questa guida ti aiuti a ottenere il massimo da Auralis mentre progredisci nel tuo percorso di benessere. Ricorda che la salute mentale è un processo continuo, e siamo qui per supportarti in ogni passo del cammino.