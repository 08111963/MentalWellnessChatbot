/**
 * Utility per garantire la navigazione verso la home page
 * Risolve problemi di navigazione in alcune pagine specifiche
 */

/**
 * Elenco delle pagine che hanno problemi di navigazione
 */
export const problematicPages = ['/exercises', '/reflections', '/ai-modules', '/guida'];

/**
 * Controlla se siamo in una pagina problematica
 * @returns {boolean} True se siamo in una pagina problematica
 */
export function isProblematicPage(): boolean {
  return problematicPages.includes(window.location.pathname);
}

/**
 * Naviga verso la home page in modo sicuro
 * @param {React.MouseEvent | Event} e - Evento click
 */
export function navigateToHome(e: React.MouseEvent | Event): void {
  // Previeni SEMPRE il comportamento di default per garantire che gestiamo noi la navigazione
  e.preventDefault();
  
  // Siamo in una pagina problematica?
  if (isProblematicPage()) {
    console.log("Navigazione da pagina problematica verso home");
    
    // Strategia 1: La più diretta, forza un hard reload sulla home
    window.location.href = '/';
    
    // Se siamo ancora qui, prova altre strategie come fallback
    setTimeout(() => {
      // Strategia 2: location.replace
      window.location.replace('/');
      
      // Strategia 3: ultima risorsa, ricarica la pagina con il nuovo URL
      setTimeout(() => {
        window.location.assign('/');
      }, 50);
    }, 50);
  } else {
    // Per le pagine non problematiche, usa semplicemente history API
    window.history.pushState({}, '', '/');
    // Trigger event per far sapere al router che siamo sulla home
    window.dispatchEvent(new Event('popstate'));
  }
}

/**
 * Aggiungi event listener per intercettare i click sui pulsanti home
 */
export function setupHomeNavigation(): void {
  // Intercetta i click a livello globale
  document.addEventListener('click', (e: Event) => {
    const target = e.target as HTMLElement;
    
    // Cerca tutti i possibili elementi "home"
    const homeLink = target.closest('a[href="/"]');
    const homeButton = target.closest('button[aria-label="Torna alla Home"]');
    const homeIcon = target.closest('i.ri-home-4-line');
    
    // Se l'elemento cliccato è un link home, un bottone home o un'icona home
    if (homeLink || homeButton || homeIcon || 
        (target.textContent && target.textContent.includes('Home'))) {
      console.log('Click su elemento Home intercettato');
      navigateToHome(e);
    }
  }, true); // Usa la fase di capturing per intercettare prima dell'event bubbling
  
  // Override dei link diretti alla home per le pagine problematiche
  if (isProblematicPage()) {
    console.log('Pagina problematica rilevata, sovrascrittura di tutti i link alla home');
    
    // Override di tutti i link alla home nella pagina
    document.querySelectorAll('a[href="/"]').forEach(link => {
      link.addEventListener('click', (e) => {
        console.log('Click su link diretto alla home in pagina problematica');
        navigateToHome(e);
      }, true);
    });
  }
}

/**
 * Inizializza il sistema di navigazione home
 * Questa funzione viene chiamata all'avvio dell'app
 * E anche ogni volta che la pagina cambia
 */
export function initHomeNavigation(): void {
  // Rimuovi eventuali listener precedenti per evitare duplicati
  const oldListener = window.homeNavigationInitialized;
  if (oldListener) {
    document.removeEventListener('click', oldListener as EventListener);
  }
  
  // Imposta il nuovo listener
  setupHomeNavigation();
  
  // Segna come inizializzato
  window.homeNavigationInitialized = setupHomeNavigation;
  
  console.log('Sistema di navigazione home inizializzato');
  
  // Aggiungi un observer per rilevare cambiamenti di pagina
  // In particolare, reimposta il sistema quando entriamo in una pagina problematica
  if (!window.navigationObserverSet) {
    window.addEventListener('popstate', () => {
      console.log('Cambio pagina rilevato, reinizializzazione sistema navigazione');
      setupHomeNavigation();
    });
    
    // Inoltre, aggiungi un MutationObserver per rilevare aggiunte di elementi alla DOM
    // Utile per quando i link vengono aggiunti dinamicamente
    const observer = new MutationObserver((mutations) => {
      if (isProblematicPage()) {
        for (const mutation of mutations) {
          if (mutation.addedNodes.length) {
            console.log('Nuovi elementi DOM in pagina problematica, reinizializzazione sistema navigazione');
            setupHomeNavigation();
            break;
          }
        }
      }
    });
    
    // Inizia l'osservazione
    observer.observe(document.body, { childList: true, subtree: true });
    
    // Memorizza che abbiamo impostato l'observer
    window.navigationObserverSet = true;
  }
}

// Estendere l'interfaccia Window per i nostri flag di inizializzazione
declare global {
  interface Window {
    homeNavigationInitialized: any;
    navigationObserverSet: boolean;
  }
}