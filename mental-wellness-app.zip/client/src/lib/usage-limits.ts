/**
 * Utility per gestire i limiti di utilizzo dell'app per utenti non premium
 */

// Chiave per memorizzare le richieste giornaliere
const DAILY_REQUESTS_KEY = 'auralis_daily_requests';

interface DailyUsage {
  date: string; // formato YYYY-MM-DD
  count: number;
}

/**
 * Ottiene l'utilizzo giornaliero corrente
 * @returns Il numero di richieste utilizzate oggi
 */
export function getDailyUsage(): number {
  try {
    const today = new Date().toISOString().split('T')[0]; // formato YYYY-MM-DD
    const storedData = localStorage.getItem(DAILY_REQUESTS_KEY);
    
    if (!storedData) {
      return 0;
    }
    
    const usage = JSON.parse(storedData) as DailyUsage;
    
    // Se è un nuovo giorno, resetta il contatore
    if (usage.date !== today) {
      return 0;
    }
    
    return usage.count;
  } catch (error) {
    console.error('Errore nel recupero dell\'utilizzo giornaliero:', error);
    return 0;
  }
}

/**
 * Incrementa il contatore delle richieste giornaliere
 * @returns Il nuovo conteggio delle richieste giornaliere
 */
export function incrementDailyUsage(): number {
  try {
    const today = new Date().toISOString().split('T')[0]; // formato YYYY-MM-DD
    const currentUsage = getDailyUsage();
    
    // Se è un nuovo giorno, inizia con 1
    const newCount = (currentUsage === 0) ? 1 : currentUsage + 1;
    
    const usage: DailyUsage = {
      date: today,
      count: newCount
    };
    
    localStorage.setItem(DAILY_REQUESTS_KEY, JSON.stringify(usage));
    
    return newCount;
  } catch (error) {
    console.error('Errore nell\'incremento dell\'utilizzo giornaliero:', error);
    return 0;
  }
}

/**
 * Controlla se l'utente ha raggiunto il limite giornaliero
 * @param maxRequests Il numero massimo di richieste consentite al giorno (default: 3)
 * @returns true se l'utente ha raggiunto il limite, false altrimenti
 */
export function hasReachedDailyLimit(maxRequests: number = 3): boolean {
  const usageCount = getDailyUsage();
  return usageCount >= maxRequests;
}

/**
 * Reimpostare il contatore delle richieste giornaliere (utile per test o debug)
 */
export function resetDailyUsage(): void {
  try {
    localStorage.removeItem(DAILY_REQUESTS_KEY);
    console.log('Contatore richieste giornaliere resettato');
  } catch (error) {
    console.error('Errore nel reset dell\'utilizzo giornaliero:', error);
  }
}

// Reset automatico del contatore (per ripristinare il contatore dopo le modifiche)
resetDailyUsage();