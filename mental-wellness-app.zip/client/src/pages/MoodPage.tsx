import { useState } from 'react';
import { format } from 'date-fns';
import { it, enUS } from 'date-fns/locale';
import Header from '@/components/SimpleHeader';
import { useTranslation } from 'react-i18next';
import BottomNavigation from '@/components/BottomNavigation';
import TabNavigation from '@/components/TabNavigation';
import { useToast } from '@/hooks/use-toast';
import { queryClient, apiRequest, getQueryFn } from '@/lib/queryClient';
import { useQuery, useMutation } from '@tanstack/react-query';
import { PremiumContent } from '@/components/PremiumContent';
import { useAuth } from '@/lib/auth-context';
import { useStripe } from '@/lib/stripe-context';
import { MoodEntry, MoodStats } from '@/lib/types';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';

// Emoji per il punteggio dell'umore / Emojis for mood score
const moodEmojis = ['😢', '😟', '😐', '🙂', '😄'];

// Colori per le emozioni / Colors for emotions
const emotionColors = [
  '#FF6B6B', '#FFD166', '#06D6A0', '#118AB2', '#073B4C', 
  '#8338EC', '#3A86FF', '#FB5607', '#FFBE0B', '#4CC9F0'
];

// Opzioni per le emozioni italiane / Italian emotion options
const emotionsIT = [
  'Felice', 'Triste', 'Arrabbiato', 'Ansioso', 'Fiducioso',
  'Stressato', 'Calmo', 'Frustrato', 'Grato', 'Energico'
];

// Opzioni per le emozioni inglesi / English emotion options
const emotionsEN = [
  'Happy', 'Sad', 'Angry', 'Anxious', 'Confident',
  'Stressed', 'Calm', 'Frustrated', 'Grateful', 'Energetic'
];

// Opzioni per le attività italiane / Italian activity options
const activityOptionsIT = [
  'Esercizio Fisico', 'Lavoro', 'Socializzazione', 'Lettura',
  'Meditazione', 'Natura', 'Hobby', 'Famiglia', 'Riposo', 'Studio'
];

// Opzioni per le attività inglesi / English activity options
const activityOptionsEN = [
  'Exercise', 'Work', 'Socializing', 'Reading',
  'Meditation', 'Nature', 'Hobbies', 'Family', 'Rest', 'Study'
];

function MoodEntryForm({ 
  onSubmit, 
  onCancel, 
  isLoading,
  initialData = {
    score: 3,
    notes: '',
    activities: [],
    emotions: [],
    triggerEvents: '',
    sleepQuality: 3,
    energyLevel: 3
  }
}: { 
  onSubmit: (entry: Partial<MoodEntry>) => void, 
  onCancel: () => void,
  isLoading?: boolean,
  initialData?: {
    score?: number;
    notes?: string;
    activities?: string[];
    emotions?: string[];
    triggerEvents?: string;
    sleepQuality?: number;
    energyLevel?: number;
  }
}) {
  const { t, i18n } = useTranslation();
  const isEnglish = i18n.language === 'en';
  const currentEmotions = isEnglish ? emotionsEN : emotionsIT;
  const currentActivityOptions = isEnglish ? activityOptionsEN : activityOptionsIT;
  
  const [score, setScore] = useState(initialData.score || 3);
  const [notes, setNotes] = useState(initialData.notes || '');
  const [activities, setActivities] = useState<string[]>(initialData.activities || []);
  const [selectedEmotions, setSelectedEmotions] = useState<string[]>(initialData.emotions || []);
  const [triggerEvents, setTriggerEvents] = useState(initialData.triggerEvents || '');
  const [sleepQuality, setSleepQuality] = useState(initialData.sleepQuality || 3);
  const [energyLevel, setEnergyLevel] = useState(initialData.energyLevel || 3);

  const toggleEmotion = (emotion: string) => {
    if (selectedEmotions.includes(emotion)) {
      setSelectedEmotions(selectedEmotions.filter(e => e !== emotion));
    } else {
      setSelectedEmotions([...selectedEmotions, emotion]);
    }
  };

  const toggleActivity = (activity: string) => {
    if (activities.includes(activity)) {
      setActivities(activities.filter(a => a !== activity));
    } else {
      setActivities([...activities, activity]);
    }
  };

  const handleSubmit = () => {
    onSubmit({
      userId: 1,
      date: new Date(),
      score,
      notes,
      activities,
      emotions: selectedEmotions,
      triggerEvents,
      sleepQuality,
      energyLevel
    });
  };

  return (
    <div className="space-y-4 py-2">
      <div className="space-y-2">
        <Label htmlFor="mood">{isEnglish ? 'How are you feeling today?' : 'Come ti senti oggi?'}</Label>
        <div className="flex items-center justify-between bg-rose-50 p-4 rounded-lg">
          <div className="flex justify-between w-full">
            {moodEmojis.map((emoji, index) => (
              <div 
                key={index}
                className={`cursor-pointer transition-all text-4xl ${score === index + 1 ? 'transform scale-125' : 'opacity-50 hover:opacity-80'}`}
                onClick={() => setScore(index + 1)}
              >
                {emoji}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">{isEnglish ? 'Notes (optional)' : 'Note (opzionale)'}</Label>
        <Textarea 
          id="notes" 
          placeholder={isEnglish ? "Write your notes here..." : "Scrivi qui le tue note..."}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="border-rose-200 focus-visible:ring-rose-500"
        />
      </div>

      <div className="space-y-2">
        <Label>{isEnglish ? 'Primary Emotions' : 'Emozioni prevalenti'}</Label>
        <div className="flex flex-wrap gap-2">
          {currentEmotions.map((emotion) => (
            <Badge 
              key={emotion}
              variant={selectedEmotions.includes(emotion) ? "default" : "outline"}
              className={selectedEmotions.includes(emotion) ? "cursor-pointer bg-rose-500 hover:bg-rose-600" : "cursor-pointer border-rose-200 text-rose-700 hover:bg-rose-50"}
              onClick={() => toggleEmotion(emotion)}
            >
              {emotion}
            </Badge>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label>{isEnglish ? 'Activities Done' : 'Attività svolte'}</Label>
        <div className="flex flex-wrap gap-2">
          {currentActivityOptions.map((activity) => (
            <Badge 
              key={activity}
              variant={activities.includes(activity) ? "default" : "outline"}
              className={activities.includes(activity) ? "cursor-pointer bg-rose-500 hover:bg-rose-600" : "cursor-pointer border-rose-200 text-rose-700 hover:bg-rose-50"}
              onClick={() => toggleActivity(activity)}
            >
              {activity}
            </Badge>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="triggers">{isEnglish ? 'Trigger Events (optional)' : 'Eventi scatenanti (opzionale)'}</Label>
        <Input 
          id="triggers" 
          placeholder={isEnglish ? "E.g. argument, work problem..." : "Es. discussione, problema al lavoro..."}
          value={triggerEvents}
          onChange={(e) => setTriggerEvents(e.target.value)}
          className="border-rose-200 focus-visible:ring-rose-500"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="sleep">{isEnglish ? 'Sleep Quality' : 'Qualità del sonno'}</Label>
        <div className="flex items-center gap-4">
          <Slider 
            id="sleep"
            className="flex-1 [&_[role=slider]]:bg-rose-500" 
            value={[sleepQuality]} 
            min={1} 
            max={5} 
            step={1} 
            onValueChange={(value) => setSleepQuality(value[0])}
          />
          <span className="text-lg font-medium">{sleepQuality}/5</span>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="energy">{isEnglish ? 'Energy Level' : 'Livello di energia'}</Label>
        <div className="flex items-center gap-4">
          <Slider 
            id="energy"
            className="flex-1 [&_[role=slider]]:bg-rose-500" 
            value={[energyLevel]} 
            min={1} 
            max={5} 
            step={1} 
            onValueChange={(value) => setEnergyLevel(value[0])}
          />
          <span className="text-lg font-medium">{energyLevel}/5</span>
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button variant="outline" className="border-rose-200 text-rose-700 hover:bg-rose-50" onClick={onCancel}>
          {isEnglish ? 'Cancel' : 'Annulla'}
        </Button>
        <Button 
          className="bg-gradient-to-r from-rose-500 to-pink-500 text-white hover:shadow-lg transition-all hover:scale-105"
          onClick={handleSubmit}
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
              {isEnglish ? 'Saving...' : 'Salvataggio...'}
            </>
          ) : isEnglish ? 'Save Entry' : 'Salva registrazione'}
        </Button>
      </div>
    </div>
  );
}

function MoodEntryCard({ entry, onDelete }: { entry: MoodEntry, onDelete: (id: number) => void }) {
  const { t, i18n } = useTranslation();
  const isEnglish = i18n.language === 'en';
  const locale = isEnglish ? enUS : it;
  const formattedDate = format(
    new Date(entry.date), 
    isEnglish ? "d MMMM yyyy 'at' HH:mm" : "d MMMM yyyy 'alle' HH:mm", 
    { locale }
  );
  
  // Get mood label based on score and language
  const getMoodLabel = (score: number) => {
    if (isEnglish) {
      return score === 1 ? 'Very sad' : 
             score === 2 ? 'Sad' : 
             score === 3 ? 'Neutral' : 
             score === 4 ? 'Happy' : 'Very happy';
    } else {
      return score === 1 ? 'Molto triste' : 
             score === 2 ? 'Triste' : 
             score === 3 ? 'Neutrale' : 
             score === 4 ? 'Felice' : 'Molto felice';
    }
  };

  return (
    <Card className="overflow-hidden transition-all hover:shadow-md border-rose-100 bg-white hover:border-rose-200">
      <CardHeader className="p-4 bg-gradient-to-r from-rose-50 to-pink-50 flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-lg flex items-center">
            <span className="mr-2 text-2xl">{moodEmojis[entry.score - 1]}</span>
            {getMoodLabel(entry.score)}
          </CardTitle>
          <CardDescription>{formattedDate}</CardDescription>
        </div>
        <Button 
          variant="ghost" 
          size="icon"
          className="text-neutral-500 hover:text-rose-500"
          onClick={() => onDelete(entry.id)}
        >
          <i className="ri-delete-bin-line"></i>
        </Button>
      </CardHeader>
      <CardContent className="p-4">
        {entry.notes && (
          <div className="mb-4">
            <h4 className="text-sm font-medium mb-1 text-rose-700">{isEnglish ? 'Notes:' : 'Note:'}</h4>
            <p className="text-neutral-600">{entry.notes}</p>
          </div>
        )}
        
        {entry.emotions && entry.emotions.length > 0 && (
          <div className="mb-4">
            <h4 className="text-sm font-medium mb-1 text-rose-700">{isEnglish ? 'Emotions:' : 'Emozioni:'}</h4>
            <div className="flex flex-wrap gap-1">
              {entry.emotions.map((emotion, index) => (
                <Badge key={index} variant="secondary" className="bg-rose-50 text-rose-600">
                  {emotion}
                </Badge>
              ))}
            </div>
          </div>
        )}
        
        {entry.activities && entry.activities.length > 0 && (
          <div className="mb-4">
            <h4 className="text-sm font-medium mb-1 text-rose-700">{isEnglish ? 'Activities:' : 'Attività:'}</h4>
            <div className="flex flex-wrap gap-1">
              {entry.activities.map((activity, index) => (
                <Badge key={index} variant="outline" className="border-rose-200 text-neutral-700">
                  {activity}
                </Badge>
              ))}
            </div>
          </div>
        )}
        
        {entry.triggerEvents && (
          <div className="mb-4">
            <h4 className="text-sm font-medium mb-1 text-rose-700">{isEnglish ? 'Trigger Events:' : 'Eventi scatenanti:'}</h4>
            <p className="text-neutral-600">{entry.triggerEvents}</p>
          </div>
        )}
        
        <div className="flex justify-between mt-2">
          <div>
            <h4 className="text-sm font-medium mb-1 text-rose-700">{isEnglish ? 'Sleep Quality:' : 'Qualità del sonno:'}</h4>
            <div className="flex">
              {Array.from({ length: 5 }).map((_, i) => (
                <i 
                  key={i} 
                  className={`ri-star-fill ${i < entry.sleepQuality! ? 'text-amber-500' : 'text-neutral-200'}`}
                ></i>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-medium mb-1 text-rose-700">{isEnglish ? 'Energy Level:' : 'Livello energia:'}</h4>
            <div className="flex">
              {Array.from({ length: 5 }).map((_, i) => (
                <i 
                  key={i} 
                  className={`ri-battery-fill ${i < entry.energyLevel! ? 'text-green-500' : 'text-neutral-200'}`}
                ></i>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function MoodStatsChart({ stats }: { stats: MoodStats }) {
  const { i18n } = useTranslation();
  const isEnglish = i18n.language === 'en';
  
  const moodData = stats.entries.map(entry => ({
    date: format(new Date(entry.date), 'dd/MM'),
    umore: entry.score,
    mood: entry.score // English key name
  }));
  
  const pieData = [...stats.topEmotions.slice(0, 5)].map((item, index) => ({
    name: item.emotion,
    value: item.count,
    fill: emotionColors[index % emotionColors.length]
  }));
  
  const activityData = [...stats.topActivities.slice(0, 5)].map(item => ({
    name: item.activity,
    value: item.count
  }));
  
  return (
    <div className="space-y-8">
      {/* Mood trend / Andamento dell'umore */}
      <div>
        <h3 className="text-lg font-semibold mb-3 text-rose-800">
          {isEnglish ? 'Mood Trend' : 'Andamento dell\'umore'}
        </h3>
        <div className="h-64 w-full bg-white rounded-xl p-4 shadow-sm">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={moodData}
              margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
            >
              <defs>
                <linearGradient id="colorUmore" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ec4899" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#ec4899" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f9a8d4" opacity={0.3} />
              <XAxis dataKey="date" tick={{ fill: '#9f1239' }} />
              <YAxis domain={[1, 5]} ticks={[1, 2, 3, 4, 5]} tick={{ fill: '#9f1239' }} />
              <RechartsTooltip contentStyle={{ backgroundColor: 'white', borderColor: '#f9a8d4' }} />
              <Area 
                type="monotone" 
                dataKey={isEnglish ? "mood" : "umore"}
                stroke="#be185d" 
                fillOpacity={1} 
                fill="url(#colorUmore)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      {/* General Statistics / Statistiche generali */}
      <div>
        <h3 className="text-lg font-semibold mb-3 text-rose-800">
          {isEnglish ? 'General Statistics' : 'Statistiche generali'}
        </h3>
        <div className="grid grid-cols-3 gap-4">
          <Card className="bg-gradient-to-br from-rose-100 to-pink-100 border-0 shadow-md overflow-hidden">
            <CardContent className="p-4 flex flex-col items-center">
              <p className="text-sm text-rose-700">{isEnglish ? 'Average' : 'Media'}</p>
              <div className="text-3xl font-bold my-2 text-rose-900">{stats.average.toFixed(1)}</div>
              <div className="text-2xl">{moodEmojis[Math.round(stats.average) - 1]}</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-100 to-emerald-100 border-0 shadow-md overflow-hidden">
            <CardContent className="p-4 flex flex-col items-center">
              <p className="text-sm text-emerald-700">{isEnglish ? 'Maximum' : 'Massimo'}</p>
              <div className="text-3xl font-bold my-2 text-emerald-900">{stats.highest}</div>
              <div className="text-2xl">{moodEmojis[stats.highest - 1]}</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-amber-100 to-yellow-100 border-0 shadow-md overflow-hidden">
            <CardContent className="p-4 flex flex-col items-center">
              <p className="text-sm text-amber-700">{isEnglish ? 'Minimum' : 'Minimo'}</p>
              <div className="text-3xl font-bold my-2 text-amber-900">{stats.lowest}</div>
              <div className="text-2xl">{moodEmojis[stats.lowest - 1]}</div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Main Emotions / Emozioni principali */}
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-semibold mb-3 text-rose-800">
            {isEnglish ? 'Main Emotions' : 'Emozioni principali'}
          </h3>
          <div className="h-64 bg-white rounded-xl p-4 shadow-sm">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <RechartsTooltip contentStyle={{ backgroundColor: 'white', borderColor: '#f9a8d4' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Main Activities / Attività principali */}
        <div>
          <h3 className="text-lg font-semibold mb-3 text-rose-800">
            {isEnglish ? 'Main Activities' : 'Attività principali'}
          </h3>
          <div className="h-64 bg-white rounded-xl p-4 shadow-sm">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                layout="vertical"
                data={activityData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f9a8d4" opacity={0.3} />
                <XAxis type="number" tick={{ fill: '#9f1239' }} />
                <YAxis type="category" dataKey="name" width={100} tick={{ fill: '#9f1239' }} />
                <RechartsTooltip contentStyle={{ backgroundColor: 'white', borderColor: '#f9a8d4' }} />
                <Bar dataKey="value" fill="#be185d" barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function MoodPage() {
  const { toast } = useToast();
  const { isAdmin } = useAuth();
  const { t, i18n } = useTranslation();
  const { subscription } = useStripe();
  
  const [activeTab, setActiveTab] = useState('stats');
  const [timeRange, setTimeRange] = useState('month');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  // Determine language specific content
  const currentLanguage = i18n.language;
  const isEnglish = currentLanguage === 'en';
  const emotions = isEnglish ? emotionsEN : emotionsIT;
  const activityOptions = isEnglish ? activityOptionsEN : activityOptionsIT;
  const dateLocale = isEnglish ? enUS : it;

  const handleSubscribe = () => {
    window.location.href = "/premium";
  };

  // Query per recuperare le entries dell'umore
  const { data: entries = [], isLoading: isLoadingEntries } = useQuery<MoodEntry[]>({
    queryKey: ['/api/mood'],
    refetchOnWindowFocus: false,
    queryFn: getQueryFn<MoodEntry[]>({ on401: "returnNull" })
  });

  // Query per recuperare le statistiche dell'umore
  const { data: stats = { 
    average: 0, highest: 0, lowest: 0, entries: [], topEmotions: [], topActivities: [] 
  }, isLoading: isLoadingStats } = useQuery<MoodStats>({
    queryKey: ['/api/mood/stats/user/1'],
    refetchOnWindowFocus: false,
    queryFn: getQueryFn<MoodStats>({ on401: "returnNull" })
  });

  // Mutation per aggiungere una nuova entry / Mutation to add a new entry
  const addMutation = useMutation({
    mutationFn: (entry: Partial<MoodEntry>) => 
      apiRequest('POST', '/api/mood', entry),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mood'] });
      queryClient.invalidateQueries({ queryKey: ['/api/mood/stats/user/1'] });
      setIsAddDialogOpen(false);
      toast({
        title: isEnglish ? "Entry saved" : "Registrazione salvata",
        description: isEnglish ? "Your mood entry has been successfully saved." : "La tua registrazione dell'umore è stata salvata con successo.",
      });
    },
    onError: () => {
      toast({
        title: isEnglish ? "Error" : "Errore",
        description: isEnglish ? "An error occurred while saving." : "Si è verificato un errore durante il salvataggio.",
        variant: "destructive"
      });
    }
  });

  // Mutation per eliminare un'entry / Mutation to delete an entry
  const deleteMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest('DELETE', `/api/mood/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mood'] });
      queryClient.invalidateQueries({ queryKey: ['/api/mood/stats/user/1'] });
      toast({
        title: isEnglish ? "Entry deleted" : "Registrazione eliminata",
        description: isEnglish ? "The entry has been successfully deleted." : "La registrazione è stata eliminata con successo.",
      });
    },
    onError: () => {
      toast({
        title: isEnglish ? "Error" : "Errore",
        description: isEnglish ? "An error occurred while deleting." : "Si è verificato un errore durante l'eliminazione.",
        variant: "destructive"
      });
    }
  });

  const handleAddEntry = (entry: Partial<MoodEntry>) => {
    addMutation.mutate(entry);
  };

  const handleDeleteEntry = (id: number) => {
    const confirmMessage = isEnglish ? "Are you sure you want to delete this entry?" : "Sei sicuro di voler eliminare questa registrazione?";
    if (confirm(confirmMessage)) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <div className="page-container min-h-screen flex flex-col bg-gradient-to-b from-rose-50 via-white to-teal-50 pb-16 md:pb-0">
      <div id="page-top" className="absolute top-0 left-0"></div>
      <Header />
      
      {/* Pattern decorativo */}
      <div className="absolute top-0 left-0 right-0 h-64 bg-[radial-gradient(#f9a8d4_1px,transparent_1px)] [background-size:20px_20px] opacity-20 pointer-events-none"></div>
      
      <main className="flex-grow max-w-4xl mx-auto w-full px-4 py-6 relative z-10">
        <TabNavigation activeTab="mood" />
        
        {/* Elementi decorativi */}
        <div className="absolute -top-10 -right-40 w-96 h-96 bg-pink-200 rounded-full opacity-20 blur-3xl"></div>
        <div className="absolute top-1/3 -left-40 w-80 h-80 bg-teal-200 rounded-full opacity-20 blur-3xl"></div>
        
        {isAdmin || subscription?.isActive ? (
          <>
            <div className="relative">
              {/* Header con gradiente / Gradient header */}
              <div className="p-6 mb-8 rounded-2xl bg-gradient-to-r from-rose-500 to-pink-500 shadow-lg relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMwLTkuOTQtOC4wNi0xOC0xOC0xOFYwYzkuOTQgMCAxOCA4LjA2IDE4IDE4aDEyYzAgOS45NCA4LjA2IDE4IDE4IDE4djEyYy05Ljk0IDAtMTgtOC4wNi0xOC0xOEgzNnoiIGZpbGwtb3BhY2l0eT0iLjEiIGZpbGw9IiNmZmYiLz48L2c+PC9zdmc+')] opacity-20"></div>
                
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
                  <div className="text-white">
                    <h2 className="font-nunito font-bold text-3xl mb-2 flex items-center">
                      <span className="text-4xl mr-3">📊</span> 
                      {isEnglish ? 'Mood Tracking' : 'Monitoraggio dell\'Umore'}
                    </h2>
                    <p className="text-rose-100 text-lg">
                      {isEnglish 
                        ? 'Track your mood and discover patterns over time to improve your wellbeing.' 
                        : 'Tieni traccia del tuo umore e scopri pattern nel tempo per migliorare il tuo benessere.'}
                    </p>
                  </div>
                  <Button 
                    className="bg-white text-rose-600 hover:bg-rose-50 px-6 py-6 h-auto shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
                    onClick={() => setIsAddDialogOpen(true)}
                  >
                    <i className="ri-add-line mr-2 text-xl"></i> 
                    {isEnglish ? 'Record Mood' : 'Registra Umore'}
                  </Button>
                </div>
              </div>
              
              <Tabs 
                defaultValue="stats" 
                value={activeTab} 
                onValueChange={setActiveTab} 
                className="mb-6 bg-white rounded-xl shadow-md p-4 border border-rose-100"
              >
                <TabsList className="mb-6 grid grid-cols-2 gap-4 bg-rose-50 p-1">
                  <TabsTrigger 
                    value="stats" 
                    className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-rose-500 data-[state=active]:to-pink-500 data-[state=active]:text-white"
                  >
                    <i className="ri-bar-chart-2-line mr-2"></i> 
                    {isEnglish ? 'Statistics' : 'Statistiche'}
                  </TabsTrigger>
                  <TabsTrigger 
                    value="history"
                    className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-rose-500 data-[state=active]:to-pink-500 data-[state=active]:text-white"
                  >
                    <i className="ri-history-line mr-2"></i> 
                    {isEnglish ? 'History' : 'Storico'}
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="stats">
                  <div className="mb-6 flex justify-between items-center">
                    <div className="inline-flex bg-rose-50 px-3 py-1 rounded-full text-rose-600 text-sm font-medium">
                      <i className="ri-calendar-line mr-2"></i> 
                      {isEnglish ? 'Filter by period' : 'Filtra per periodo'}
                    </div>
                    <Select value={timeRange} onValueChange={setTimeRange}>
                      <SelectTrigger className="w-40 border-rose-200 focus:ring-rose-500">
                        <SelectValue placeholder={isEnglish ? 'Period' : 'Periodo'} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="week">{isEnglish ? 'Week' : 'Settimana'}</SelectItem>
                        <SelectItem value="month">{isEnglish ? 'Month' : 'Mese'}</SelectItem>
                        <SelectItem value="year">{isEnglish ? 'Year' : 'Anno'}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {isLoadingStats ? (
                    <div className="flex justify-center py-20">
                      <div className="w-12 h-12 rounded-full border-4 border-rose-300 border-t-rose-600 animate-spin"></div>
                    </div>
                  ) : stats && stats.entries.length > 0 ? (
                    <div className="bg-white p-2 rounded-xl">
                      <MoodStatsChart stats={stats} />
                    </div>
                  ) : (
                    <Card className="text-center p-8 border-rose-100 bg-gradient-to-br from-white to-rose-50">
                      <div className="flex flex-col items-center">
                        <div className="w-20 h-20 rounded-full bg-gradient-to-r from-rose-200 to-pink-200 flex items-center justify-center mb-6 shadow-inner">
                          <i className="ri-emotion-line text-3xl text-rose-500"></i>
                        </div>
                        <h3 className="text-xl font-bold mb-3 text-rose-700">
                          {isEnglish ? 'No data available' : 'Nessun dato disponibile'}
                        </h3>
                        <p className="text-neutral-600 mb-6 max-w-md">
                          {isEnglish 
                            ? 'Start recording your mood to see statistics and trends over time. The visualizations will help you better understand your emotional patterns.'
                            : 'Inizia a registrare il tuo umore per vedere statistiche e tendenze nel tempo. Le visualizzazioni ti aiuteranno a comprendere meglio i tuoi pattern emotivi.'}
                        </p>
                        <Button 
                          className="bg-gradient-to-r from-rose-500 to-pink-500 text-white hover:shadow-lg transition-all hover:scale-105"
                          onClick={() => setIsAddDialogOpen(true)}
                        >
                          <i className="ri-add-line mr-2 text-xl"></i> 
                          {isEnglish ? 'Record your mood' : 'Registra il tuo umore'}
                        </Button>
                      </div>
                    </Card>
                  )}
                </TabsContent>
                
                <TabsContent value="history">
                  {isLoadingEntries ? (
                    <div className="flex justify-center py-20">
                      <div className="w-12 h-12 rounded-full border-4 border-rose-300 border-t-rose-600 animate-spin"></div>
                    </div>
                  ) : entries && entries.length > 0 ? (
                    <div className="grid gap-4">
                      {[...entries].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((entry: MoodEntry) => (
                        <MoodEntryCard key={entry.id} entry={entry} onDelete={handleDeleteEntry} />
                      ))}
                    </div>
                  ) : (
                    <Card className="text-center p-8 border-rose-100 bg-gradient-to-br from-white to-rose-50">
                      <div className="flex flex-col items-center">
                        <div className="w-20 h-20 rounded-full bg-gradient-to-r from-rose-200 to-pink-200 flex items-center justify-center mb-6 shadow-inner">
                          <i className="ri-emotion-line text-3xl text-rose-500"></i>
                        </div>
                        <h3 className="text-xl font-bold mb-3 text-rose-700">
                          {isEnglish ? 'No entries found' : 'Nessuna registrazione'}
                        </h3>
                        <p className="text-neutral-600 mb-6 max-w-md">
                          {isEnglish 
                            ? "You haven't recorded your mood yet. Start now to keep track of how you feel and monitor changes over time."
                            : "Non hai ancora registrato il tuo umore. Inizia ora per tenere traccia di come ti senti e monitora i cambiamenti nel tempo."}
                        </p>
                        <Button 
                          className="bg-gradient-to-r from-rose-500 to-pink-500 text-white hover:shadow-lg transition-all hover:scale-105"
                          onClick={() => setIsAddDialogOpen(true)}
                        >
                          <i className="ri-add-line mr-2 text-xl"></i> 
                          {isEnglish ? 'Record your mood' : 'Registra il tuo umore'}
                        </Button>
                      </div>
                    </Card>
                  )}
                </TabsContent>
              </Tabs>
            </div>
            
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>
                    {isEnglish ? 'Record your mood' : 'Registra il tuo umore'}
                  </DialogTitle>
                  <DialogDescription>
                    {isEnglish 
                      ? 'How is your day today? Record your mood to keep track of your emotional wellbeing.'
                      : 'Com\'è la tua giornata oggi? Registra il tuo umore per tenere traccia del tuo benessere emotivo.'}
                  </DialogDescription>
                </DialogHeader>
                
                <MoodEntryForm 
                  onSubmit={handleAddEntry}
                  onCancel={() => setIsAddDialogOpen(false)}
                  isLoading={addMutation.isPending}
                />
              </DialogContent>
            </Dialog>
          </>
        ) : (
          <div className="mt-6">
            <PremiumContent
              title={t('moodTracking.title')}
              description={t('moodTracking.description')}
              onSubscribe={handleSubscribe}
              type="mood"
            />
          </div>
        )}
      </main>
      
      <BottomNavigation />
    </div>
  );
}