import React, { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { useLocation } from 'wouter';
import { ScrollArea } from "@/components/ui/scroll-area";
import { ArrowLeft, Info, BookOpen, Check, Crown, Globe, LifeBuoy, Search, Sparkles } from 'lucide-react';

// Componente per la formattazione statica e sicura del testo
const TextBlock = ({ children }: { children: React.ReactNode }) => (
  <div className="my-3">{children}</div>
);

const Heading1 = ({ children }: { children: React.ReactNode }) => (
  <h1 className="text-3xl font-bold mt-8 mb-4 text-purple-800">{children}</h1>
);

interface Heading2Props {
  children: React.ReactNode;
  id?: string;
}

const Heading2 = ({ children, id }: Heading2Props) => (
  <h2 id={id || `section-${children?.toString().toLowerCase().replace(/\s+/g, '-')}`} 
    className="text-2xl font-bold mt-7 mb-3 text-purple-700">{children}</h2>
);

const Heading3 = ({ children }: { children: React.ReactNode }) => (
  <h3 className="text-xl font-bold mt-6 mb-2 text-purple-600">{children}</h3>
);

const Paragraph = ({ children }: { children: React.ReactNode }) => (
  <p className="my-3 text-neutral-800">{children}</p>
);

const BulletList = ({ items }: { items: React.ReactNode[] }) => (
  <ul className="list-disc my-3 pl-5 space-y-2">
    {items.map((item, index) => (
      <li key={index} className="ml-2 flex items-start">
        <span className="text-purple-500 mr-2">•</span>
        <span>{item}</span>
      </li>
    ))}
  </ul>
);

const NumberedList = ({ items }: { items: React.ReactNode[] }) => (
  <ol className="list-decimal my-3 pl-5 space-y-2">
    {items.map((item, index) => (
      <li key={index} className="ml-2">
        <span className="font-medium text-purple-600">{index + 1}.</span> {item}
      </li>
    ))}
  </ol>
);

const Bold = ({ children }: { children: React.ReactNode }) => (
  <strong className="font-bold">{children}</strong>
);

const Italic = ({ children }: { children: React.ReactNode }) => (
  <em className="italic">{children}</em>
);

export function SafeAppGuidePage() {
  const { i18n, t } = useTranslation();
  const [, navigate] = useLocation();
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  
  // Determine the title of the guide based on language
  const guideTitle = i18n.language === 'it' 
    ? t('app.guide.title', 'Guida App') 
    : t('app.guide.title', 'App Guide');
  
  // Define tab sections for quick navigation
  const tabSections = [
    { 
      id: 'overview', 
      title: i18n.language === 'it' ? 'Panoramica' : 'Overview',
      icon: <BookOpen className="h-4 w-4 mr-1" />
    },
    { 
      id: 'features', 
      title: i18n.language === 'it' ? 'Funzionalità' : 'Features',
      icon: <Sparkles className="h-4 w-4 mr-1" /> 
    },
    { 
      id: 'premium', 
      title: i18n.language === 'it' ? 'Premium' : 'Premium',
      icon: <Crown className="h-4 w-4 mr-1" /> 
    },
    { 
      id: 'support', 
      title: i18n.language === 'it' ? 'Supporto' : 'Support',
      icon: <LifeBuoy className="h-4 w-4 mr-1" /> 
    }
  ];
  
  // Scrolling function (sicuro, usa solo riferimenti React)
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(`section-${sectionId}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };
  
  return (
    <div className="container mx-auto p-4 max-w-4xl mb-16">
      <div className="flex items-center mb-4">
        <Button 
          variant="ghost" 
          size="icon" 
          className="mr-2"
          onClick={() => navigate('/')}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-purple-800">{guideTitle}</h1>
          <p className="text-sm text-neutral-500">
            {i18n.language === 'it' 
              ? 'Guida completa all\'utilizzo di Auralis' 
              : 'Complete guide to using Auralis'}
          </p>
        </div>
      </div>
      
      <Separator className="mb-4" />
      
      <div className="bg-blue-50 p-4 rounded-lg mb-6 flex items-start">
        <Info className="h-5 w-5 text-blue-500 mt-0.5 mr-3 flex-shrink-0" />
        <p className="text-sm text-blue-700">
          {i18n.language === 'it'
            ? 'Questa guida è disponibile in italiano e inglese e si adatta automaticamente alla lingua selezionata.'
            : 'This guide is available in Italian and English and automatically adapts to your selected language.'}
        </p>
      </div>
      
      {/* Quick navigation tabs */}
      <div className="sticky top-0 z-10 bg-white pb-2 shadow-sm rounded mb-4">
        <div className="p-2 bg-purple-50 rounded-lg">
          <div className="flex items-center mb-2">
            <Search className="h-4 w-4 text-purple-500 mr-2" />
            <span className="text-sm font-medium text-purple-700">
              {i18n.language === 'it' ? 'Naviga Sezioni' : 'Navigate Sections'}
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {tabSections.map((section) => (
              <Button 
                key={section.id}
                variant="outline" 
                size="sm"
                onClick={() => scrollToSection(section.id)}
                className="border-purple-300 hover:bg-purple-100 hover:text-purple-800 text-purple-700 flex items-center"
              >
                {section.icon}
                {section.title}
              </Button>
            ))}
          </div>
        </div>
      </div>
      
      <ScrollArea className="h-[calc(100vh-280px)] pr-4" ref={scrollAreaRef}>
        <div className="guide-content">
          {i18n.language === 'it' ? (
            // ITALIAN VERSION
            <>
              <Heading1>Guida Completa all'App Auralis</Heading1>
              
              <Heading2>Introduzione</Heading2>
              <Paragraph>
                Benvenuto in Auralis – il tuo compagno personale per il benessere mentale. 
                Questa guida completa ti accompagnerà attraverso tutte le funzionalità disponibili nella nostra 
                applicazione, aiutandoti a sfruttare al meglio il tuo percorso verso una migliore salute mentale e benessere.
              </Paragraph>
              
              <Heading2 id="section-features">Funzionalità Principali</Heading2>
              
              <Heading3>Creazione del tuo Account</Heading3>
              <Paragraph>
                Per accedere a tutte le funzionalità di Auralis, inizia creando un account:
              </Paragraph>
              <NumberedList items={[
                "Tocca il pulsante di accesso/registrazione nell'angolo in alto a destra",
                "Inserisci il tuo nome utente e password",
                "Completa la registrazione accettando i nostri termini di servizio",
                "Una volta registrato, avrai immediatamente accesso a tutte le funzionalità gratuite"
              ]} />
              
              <Heading3>Navigazione nell'App</Heading3>
              <Paragraph>
                Auralis è progettata con una navigazione intuitiva:
              </Paragraph>
              <BulletList items={[
                <>La <Bold>barra di navigazione inferiore</Bold> fornisce accesso rapido alle sezioni principali</>,
                <>Il <Bold>menu hamburger</Bold> (≡) in alto a destra dà accesso a tutte le funzionalità e impostazioni</>,
                <>Il <Bold>pulsante home</Bold> ti riporterà sempre alla dashboard principale</>
              ]} />
              
              <Heading3>Moduli di Meditazione (Meditazione)</Heading3>
              <Paragraph>
                La nostra sezione di meditazione offre sessioni guidate per il rilassamento e la consapevolezza:
              </Paragraph>
              <Paragraph>
                <Bold>Come Accedere:</Bold>
              </Paragraph>
              <NumberedList items={[
                'Tocca "Meditazione" nella navigazione inferiore o nel menu',
                'Sfoglia i moduli di meditazione disponibili per categoria o lunghezza',
                'Seleziona una sessione di meditazione per visualizzare i dettagli',
                'Premi "Play" per iniziare la sessione guidata'
              ]} />
              <Paragraph>
                <Bold>Caratteristiche:</Bold>
              </Paragraph>
              <BulletList items={[
                'Diverse categorie di meditazione (sonno, ansia, stress, concentrazione, ecc.)',
                'Varie lunghezze di sessione (5-30 minuti)',
                'Suoni di sottofondo e visuali calmanti',
                'Monitoraggio dei progressi'
              ]} />
              
              <Heading3>Esercizi CBT (Esercizi)</Heading3>
              <Paragraph>
                Esercizi di terapia cognitivo-comportamentale basati su evidenze per migliorare la salute mentale:
              </Paragraph>
              <Paragraph>
                <Bold>Categorie di Esercizi:</Bold>
              </Paragraph>
              <BulletList items={[
                <><Bold>Sfida ai pensieri</Bold> - Identificare e reinterpretare modelli di pensiero negativi</>,
                <><Bold>Attivazione comportamentale</Bold> - Aumentare il coinvolgimento in attività positive</>,
                <><Bold>Tecniche di esposizione</Bold> - Affrontare gradualmente le paure in modo controllato</>,
                <><Bold>Allenamento al rilassamento</Bold> - Metodi per rilassarsi fisicamente e mentalmente</>,
                <><Bold>Problem-solving</Bold> - Approcci strutturati per affrontare le sfide</>,
                <><Bold>Pratiche di mindfulness</Bold> - Esercizi per aumentare la consapevolezza del presente</>
              ]} />
              
              <Heading2 id="section-premium">Funzionalità Premium</Heading2>
              <Paragraph>
                Auralis offre un abbonamento premium che migliora la tua esperienza con:
              </Paragraph>
              <Heading3>Benefici Premium</Heading3>
              <BulletList items={[
                <><Bold>Conversazioni chat illimitate</Bold> - Nessun limite giornaliero</>,
                <><Bold>Biblioteca completa di esercizi</Bold> - Accesso a tutti gli esercizi CBT</>,
                <><Bold>Collezione completa di meditazioni</Bold> - Incluse sessioni estese e specializzate</>,
                <><Bold>Analisi avanzate dell'umore</Bold> - Approfondimenti dettagliati e opzioni di esportazione</>,
                <><Bold>Accesso illimitato ai moduli AI</Bold> - Utilizza tutti gli strumenti specializzati senza restrizioni</>,
                <><Bold>Contenuti premium esclusivi</Bold> - Accesso a guide approfondite e risorse</>,
                <><Bold>Esperienza senza pubblicità</Bold> - Utilizzo ininterrotto</>,
                <><Bold>Aggiornamenti prioritari dei contenuti</Bold> - Sii il primo ad accedere alle nuove funzionalità</>
              ]} />
              
              <Heading3>Opzioni di Abbonamento</Heading3>
              <BulletList items={[
                <><Bold>Piano Mensile</Bold>: €4,99/mese con facile cancellazione</>,
                <><Bold>Piano Annuale</Bold>: €39,99/anno (risparmio oltre il 30%)</>,
                <>Tutti gli abbonamenti includono una prova gratuita di 7 giorni</>
              ]} />
              
              <Heading2 id="section-support">Risoluzione dei Problemi e Supporto</Heading2>
              <Heading3>Problemi Comuni</Heading3>
              <BulletList items={[
                <><Bold>App non carica</Bold>: Assicurati di avere una connessione internet stabile</>,
                <><Bold>Contenuti non visualizzati</Bold>: Prova ad aggiornare la pagina o riavviare l'app</>,
                <><Bold>Problemi di login</Bold>: Usa l'opzione di ripristino password o contatta il supporto</>
              ]} />
              
              <Heading3>Ottenere Aiuto</Heading3>
              <Paragraph>
                Se hai bisogno di assistenza con l'app, puoi:
              </Paragraph>
              <BulletList items={[
                <>Visitare questa guida attraverso la voce "Help" nel menu hamburger</>,
                <>Consultare la pagina Premium per domande sull'abbonamento</>,
                <>
                  <span 
                    className="text-purple-600 cursor-pointer underline"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      window.location.href = '/support';
                    }}
                  >
                    Inviare una richiesta attraverso il modulo di supporto
                  </span>
                </>
              ]} />
              
              <Heading2>Consigli per Massimi Benefici</Heading2>
              <NumberedList items={[
                <><Bold>Usa regolarmente</Bold> - Il benessere mentale trae vantaggio dalla pratica costante</>,
                <><Bold>Prova diverse funzionalità</Bold> - Esplora vari strumenti per trovare ciò che funziona meglio per te</>,
                <><Bold>Monitora i tuoi progressi</Bold> - La registrazione regolare dell'umore fornisce preziosi spunti</>,
                <><Bold>Combina gli approcci</Bold> - Ad esempio, abbina la meditazione con gli esercizi CBT</>,
                <><Bold>Imposta promemoria</Bold> - Programma check-in regolari con te stesso</>,
                <><Bold>Sii paziente</Bold> - Il miglioramento della salute mentale richiede tempo</>
              ]} />
              
              <Paragraph>
                Speriamo che questa guida ti aiuti a ottenere il massimo da Auralis mentre progredisci nel tuo percorso di benessere. 
                Ricorda che la salute mentale è un processo continuo, e siamo qui per supportarti in ogni fase del cammino.
              </Paragraph>
            </>
          ) : (
            // ENGLISH VERSION
            <>
              <Heading1>Complete Guide to the Auralis App</Heading1>
              
              <Heading2>Introduction</Heading2>
              <Paragraph>
                Welcome to Auralis – your personal companion for mental wellbeing. 
                This comprehensive guide will walk you through all the features and functions 
                available in our application, helping you make the most of your journey toward improved mental health and wellness.
              </Paragraph>
              
              <Heading2 id="section-features">Core Features</Heading2>
              
              <Heading3>Creating Your Account</Heading3>
              <Paragraph>
                To access all features of Auralis, start by creating an account:
              </Paragraph>
              <NumberedList items={[
                'Tap the login/register button in the top right corner',
                'Enter your username and password',
                'Complete the registration by accepting our terms of service',
                'Once registered, you will have immediate access to all free features'
              ]} />
              
              <Heading3>Navigating the App</Heading3>
              <Paragraph>
                Auralis is designed with intuitive navigation:
              </Paragraph>
              <BulletList items={[
                <>The <Bold>bottom navigation bar</Bold> provides quick access to main sections</>,
                <>The <Bold>hamburger menu</Bold> (≡) in the top right gives access to all features and settings</>,
                <>The <Bold>home button</Bold> will always take you back to the main dashboard</>
              ]} />
              
              <Heading3>Meditation Modules</Heading3>
              <Paragraph>
                Our meditation section offers guided sessions for relaxation and mindfulness:
              </Paragraph>
              <Paragraph>
                <Bold>How to Access:</Bold>
              </Paragraph>
              <NumberedList items={[
                'Tap "Meditation" in the bottom navigation or menu',
                'Browse the available meditation modules by category or length',
                'Select a meditation session to view details',
                'Press "Play" to begin the guided session'
              ]} />
              <Paragraph>
                <Bold>Features:</Bold>
              </Paragraph>
              <BulletList items={[
                'Diverse meditation categories (sleep, anxiety, stress, focus, etc.)',
                'Various session lengths (5-30 minutes)',
                'Background sounds and calming visuals',
                'Progress tracking'
              ]} />
              
              <Heading3>CBT Exercises</Heading3>
              <Paragraph>
                Evidence-based cognitive behavioral therapy exercises to improve mental health:
              </Paragraph>
              <Paragraph>
                <Bold>Exercise Categories:</Bold>
              </Paragraph>
              <BulletList items={[
                <><Bold>Thought challenging</Bold> - Identify and reframe negative thought patterns</>,
                <><Bold>Behavioral activation</Bold> - Increase engagement in positive activities</>,
                <><Bold>Exposure techniques</Bold> - Gradually face fears in a controlled manner</>,
                <><Bold>Relaxation training</Bold> - Methods to physically and mentally relax</>,
                <><Bold>Problem-solving</Bold> - Structured approaches to tackle challenges</>,
                <><Bold>Mindfulness practices</Bold> - Exercises to increase present awareness</>
              ]} />
              
              <Heading2 id="section-premium">Premium Features</Heading2>
              <Paragraph>
                Auralis offers a premium subscription that enhances your experience with:
              </Paragraph>
              <Heading3>Premium Benefits</Heading3>
              <BulletList items={[
                <><Bold>Unlimited chat conversations</Bold> - No daily limits</>,
                <><Bold>Complete exercise library</Bold> - Access all CBT exercises</>,
                <><Bold>Full meditation collection</Bold> - Including extended and specialized sessions</>,
                <><Bold>Advanced mood analytics</Bold> - Detailed insights and export options</>,
                <><Bold>Unlimited AI module access</Bold> - Use all specialized tools without restrictions</>,
                <><Bold>Exclusive premium content</Bold> - Access to in-depth guides and resources</>,
                <><Bold>Ad-free experience</Bold> - Uninterrupted usage</>,
                <><Bold>Priority content updates</Bold> - Be the first to access new features</>
              ]} />
              
              <Heading3>Subscription Options</Heading3>
              <BulletList items={[
                <><Bold>Monthly Plan</Bold>: €4.99/month with easy cancellation</>,
                <><Bold>Annual Plan</Bold>: €39.99/year (saving over 30%)</>,
                <>All subscriptions include a 7-day free trial</>
              ]} />
              
              <Heading2 id="section-support">Troubleshooting & Support</Heading2>
              <Heading3>Common Issues</Heading3>
              <BulletList items={[
                <><Bold>App not loading</Bold>: Ensure you have a stable internet connection</>,
                <><Bold>Content not displaying</Bold>: Try refreshing the page or restarting the app</>,
                <><Bold>Login problems</Bold>: Use the password reset option or contact support</>
              ]} />
              
              <Heading3>Getting Help</Heading3>
              <Paragraph>
                If you need assistance with the app, you can:
              </Paragraph>
              <BulletList items={[
                <>Visit this guide through the "Help" option in the hamburger menu</>,
                <>Review the information in the Premium page for subscription-related questions</>,
                <>
                  <span 
                    className="text-purple-600 cursor-pointer underline"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      window.location.href = '/support';
                    }}
                  >
                    Submit a request through our support form
                  </span>
                </>
              ]} />
              
              <Heading2>Tips for Maximum Benefit</Heading2>
              <NumberedList items={[
                <><Bold>Use regularly</Bold> - Mental wellness benefits from consistent practice</>,
                <><Bold>Try different features</Bold> - Explore various tools to find what works best for you</>,
                <><Bold>Track your progress</Bold> - Regular mood logging provides valuable insights</>,
                <><Bold>Combine approaches</Bold> - For example, pair meditation with CBT exercises</>,
                <><Bold>Set reminders</Bold> - Schedule regular check-ins with yourself</>,
                <><Bold>Be patient</Bold> - Mental wellness improvement takes time</>
              ]} />
              
              <Paragraph>
                We hope this guide helps you get the most from Auralis as you progress on your wellness journey. 
                Remember that mental health is a continuous process, and we're here to support you every step of the way.
              </Paragraph>
            </>
          )}
          
          {/* Bottom Footer with quick links */}
          <div className="mt-12 p-6 bg-purple-50 rounded-lg border border-purple-100">
            <h3 className="text-lg font-bold text-purple-700 mb-3">
              {i18n.language === 'it' ? 'Collegamenti Rapidi' : 'Quick Links'}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Button
                variant="outline"
                className="w-full justify-start border-purple-300 hover:bg-purple-100"
                onClick={() => navigate('/chat')}
              >
                <i className="ri-chat-3-line mr-2 text-purple-600"></i>
                {i18n.language === 'it' ? 'Vai alla Chat' : 'Go to Chat'}
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start border-purple-300 hover:bg-purple-100"
                onClick={() => navigate('/meditation')}
              >
                <i className="ri-emotion-happy-line mr-2 text-purple-600"></i>
                {i18n.language === 'it' ? 'Esplora Meditazioni' : 'Explore Meditations'}
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start border-purple-300 hover:bg-purple-100"
                onClick={() => navigate('/exercises')}
              >
                <i className="ri-mental-health-line mr-2 text-purple-600"></i>
                {i18n.language === 'it' ? 'Prova Esercizi' : 'Try Exercises'}
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start border-purple-300 hover:bg-purple-100"
                onClick={() => navigate('/subscription')}
              >
                <i className="ri-vip-crown-line mr-2 text-purple-600"></i>
                {i18n.language === 'it' ? 'Scopri Premium' : 'Discover Premium'}
              </Button>
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}

export default SafeAppGuidePage;