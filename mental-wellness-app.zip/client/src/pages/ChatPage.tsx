import React, { useState, useEffect } from 'react';
import Header from '@/components/SimpleHeader';
import DisclaimerBanner from '@/components/DisclaimerBanner';
import TabNavigation from '@/components/TabNavigation';
import ChatInterface from '@/components/ChatInterface';
import QuickAccessModules from '@/components/QuickAccessModules';
import BottomNavigation from '@/components/BottomNavigation';
import { type Module } from '@/lib/types';
import { useTranslation } from 'react-i18next';

// I moduli saranno definiti nella funzione del componente per usare le traduzioni

const ChatPage: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [language, setLanguage] = useState(i18n.language);
  
  // Forza il rendering quando la lingua cambia
  useEffect(() => {
    const handleLanguageChange = () => {
      setLanguage(i18n.language);
      console.log("Language changed in ChatPage:", i18n.language);
    };
    
    i18n.on('languageChanged', handleLanguageChange);
    
    return () => {
      i18n.off('languageChanged', handleLanguageChange);
    };
  }, [i18n]);
  
  // Definizione dei moduli con traduzioni
  const modules: Module[] = [
    {
      id: 1,
      title: t('homepage.meditation', 'Meditazione Guidata'),
      description: t('homepage.meditationDescription', 'Sessioni guidate per ridurre stress e ansia'),
      icon: 'ri-mental-health-line',
      color: 'blue-600',
      route: '/meditation'
    },
    {
      id: 2,
      title: t('homepage.cbtExercises', 'Esercizi CBT'),
      description: t('homepage.exercisesDescription', 'Tecniche pratiche basate su evidenze scientifiche'),
      icon: 'ri-mental-health-fill',
      color: 'emerald-600',
      route: '/exercises'
    },
    {
      id: 3,
      title: t('homepage.moodTracking', 'Monitoraggio Umore'),
      description: t('homepage.moodDescription', 'Traccia e analizza il tuo umore nel tempo'),
      icon: 'ri-emotion-line',
      color: 'rose-600',
      route: '/mood',
      isPremium: true
    }
  ];
  
  return (
    <div className="page-container min-h-screen flex flex-col bg-gradient-to-b from-teal-50 to-cyan-50 pb-16 md:pb-0">
      <div id="page-top" className="absolute top-0 left-0"></div>
      <Header />
      
      {/* Pattern decorativo */}
      <div className="absolute top-0 left-0 right-0 h-64 bg-[radial-gradient(#d1fafe_1px,transparent_1px)] [background-size:20px_20px] opacity-30 pointer-events-none"></div>
      <div className="absolute -bottom-16 left-0 right-0 h-64 bg-gradient-to-t from-transparent to-teal-50/20 pointer-events-none"></div>
      
      <div className="absolute top-20 right-5 w-24 h-24 bg-gradient-to-br from-cyan-300/20 to-teal-300/20 rounded-full blur-2xl"></div>
      <div className="absolute top-40 left-5 w-32 h-32 bg-gradient-to-br from-teal-300/20 to-cyan-300/20 rounded-full blur-2xl"></div>
      
      <main className="flex-grow max-w-3xl mx-auto w-full px-4 py-6 relative z-10">
        <div className="mb-6 text-center">
          <div className="inline-flex items-center bg-teal-100 text-teal-800 px-3 py-1 rounded-full text-sm font-medium mb-2">
            <i className="ri-chat-smile-3-line text-lg mr-2"></i> {t('chatPage.badge', 'Chat Assistivo')}
          </div>
          <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-teal-700 via-teal-600 to-cyan-700 text-transparent bg-clip-text">
            {t('chatPage.title', 'Il tuo compagno di benessere')}
          </h1>
        </div>
        
        <div className="relative z-10 mb-6">
          <DisclaimerBanner />
        </div>
        
        <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg overflow-hidden mb-8 relative">
          <div className="h-1 bg-gradient-to-r from-teal-400 to-cyan-400"></div>
          <TabNavigation activeTab="chat" />
          <ChatInterface />
        </div>
        
        <div className="bg-white/70 backdrop-blur-sm rounded-xl p-5 shadow-lg mb-4 border border-teal-100">
          <h2 className="text-lg font-bold text-teal-800 mb-4 flex items-center">
            <i className="ri-compass-3-line mr-2 text-teal-600"></i> {t('chatPage.exploreTools', 'Esplora altri strumenti')}
          </h2>
          <QuickAccessModules modules={modules} />
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
};

export default ChatPage;