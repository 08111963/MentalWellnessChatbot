import React, { useEffect } from 'react';
import { ResourceRecommendations } from '@/components/ResourceRecommendations';
import TabNavigation from '@/components/TabNavigation';
import Header from '@/components/Header';
import BottomNavigation from '@/components/BottomNavigation';
import { useTranslation } from 'react-i18next';

export default function ResourcesPage() {
  const { t } = useTranslation();
  
  // Questo effetto assicura che la pagina si apra dall'inizio ogni volta
  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: 'auto'
    });
    
    // Per browser più vecchi o casi particolari
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }, []);
  
  return (
    <div className="flex flex-col min-h-screen" id="resource-page-top">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-6">
        <div id="page-top"></div>
        <h1 className="text-3xl font-bold text-center mb-8">{t('resourcesPage.title')}</h1>
        <ResourceRecommendations />
      </main>
      <TabNavigation activeTab="resources" />
      <BottomNavigation />
    </div>
  );
}