import React, { useState, useEffect, useMemo } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';
// 
import Header2 from '@/components/Header2';
import TabNavigation from '@/components/TabNavigation';
import BottomNavigation2 from '@/components/BottomNavigation2';
import { EmergencyHomeButton } from '@/components/EmergencyHome';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/lib/auth-context';
import { useStripe } from '@/lib/stripe-context';
import { type Reflection } from '@/lib/types';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';

// Colori associati alle categorie di riflessione
const categoryColors: Record<string, string> = {
  "gratitudine": "bg-amber-600",
  "resilienza": "bg-emerald-600",
  "auto-consapevolezza": "bg-blue-600",
  "auto-stima": "bg-purple-600",
  "auto-compassione": "bg-rose-600",
  "consapevolezza": "bg-cyan-600",
  "crescita": "bg-teal-600",
  "connessione": "bg-indigo-600",
  "flow": "bg-violet-600"
};

// Badge colori per le categorie
const categoryBadgeColors: Record<string, string> = {
  "gratitudine": "bg-amber-100 text-amber-800 border-amber-200",
  "resilienza": "bg-emerald-100 text-emerald-800 border-emerald-200",
  "auto-consapevolezza": "bg-blue-100 text-blue-800 border-blue-200",
  "auto-stima": "bg-purple-100 text-purple-800 border-purple-200",
  "auto-compassione": "bg-rose-100 text-rose-800 border-rose-200",
  "consapevolezza": "bg-cyan-100 text-cyan-800 border-cyan-200",
  "crescita": "bg-teal-100 text-teal-800 border-teal-200",
  "connessione": "bg-indigo-100 text-indigo-800 border-indigo-200",
  "flow": "bg-violet-100 text-violet-800 border-violet-200"
};

const ReflectionsPage: React.FC = () => {
  const [userReflection, setUserReflection] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [generatedReflection, setGeneratedReflection] = useState<string | null>(null);
  const [selectedReflection, setSelectedReflection] = useState<Reflection | null>(null);
  const [savedReflections, setSavedReflections] = useState<Record<number, string>>({});
  const { toast } = useToast();
  const { t, i18n } = useTranslation();
  const { isAdmin } = useAuth();
  const stripe = useStripe();
  
  // Verifica dello stato premium
  const legacyPremium = localStorage.getItem('auralis_premium') === 'true';
  const localAdmin = localStorage.getItem('guida_admin') === 'true';
  const hasActiveSub = stripe.isSubscriptionActive();
  // Utilizziamo la navigazione diretta con window.location invece di useLocation
  
  // Funzione per la navigazione con il router di wouter
  // Navigazione gestita direttamente dai componenti di navigazione

  // Chiave per salvare le riflessioni dell'utente
  const SAVED_REFLECTIONS_KEY = 'mentebene_saved_reflections';
  
  // Carica tutte le riflessioni (sia free che premium)
  const { data: allReflections, isLoading } = useQuery<Reflection[]>({
    queryKey: ['/api/reflections?showAll=true'],
  });

  // Carica le riflessioni salvate dal localStorage
  useEffect(() => {
    const saved = localStorage.getItem(SAVED_REFLECTIONS_KEY);
    if (saved) {
      try {
        setSavedReflections(JSON.parse(saved));
      } catch (e) {
        console.error('Errore nel parsing delle riflessioni salvate:', e);
      }
    }
  }, []);
  
  // Mutation per generare una risposta AI
  const generateMutation = useMutation({
    mutationFn: async (theme: string) => {
      const response = await apiRequest('POST', '/api/reflections/generate', {
        theme: theme,
        previousReflections: []
      });
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedReflection(data.reflection);
      toast({
        title: t('reflectionsPage.successMessages.reflectionGenerated'),
        description: t('reflectionsPage.successMessages.reflectionGeneratedDescription'),
      });
    },
    onError: () => {
      toast({
        title: t('reflectionsPage.errorMessages.error'),
        description: t('reflectionsPage.errorMessages.errorDescription'),
        variant: 'destructive'
      });
    }
  });
  
  // Funzione per generare una risposta AI
  const handleGenerateAIReflection = () => {
    if (!userReflection.trim()) {
      toast({
        title: t('reflectionsPage.errorMessages.emptyReflection'),
        description: t('reflectionsPage.errorMessages.emptyReflectionDescription'),
        variant: 'destructive'
      });
      return;
    }
    
    generateMutation.mutate(userReflection);
  };

  // Funzione per salvare una riflessione
  const handleSaveReflection = (reflectionId: number, text: string) => {
    if (!text.trim()) {
      toast({
        title: t('reflectionsPage.errorMessages.emptyReflection'),
        description: t('reflectionsPage.errorMessages.emptyReflectionDescription'),
        variant: 'destructive'
      });
      return;
    }
    
    const updatedReflections = { ...savedReflections, [reflectionId]: text };
    setSavedReflections(updatedReflections);
    localStorage.setItem(SAVED_REFLECTIONS_KEY, JSON.stringify(updatedReflections));
    
    toast({
      title: t('reflectionsPage.successMessages.reflectionSaved'),
      description: t('reflectionsPage.successMessages.reflectionSavedDescription'),
    });
  };
  
  // Estrai le categorie uniche dalle riflessioni
  const categories = useMemo(() => {
    if (!allReflections) return ['all'];
    
    const uniqueCategories = ['all'];
    const seenCategories: Record<string, boolean> = {};
    
    allReflections.forEach(reflection => {
      if (!seenCategories[reflection.category]) {
        seenCategories[reflection.category] = true;
        uniqueCategories.push(reflection.category);
      }
    });
    
    return uniqueCategories;
  }, [allReflections]);
  
  // Filtra le riflessioni in base alla categoria e alla ricerca
  const filteredReflections = useMemo(() => {
    if (!allReflections) return [];
    
    let filtered = activeCategory === 'all'
      ? allReflections
      : allReflections.filter(reflection => reflection.category.toLowerCase() === activeCategory.toLowerCase());
    
    // Se c'è una query di ricerca, filtra ulteriormente
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(reflection => 
        reflection.prompt.toLowerCase().includes(query) || 
        reflection.category.toLowerCase().includes(query)
      );
    }
    
    return filtered;
  }, [allReflections, activeCategory, searchQuery]);
  
  // Stato admin già ottenuto all'inizio del componente
  
  // Handler per l'abbonamento
  const handleSubscribe = () => {
    window.location.href = '/subscription';
  };
  
  // Seleziona una riflessione specifica
  const handleSelectReflection = (reflection: Reflection) => {
    // Usiamo le variabili già dichiarate all'inizio del componente
    
    // Gli admin e utenti con abbonamento possono accedere a tutti i contenuti premium
    if (reflection.isPremium && !isAdmin && !hasActiveSub && !legacyPremium && !localAdmin) {
      // Reindirizza alla pagina di abbonamento
      handleSubscribe();
      return;
    }
    
    // Previeni l'evento di navigazione default che potrebbe interferire
    document.body.style.pointerEvents = 'none';
    setTimeout(() => {
      document.body.style.pointerEvents = 'auto';
      // Altrimenti, mostra la riflessione
      setSelectedReflection(reflection);
      setUserReflection(savedReflections[reflection.id] || '');
      setGeneratedReflection(null);
    }, 50);
  };
  
  // Torna alla lista delle riflessioni
  const handleBackToList = () => {
    setSelectedReflection(null);
    setUserReflection('');
    setGeneratedReflection(null);
  };
  
  // Prende una riflessione casuale
  const handleRandomReflection = () => {
    if (allReflections && allReflections.length > 0) {
      const randomIndex = Math.floor(Math.random() * allReflections.length);
      handleSelectReflection(allReflections[randomIndex]);
    }
  };
  
  // Ottiene il colore per una categoria
  const getCategoryColor = (category: string) => {
    return categoryColors[category] || "bg-gray-600";
  };
  
  // Ottiene il colore del badge per una categoria
  const getCategoryBadgeColor = (category: string) => {
    return categoryBadgeColors[category] || "bg-gray-100 text-gray-800 border-gray-200";
  };
  
  // Genera una classe di gradiente basata sulla categoria
  const getGradientClass = (category: string) => {
    if (category === 'auto-compassione') return 'from-rose-500 to-pink-500';
    if (category === 'gratitudine') return 'from-amber-500 to-yellow-500';
    if (category === 'resilienza') return 'from-emerald-500 to-green-500';
    if (category === 'crescita') return 'from-teal-500 to-emerald-500';
    if (category === 'consapevolezza') return 'from-cyan-500 to-blue-500';
    if (category === 'auto-stima') return 'from-purple-500 to-violet-500';
    if (category === 'connessione') return 'from-indigo-500 to-blue-500';
    if (category === 'flow') return 'from-violet-500 to-purple-500';
    return 'from-blue-500 to-indigo-500';
  };
  
  // Genera una classe di sfondo leggero basata sulla categoria
  const getLightBgClass = (category: string) => {
    if (category === 'auto-compassione') return 'bg-rose-50';
    if (category === 'gratitudine') return 'bg-amber-50';
    if (category === 'resilienza') return 'bg-emerald-50';
    if (category === 'crescita') return 'bg-teal-50';
    if (category === 'consapevolezza') return 'bg-cyan-50';
    if (category === 'auto-stima') return 'bg-purple-50';
    if (category === 'connessione') return 'bg-indigo-50';
    if (category === 'flow') return 'bg-violet-50';
    return 'bg-blue-50';
  };
  
  // Genera una classe di bordo basata sulla categoria
  const getBorderClass = (category: string) => {
    if (category === 'auto-compassione') return 'border-rose-200';
    if (category === 'gratitudine') return 'border-amber-200';
    if (category === 'resilienza') return 'border-emerald-200';
    if (category === 'crescita') return 'border-teal-200';
    if (category === 'consapevolezza') return 'border-cyan-200';
    if (category === 'auto-stima') return 'border-purple-200';
    if (category === 'connessione') return 'border-indigo-200';
    if (category === 'flow') return 'border-violet-200';
    return 'border-blue-200';
  };
  
  return (
    <div className="page-container min-h-screen flex flex-col bg-gradient-to-b from-purple-50 via-white to-violet-50 pb-16 md:pb-0">
      <div id="page-top" className="absolute top-0 left-0"></div>
      <Header2 />
      
      {/* Pattern decorativo */}
      <div className="absolute top-0 left-0 right-0 h-64 bg-gradient-to-br from-purple-600/10 to-violet-600/10 pointer-events-none"></div>
      <div className="absolute top-0 left-0 right-0 h-64 bg-[radial-gradient(#c4b5fd_1px,transparent_1px)] [background-size:20px_20px] opacity-20 pointer-events-none"></div>
      
      {/* Elementi decorativi */}
      <div className="absolute -top-20 right-0 w-96 h-96 bg-purple-200 rounded-full opacity-20 blur-3xl"></div>
      <div className="absolute top-1/3 left-0 w-80 h-80 bg-violet-200 rounded-full opacity-20 blur-3xl"></div>
      
      <main className="reflections-content flex-grow max-w-3xl mx-auto w-full px-4 py-6 relative z-10">
        <EmergencyHomeButton discreet={true} />
        
        <TabNavigation activeTab="reflections" />
        
        {selectedReflection ? (
          <div>
            <Button 
              variant="ghost" 
              className="mb-4 btn-secondary"
              onClick={handleBackToList}
            >
              <i className="ri-arrow-left-s-line mr-2"></i> {t('reflectionsPage.backToList')}
            </Button>
            
            <Card className="mb-6">
              <CardHeader className={`${getCategoryColor(selectedReflection.category)} text-white`}>
                <CardTitle>
                  {t('reflectionsPage.reflectionPrompt')}
                  {selectedReflection.isPremium && (() => {
                    // Usiamo le variabili già dichiarate all'inizio del componente
                    const showPremiumBadge = !hasActiveSub && !legacyPremium && !localAdmin && !isAdmin;
                    
                    return showPremiumBadge ? (
                      <span className="ml-2 inline-flex items-center text-yellow-200 text-xs">
                        <span className="mr-0.5">⭐</span> {t('reflectionsPage.premium')}
                      </span>
                    ) : null;
                  })()}
                </CardTitle>
                <CardDescription className="text-white opacity-90">
                  {t('reflectionsPage.category')} 
                  {t(`reflectionsPage.categories.${selectedReflection.category}`) !== `reflectionsPage.categories.${selectedReflection.category}` ? 
                    t(`reflectionsPage.categories.${selectedReflection.category}`) : 
                    selectedReflection.category.charAt(0).toUpperCase() + selectedReflection.category.slice(1)}
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <p className="text-lg font-medium mb-6">
                  {t(`reflectionsPage.prompts.${selectedReflection.id}`) !== `reflectionsPage.prompts.${selectedReflection.id}` 
                    ? t(`reflectionsPage.prompts.${selectedReflection.id}`) 
                    : selectedReflection.prompt}
                </p>
                
                <Textarea
                  placeholder={t('reflectionsPage.writeYourThoughts')}
                  className="min-h-32"
                  value={userReflection}
                  onChange={(e) => setUserReflection(e.target.value)}
                />
              </CardContent>
              <CardFooter className="flex justify-between gap-4 flex-wrap">
                <Button 
                  variant="outline"
                  className="btn-secondary" 
                  onClick={() => handleSaveReflection(selectedReflection.id, userReflection)}
                >
                  <i className="ri-save-line mr-2"></i> {t('reflectionsPage.saveReflection')}
                </Button>
                <Button 
                  className={`${getCategoryColor(selectedReflection.category)} btn-action`}
                  onClick={handleGenerateAIReflection}
                  disabled={generateMutation.isPending}
                >
                  {generateMutation.isPending ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      {t('reflectionsPage.generating')}
                    </>
                  ) : (
                    <><i className="ri-magic-line mr-2"></i> {t('reflectionsPage.generatePerspective')}</>
                  )}
                </Button>
              </CardFooter>
            </Card>
            
            {generatedReflection && selectedReflection && (
              <Card className={`border-l-4 ${selectedReflection.category === 'auto-compassione' ? 'border-rose-400' : 
                selectedReflection.category === 'gratitudine' ? 'border-amber-400' : 
                selectedReflection.category === 'resilienza' ? 'border-emerald-400' :
                selectedReflection.category === 'crescita' ? 'border-teal-400' :
                selectedReflection.category === 'consapevolezza' ? 'border-cyan-400' :
                selectedReflection.category === 'auto-stima' ? 'border-purple-400' :
                selectedReflection.category === 'connessione' ? 'border-indigo-400' :
                selectedReflection.category === 'flow' ? 'border-violet-400' :
                'border-blue-400'}`}>
                <CardHeader>
                  <CardTitle className="text-gray-700">{t('reflectionsPage.generatedPerspective')}</CardTitle>
                  <CardDescription>
                    {t('reflectionsPage.newPerspective')}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="italic text-gray-700">{generatedReflection}</p>
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          <div>
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="font-nunito font-bold text-2xl">{t('reflectionsPage.title')}</h2>
                <p className="text-neutral-600">{t('reflectionsPage.subtitle')}</p>
              </div>
              <Button 
                className="btn-action"
                onClick={handleRandomReflection}
              >
                <i className="ri-shuffle-line mr-2"></i> {t('reflectionsPage.randomReflection')}
              </Button>
            </div>
            
            {/* Barra di ricerca */}
            <div className="relative mb-6">
              <Input
                type="text"
                placeholder={t('reflectionsPage.searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400">
                <i className="ri-search-line"></i>
              </div>
              {searchQuery && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 h-7 w-7 p-0"
                  onClick={() => setSearchQuery('')}
                >
                  <i className="ri-close-line"></i>
                </Button>
              )}
            </div>
            
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : (
              <div>
                <Tabs defaultValue="all" className="mb-6">
                  <TabsList className="reflections-categories mb-4 flex flex-wrap">
                    {categories.map(category => (
                      <TabsTrigger 
                        key={category} 
                        value={category}
                        onClick={() => setActiveCategory(category)}
                      >
                        {category === 'all' ? t('reflectionsPage.allCategories') : 
                          (t(`reflectionsPage.categories.${category}`) !== `reflectionsPage.categories.${category}` ? 
                            t(`reflectionsPage.categories.${category}`) : 
                            category.charAt(0).toUpperCase() + category.slice(1))
                        }
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
                
                {filteredReflections.length === 0 ? (
                  <Card className="text-center p-8">
                    <div className="flex flex-col items-center">
                      <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mb-4">
                        <i className="ri-file-search-line text-2xl text-neutral-400"></i>
                      </div>
                      <h3 className="text-lg font-semibold mb-2">{t('reflectionsPage.noReflectionsFound')}</h3>
                      <p className="text-neutral-600 mb-4">
                        {searchQuery 
                          ? t('reflectionsPage.noSearchResults').replace('{query}', searchQuery)
                          : t('reflectionsPage.noCategoryResults').replace('{category}', 
                              activeCategory === 'all' ? t('reflectionsPage.allCategories') : 
                              (t(`reflectionsPage.categories.${activeCategory}`) !== `reflectionsPage.categories.${activeCategory}` ? 
                                t(`reflectionsPage.categories.${activeCategory}`) : 
                                activeCategory.charAt(0).toUpperCase() + activeCategory.slice(1))
                            )}
                      </p>
                      <Button 
                        variant="outline"
                        className="btn-secondary" 
                        onClick={() => {
                          setSearchQuery('');
                          setActiveCategory('all');
                        }}
                      >
                        <i className="ri-refresh-line mr-2"></i> {t('reflectionsPage.showAllReflections')}
                      </Button>
                    </div>
                  </Card>
                ) : (
                  <div className="reflections-list grid grid-cols-1 gap-5">
                    {filteredReflections.map((reflection) => {
                      
                      return (
                        <Card 
                          key={reflection.id} 
                          className={`cursor-pointer hover:shadow-xl transition-all hover:-translate-y-1 relative group overflow-hidden ${savedReflections[reflection.id] ? `border-l-4 ${getBorderClass(reflection.category)}` : 'border-none'}`}
                          onClick={() => handleSelectReflection(reflection)}
                        >
                          {/* Elementi decorativi */}
                          <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${getGradientClass(reflection.category)}`}></div>
                          <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-transparent via-transparent to-gray-100 opacity-50 rounded-full -translate-y-1/2 translate-x-1/2"></div>
                          
                          <CardHeader className="pb-2 relative">
                            <div className="flex justify-between items-start">
                              <CardTitle className={`text-base font-nunito font-bold bg-gradient-to-r ${getGradientClass(reflection.category)} bg-clip-text text-transparent`}>
                                {t(`reflectionsPage.prompts.${reflection.id}`) !== `reflectionsPage.prompts.${reflection.id}` 
                                  ? t(`reflectionsPage.prompts.${reflection.id}`) 
                                  : reflection.prompt}
                                {reflection.isPremium && (() => {
                                  // Usiamo le variabili già dichiarate all'inizio del componente
                                  const showPremiumBadge = !hasActiveSub && !legacyPremium && !localAdmin && !isAdmin;
                                  
                                  return showPremiumBadge ? (
                                    <span className="ml-2 inline-flex items-center bg-gradient-to-r from-amber-400 to-yellow-500 bg-clip-text text-transparent text-xs">
                                      <span className="mr-0.5 filter drop-shadow-sm">⭐</span> {t('reflectionsPage.premium')}
                                    </span>
                                  ) : null;
                                })()}
                              </CardTitle>
                              <Badge 
                                variant="outline" 
                                className={`${getLightBgClass(reflection.category)} bg-gradient-to-r ${getGradientClass(reflection.category)} text-white border-0 shadow-sm group-hover:shadow transition-all`}
                              >
                                {t(`reflectionsPage.categories.${reflection.category}`) !== `reflectionsPage.categories.${reflection.category}` ? 
                                  t(`reflectionsPage.categories.${reflection.category}`) : 
                                  reflection.category.charAt(0).toUpperCase() + reflection.category.slice(1)}
                              </Badge>
                            </div>
                          </CardHeader>
                          
                          {savedReflections[reflection.id] && (
                            <CardContent className="pt-2 pb-3">
                              <div className={`p-3 ${getLightBgClass(reflection.category)} text-sm text-neutral-700 rounded-md border-l-4 ${getBorderClass(reflection.category)} shadow-sm`}>
                                <div className="flex">
                                  <i className="ri-book-read-line text-lg mr-2 opacity-70"></i>
                                  <div>
                                    <span className="font-medium">{t('reflectionsPage.yourReflection')}</span> {savedReflections[reflection.id].substring(0, 100)}{savedReflections[reflection.id].length > 100 ? '...' : ''}
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          )}
                          
                          <CardFooter className="pt-0">
                            <Button 
                              variant="outline" 
                              className={`text-sm group-hover:bg-gradient-to-r ${getGradientClass(reflection.category)} group-hover:text-white group-hover:border-transparent transition-all duration-300`}
                            >
                              {savedReflections[reflection.id] ? (
                                <><i className="ri-eye-line mr-2"></i> {t('reflectionsPage.viewYourReflection')}</>
                              ) : (
                                <><i className="ri-quill-pen-line mr-2"></i> {t('reflectionsPage.reflectOnThis')}</>
                              )}
                            </Button>
                          </CardFooter>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </main>
      
      <BottomNavigation2 />
    </div>
  );
};

export default ReflectionsPage;
