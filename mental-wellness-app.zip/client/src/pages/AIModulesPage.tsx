import React, { useState, useMemo } from 'react';
import { useAuth } from '@/lib/auth-context';
import { useStripe } from '@/lib/stripe-context';
import Header2 from '@/components/Header2';
import BottomNavigation2 from '@/components/BottomNavigation2';
import { EmergencyHomeButton } from '@/components/EmergencyHome';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';
import { PremiumBanner } from '@/components/PremiumBanner';
import { useTranslation } from 'react-i18next';

// Tipi di moduli AI
type ModuleType = 'relationships' | 'writing' | 'relaxation' | 'sleep';
type Language = 'it' | 'en';

interface AIPrompt {
  id: string;
  title: string;
  prompt: string;
  category: ModuleType;
  isPremium: boolean;
}

interface AIPromptTranslations {
  [key: string]: {
    title: string;
    prompt: string;
  };
}

interface AIPromptData {
  id: string;
  translations: AIPromptTranslations;
  category: string;
  isPremium: boolean;
}

// Prompt predefiniti per i vari moduli con supporto multilingua
const aiPromptsData: AIPromptData[] = [
  // Relazioni
  {
    id: 'relationships-1',
    translations: {
      it: {
        title: 'Comunicazione efficace',
        prompt: 'Voglio comunicare in modo più efficace con il mio partner. Puoi suggerirmi tecniche di comunicazione non violenta?'
      },
      en: {
        title: 'Effective Communication',
        prompt: 'I want to communicate more effectively with my partner. Can you suggest non-violent communication techniques?'
      }
    },
    category: 'relationships',
    isPremium: false
  },
  {
    id: 'relationships-2',
    translations: {
      it: {
        title: 'Risoluzione conflitti',
        prompt: 'Ho avuto un disaccordo con un amico. Come posso risolvere il conflitto in modo costruttivo?'
      },
      en: {
        title: 'Conflict Resolution',
        prompt: 'I had a disagreement with a friend. How can I resolve the conflict constructively?'
      }
    },
    category: 'relationships',
    isPremium: false
  },
  {
    id: 'relationships-3',
    translations: {
      it: {
        title: 'Stabilire confini',
        prompt: 'Fatico a stabilire confini personali nelle mie relazioni. Puoi aiutarmi con strategie pratiche?'
      },
      en: {
        title: 'Setting Boundaries',
        prompt: 'I struggle to establish personal boundaries in my relationships. Can you help me with practical strategies?'
      }
    },
    category: 'relationships',
    isPremium: true
  },
  {
    id: 'relationships-4',
    translations: {
      it: {
        title: 'Gestire persone difficili',
        prompt: 'Come posso gestire in modo sano le interazioni con persone negative o difficili nella mia vita?'
      },
      en: {
        title: 'Managing Difficult People',
        prompt: 'How can I healthily manage interactions with negative or difficult people in my life?'
      }
    },
    category: 'relationships',
    isPremium: true
  },
  
  // Scrittura
  {
    id: 'writing-1',
    translations: {
      it: {
        title: 'Journaling terapeutico',
        prompt: 'Vorrei iniziare a fare journaling per migliorare il mio benessere mentale. Puoi darmi alcuni spunti per iniziare?'
      },
      en: {
        title: 'Therapeutic Journaling',
        prompt: 'I would like to start journaling to improve my mental wellbeing. Can you give me some prompts to get started?'
      }
    },
    category: 'writing',
    isPremium: false
  },
  {
    id: 'writing-2',
    translations: {
      it: {
        title: 'Lettere a me stesso',
        prompt: 'Come posso scrivere una lettera compassionevole a me stesso per elaborare emozioni difficili?'
      },
      en: {
        title: 'Letters to Myself',
        prompt: 'How can I write a compassionate letter to myself to process difficult emotions?'
      }
    },
    category: 'writing',
    isPremium: false
  },
  {
    id: 'writing-3',
    translations: {
      it: {
        title: 'Scrittura espressiva',
        prompt: 'Voglio usare la scrittura espressiva per superare un trauma. Quali tecniche posso utilizzare?'
      },
      en: {
        title: 'Expressive Writing',
        prompt: 'I want to use expressive writing to overcome trauma. What techniques can I use?'
      }
    },
    category: 'writing',
    isPremium: true
  },
  {
    id: 'writing-4',
    translations: {
      it: {
        title: 'Poesia terapeutica',
        prompt: 'Come posso usare la poesia come strumento per esprimere e gestire le mie emozioni?'
      },
      en: {
        title: 'Therapeutic Poetry',
        prompt: 'How can I use poetry as a tool to express and manage my emotions?'
      }
    },
    category: 'writing',
    isPremium: true
  },
  
  // Rilassamento muscolare
  {
    id: 'relax-1',
    translations: {
      it: {
        title: 'Rilassamento progressivo',
        prompt: 'Puoi guidarmi attraverso un esercizio di rilassamento muscolare progressivo per ridurre la tensione?'
      },
      en: {
        title: 'Progressive Relaxation',
        prompt: 'Can you guide me through a progressive muscle relaxation exercise to reduce tension?'
      }
    },
    category: 'relaxation',
    isPremium: false
  },
  {
    id: 'relax-2',
    translations: {
      it: {
        title: 'Stretching consapevole',
        prompt: 'Quali sono alcuni esercizi di stretching consapevole che posso fare per rilassare il corpo e la mente?'
      },
      en: {
        title: 'Mindful Stretching',
        prompt: 'What are some mindful stretching exercises I can do to relax my body and mind?'
      }
    },
    category: 'relaxation',
    isPremium: false
  },
  {
    id: 'relax-3',
    translations: {
      it: {
        title: 'Rilassamento con visualizzazione',
        prompt: 'Puoi guidarmi in un esercizio di rilassamento muscolare combinato con visualizzazione?'
      },
      en: {
        title: 'Visualization Relaxation',
        prompt: 'Can you guide me through a muscle relaxation exercise combined with visualization?'
      }
    },
    category: 'relaxation',
    isPremium: true
  },
  {
    id: 'relax-4',
    translations: {
      it: {
        title: 'Tecniche di rilassamento per ansia acuta',
        prompt: 'Quali tecniche di rilassamento muscolare posso usare durante un attacco d\'ansia?'
      },
      en: {
        title: 'Relaxation Techniques for Acute Anxiety',
        prompt: 'What muscle relaxation techniques can I use during an anxiety attack?'
      }
    },
    category: 'relaxation',
    isPremium: true
  },
  
  // Sonno
  {
    id: 'sleep-1',
    translations: {
      it: {
        title: 'Routine serale',
        prompt: 'Puoi suggerirmi una routine serale per migliorare la qualità del sonno?'
      },
      en: {
        title: 'Evening Routine',
        prompt: 'Can you suggest an evening routine to improve sleep quality?'
      }
    },
    category: 'sleep',
    isPremium: false
  },
  {
    id: 'sleep-2',
    translations: {
      it: {
        title: 'Tecniche di rilassamento per dormire',
        prompt: 'Quali tecniche di rilassamento posso praticare a letto per addormentarmi più facilmente?'
      },
      en: {
        title: 'Relaxation Techniques for Sleep',
        prompt: 'What relaxation techniques can I practice in bed to fall asleep more easily?'
      }
    },
    category: 'sleep',
    isPremium: false
  },
  {
    id: 'sleep-3',
    translations: {
      it: {
        title: 'Gestione dei pensieri notturni',
        prompt: 'Come posso fermare il flusso di pensieri e preoccupazioni che mi tengono sveglio di notte?'
      },
      en: {
        title: 'Managing Night Thoughts',
        prompt: 'How can I stop the flow of thoughts and worries that keep me awake at night?'
      }
    },
    category: 'sleep',
    isPremium: true
  },
  {
    id: 'sleep-4',
    translations: {
      it: {
        title: 'Superare l\'insonnia',
        prompt: 'Quali strategie cognitive posso usare per superare l\'insonnia cronica?'
      },
      en: {
        title: 'Overcoming Insomnia',
        prompt: 'What cognitive strategies can I use to overcome chronic insomnia?'
      }
    },
    category: 'sleep',
    isPremium: true
  }
];

const AIModulesPage: React.FC = () => {
  const { isAuthenticated, isAdmin } = useAuth();
  const { isSubscriptionActive } = useStripe();
  const { t, i18n } = useTranslation();
  // Utilizziamo la navigazione diretta con window.location invece di useLocation
  
  // Ottieni lingua corrente (i18n.language) o fallback a italiano
  const currentLanguage = (i18n.language && ['it', 'en'].includes(i18n.language)) ? i18n.language : 'it';
  
  // Trasforma i dati dei prompt nella lingua corrente
  const aiPrompts: AIPrompt[] = useMemo(() => {
    return aiPromptsData.map(promptData => {
      // Sicurezza di tipo: garantisce che currentLanguage sia usato solo come chiave se esiste
      const langKey = promptData.translations[currentLanguage as keyof typeof promptData.translations] ? 
                      currentLanguage as keyof typeof promptData.translations : 
                      'it';
      
      // Ottieni il titolo tradotto dalle traduzioni i18n se disponibile
      const getTranslatedPromptTitle = (id: string) => {
        // Map dei prompt IDs per le traduzioni i18n
        const translationMap: Record<string, string> = {
          'relationships-1': 'aiModulesPage.communicationTechniques',
          'relationships-2': 'aiModulesPage.conflictResolution',
          'relationships-3': 'aiModulesPage.setBoundaries',
          'relationships-4': 'aiModulesPage.difficultPeople',
          'writing-1': 'aiModulesPage.therapeuticJournaling',
          'writing-2': 'aiModulesPage.lettersToSelf',
          'writing-3': 'aiModulesPage.expressiveWriting',
          'writing-4': 'aiModulesPage.therapeuticPoetry',
          'relax-1': 'aiModulesPage.progressiveRelaxation',
          'relax-2': 'aiModulesPage.mindfulStretching',
          'relax-3': 'aiModulesPage.visualizationRelaxation',
          'relax-4': 'aiModulesPage.anxietyRelaxation',
          'sleep-1': 'aiModulesPage.eveningRoutine',
          'sleep-2': 'aiModulesPage.sleepRelaxation',
          'sleep-3': 'aiModulesPage.nightThoughts',
          'sleep-4': 'aiModulesPage.overcomingInsomnia'
        };
        
        // Se esiste una traduzione, usala, altrimenti usa il titolo originale
        const translationKey = translationMap[id];
        if (translationKey && t(translationKey) !== translationKey) {
          return t(translationKey);
        }
        return promptData.translations[langKey].title;
      };
      
      return {
        id: promptData.id,
        title: getTranslatedPromptTitle(promptData.id),
        prompt: promptData.translations[langKey].prompt,
        category: promptData.category as ModuleType,
        isPremium: promptData.isPremium
      };
    });
  }, [currentLanguage, t]);
  
  // Handler per l'abbonamento
  const handleSubscribe = () => {
    window.location.href = '/subscription';
  };
  
  const [activeTab, setActiveTab] = useState<ModuleType>('relationships');
  const [selectedPrompt, setSelectedPrompt] = useState<AIPrompt | null>(null);
  const [customPrompt, setCustomPrompt] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [response, setResponse] = useState('');
  const { toast } = useToast();

  // Filtra i prompt in base alla categoria attiva
  const filteredPrompts = aiPrompts.filter(prompt => prompt.category === activeTab);

  // Verifica se un utente può accedere a un prompt
  const canAccessPrompt = (prompt: AIPrompt) => {
    // Se il contenuto non è premium, tutti possono accedervi
    if (!prompt.isPremium) return true;
    
    // Se l'utente è admin, può accedere a tutto
    if (isAdmin) return true;
    
    // Controlla l'abbonamento Stripe
    const hasActiveSubscription = isSubscriptionActive();
    
    // Debug per identificare il problema
    console.log('AIModulesPage - hasActiveSubscription:', hasActiveSubscription);
    
    // L'utente può accedere solo se ha un abbonamento attivo
    return hasActiveSubscription;
  };

  // Gestisce la selezione di un prompt
  const handleSelectPrompt = (prompt: AIPrompt) => {
    if (!canAccessPrompt(prompt)) {
      // Redirect alla pagina di abbonamento per contenuti premium
      handleSubscribe();
      return;
    }
    
    // Previeni l'evento di navigazione default che potrebbe interferire
    document.body.style.pointerEvents = 'none';
    setTimeout(() => {
      document.body.style.pointerEvents = 'auto';
      setSelectedPrompt(prompt);
      setCustomPrompt(prompt.prompt);
      setResponse('');
    }, 50);
  };

  // Gestisce l'invio di un prompt a OpenAI
  const handleSubmitPrompt = async () => {
    if (!customPrompt.trim()) {
      toast({
        title: t('aiModulesPage.error'),
        description: t('aiModulesPage.errorPrompt'),
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    setResponse('');

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          message: customPrompt,
          sessionId: `ai-module-${activeTab}` 
        }),
      });

      if (!response.ok) {
        throw new Error('Errore nella richiesta');
      }

      const data = await response.json();
      setResponse(data.message);
    } catch (error) {
      console.error('Errore:', error);
      toast({
        title: t('aiModulesPage.error'),
        description: t('aiModulesPage.requestError'),
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="page-container min-h-screen flex flex-col bg-gradient-to-b from-violet-50/80 via-indigo-50/90 to-fuchsia-50/80 pb-16 md:pb-0 relative overflow-hidden">
      <div id="page-top" className="absolute top-0 left-0"></div>
      <Header2 />
      
      {/* Pattern decorativo */}
      <div className="absolute top-0 left-0 right-0 h-64 bg-gradient-to-br from-purple-500/10 to-indigo-600/10 pointer-events-none"></div>
      <div className="absolute top-0 left-0 right-0 h-64 bg-[radial-gradient(#e0e7ff_1px,transparent_1px)] [background-size:20px_20px] opacity-40 pointer-events-none"></div>
      
      {/* Elementi decorativi */}
      <div className="absolute -top-20 right-0 w-96 h-96 bg-purple-300 rounded-full opacity-20 blur-3xl"></div>
      <div className="absolute top-1/3 -left-20 w-80 h-80 bg-indigo-200 rounded-full opacity-20 blur-3xl"></div>
      <div className="absolute bottom-1/4 right-0 w-72 h-72 bg-fuchsia-200 rounded-full opacity-20 blur-3xl"></div>
      
      <main className="ai-modules-content flex-grow w-full max-w-5xl mx-auto px-4 py-8 mb-16 md:mb-0 relative z-10">
        <EmergencyHomeButton discreet={true} />
        
        <div className="mb-8 text-center">
          <div className="inline-flex items-center bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full text-sm font-medium mb-3">
            <i className="ri-brain-line text-lg mr-2"></i> {t('aiModulesPage.badge')}
          </div>
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-indigo-700 via-purple-600 to-indigo-700 text-transparent bg-clip-text">
            {t('aiModulesPage.title')}
          </h1>
          <p className="text-neutral-600 max-w-2xl mx-auto text-lg">
            {t('aiModulesPage.subtitle')}
          </p>
        </div>
        
        <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-xl mb-8 relative overflow-hidden border border-white/80">
          {/* Decorazioni di sfondo */}
          <div className="absolute -top-12 -right-12 w-40 h-40 bg-indigo-500/10 rounded-full blur-lg"></div>
          <div className="absolute -bottom-12 -left-12 w-40 h-40 bg-purple-500/10 rounded-full blur-lg"></div>
          <div className="absolute top-1/2 left-0 right-0 h-40 bg-gradient-to-r from-indigo-100/5 via-fuchsia-100/5 to-indigo-100/5 blur-2xl"></div>
          
          {/* Pattern decorativo */}
          <div className="absolute inset-0 bg-[radial-gradient(#e0e7ff_1px,transparent_1px)] [background-size:16px_16px] opacity-20 pointer-events-none"></div>
          
          <Tabs defaultValue="relationships" className="w-full relative z-10" onValueChange={(value) => setActiveTab(value as ModuleType)}>
            <TabsList className="ai-modules-tabs grid grid-cols-4 mb-8 bg-gradient-to-r from-indigo-100/80 via-purple-100/80 to-indigo-100/80 rounded-lg p-1 shadow-sm">
              <TabsTrigger 
                value="relationships" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-indigo-600 data-[state=active]:text-white"
              >
                <i className="ri-heart-3-line mr-2 hidden md:inline"></i>{t('aiModulesPage.relationships')}
              </TabsTrigger>
              <TabsTrigger 
                value="writing" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-purple-600 data-[state=active]:text-white"
              >
                <i className="ri-edit-line mr-2 hidden md:inline"></i>{t('aiModulesPage.writing')}
              </TabsTrigger>
              <TabsTrigger 
                value="relaxation"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-blue-600 data-[state=active]:text-white"
              >
                <i className="ri-emotion-happy-line mr-2 hidden md:inline"></i>{t('aiModulesPage.relaxation')}
              </TabsTrigger>
              <TabsTrigger 
                value="sleep"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-400 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
              >
                <i className="ri-moon-line mr-2 hidden md:inline"></i>{t('aiModulesPage.sleep')}
              </TabsTrigger>
            </TabsList>
            
            {['relationships', 'writing', 'relaxation', 'sleep'].map((category) => (
              <TabsContent key={category} value={category} className="space-y-6">
                <div className="ai-modules-grid grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredPrompts.map((prompt) => {
                    // Determina colori in base alla categoria
                    let cardColors = {
                      relationships: "hover:border-indigo-200 hover:bg-gradient-to-br hover:from-indigo-50/80 hover:to-purple-50/80",
                      writing: "hover:border-purple-200 hover:bg-gradient-to-br hover:from-purple-50/80 hover:to-pink-50/80",
                      relaxation: "hover:border-blue-200 hover:bg-gradient-to-br hover:from-blue-50/80 hover:to-cyan-50/80",
                      sleep: "hover:border-blue-200 hover:bg-gradient-to-br hover:from-indigo-50/80 hover:to-blue-50/80"
                    };
                    
                    let gradientBorderColors = {
                      relationships: "from-indigo-400 to-indigo-600",
                      writing: "from-purple-400 to-pink-500",
                      relaxation: "from-blue-400 to-cyan-500",
                      sleep: "from-indigo-400 to-blue-500"
                    };
                    
                    let cardBgGradients = {
                      relationships: "bg-gradient-to-br from-white to-indigo-50/30",
                      writing: "bg-gradient-to-br from-white to-purple-50/30",
                      relaxation: "bg-gradient-to-br from-white to-blue-50/30",
                      sleep: "bg-gradient-to-br from-white to-indigo-50/30"
                    };
                    
                    let iconColors = {
                      relationships: "text-indigo-600 bg-gradient-to-br from-indigo-100 to-indigo-200",
                      writing: "text-purple-600 bg-gradient-to-br from-purple-100 to-pink-200",
                      relaxation: "text-blue-600 bg-gradient-to-br from-blue-100 to-cyan-200",
                      sleep: "text-blue-600 bg-gradient-to-br from-indigo-100 to-blue-200"
                    };
                    
                    let icons = {
                      relationships: "ri-heart-3-line",
                      writing: "ri-edit-line",
                      relaxation: "ri-emotion-happy-line",
                      sleep: "ri-moon-line"
                    };
                    
                    return (
                      <Card 
                        key={prompt.id}
                        className={`cursor-pointer transition-all relative overflow-hidden ${
                          selectedPrompt?.id === prompt.id 
                            ? `${cardBgGradients[prompt.category as ModuleType]} border-0 shadow-lg scale-[1.02]` 
                            : `border ${cardBgGradients[prompt.category as ModuleType]} shadow-sm ${cardColors[prompt.category as ModuleType]}`
                        } ${prompt.isPremium && !canAccessPrompt(prompt) ? 'opacity-90' : ''} hover:shadow-lg hover:scale-[1.02] group`}
                        onClick={() => handleSelectPrompt(prompt)}
                      >
                        {/* Bordo superiore colorato */}
                        <div className={`absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r ${gradientBorderColors[prompt.category as ModuleType]}`}></div>
                        
                        {/* Elementi decorativi */}
                        <div className="absolute -top-10 -right-10 w-20 h-20 bg-gradient-to-br from-transparent via-transparent to-white/20 rounded-full"></div>
                        <div className="absolute bottom-0 right-0 w-full h-10 bg-gradient-to-t from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                        
                        {/* Cerchio decorativo che appare in hover */}
                        <div className={`absolute -bottom-10 -right-10 w-20 h-20 rounded-full bg-gradient-to-br ${gradientBorderColors[prompt.category as ModuleType]} opacity-0 group-hover:opacity-10 transition-opacity duration-300 blur-md`}></div>
                        
                        <CardContent className="p-4 pt-5">
                          <div className="flex items-start gap-3">
                            <div className={`flex-shrink-0 w-9 h-9 rounded-full ${iconColors[prompt.category as ModuleType]} flex items-center justify-center mt-1 shadow-sm`}>
                              <i className={`${icons[prompt.category as ModuleType]} text-lg`}></i>
                            </div>
                            <div className="flex-grow">
                              <div className="flex items-center justify-between">
                                <h3 className={`font-semibold bg-gradient-to-r ${gradientBorderColors[prompt.category as ModuleType]} bg-clip-text text-transparent`}>{prompt.title}</h3>
                                {prompt.isPremium && !canAccessPrompt(prompt) && (
                                  <span className="flex-shrink-0 bg-gradient-to-r from-amber-400 to-yellow-500 bg-clip-text text-transparent ml-2">
                                    <i className="ri-vip-crown-fill filter drop-shadow-sm"></i>
                                  </span>
                                )}
                              </div>
                              <p className="text-sm text-neutral-600 line-clamp-2 mt-1">{prompt.prompt}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
                
                {selectedPrompt && (
                  <div className="mt-10">
                    <Card className="border-none shadow-xl overflow-hidden bg-white backdrop-blur-sm relative">
                      {/* Background decorazioni */}
                      <div className="absolute -top-10 -right-10 w-40 h-40 bg-gradient-to-br from-transparent via-transparent to-indigo-100/60 rounded-full blur-md"></div>
                      <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-gradient-to-br from-transparent via-transparent to-purple-100/60 rounded-full blur-md"></div>
                      
                      {/* Bordo superiore colorato */}
                      <div className={`h-1.5 bg-gradient-to-r ${selectedPrompt.category === 'relationships' ? 'from-indigo-400 to-indigo-600' : 
                                        selectedPrompt.category === 'writing' ? 'from-purple-400 to-pink-500' :
                                        selectedPrompt.category === 'relaxation' ? 'from-blue-400 to-cyan-500' :
                                        'from-indigo-400 to-blue-500'}`}></div>
                      
                      <CardContent className="p-6 relative z-10">
                        <div className="flex items-center mb-5">
                          <div className={`flex-shrink-0 w-10 h-10 rounded-full ${
                            selectedPrompt.category === 'relationships' ? 'text-indigo-600 bg-gradient-to-br from-indigo-100 to-indigo-200' : 
                            selectedPrompt.category === 'writing' ? 'text-purple-600 bg-gradient-to-br from-purple-100 to-pink-200' :
                            selectedPrompt.category === 'relaxation' ? 'text-blue-600 bg-gradient-to-br from-blue-100 to-cyan-200' :
                            'text-blue-600 bg-gradient-to-br from-indigo-100 to-blue-200'
                          } flex items-center justify-center shadow-sm mr-3`}>
                            <i className={`${
                              selectedPrompt.category === 'relationships' ? 'ri-heart-3-line' :
                              selectedPrompt.category === 'writing' ? 'ri-edit-line' :
                              selectedPrompt.category === 'relaxation' ? 'ri-emotion-happy-line' :
                              'ri-moon-line'
                            } text-lg`}></i>
                          </div>
                          <h3 className={`text-xl font-bold bg-gradient-to-r ${
                            selectedPrompt.category === 'relationships' ? 'from-indigo-400 to-indigo-600' : 
                            selectedPrompt.category === 'writing' ? 'from-purple-400 to-pink-500' :
                            selectedPrompt.category === 'relaxation' ? 'from-blue-400 to-cyan-500' :
                            'from-indigo-400 to-blue-500'
                          } bg-clip-text text-transparent flex items-center`}>
                            {selectedPrompt.title}
                            {selectedPrompt.isPremium && !canAccessPrompt(selectedPrompt) && (
                              <span className="ml-2 bg-gradient-to-r from-amber-400 to-yellow-500 bg-clip-text text-transparent">
                                <i className="ri-vip-crown-fill filter drop-shadow-sm"></i>
                              </span>
                            )}
                          </h3>
                        </div>
                        
                        <div className="space-y-5">
                          <div className={`bg-gradient-to-br from-white to-${selectedPrompt.category === 'relationships' ? 'indigo' : 
                                            selectedPrompt.category === 'writing' ? 'purple' :
                                            selectedPrompt.category === 'relaxation' ? 'blue' :
                                            'indigo'}-50/50 p-5 rounded-lg border border-${selectedPrompt.category === 'relationships' ? 'indigo' : 
                                            selectedPrompt.category === 'writing' ? 'purple' :
                                            selectedPrompt.category === 'relaxation' ? 'blue' :
                                            'indigo'}-100 shadow-inner`}>
                            <label className={`block text-sm font-medium text-${selectedPrompt.category === 'relationships' ? 'indigo' : 
                                                selectedPrompt.category === 'writing' ? 'purple' :
                                                selectedPrompt.category === 'relaxation' ? 'blue' :
                                                'indigo'}-800 mb-3 flex items-center`}>
                              <i className="ri-message-3-line mr-2"></i> {t('aiModulesPage.customPrompt')}:
                            </label>
                            <Textarea
                              value={customPrompt}
                              onChange={(e) => setCustomPrompt(e.target.value)}
                              className={`min-h-[120px] border-${selectedPrompt.category === 'relationships' ? 'indigo' : 
                                            selectedPrompt.category === 'writing' ? 'purple' :
                                            selectedPrompt.category === 'relaxation' ? 'blue' :
                                            'indigo'}-200 focus:border-${selectedPrompt.category === 'relationships' ? 'indigo' : 
                                            selectedPrompt.category === 'writing' ? 'purple' :
                                            selectedPrompt.category === 'relaxation' ? 'blue' :
                                            'indigo'}-400 bg-white/80 backdrop-blur-sm rounded-md shadow-sm`}
                              placeholder={t('aiModulesPage.promptPlaceholder')}
                            />
                          </div>
                          
                          <Button 
                            onClick={handleSubmitPrompt} 
                            disabled={isSubmitting}
                            className={`w-full bg-gradient-to-r ${
                              selectedPrompt.category === 'relationships' ? 'from-indigo-400 to-indigo-600' : 
                              selectedPrompt.category === 'writing' ? 'from-purple-400 to-pink-500' :
                              selectedPrompt.category === 'relaxation' ? 'from-blue-400 to-cyan-500' :
                              'from-indigo-400 to-blue-500'
                            } hover:shadow-lg hover:translate-y-[-1px] transition-all text-white shadow-md`}
                          >
                            {isSubmitting ? (
                              <span className="flex items-center justify-center">
                                <i className="ri-loader-4-line animate-spin mr-2"></i> {t('aiModulesPage.submitting')}
                              </span>
                            ) : (
                              <span className="flex items-center justify-center">
                                <i className="ri-brain-line mr-2"></i> {t('aiModulesPage.submitPrompt')}
                              </span>
                            )}
                          </Button>
                        </div>
                        
                        {response && (
                          <div className="mt-10">
                            <Separator className={`mb-5 bg-${selectedPrompt.category === 'relationships' ? 'indigo' : 
                                                   selectedPrompt.category === 'writing' ? 'purple' :
                                                   selectedPrompt.category === 'relaxation' ? 'blue' :
                                                   'indigo'}-100`} />
                            <h4 className={`font-semibold text-${selectedPrompt.category === 'relationships' ? 'indigo' : 
                                           selectedPrompt.category === 'writing' ? 'purple' :
                                           selectedPrompt.category === 'relaxation' ? 'blue' :
                                           'indigo'}-900 mb-4 flex items-center`}>
                              <div className={`flex-shrink-0 w-8 h-8 rounded-full ${
                                selectedPrompt.category === 'relationships' ? 'text-indigo-600 bg-gradient-to-br from-indigo-100 to-indigo-200' : 
                                selectedPrompt.category === 'writing' ? 'text-purple-600 bg-gradient-to-br from-purple-100 to-pink-200' :
                                selectedPrompt.category === 'relaxation' ? 'text-blue-600 bg-gradient-to-br from-blue-100 to-cyan-200' :
                                'text-blue-600 bg-gradient-to-br from-indigo-100 to-blue-200'
                              } flex items-center justify-center shadow-sm mr-3`}>
                                <i className="ri-robot-line"></i>
                              </div>
                              {t('aiModulesPage.promptResults')}:
                            </h4>
                            <div className={`bg-gradient-to-br from-white to-${selectedPrompt.category === 'relationships' ? 'indigo' : 
                                            selectedPrompt.category === 'writing' ? 'purple' :
                                            selectedPrompt.category === 'relaxation' ? 'blue' :
                                            'indigo'}-50/50 p-5 rounded-lg border border-${selectedPrompt.category === 'relationships' ? 'indigo' : 
                                            selectedPrompt.category === 'writing' ? 'purple' :
                                            selectedPrompt.category === 'relaxation' ? 'blue' :
                                            'indigo'}-100 shadow-inner relative overflow-hidden`}>
                              {/* Sfondo decorativo */}
                              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-transparent via-transparent to-white/30 rounded-full opacity-50"></div>
                              <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-gradient-to-br from-transparent via-transparent to-white/20 rounded-full opacity-50"></div>
                              
                              <div className="relative">
                                <div className={`absolute -top-1 -left-1 text-3xl opacity-20 text-${selectedPrompt.category === 'relationships' ? 'indigo' : 
                                            selectedPrompt.category === 'writing' ? 'purple' :
                                            selectedPrompt.category === 'relaxation' ? 'blue' :
                                            'indigo'}-400`}>❝</div>
                                <div className={`absolute -bottom-4 -right-1 text-3xl opacity-20 text-${selectedPrompt.category === 'relationships' ? 'indigo' : 
                                            selectedPrompt.category === 'writing' ? 'purple' :
                                            selectedPrompt.category === 'relaxation' ? 'blue' :
                                            'indigo'}-400`}>❞</div>
                                <p className="whitespace-pre-line text-neutral-800 relative z-10 p-2 leading-relaxed">{response}</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                )}
                
                {!isAdmin && !isSubscriptionActive() && (
                  <div className="mt-12 relative">
                    <div className="absolute -top-8 left-1/4 w-20 h-20 bg-amber-200 rounded-full opacity-30 blur-xl"></div>
                    <div className="absolute -bottom-8 right-1/4 w-20 h-20 bg-amber-300 rounded-full opacity-30 blur-xl"></div>
                    <PremiumBanner onSubscribe={handleSubscribe} />
                  </div>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </main>
      
      <BottomNavigation2 />
    </div>
  );
};

export default AIModulesPage;