import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth-context";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useTranslation } from "react-i18next";

interface AuthDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AuthDialog({ open, onOpenChange }: AuthDialogProps) {
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const { login, logout, isAuthenticated, loginWithCredentials, register, user } = useAuth();
  const { toast } = useToast();
  const { t } = useTranslation();
  
  // Quando l'utente è già autenticato, conserviamo il suo username in localStorage
  const [loggedInUsername, setLoggedInUsername] = useState(() => {
    return localStorage.getItem('auralis_username') || username;
  });

  // Salva l'username nel localStorage quando viene aggiornato
  useEffect(() => {
    if (username.trim() !== '') {
      setLoggedInUsername(username);
    }
  }, [username]);
  
  // Quando l'utente effettua il login, utilizziamo la funzione loginWithCredentials dal contesto Auth
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Utilizziamo la funzione dal contesto
      const success = await loginWithCredentials(username, password);
      
      if (success) {
        setLoggedInUsername(username);
        
        // Verifica se c'è un parametro returnTo nell'URL o un piano selezionato nel localStorage
        const url = new URL(window.location.href);
        const returnTo = url.searchParams.get('returnTo');
        const selectedPlan = localStorage.getItem('selectedSubscriptionPlan');
        
        toast({
          title: t('auth.loginSuccess', 'Accesso effettuato'),
          description: t('auth.welcomeMessage', 'Benvenuto su Auralis'),
        });
        
        onOpenChange(false);
        
        // Se c'è un returnTo nell'URL, reindirizza l'utente a quella pagina
        if (returnTo === 'subscription' && selectedPlan) {
          // Utilizziamo setTimeout per assicurarci che il Dialog si chiuda prima
          setTimeout(() => {
            // Rimuoviamo il parametro returnTo dall'URL
            url.searchParams.delete('returnTo');
            window.history.replaceState({}, '', url.toString());
            
            // Reindirizza alla pagina di abbonamento
            window.location.href = '/subscription';
          }, 500);
        }
      } else {
        toast({
          title: t('auth.loginError', 'Errore di accesso'),
          description: t('auth.invalidCredentials', 'Credenziali non valide'),
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Errore durante il login:', error);
      toast({
        title: t('auth.loginError', 'Errore di accesso'),
        description: t('auth.serverError', 'Si è verificato un errore durante l\'accesso'),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Validazione
    if (!email.includes('@') || password.length < 6) {
      toast({
        title: t('auth.registerError', 'Errore di registrazione'),
        description: t('auth.validationError', 'Controlla che l\'email sia valida e la password sia di almeno 6 caratteri'),
        variant: "destructive",
      });
      setLoading(false);
      return;
    }

    try {
      // Utilizziamo la funzione register dal contesto
      const result = await register({
        username,
        password,
        email,
        name
      });
      
      if (result.success) {
        setLoggedInUsername(username);
        
        // Verifica se c'è un parametro returnTo nell'URL o un piano selezionato nel localStorage
        const url = new URL(window.location.href);
        const returnTo = url.searchParams.get('returnTo');
        const selectedPlan = localStorage.getItem('selectedSubscriptionPlan');
        
        toast({
          title: t('auth.registerSuccess', 'Registrazione completata'),
          description: t('auth.welcomeMessage', 'Benvenuto su Auralis'),
        });
        
        onOpenChange(false);
        
        // Se c'è un returnTo nell'URL, reindirizza l'utente a quella pagina
        if (returnTo === 'subscription' && selectedPlan) {
          // Utilizziamo setTimeout per assicurarci che il Dialog si chiuda prima
          setTimeout(() => {
            // Rimuoviamo il parametro returnTo dall'URL
            url.searchParams.delete('returnTo');
            window.history.replaceState({}, '', url.toString());
            
            // Reindirizza alla pagina di abbonamento
            window.location.href = '/subscription';
          }, 500);
        }
      } else {
        // Gestisci i diversi tipi di errore
        if (result.error === 'username_exists') {
          toast({
            title: t('auth.registerError', 'Errore di registrazione'),
            description: t('auth.usernameExists', 'Username già in uso. Per favore, scegli un altro username.'),
            variant: "destructive",
          });
        } else {
          toast({
            title: t('auth.registerError', 'Errore di registrazione'),
            description: t('auth.registrationFailed', 'La registrazione non è andata a buon fine'),
            variant: "destructive",
          });
        }
      }
    } catch (error) {
      console.error('Errore durante la registrazione:', error);
      toast({
        title: t('auth.registerError', 'Errore di registrazione'),
        description: t('auth.serverError', 'Si è verificato un errore durante la registrazione'),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleLogout = () => {
    logout(); // Usa la funzione logout dal context che gestisce il localStorage
    toast({
      title: t('auth.logoutSuccess', 'Logout effettuato'),
      description: t('auth.logoutMessage', 'Hai effettuato il logout con successo'),
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        {isAuthenticated ? (
          // Vista utente autenticato
          <>
            <DialogHeader>
              <DialogTitle>{t('auth.yourAccount', 'Il tuo account')}</DialogTitle>
              <DialogDescription>
                {t('auth.manageAccount', 'Gestisci il tuo account e le preferenze.')}
              </DialogDescription>
            </DialogHeader>
            
            <Card className="mt-4">
              <CardHeader className="pb-2">
                <div className="flex items-center space-x-4">
                  <Avatar className="h-14 w-14 border-2 border-primary">
                    <AvatarFallback className="bg-purple-100 text-purple-500 text-lg font-semibold">
                      {loggedInUsername ? loggedInUsername.charAt(0).toUpperCase() : "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-xl mb-1">{user?.username || loggedInUsername}</CardTitle>
                    <CardDescription>
                      {t('auth.premiumStatus', 'Utente Premium')}: {user?.isPremium ? t('common.yes', 'Sì') : t('common.no', 'No')}
                      {user?.subscriptionPlan && (
                        <span className="ml-1">({user.subscriptionPlan === 'yearly' ? t('subscription.yearly', 'Annuale') : t('subscription.monthly', 'Mensile')})</span>
                      )}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-2 pt-3">
                <div className="grid gap-1">
                  <div className="text-sm text-muted-foreground">{t('auth.dailyUsage', 'Utilizzo Giornaliero')}</div>
                  <div className="font-medium">{t('auth.requestsUsed', '3/3 richieste gratuite utilizzate oggi')}</div>
                  <div className="text-xs text-muted-foreground mt-1">{t('auth.upgradeForUnlimited', 'Aggiorna al piano Premium per richieste illimitate')}</div>
                </div>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full mt-2"
                  onClick={() => window.location.href = '/subscription'}
                >
                  <i className="ri-vip-crown-line mr-2"></i> {t('auth.upgradeToPremium', 'Passa a Premium')}
                </Button>
              </CardContent>
              
              <CardFooter className="flex flex-col gap-2 pt-2">
                <Button 
                  variant="secondary" 
                  className="w-full" 
                  onClick={handleLogout}
                >
                  <i className="ri-logout-box-line mr-2"></i> {t('auth.logout', 'Disconnetti')}
                </Button>
              </CardFooter>
            </Card>
          </>
        ) : (
          // Vista login/registrazione
          <>
            <DialogHeader>
              <DialogTitle>{t('auth.loginToAuralis', 'Accedi a Auralis')}</DialogTitle>
              <DialogDescription>
                {t('auth.loginDescription', 'Accedi o crea un account per salvare i tuoi progressi e sbloccare altre funzionalità.')}
              </DialogDescription>
            </DialogHeader>

            <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "login" | "register")} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">{t('auth.login', 'Accedi')}</TabsTrigger>
                <TabsTrigger value="register">{t('auth.register', 'Registrati')}</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login" className="mt-4">
                <form onSubmit={handleLogin}>
                  <div className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="username">{t('auth.username', 'Username')}</Label>
                      <Input
                        id="username"
                        placeholder={t('auth.usernamePlaceholder', 'Il tuo username')}
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="password">{t('auth.password', 'Password')}</Label>
                      <Input
                        id="password"
                        type="password"
                        placeholder={t('auth.passwordPlaceholder', 'La tua password')}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={loading}
                    >
                      {loading ? t('auth.loggingIn', 'Accesso in corso...') : t('auth.login', 'Accedi')}
                    </Button>
                  </div>
                </form>
              </TabsContent>
              
              <TabsContent value="register" className="mt-4">
                <form onSubmit={handleRegister}>
                  <div className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="name">{t('auth.fullName', 'Nome e Cognome')}</Label>
                      <Input
                        id="name"
                        placeholder={t('auth.fullNamePlaceholder', 'Il tuo nome e cognome')}
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="email">{t('auth.email', 'Email')}</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder={t('auth.emailPlaceholder', 'La tua email')}
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="reg-username">{t('auth.username', 'Username')}</Label>
                      <Input
                        id="reg-username"
                        placeholder={t('auth.chooseUsername', 'Scegli un username')}
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="reg-password">{t('auth.password', 'Password')}</Label>
                      <Input
                        id="reg-password"
                        type="password"
                        placeholder={t('auth.minChars', 'Almeno 6 caratteri')}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        minLength={6}
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={loading}
                    >
                      {loading ? t('auth.registering', 'Registrazione in corso...') : t('auth.register', 'Registrati')}
                    </Button>
                  </div>
                </form>
              </TabsContent>
            </Tabs>

            <DialogFooter className="flex flex-col items-center gap-2 sm:gap-0">
              <p className="text-xs text-muted-foreground text-center max-w-md">
                {t('auth.termsAgreement', 'Registrandoti accetti i nostri Termini di Servizio e la nostra Informativa sulla Privacy.')}
              </p>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default AuthDialog;