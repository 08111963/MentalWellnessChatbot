import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/lib/auth-context';
import { useStripe } from '@/lib/stripe-context';
import { useIsMobile } from '@/hooks/use-mobile';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { PremiumBadge } from '@/components/PremiumBadge';
import { BookOpen, Clock, FileText, ChevronLeft, Save, Tag, Eye, ArrowLeft } from 'lucide-react';

// Definizione del tipo Resource qui invece di importarlo
interface Resource {
  id: number;
  title: string;
  description: string;
  type: string;
  tags?: string[];
  url?: string;
  imageUrl?: string;
  isPremium: boolean;
  category: string;
  estimatedTime?: string;
  relevanceScore?: number;
  content?: string;
}

interface ResourceRecommendationsProps {
  className?: string;
}

export function ResourceRecommendations({ className = '' }: ResourceRecommendationsProps) {
  const { isAuthenticated, isAdmin } = useAuth();
  const { subscription } = useStripe();
  const isMobile = useIsMobile();
  const { toast } = useToast();
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<string>('recommended');
  
  // Funzione modificata per gestire il cambio di tab con scrolling
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    
    // Trova il contenitore principale della pagina delle risorse
    const resourcePageTop = document.getElementById('resource-page-top');
    if (resourcePageTop) {
      resourcePageTop.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      // Fallback allo scroll standard
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }
  };
  const [userMessage, setUserMessage] = useState<string>('');
  const [isSearchingByMessage, setIsSearchingByMessage] = useState<boolean>(false);
  const [selectedResource, setSelectedResource] = useState<Resource | null>(null);
  const [isDetailView, setIsDetailView] = useState<boolean>(false);

  // Query per ottenere le risorse raccomandate (personalizzate o tutte)
  const { i18n } = useTranslation();
  const currentLanguage = i18n.language;
  
  const {
    data: recommendedResources,
    isLoading: isLoadingRecommended,
    refetch: refetchRecommended
  } = useQuery<Resource[]>({
    queryKey: ['/api/resources', { limit: 5, language: currentLanguage }],
    queryFn: async () => {
      const response = await apiRequest(
        'GET',
        `/api/resources?language=${currentLanguage}`
      );
      const data = await response.json();
      return data as Resource[];
    },
    enabled: activeTab === 'recommended' || isDetailView // Abilita la query anche in modalità dettaglio
  });
  
  // Query per ottenere risorse correlate (per tag)
  const [relatedResourcesQuery, setRelatedResourcesQuery] = useState<string[]>([]);
  const {
    data: relatedResources,
    isLoading: isLoadingRelated
  } = useQuery<Resource[]>({
    queryKey: ['/api/resources/tags', { tags: relatedResourcesQuery }],
    queryFn: async () => {
      if (!relatedResourcesQuery.length) return [];
      const response = await apiRequest(
        'POST',
        '/api/resources/tags',
        { tags: relatedResourcesQuery }
      );
      const data = await response.json();
      return data as Resource[];
    },
    enabled: isDetailView && relatedResourcesQuery.length > 0
  });

  // Mutation per ottenere raccomandazioni basate sul messaggio dell'utente
  const resourcesByMessageMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest(
        'POST',
        `/api/resources/recommend?language=${currentLanguage}`,
        { message }
      );
      
      const data = await response.json();
      return data as {resources: Resource[], analysis: any};
    },
    onSuccess: (data) => {
      setIsSearchingByMessage(false);
      toast({
        title: t('resourcesPage.recommendationsFound'),
        description: t('resourcesPage.recommendationsFoundDescription', { count: data.resources.length }),
      });
    },
    onError: (error) => {
      setIsSearchingByMessage(false);
      toast({
        title: t('resourcesPage.errorTitle'),
        description: t('resourcesPage.errorDescription'),
        variant: "destructive",
      });
      console.error("Error fetching recommendations:", error);
    }
  });

  // Query per ottenere tutte le categorie disponibili
  const {
    data: resourceCategories = ['ansia', 'depressione', 'mindfulness', 'sonno', 'stress'],
    isLoading: isLoadingCategories
  } = useQuery<string[]>({
    queryKey: ['/api/resources/categories', { language: currentLanguage }],
    queryFn: async () => {
      const response = await apiRequest(
        'GET',
        `/api/resources/categories?language=${currentLanguage}`
      );
      const data = await response.json();
      return data as string[];
    }
  });
  
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  
  // Gestisce il cambio di categoria con scrolling
  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    
    // Trova il contenitore principale della pagina delle risorse
    const resourcePageTop = document.getElementById('resource-page-top');
    if (resourcePageTop) {
      resourcePageTop.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      // Fallback allo scroll standard
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }
  };
  
  // Imposta la categoria selezionata quando le categorie vengono caricate
  React.useEffect(() => {
    if (resourceCategories && resourceCategories.length > 0 && !selectedCategory) {
      setSelectedCategory(resourceCategories[0]);
    }
  }, [resourceCategories, selectedCategory]);

  const {
    data: categoryResources,
    isLoading: isLoadingCategory
  } = useQuery<Resource[]>({
    queryKey: ['/api/resources/category', selectedCategory, { language: currentLanguage }],
    queryFn: async () => {
      const response = await apiRequest(
        'GET',
        `/api/resources/category/${selectedCategory}?language=${currentLanguage}`
      );
      const data = await response.json();
      return data as Resource[];
    },
    enabled: activeTab === 'categories' && selectedCategory !== '',
  });

  const handleSearch = () => {
    if (!userMessage.trim()) {
      toast({
        title: t('resourcesPage.missingMessageTitle'),
        description: t('resourcesPage.missingMessageDescription'),
        variant: "destructive",
      });
      return;
    }

    setIsSearchingByMessage(true);
    resourcesByMessageMutation.mutate(userMessage);
  };
  
  // Effetto per gestire lo scroll dopo che una ricerca produce risultati
  React.useEffect(() => {
    if (resourcesByMessageMutation.data && resourcesByMessageMutation.data.resources.length > 0) {
      // Scorri la pagina per mostrare i risultati della ricerca
      setTimeout(() => {
        const searchResults = document.getElementById('searchResults');
        if (searchResults) {
          searchResults.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
  }, [resourcesByMessageMutation.data]);

  // Redirect alla pagina di abbonamento
  const handleGoToSubscription = () => {
    // Usa window.location invece di wouter per assicurarsi che funzioni sempre
    window.location.href = '/subscription';
  };

  const handleViewResource = (resource: Resource) => {
    // Verifica se la risorsa è premium e l'utente non è premium o admin
    if (resource.isPremium && !isAdmin && !subscription?.isActive) {
      // Reindirizza direttamente alla pagina di abbonamento
      window.location.href = '/subscription';
      return;
    }
    
    setSelectedResource(resource);
    setIsDetailView(true);
    
    // Imposta le query per le risorse correlate in base ai tag della risorsa selezionata
    if (resource.tags && resource.tags.length > 0) {
      // Usa i tag della risorsa per trovare risorse correlate
      setRelatedResourcesQuery(resource.tags);
    } else {
      // Se non ci sono tag, usa almeno la categoria
      setRelatedResourcesQuery([resource.category]);
    }
    
    // Scorri all'inizio della pagina quando viene visualizzata una risorsa
    const resourcePageTop = document.getElementById('resource-page-top');
    if (resourcePageTop) {
      resourcePageTop.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      // Fallback allo scroll standard
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }
  };

  const handleBackFromDetail = () => {
    setIsDetailView(false);
    setSelectedResource(null);
  };

  const renderResourceCard = (resource: Resource) => {
    return (
      <Card key={resource.id} className="mb-4">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <CardTitle className="text-lg font-semibold">{resource.title}</CardTitle>
            {resource.isPremium && <PremiumBadge className="ml-2" />}
          </div>
          <CardDescription className="text-sm text-muted-foreground mt-1">
            <div className="flex items-center space-x-1">
              <Clock size={14} />
              <span>{resource.estimatedTime || `5 ${t('resourcesPage.readingTime')}`}</span>
            </div>
          </CardDescription>
        </CardHeader>
        <CardContent className="pb-2">
          <p className="text-sm mb-2">{resource.description}</p>
          
          <div className="flex flex-wrap gap-2 mt-3">
            <Badge variant="outline" className="capitalize">
              {t(`resourcesPage.resourceCategories.${resource.category}`)}
            </Badge>
            <Badge variant="outline" className="capitalize">
              {t(`resourcesPage.resourceTypes.${resource.type}`)}
            </Badge>
            {resource.tags?.slice(0, 2).map((tag, index) => (
              <Badge key={index} variant="secondary" className="capitalize">
                {t(`resourcesPage.resourceTags.${tag}`) || tag}
              </Badge>
            ))}
          </div>
        </CardContent>
        <CardFooter className="pt-2 flex justify-between">
          <Button variant="outline" size="sm" onClick={() => handleViewResource(resource)}>
            <Eye size={16} className="mr-1" />
            {t('resourcesPage.viewResource')}
          </Button>
          <Button variant="ghost" size="sm">
            <Save size={16} className="mr-1" />
            {t('resourcesPage.saveResource')}
          </Button>
        </CardFooter>
      </Card>
    );
  };

  const renderResourceDetailView = () => {
    if (!selectedResource) return null;
    
    // Contenuto predefinito per dimostrare l'interfaccia quando non c'è content
    const defaultContent = `
      <h2>${t('resourcesPage.guideTo')} ${selectedResource.title}</h2>
      <p>${t('resourcesPage.resourceDescription', { title: selectedResource.title })}</p>
      
      <h3>${t('resourcesPage.whyImportant')}</h3>
      <p>${selectedResource.description}</p>
      
      <h3>${t('resourcesPage.keyPoints')}</h3>
      <ul>
        <li>${t('resourcesPage.keyPoint1')}</li>
        <li>${t('resourcesPage.keyPoint2')}</li>
        <li>${t('resourcesPage.keyPoint3')}</li>
        <li>${t('resourcesPage.keyPoint4')}</li>
      </ul>
      
      <h3>${t('resourcesPage.practicalTips')}</h3>
      <p>${t('resourcesPage.practicalTipsDescription')}</p>
      
      <h3>${t('resourcesPage.importantNote')}</h3>
      <p>${t('resourcesPage.importantNoteDescription')}</p>
    `;
    
    const contentHtml = selectedResource.content || defaultContent;
    
    return (
      <div className="w-full">
        <div className="mb-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleBackFromDetail}
            className="mb-4"
          >
            <ArrowLeft size={16} className="mr-2" />
            {t('resourcesPage.backToList')}
          </Button>
          
          <div className="bg-white rounded-lg shadow-md p-6 mb-4">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="text-2xl font-bold text-gray-800">{selectedResource.title}</h2>
                <div className="flex items-center mt-2 text-sm text-gray-500">
                  <Clock size={14} className="mr-1" />
                  <span>{selectedResource.estimatedTime || `5 ${t('resourcesPage.readingTime')}`}</span>
                </div>
              </div>
              {selectedResource.isPremium && <PremiumBadge />}
            </div>
            
            <div className="flex flex-wrap gap-2 mb-4">
              <Badge variant="outline" className="capitalize">
                {t(`resourcesPage.resourceCategories.${selectedResource.category}`)}
              </Badge>
              <Badge variant="outline" className="capitalize">
                {t(`resourcesPage.resourceTypes.${selectedResource.type}`)}
              </Badge>
              {selectedResource.tags?.map((tag, index) => (
                <Badge key={index} variant="secondary" className="capitalize">
                  {t(`resourcesPage.resourceTags.${tag}`) || tag}
                </Badge>
              ))}
            </div>
            
            <div className="prose max-w-none">
              <div dangerouslySetInnerHTML={{ __html: contentHtml }} />
            </div>
            
            <div className="mt-8 pt-4 border-t border-gray-200">
              <h3 className="text-lg font-semibold mb-2">{t('resourcesPage.feedbackQuestion')}</h3>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    toast({
                      title: t('resourcesPage.feedbackSent'),
                      description: t('resourcesPage.feedbackThankYou'),
                    });
                  }}
                >
                  {t('resourcesPage.veryUseful')}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    toast({
                      title: t('resourcesPage.feedbackSent'),
                      description: t('resourcesPage.feedbackThankYou'),
                    });
                  }}
                >
                  {t('resourcesPage.quiteUseful')}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    toast({
                      title: t('resourcesPage.feedbackSent'),
                      description: t('resourcesPage.feedbackThankYou'),
                    });
                  }}
                >
                  {t('resourcesPage.notVeryUseful')}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className={`w-full max-w-3xl mx-auto p-4 ${className}`}>
      <h2 className="text-2xl font-bold mb-6 text-center">{t('resourcesPage.personalizedResources')}</h2>
      
      {isDetailView && selectedResource ? (
        renderResourceDetailView()
      ) : (
        <Tabs 
          defaultValue="recommended" 
          value={activeTab} 
          onValueChange={handleTabChange}
          className="w-full"
        >
          <TabsList className="w-full grid grid-cols-3 mb-6">
            <TabsTrigger value="recommended">{t('resourcesPage.recommended')}</TabsTrigger>
            <TabsTrigger value="categories">{t('resourcesPage.categories')}</TabsTrigger>
            <TabsTrigger value="search">{t('resourcesPage.search')}</TabsTrigger>
          </TabsList>
          
          <TabsContent value="recommended" className="space-y-4">
            <div className="mb-4">
              <p className="text-center text-muted-foreground mb-6">
                {t('resourcesPage.recommendedDescription')}
              </p>
              
              {isLoadingRecommended ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <Card key={i} className="mb-4">
                      <CardHeader className="pb-2">
                        <div className="h-6 bg-muted rounded animate-pulse w-3/4"></div>
                        <div className="h-4 bg-muted rounded animate-pulse w-1/3 mt-2"></div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="h-4 bg-muted rounded animate-pulse w-full mt-2"></div>
                        <div className="h-4 bg-muted rounded animate-pulse w-full mt-2"></div>
                        <div className="flex gap-2 mt-4">
                          <div className="h-6 bg-muted rounded animate-pulse w-20"></div>
                          <div className="h-6 bg-muted rounded animate-pulse w-20"></div>
                        </div>
                      </CardContent>
                      <CardFooter className="pt-2">
                        <div className="h-9 bg-muted rounded animate-pulse w-32"></div>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : recommendedResources && recommendedResources.length > 0 ? (
                <div>
                  {recommendedResources.map(renderResourceCard)}
                </div>
              ) : (
                <div className="text-center py-10">
                  <BookOpen className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">{t('resourcesPage.noResources')}</h3>
                  <p className="text-muted-foreground mt-2">
                    {t('resourcesPage.noRecommendedResources')}
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="categories" className="space-y-4">
            <div className="mb-6">
              <p className="text-center text-muted-foreground mb-4">
                {t('resourcesPage.exploreByCategory')}
              </p>
              
              <div className="flex flex-wrap gap-2 justify-center mb-6">
                {resourceCategories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    size="sm"
                    className="capitalize"
                    onClick={() => handleCategoryChange(category)}
                  >
                    {t(`resourcesPage.resourceCategories.${category}`)}
                  </Button>
                ))}
              </div>
              
              {isLoadingCategory ? (
                <div className="space-y-4">
                  {[1, 2].map((i) => (
                    <Card key={i} className="mb-4">
                      <CardHeader className="pb-2">
                        <div className="h-6 bg-muted rounded animate-pulse w-3/4"></div>
                        <div className="h-4 bg-muted rounded animate-pulse w-1/3 mt-2"></div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="h-4 bg-muted rounded animate-pulse w-full mt-2"></div>
                        <div className="h-4 bg-muted rounded animate-pulse w-full mt-2"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : categoryResources && categoryResources.length > 0 ? (
                <div>
                  {categoryResources.map(renderResourceCard)}
                </div>
              ) : (
                <div className="text-center py-10">
                  <Tag className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">{t('resourcesPage.noResources')}</h3>
                  <p className="text-muted-foreground mt-2">
                    {t('resourcesPage.noCategoryResources')}
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="search" className="space-y-4">
            <div className="mb-4">
              <p className="text-center text-muted-foreground mb-6">
                {t('resourcesPage.searchDescription')}
              </p>
              
              <div className="space-y-4">
                <Textarea
                  placeholder={t('resourcesPage.searchPlaceholder')}
                  value={userMessage}
                  onChange={(e) => setUserMessage(e.target.value)}
                  className="min-h-[100px]"
                />
                <Button 
                  onClick={handleSearch} 
                  className="w-full"
                  disabled={isSearchingByMessage || !userMessage.trim()}
                >
                  {isSearchingByMessage ? t('resourcesPage.searching') : t('resourcesPage.findResources')}
                </Button>
              </div>
              
              {resourcesByMessageMutation.isPending ? (
                <div className="space-y-4 mt-6">
                  {[1, 2].map((i) => (
                    <Card key={i} className="mb-4">
                      <CardHeader className="pb-2">
                        <div className="h-6 bg-muted rounded animate-pulse w-3/4"></div>
                        <div className="h-4 bg-muted rounded animate-pulse w-1/3 mt-2"></div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="h-4 bg-muted rounded animate-pulse w-full mt-2"></div>
                        <div className="h-4 bg-muted rounded animate-pulse w-full mt-2"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : resourcesByMessageMutation.data ? (
                <div className="mt-6" id="searchResults">
                  <h3 className="text-lg font-medium mb-4">{t('resourcesPage.recommendedForYou')}</h3>
                  <Separator className="mb-6" />
                  {resourcesByMessageMutation.data.resources.map(renderResourceCard)}
                </div>
              ) : resourcesByMessageMutation.isError ? (
                <div className="text-center py-10 mt-6">
                  <h3 className="text-lg font-medium text-red-500">{t('resourcesPage.errorOccurred')}</h3>
                  <p className="text-muted-foreground mt-2">
                    {t('resourcesPage.cannotFindResourcesForMessage')}
                  </p>
                </div>
              ) : null}
            </div>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}