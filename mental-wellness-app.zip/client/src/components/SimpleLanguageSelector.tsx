import React, { useEffect, useCallback } from 'react';
import { Globe } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';

// Componente semplificato del selettore di lingua
interface SimpleLanguageSelectorProps {
  hideInPaths?: string[];
}

const SimpleLanguageSelector: React.FC<SimpleLanguageSelectorProps> = ({ 
  hideInPaths = []
}) => {
  // Importante: tutti gli hooks devono essere dichiarati prima di qualsiasi return condizionale
  const [location] = useLocation();
  const { i18n, t } = useTranslation();
  const { toast } = useToast();

  // Lista delle lingue disponibili
  const languages = [
    { code: 'it', name: 'Italiano' },
    { code: 'en', name: 'English' }
  ];

  // Lingua corrente
  const currentLang = i18n.language.substring(0, 2);

  // Log all'avvio per debug (solo una volta)
  useEffect(() => {
    console.log('SimpleLanguageSelector: current language =', i18n.language);
    console.log('SimpleLanguageSelector: localStorage i18nextLng =', localStorage.getItem('i18nextLng'));
    console.log('SimpleLanguageSelector: t("app.name") =', t('app.name'));
  }, []);

  // Funzione per cambiare lingua senza perdere lo stato dell'abbonamento e senza ricaricare la pagina
  const changeLanguage = useCallback((lang: string) => {
    if (lang === currentLang) return; // Se è già la lingua corrente, non fare nulla
    
    console.log('SimpleLanguageSelector: changing language to:', lang);
    
    try {
      // Salva in localStorage
      localStorage.setItem('i18nextLng', lang);
      
      // Cambia la lingua in i18n (questo aggiorna tutti i componenti che usano useTranslation)
      i18n.changeLanguage(lang);
      
      // Non mostriamo più il toast di conferma
      // Il cambio avviene silenziosamente
      
      console.log('SimpleLanguageSelector: language changed to', lang);
    } catch (err) {
      console.error('SimpleLanguageSelector: Error changing language:', err);
      toast({
        title: t('languages.error', 'Errore'),
        description: t('languages.errorChanging', 'Errore nel cambio lingua'),
        variant: 'destructive'
      });
    }
  }, [i18n, currentLang, t, toast]);

  return (
    <div className="inline-flex items-center bg-white bg-opacity-80 p-2 rounded-md shadow-md">
      <Globe className="h-4 w-4 mr-2 text-blue-500" />
      <div className="flex space-x-2">
        {languages.map((lang) => (
          <button
            key={lang.code}
            onClick={() => changeLanguage(lang.code)}
            className={`text-xs font-medium px-2 py-1 rounded-md transition-colors ${
              currentLang === lang.code 
                ? 'bg-blue-500 text-white font-bold' 
                : 'bg-blue-100 text-blue-800 hover:bg-blue-200'
            }`}
            title={lang.name}
          >
            {lang.code.toUpperCase()}
          </button>
        ))}
      </div>
    </div>
  );
};

export default SimpleLanguageSelector;