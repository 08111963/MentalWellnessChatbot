import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '@/lib/auth-context';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { navigateToHome, isProblematicPage } from '@/lib/home-navigation';
import HamburgerMenu from '@/components/HamburgerMenu';
import AuthDialog from '@/components/AuthDialog';
import { useTranslation } from 'react-i18next';

interface Header2Props {
  title?: string;
}

// Utilizziamo window.location invece di useLocation per una navigazione più semplice
const Header2: React.FC<Header2Props> = ({ title }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [authDialogOpen, setAuthDialogOpen] = useState(() => {
    // Controlla se c'è il parametro openAuth nell'URL
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('openAuth') === 'true';
  });
  const isHomePage = window.location.pathname === '/';
  const { isAdmin, setAdmin, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const adminCodeRef = useRef('');
  const adminCodeTimeout = useRef<NodeJS.Timeout | null>(null);
  
  // Codice segreto per attivare la modalità admin
  const { adminPassword } = useAuth();
  
  // Definizione delle funzioni
  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  // Chiudi il menu quando si fa clic su un elemento
  const handleMenuItemClick = () => {
    setMenuOpen(false);
  };
  
  const handleActivateAdmin = useCallback(() => {
    if (!isAdmin) {
      setAdmin(true);
      toast({
        title: "Modalità Admin attivata",
        description: "Ora hai accesso a tutti i contenuti premium",
        variant: "default",
      });
    }
  }, [isAdmin, setAdmin, toast]);
  
  // Effetto per rimuovere il parametro openAuth dall'URL quando viene caricato la prima volta
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('openAuth') === 'true') {
      // Rimuovi il parametro dall'URL senza ricaricare la pagina
      urlParams.delete('openAuth');
      const newUrl = `${window.location.pathname}${urlParams.toString() ? `?${urlParams.toString()}` : ''}${window.location.hash}`;
      window.history.replaceState({}, '', newUrl);
    }
  }, []);
  
  useEffect(() => {
    // Listener per le pressioni dei tasti per il codice segreto
    const handleKeyDown = (e: KeyboardEvent) => {
      // Non catturare eventi da input fields
      if (e.target instanceof HTMLInputElement || 
          e.target instanceof HTMLTextAreaElement) {
        return;
      }
      
      // Aggiungi il carattere al codice
      adminCodeRef.current += e.key.toLowerCase();
      
      // Limita la lunghezza del codice
      if (adminCodeRef.current.length > 20) {
        adminCodeRef.current = adminCodeRef.current.substring(adminCodeRef.current.length - 20);
      }
      
      // Controlla se il codice contiene la sequenza segreta
      if (adminCodeRef.current.includes(adminPassword)) {
        handleActivateAdmin();
        adminCodeRef.current = ''; // Reset del codice
      }
      
      // Reset del codice dopo 2 secondi di inattività
      if (adminCodeTimeout.current) {
        clearTimeout(adminCodeTimeout.current);
      }
      
      adminCodeTimeout.current = setTimeout(() => {
        adminCodeRef.current = '';
      }, 2000);
    };
    
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (adminCodeTimeout.current) {
        clearTimeout(adminCodeTimeout.current);
      }
    };
  }, [adminPassword, handleActivateAdmin]);
  
  // La funzione handleToggleAdmin è stata rimossa
  
  // Funzione diretta per tornare alla home
  const handleHomeClick = (e: React.MouseEvent) => {
    // Blocca la navigazione standard
    e.preventDefault();
    // Disabilita temporaneamente tutti gli event handler
    document.body.style.pointerEvents = 'none';
    // Forza un ricaricamento completo della pagina sulla home
    window.location.href = '/';
  };
  
  // Importa useTranslation per le traduzioni
  const { t } = useTranslation();
  
  // Gestire il logout
  const { logout } = useAuth();
  
  const handleLogout = () => {
    logout();
    // Dopo il logout, ricarica la pagina per aggiornare lo stato
    window.location.reload();
  };
  
  // Verifica se siamo in una pagina problematica
  const isInProblematicPage = isProblematicPage();

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-5xl mx-auto px-4 py-4 flex justify-between items-center">
        {/* Logo e nome */}
        <div className="flex items-center space-x-2">
          {isHomePage ? (
            // Sulla home page, il logo non è cliccabile
            <>
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <i className="ri-mental-health-line text-white text-xl"></i>
              </div>
              <h1 className="font-nunito font-bold text-2xl text-neutral-800">
                {title || "Auralis"}
              </h1>
            </>
          ) : (
            // Su altre pagine, il logo è cliccabile e porta alla home
            <a 
              href="/" 
              className="flex items-center space-x-2 transition-transform hover:scale-105"
              onClick={handleHomeClick}
              aria-label="Torna alla Home"
            >
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <i className="ri-mental-health-line text-white text-xl"></i>
              </div>
              <h1 className="font-nunito font-bold text-2xl text-neutral-800">
                {title || "Auralis"}
              </h1>
            </a>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          {/* Pulsante Home visibile solo quando non siamo nella home e non siamo in una pagina problematica */}
          {!isHomePage && !isInProblematicPage && (
            <a 
              href="/"
              className="px-3 py-1.5 bg-purple-600 text-white text-sm rounded-md font-medium hover:bg-purple-700 shadow-md inline-flex items-center" 
              onClick={handleHomeClick}
              aria-label="Torna alla Home"
            >
              <i className="ri-home-4-line mr-1.5"></i> Home
            </a>
          )}
          

          
          {/* Il pulsante Admin è stato rimosso */}
          
          {/* Pulsante Gestisci Abbonamento - visibile solo per utenti premium */}
          {isAuthenticated && localStorage.getItem('auralis_premium') === 'true' && (
            <Button 
              variant="outline" 
              size="sm"
              className="px-3 py-1.5 border-amber-500 text-amber-600 hover:bg-amber-50 mr-2"
              onClick={() => window.location.href = '/manage-subscription'}
            >
              <i className="ri-vip-crown-line mr-1.5"></i> Premium
            </Button>
          )}
          
          {/* Pulsante Login/Logout */}
          {isAuthenticated ? (
            <Button 
              variant="outline" 
              size="sm"
              className="px-3 py-1.5 border-indigo-500 text-indigo-600 hover:bg-indigo-50"
              onClick={handleLogout}
            >
              <i className="ri-logout-box-line mr-1.5"></i> {t('auth.login')}/{t('auth.logout')}
            </Button>
          ) : (
            <Button 
              variant="outline" 
              size="sm"
              className="px-3 py-1.5 border-indigo-500 text-indigo-600 hover:bg-indigo-50"
              onClick={() => setAuthDialogOpen(true)}
            >
              <i className="ri-login-box-line mr-1.5"></i> {t('auth.login')}/{t('auth.logout')}
            </Button>
          )}
          
          {/* Hamburger Menu */}
          <HamburgerMenu />
          
          {/* Pulsante Admin */}
          {isAdmin && (
            <a 
              href="/admin"
              className="px-3 py-2 text-sm text-amber-600 border border-amber-500 rounded-md hover:bg-amber-50 focus:outline-none mr-2 inline-flex items-center" 
              aria-label="Amministrazione"
            >
              <i className="ri-settings-3-line mr-1"></i> Admin
            </a>
          )}
          
          {/* Dialog di Autenticazione */}
          <AuthDialog 
            open={authDialogOpen} 
            onOpenChange={setAuthDialogOpen} 
          />
        </div>
      </div>
    </header>
  );
};

export default Header2;