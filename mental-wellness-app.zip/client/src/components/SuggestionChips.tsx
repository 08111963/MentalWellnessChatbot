import React from 'react';
import { type Suggestion } from '@/lib/types';

interface SuggestionChipsProps {
  suggestions: Suggestion[];
  onSelectSuggestion: (suggestion: string) => void;
}

const SuggestionChips: React.FC<SuggestionChipsProps> = ({ 
  suggestions = [], 
  onSelectSuggestion 
}) => {
  return (
    <div className="mb-8">
      <h3 className="text-sm font-medium text-neutral-500 mb-3">Suggerimenti</h3>
      {suggestions.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-[200px] overflow-y-auto pr-1">
          {suggestions.map((suggestion) => (
            <button
              key={suggestion.id}
              onClick={() => onSelectSuggestion(suggestion.text)}
              className="bg-white border border-neutral-200 text-neutral-700 text-sm py-2 px-3 rounded-lg hover:bg-neutral-50 hover:border-primary/30 hover:text-primary transition-all shadow-sm flex items-center"
            >
              <span className="mr-2 text-primary">
                <i className="ri-question-line"></i>
              </span>
              <span className="text-left">{suggestion.text}</span>
            </button>
          ))}
        </div>
      ) : (
        <div className="bg-neutral-50 p-4 rounded-lg text-center text-neutral-500">
          <i className="ri-loader-line animate-spin text-xl mb-2"></i>
          <p>Caricamento suggerimenti...</p>
        </div>
      )}
    </div>
  );
};

export default SuggestionChips;
