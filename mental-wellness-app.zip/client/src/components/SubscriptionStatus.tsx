import React, { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, Zap, ChevronRight, Crown } from 'lucide-react';
import { useLocation } from 'wouter';
import { useStripe } from '../lib/stripe-context';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';

interface SubscriptionStatusProps {
  className?: string;
}

export function SubscriptionStatus({ className = '' }: SubscriptionStatusProps) {
  console.log("RENDERING SubscriptionStatus component");
  const [, navigate] = useLocation();
  const { subscription, isSubscriptionActive } = useStripe();
  const { toast } = useToast();
  const { t, i18n } = useTranslation();
  const [showBanner, setShowBanner] = useState(false);
  
  // Controllo se è appena stato attivato l'abbonamento
  useEffect(() => {
    const justSubscribed = localStorage.getItem('just_subscribed');
    if (justSubscribed && isSubscriptionActive()) {
      setShowBanner(true);
      
      // Mostra un messaggio di benvenuto
      toast({
        title: "Abbonamento attivato!",
        description: "Grazie per esserti abbonato a Guida Premium. Ora hai accesso a tutti i contenuti esclusivi!",
        duration: 5000,
      });
      
      // Rimuovi il flag
      localStorage.removeItem('just_subscribed');
      
      // Nascondi il banner dopo 5 secondi
      setTimeout(() => {
        setShowBanner(false);
      }, 5000);
    }
  }, [toast, subscription.isActive]);
  
  const handleSubscribe = () => {
    navigate('/subscription');
  };
  
  const handleManage = () => {
    // Utilizziamo il routing per navigare alla pagina di gestione abbonamento
    window.location.href = '/manage-subscription';
  };
  
  // Verifichiamo anche il sistema legacy
  const legacyPremium = localStorage.getItem('auralis_premium') === 'true';
  
  // Se l'utente non è premium, non mostriamo più il pulsante per l'abbonamento
  if (!isSubscriptionActive() && !legacyPremium) {
    return null;
  }
  
  // Altrimenti, mostra lo stato dell'abbonamento
  return (
    <>
      {showBanner && (
        <div className={`mb-4 p-4 rounded-lg bg-gradient-to-r from-amber-100 to-amber-200 border border-amber-300 shadow-md animate-pulse ${className}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Crown className="h-5 w-5 text-amber-600 mr-2" />
              <div>
                <h3 className="text-sm font-semibold text-amber-900">Benvenuto in Premium!</h3>
                <p className="text-xs text-amber-700">Grazie per il tuo supporto. Goditi tutti i contenuti esclusivi!</p>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <div className={`flex items-center justify-between p-4 rounded-lg bg-gradient-to-r from-amber-50 to-amber-100/80 border border-amber-200 ${className}`}>
        <div className="flex items-center">
          <Badge className="bg-amber-500 text-white font-normal mr-3">
            <Zap className="mr-1 h-3 w-3" /> {t('subscriptionManager.premiumBadge')}
          </Badge>
          <div>
            {legacyPremium && !subscription.isActive ? (
              // Visualizzazione per utenti con abbonamento legacy
              <p className="text-xs font-medium text-amber-900">
                {localStorage.getItem('auralis_plan') === 'yearly' 
                  ? t('subscriptionManager.yearlyPlan') 
                  : t('subscriptionManager.monthlyPlan')}
              </p>
            ) : (
              // Visualizzazione per utenti con abbonamento normale
              <p className="text-xs font-medium text-amber-900">
                {subscription.plan === 'yearly' 
                  ? t('subscriptionManager.yearlyPlan') 
                  : t('subscriptionManager.monthlyPlan')}
              </p>
            )}
            
            {subscription.expiresAt ? (
              // Se c'è una data di scadenza, mostrala
              <p className="text-xs text-amber-700">
                <Calendar className="inline-block mr-1 h-3 w-3" /> 
                {t('subscriptionManager.nextPayment')}: {subscription.expiresAt.toLocaleDateString(i18n.language === 'it' ? 'it-IT' : 'en-US')}
              </p>
            ) : legacyPremium ? (
              // Altrimenti, se è un abbonamento legacy, mostra un messaggio generico
              <p className="text-xs text-amber-700">
                <Calendar className="inline-block mr-1 h-3 w-3" /> 
                {t('subscriptionManager.active')}
              </p>
            ) : null}
          </div>
        </div>
        <Button 
          onClick={handleManage}
          variant="ghost" 
          size="sm"
          className="text-amber-700 hover:text-amber-900 hover:bg-amber-200/50"
        >
          {t('subscriptionManager.manageButton')} <ChevronRight className="ml-1 h-3 w-3" />
        </Button>
      </div>
    </>
  );
}