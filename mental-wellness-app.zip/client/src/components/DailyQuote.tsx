import React, { useState, useEffect } from 'react';
import { Quote } from '@/lib/types';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Check, Settings } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import i18next from 'i18next';

// Definizione della struttura di una categoria di citazioni
interface QuoteCategory {
  id: string;
  name: string;
}

// Tipo delle preferenze utente
interface QuotePreferences {
  categories: string[];
  mood: string;
}

// Costante per la chiave di localStorage
const QUOTE_PREFERENCES_KEY = 'auralis_quote_preferences';

export function DailyQuote() {
  const { t } = useTranslation();
  const [quote, setQuote] = useState<Quote | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [categories, setCategories] = useState<QuoteCategory[]>([]);
  const [showPreferences, setShowPreferences] = useState(false);
  // Preferenze salvate (categorie e mood)
  const [preferences, setPreferences] = useState<QuotePreferences>({
    categories: [],
    mood: 'neutral'
  });
  
  // Carica le preferenze da localStorage
  useEffect(() => {
    const savedPreferences = localStorage.getItem(QUOTE_PREFERENCES_KEY);
    if (savedPreferences) {
      try {
        const parsed = JSON.parse(savedPreferences);
        setPreferences(parsed);
      } catch (err) {
        console.error('Error parsing saved quote preferences:', err);
      }
    }
  }, []);

  // Funzione per salvare le preferenze in localStorage
  const savePreferences = (newPreferences: QuotePreferences) => {
    setPreferences(newPreferences);
    localStorage.setItem(QUOTE_PREFERENCES_KEY, JSON.stringify(newPreferences));
  };

  // Funzione per caricare le categorie
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch('/api/quotes/categories');
        if (response.ok) {
          const data = await response.json();
          setCategories(data);
        }
      } catch (err) {
        console.error('Error fetching quote categories:', err);
      }
    };

    fetchCategories();
  }, []);

  // Funzione per caricare la citazione quotidiana
  useEffect(() => {
    const fetchDailyQuote = async () => {
      setLoading(true);
      try {
        // Ottieni la lingua corrente dall'hook useTranslation
        const currentLanguage = t('language', { defaultValue: 'it' });
        
        // Costruisci l'URL con le preferenze
        let url = `/api/quotes/daily?t=${Date.now()}&language=${currentLanguage}`;
        
        // Aggiungi categorie preferite, se presenti
        if (preferences.categories && preferences.categories.length > 0) {
          url += `&categories=${preferences.categories.join(',')}`;
        }
        
        // Aggiungi mood, se presente
        if (preferences.mood) {
          url += `&mood=${preferences.mood}`;
        }
        
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error('Failed to fetch daily quote');
        }
        const data = await response.json();
        setQuote(data);
        setError(null);
      } catch (err) {
        console.error('Error fetching daily quote:', err);
        setError(t('quotes.error'));
      } finally {
        setLoading(false);
      }
    };

    fetchDailyQuote();
  }, [preferences, t]); // Ricarica quando cambiano le preferenze o la lingua

  // Toggle una categoria nelle preferenze
  const toggleCategory = (categoryId: string) => {
    const newCategories = [...preferences.categories];
    const index = newCategories.indexOf(categoryId);
    
    if (index === -1) {
      // Aggiungi categoria
      newCategories.push(categoryId);
    } else {
      // Rimuovi categoria
      newCategories.splice(index, 1);
    }
    
    savePreferences({
      ...preferences,
      categories: newCategories
    });
  };

  // Imposta il mood nelle preferenze
  const setMood = (mood: string) => {
    savePreferences({
      ...preferences,
      mood
    });
  };

  if (loading) {
    return (
      <Card className="border-primary/20 bg-primary/5 mb-8">
        <CardContent className="pt-6 pb-6 text-center">
          <div className="h-24 flex items-center justify-center">
            <div className="animate-pulse flex flex-col items-center w-full">
              <div className="bg-primary/30 h-4 w-3/4 rounded mb-4"></div>
              <div className="bg-primary/30 h-4 w-1/2 rounded"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error || !quote) {
    return null; // Non mostriamo nulla in caso di errore
  }

  return (
    <Card className="border-primary/20 bg-primary/5 mb-8 shadow-md overflow-hidden">
      <CardContent className="pt-6 pb-5 relative">
        <div className="absolute top-2 right-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                <Settings className="h-4 w-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="end">
              <div className="space-y-4">
                <h4 className="font-medium text-sm">{t('quotes.customize')}</h4>
                <Separator />
                
                <div className="space-y-2">
                  <h5 className="text-sm font-medium">{t('quotes.categories')}</h5>
                  <div className="flex flex-wrap gap-2">
                    {categories.map((category) => (
                      <Badge 
                        key={category.id}
                        variant={preferences.categories.includes(category.id) ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => toggleCategory(category.id)}
                      >
                        {preferences.categories.includes(category.id) && (
                          <Check className="mr-1 h-3 w-3" />
                        )}
                        {category.name}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h5 className="text-sm font-medium">{t('quotes.mood')}</h5>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { id: 'neutral', name: t('quotes.moods.neutral') },
                      { id: 'happy', name: t('quotes.moods.happy') },
                      { id: 'calm', name: t('quotes.moods.calm') },
                      { id: 'sad', name: t('quotes.moods.sad') },
                      { id: 'anxious', name: t('quotes.moods.anxious') }
                    ].map((mood) => (
                      <Badge 
                        key={mood.id}
                        variant={preferences.mood === mood.id ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => setMood(mood.id)}
                      >
                        {mood.name}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <Button 
                  size="sm" 
                  variant="outline"
                  className="w-full"
                  onClick={() => savePreferences({ categories: [], mood: 'neutral' })}
                >
                  {t('quotes.reset')}
                </Button>
              </div>
            </PopoverContent>
          </Popover>
        </div>
        
        <div className="absolute top-1 left-0 text-8xl text-primary opacity-10">
          <i className="ri-double-quotes-l"></i>
        </div>
        
        <div className="relative z-10">
          <blockquote className="text-lg font-serif italic text-neutral-800 mb-4 relative">
            {quote.text}
          </blockquote>
          
          <div className="flex justify-end">
            <cite className="text-sm text-primary font-medium not-italic">
              — {quote.author}
            </cite>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default DailyQuote;