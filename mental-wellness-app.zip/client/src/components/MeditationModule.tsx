import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import MeditationModuleCard from './MeditationModuleCard';
import { type Meditation } from '@/lib/types';

interface MeditationModuleProps {
  title: string;
  description?: string;
  limit?: number;
  compact?: boolean;
  showViewAll?: boolean;
  category?: string;
  className?: string;
  onMeditationSelect?: (meditation: Meditation) => void;
}

export const MeditationModule: React.FC<MeditationModuleProps> = ({
  title,
  description,
  limit = 4,
  compact = false,
  showViewAll = true,
  category,
  className = '',
  onMeditationSelect
}) => {
  const { t, i18n } = useTranslation();
  const { toast } = useToast();
  
  // Esegue la query per ottenere le meditazioni
  const { data: allMeditations, isLoading, error } = useQuery<Meditation[]>({
    queryKey: ['/api/meditations', i18n.language],
    queryFn: () => fetch(`/api/meditations?language=${i18n.language}`).then(res => res.json()),
  });
  
  // Filtra le meditazioni in base alla categoria se fornita
  const meditations = !category 
    ? allMeditations?.slice(0, limit)
    : allMeditations?.filter(m => 
        // Adattare questo filtro in base alla struttura delle categorie delle meditazioni
        // Per ora usiamo solo la corrispondenza nel titolo come esempio
        m.title.toLowerCase().includes(category.toLowerCase())
      ).slice(0, limit);
  
  // Gestisce il click su una meditazione
  const handleMeditationClick = (meditation: Meditation) => {
    if (onMeditationSelect) {
      onMeditationSelect(meditation);
    } else {
      // Comportamento predefinito: navigazione alla pagina della meditazione
      window.location.href = `/meditation?id=${meditation.id}`;
    }
  };
  
  return (
    <div className={`meditation-module ${className}`}>
      <div className="module-header mb-4">
        <h2 className="text-xl font-nunito font-bold text-neutral-800">{title}</h2>
        {description && (
          <p className="text-neutral-600 text-sm mt-1">{description}</p>
        )}
      </div>
      
      {isLoading ? (
        <div className={`grid ${compact ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-1 sm:grid-cols-2'} gap-4`}>
          {Array(limit).fill(0).map((_, i) => (
            <div key={i} className="flex flex-col h-full">
              <Skeleton className="h-24 w-full mb-2" />
              <Skeleton className="h-16 w-full mb-2" />
              <Skeleton className="h-8 w-full" />
            </div>
          ))}
        </div>
      ) : error ? (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg mb-4">
          <p className="text-red-600 text-sm">
            {t('meditation.errorLoading', 'Errore nel caricamento delle meditazioni')}
          </p>
        </div>
      ) : (
        <>
          <div className={`grid ${compact ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-1 sm:grid-cols-2'} gap-4`}>
            {meditations?.map(meditation => (
              <MeditationModuleCard 
                key={meditation.id}
                meditation={meditation}
                compact={compact}
                onClick={handleMeditationClick}
              />
            ))}
          </div>
          
          {showViewAll && (
            <div className="mt-4 text-center">
              <Link href="/meditation">
                <Button variant="outline" className="text-primary hover:text-primary hover:bg-primary/10">
                  {t('meditation.viewAllMeditations', 'Visualizza tutte le meditazioni')}
                  <i className="ri-arrow-right-line ml-2"></i>
                </Button>
              </Link>
            </div>
          )}
        </>
      )}
      
      <Separator className="my-6" />
    </div>
  );
};

export default MeditationModule;