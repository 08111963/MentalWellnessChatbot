import { useState, useEffect } from 'react';

/**
 * Hook personalizzato per utilizzare localStorage con React.
 * Permette di salvare e caricare dati persistenti nel browser.
 * 
 * @param key La chiave sotto cui salvare i dati nel localStorage
 * @param initialValue Il valore iniziale da usare se non esiste nulla nel localStorage
 * @returns Un array con il valore corrente e una funzione per aggiornarlo
 */
export function useLocalStorage<T>(
  key: string,
  initialValue: T
): [T, (value: T | ((val: T) => T)) => void] {
  // Funzione per ottenere il valore iniziale
  const readValue = (): T => {
    // Nel SSR, non abbiamo accesso a localStorage
    if (typeof window === 'undefined') {
      return initialValue;
    }

    try {
      // Ottieni dal localStorage per chiave
      const item = window.localStorage.getItem(key);
      // Analizza il JSON memorizzato o restituisci initialValue
      return item ? (JSON.parse(item) as T) : initialValue;
    } catch (error) {
      console.warn(`Error reading localStorage key "${key}":`, error);
      return initialValue;
    }
  };

  // Stato per memorizzare il valore
  const [storedValue, setStoredValue] = useState<T>(readValue);

  // Funzione per aggiornare il valore sia nello stato che nel localStorage
  const setValue = (value: T | ((val: T) => T)) => {
    try {
      // Consenti che il value sia una funzione
      const valueToStore =
        value instanceof Function ? value(storedValue) : value;
      
      // Salva nello stato
      setStoredValue(valueToStore);
      
      // Salva nel localStorage
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      }
    } catch (error) {
      console.warn(`Error setting localStorage key "${key}":`, error);
    }
  };

  // Ascolta per i cambiamenti in altri tab/finestre
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === key && e.newValue) {
        setStoredValue(JSON.parse(e.newValue) as T);
      }
    };

    // Aggiungi ascoltatore per gli eventi storage
    window.addEventListener('storage', handleStorageChange);
    
    // Rimuovi ascoltatore su cleanup
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [key]);

  return [storedValue, setValue];
}