import { useState, useCallback, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { type ChatMessage, type ChatResponse } from '@/lib/types';
import { nanoid } from 'nanoid';
import { useTranslation } from 'react-i18next';

// Chiave per memorizzare la history nel localStorage
const CHAT_HISTORY_KEY = 'auralis_chat_history';

// Welcome messages in different languages
const WELCOME_MESSAGES: { [key: string]: string } = {
  'it': "Ciao! Sono qui per offrirti supporto con ansia e stress, utilizzando principi di terapia cognitivo-comportamentale. Come posso aiutarti oggi?",
  'en': "Hello! I'm here to offer you support with anxiety and stress, using cognitive-behavioral therapy principles. How can I help you today?",
  'es': "¡Hola! Estoy aquí para ofrecerte apoyo con la ansiedad y el estrés, utilizando principios de terapia cognitivo-conductual. ¿Cómo puedo ayudarte hoy?",
  'fr': "Bonjour! Je suis là pour vous offrir un soutien en matière d'anxiété et de stress, en utilisant les principes de la thérapie cognitivo-comportementale. Comment puis-je vous aider aujourd'hui?",
  'de': "Hallo! Ich bin hier, um Ihnen bei Angst und Stress zu helfen, mit Prinzipien der kognitiven Verhaltenstherapie. Wie kann ich Ihnen heute helfen?"
};

// Error messages in different languages
const ERROR_MESSAGES: { [key: string]: { title: string, description: string } } = {
  'it': {
    title: 'Errore',
    description: 'Non è stato possibile inviare il messaggio. Riprova più tardi.'
  },
  'en': {
    title: 'Error',
    description: 'Could not send the message. Please try again later.'
  },
  'es': {
    title: 'Error',
    description: 'No se pudo enviar el mensaje. Inténtalo de nuevo más tarde.'
  },
  'fr': {
    title: 'Erreur',
    description: 'Impossible d\'envoyer le message. Veuillez réessayer plus tard.'
  },
  'de': {
    title: 'Fehler',
    description: 'Die Nachricht konnte nicht gesendet werden. Bitte versuchen Sie es später erneut.'
  }
};

export const useChat = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [chatInitialized, setChatInitialized] = useState(false);
  const { toast } = useToast();
  const { i18n } = useTranslation();
  
  // Get welcome message based on current language
  const getWelcomeMessage = useCallback(() => {
    const currentLang = i18n.language || 'it';
    const lang = Object.keys(WELCOME_MESSAGES).includes(currentLang) ? currentLang : 'it';
    return WELCOME_MESSAGES[lang];
  }, [i18n.language]);
  
  // Get error message based on current language
  const getErrorMessage = useCallback(() => {
    const currentLang = i18n.language || 'it';
    const lang = Object.keys(ERROR_MESSAGES).includes(currentLang) ? currentLang : 'it';
    return ERROR_MESSAGES[lang];
  }, [i18n.language]);
  
  // Initialize with welcome message
  const initializeChat = useCallback(() => {
    const welcomeMessage: ChatMessage = {
      id: nanoid(),
      role: 'assistant',
      content: getWelcomeMessage(),
      timestamp: new Date()
    };
    
    setMessages([welcomeMessage]);
    setChatInitialized(true);
  }, [getWelcomeMessage]);
  
  // Send message to chatbot API
  const sendMessage = useCallback(async (content: string) => {
    if (!content.trim() || isLoading) return;
    
    // Add user message to chat
    const userMessage: ChatMessage = {
      id: nanoid(),
      role: 'user',
      content,
      timestamp: new Date()
    };
    
    // Aggiungi solo il messaggio dell'utente, per evitare duplicazioni
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);
    
    try {
      // Include current language in the request
      const currentLang = i18n.language || 'it';
      
      const response = await apiRequest('POST', '/api/chat', {
        message: content,
        sessionId: 'default', // For future user sessions
        language: currentLang // Pass the current language to the server
      });
      
      const data: ChatResponse = await response.json();
      
      // Add bot response to chat
      const botMessage: ChatMessage = {
        id: nanoid(),
        role: 'assistant',
        content: data.message,
        timestamp: new Date()
      };
      
      // Aggiungiamo la risposta del bot
      setMessages(prev => {
        const updatedMessages = [...prev, botMessage];
        // Salviamo i messaggi in localStorage per persistenza
        localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(updatedMessages));
        return updatedMessages;
      });
    } catch (error) {
      console.error('Chat API error:', error);
      const errorMsg = getErrorMessage();
      toast({
        title: errorMsg.title,
        description: errorMsg.description,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast, isLoading, i18n.language, getErrorMessage]);
  
  // Load chat history from API or localStorage
  const loadChatHistory = useCallback(async () => {
    if (chatInitialized) return; // Evita caricamenti multipli
    
    // Prima controlla se c'è una history salvata in localStorage
    const savedHistory = localStorage.getItem(CHAT_HISTORY_KEY);
    if (savedHistory) {
      try {
        const parsedHistory = JSON.parse(savedHistory) as ChatMessage[];
        setMessages(parsedHistory);
        setChatInitialized(true);
        return;
      } catch (e) {
        console.error('Error parsing saved chat history:', e);
        localStorage.removeItem(CHAT_HISTORY_KEY);
      }
    }
    
    // Se non c'è una history nel localStorage, caricala dall'API
    try {
      const response = await fetch('/api/chat/history?sessionId=default');
      const history: ChatMessage[] = await response.json();
      
      if (history.length > 0) {
        // Add IDs to messages from history
        const historyWithIds = history.map(msg => ({
          ...msg,
          id: nanoid(),
          timestamp: new Date()
        }));
        setMessages(historyWithIds);
        
        // Salva la history nel localStorage
        localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(historyWithIds));
      } else {
        // If no history, initialize with welcome message
        initializeChat();
      }
      
      setChatInitialized(true);
    } catch (error) {
      console.error('Failed to load chat history:', error);
      // Initialize with welcome message on error
      initializeChat();
    }
  }, [initializeChat, chatInitialized]);
  
  // Ensure chat is initialized when component mounts
  useEffect(() => {
    if (!chatInitialized) {
      loadChatHistory();
    }
  }, [loadChatHistory, chatInitialized]);
  
  // Reset chat function - cancella la chat e mostra il messaggio di benvenuto
  const resetChat = useCallback(() => {
    // Cancella la chat e il localStorage
    localStorage.removeItem(CHAT_HISTORY_KEY);
    
    // Mostra il messaggio di benvenuto nella lingua corrente
    const welcomeMessage: ChatMessage = {
      id: nanoid(),
      role: 'assistant',
      content: getWelcomeMessage(),
      timestamp: new Date()
    };
    
    setMessages([welcomeMessage]);
    
    // Notification messages for different languages
    const resetMessages: { [key: string]: { title: string, description: string } } = {
      'it': {
        title: 'Chat resettata',
        description: 'La conversazione è stata cancellata.'
      },
      'en': {
        title: 'Chat reset',
        description: 'The conversation has been cleared.'
      },
      'es': {
        title: 'Chat restablecido',
        description: 'La conversación ha sido borrada.'
      },
      'fr': {
        title: 'Chat réinitialisé',
        description: 'La conversation a été effacée.'
      },
      'de': {
        title: 'Chat zurückgesetzt',
        description: 'Die Konversation wurde gelöscht.'
      }
    };
    
    // Get current language
    const currentLang = i18n.language || 'it';
    const lang = Object.keys(resetMessages).includes(currentLang) ? currentLang : 'it';
    
    // Notifica all'utente
    toast({
      title: resetMessages[lang].title,
      description: resetMessages[lang].description,
    });
  }, [toast, getWelcomeMessage, i18n.language]);
  
  return {
    messages,
    isLoading,
    sendMessage,
    loadChatHistory,
    initializeChat,
    resetChat
  };
};
