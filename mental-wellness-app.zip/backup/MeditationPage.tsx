import React, { useState, useEffect, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';

import Header from '@/components/Header';
import TabNavigation from '@/components/TabNavigation';
import BottomNavigation from '@/components/BottomNavigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/auth-context';
import { useStripe } from '@/lib/stripe-context';
import { type Meditation } from '@/lib/types';
import { PremiumBadge } from '@/components/PremiumBadge';
import { PremiumContent } from '@/components/PremiumContent';
import { EmergencyHomeButton } from '@/components/EmergencyHome';

const MeditationPage: React.FC = () => {
  // Resetta lo scroll quando il componente viene montato
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const [selectedMeditation, setSelectedMeditation] = useState<Meditation | null>(null);
  const { toast } = useToast();
  
  // Otteniamo lo stato admin e i limiti di utilizzo dall'auth context
  const { isAdmin, hasReachedRequestLimit, incrementDailyUsageCount } = useAuth();
  
  const { data: meditations, isLoading, error } = useQuery<Meditation[]>({
    queryKey: ['/api/meditations'],
    enabled: true, // Sempre abilitata per permettere di vedere la lista completa
  });
  
  // Incrementiamo il contatore solo quando l'utente fa una richiesta intenzionale
  // (verrà fatto nel gestore di eventi dell'interfaccia)
  
  // Handler per l'abbonamento
  const handleSubscribe = useCallback(() => {
    window.location.href = '/subscription';
  }, []);
  
  // Import dello stato di Stripe
  const { isSubscriptionActive } = useStripe();
  
  const handleSelectMeditation = useCallback((meditation: Meditation) => {
    // Debug dell'abbonamento
    console.log('handleSelectMeditation - Abbonamento attivo:', isSubscriptionActive());
    
    // Verifichiamo anche il sistema legacy
    const legacyPremium = localStorage.getItem('auralis_premium') === 'true';
    console.log('handleSelectMeditation - Legacy premium:', legacyPremium);
    
    // Gli admin o gli utenti premium possono accedere a tutti i contenuti
    if (meditation.isPremium && !isAdmin && !isSubscriptionActive() && !legacyPremium) {
      // Reindirizza alla pagina di abbonamento solo se non è un utente premium
      handleSubscribe();
      return;
    }
    
    // Per gli utenti non-admin, incrementa il contatore di utilizzo giornaliero
    // quando accedono a una meditazione (solo alla prima interazione)
    if (!isAdmin && meditations) {
      incrementDailyUsageCount();
    }
    
    // Altrimenti, mostra la meditazione
    setSelectedMeditation(meditation);
  }, [isAdmin, handleSubscribe, meditations, incrementDailyUsageCount, isSubscriptionActive]);
  
  const handleBackToList = useCallback(() => {
    setSelectedMeditation(null);
  }, []);
  
  return (
    <div className="page-container min-h-screen flex flex-col bg-gradient-to-b from-blue-50 to-indigo-50 pb-16 md:pb-0">
      <div id="page-top" style={{ position: 'absolute', top: 0, left: 0 }}></div>
      <Header />
      
      {/* Pattern decorativo */}
      <div className="absolute top-0 left-0 right-0 h-64 bg-gradient-to-br from-blue-600/5 to-indigo-600/5 pointer-events-none"></div>
      <div className="absolute top-0 left-0 right-0 h-64 bg-[radial-gradient(#e0e7ff_1px,transparent_1px)] [background-size:20px_20px] opacity-30 pointer-events-none"></div>
      
      <main className="flex-grow max-w-3xl mx-auto w-full px-4 py-6 relative z-10">
        <EmergencyHomeButton discreet={true} />
        <TabNavigation activeTab="meditation" />
        
        {/* Banner per limite di utilizzo */}
        {!isAdmin && hasReachedRequestLimit && (
          <div className="mb-4 p-3 rounded-lg shadow-md bg-white border border-rose-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="rounded-full w-8 h-8 flex items-center justify-center bg-rose-100 text-rose-600">
                  <i className="ri-error-warning-line"></i>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-rose-800">
                    Limite giornaliero raggiunto
                  </h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    Abbonati per richieste illimitate
                  </p>
                </div>
              </div>
              <Link to="/subscription">
                <Button className="bg-purple-600 hover:bg-purple-700 text-white shadow-sm text-xs h-8">
                  Sblocca accesso
                </Button>
              </Link>
            </div>
          </div>
        )}
        
        {selectedMeditation ? (
          <MeditationDetail meditation={selectedMeditation} onBack={handleBackToList} />
        ) : (
          <div>
            <div className="meditation-header text-center mb-8">
              <div className="inline-flex items-center bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium mb-2">
                <i className="ri-mental-health-line text-lg mr-2"></i> Pratica Mindfulness
              </div>
              <h2 className="font-nunito font-bold text-3xl mb-3 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-transparent bg-clip-text">Meditazione Guidata</h2>
              <p className="text-neutral-600 mb-8 max-w-xl mx-auto">Scegli una sessione di meditazione guidata per ridurre stress e ansia, migliorando la tua calma interiore.</p>
            </div>
            
            {hasReachedRequestLimit && !isAdmin ? (
              <div className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-rose-100 mb-4">
                  <i className="ri-lock-line text-rose-600 text-2xl"></i>
                </div>
                <h3 className="text-lg font-bold text-rose-700 mb-2">Limite di richieste giornaliero raggiunto</h3>
                <p className="text-neutral-600 mb-6">Hai raggiunto il massimo di 3 richieste giornaliere disponibili nel piano gratuito.</p>
                <Link to="/subscription">
                  <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                    Passa al piano Premium
                  </Button>
                </Link>
              </div>
            ) : isLoading ? (
              <div className="flex justify-center py-12">
                <div className="w-8 h-8 border-3 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : error ? (
              <Card className="bg-red-50 border border-red-200 shadow-md">
                <CardContent className="p-8">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center text-red-500">
                      <i className="ri-error-warning-line text-2xl"></i>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-red-700 mb-1">Errore nel caricamento</h3>
                      <p className="text-red-600">Non è stato possibile caricare le meditazioni. Riprova più tardi.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {meditations?.map((meditation) => {
                  // Funzione per determinare il colore in base al titolo della meditazione
                  const getCardColor = (title: string) => {
                    switch(title) {
                      case "Respirazione Consapevole":
                        return "bg-blue-600";
                      case "Body Scan Rilassante":
                        return "bg-purple-600";
                      case "Radici del Presente":
                        return "bg-emerald-600";
                      case "Giardino del Cuore":
                        return "bg-rose-600";
                      default:
                        return "bg-accent";
                    }
                  };
                  
                  // Ottieni il colore per questa meditazione
                  const cardColor = getCardColor(meditation.title);
                  
                  // Ottieni il colore del testo del pulsante corrispondente
                  const getButtonClass = (title: string) => {
                    switch(title) {
                      case "Respirazione Consapevole":
                        return "text-blue-600 hover:text-blue-600 hover:bg-blue-50";
                      case "Body Scan Rilassante":
                        return "text-purple-600 hover:text-purple-600 hover:bg-purple-50";
                      case "Radici del Presente":
                        return "text-emerald-600 hover:text-emerald-600 hover:bg-emerald-50";
                      case "Giardino del Cuore":
                        return "text-rose-600 hover:text-rose-600 hover:bg-rose-50";
                      default:
                        return "text-accent hover:text-accent hover:bg-accent/10";
                    }
                  };
                  
                  return (
                    <Card 
                      key={meditation.id} 
                      className="meditation-card cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => handleSelectMeditation(meditation)}
                    >
                      <CardHeader 
                        className={`${meditation.isPremium 
                          ? 'bg-gradient-to-br from-yellow-400 via-amber-500 to-amber-700' 
                          : cardColor} 
                          text-white
                        `}
                      >
                        <div className="flex items-center justify-between relative z-10">
                          <div>
                            <CardTitle className="flex items-center font-bold">
                              {meditation.isPremium ? (
                                <span className="text-yellow-100 drop-shadow-md">
                                  {meditation.title === "Meditazione della Montagna" ? (
                                    "Vette di Serenità"
                                  ) : meditation.title === "Meditazione di Autocompassione" ? (
                                    "Abbraccio Interiore"
                                  ) : (
                                    meditation.title
                                  )}
                                </span>
                              ) : (
                                meditation.title
                              )}
                              {meditation.isPremium && (
                                <div className="ml-2 bg-white text-amber-600 text-xs px-2 py-1 rounded-full font-bold flex items-center shadow-md">
                                  <span className="mr-1 text-yellow-500">⭐</span>PREMIUM
                                </div>
                              )}
                            </CardTitle>
                            <CardDescription className="text-white opacity-90 flex items-center gap-2">
                              {meditation.duration} minuti
                            </CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="p-4">
                        <p className="text-neutral-600">{meditation.description}</p>
                      </CardContent>
                      <CardFooter className="pt-0 pb-4 px-4">
                        {/* Verifichiamo anche il sistema legacy per la visualizzazione del bottone */}
                        {(() => {
                          const legacyPremium = localStorage.getItem('auralis_premium') === 'true';
                          const needsPremium = meditation.isPremium && !isAdmin && !isSubscriptionActive() && !legacyPremium;
                          
                          return (
                            <Button 
                              variant={needsPremium ? "default" : "ghost"}
                              className={needsPremium
                                ? "bg-amber-500 hover:bg-amber-600 text-white w-full"
                                : `${getButtonClass(meditation.title)} btn-action`
                              }
                            >
                              {needsPremium ? 'Sblocca con Premium' : 'Inizia meditazione'}
                            </Button>
                          );
                        })()}
                      </CardFooter>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>
      
      <BottomNavigation />
    </div>
  );
};

interface MeditationDetailProps {
  meditation: Meditation;
  onBack: () => void;
}

const MeditationDetail: React.FC<MeditationDetailProps> = ({ meditation, onBack }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [timeLeft, setTimeLeft] = useState(meditation.duration * 60); // Convert to seconds
  
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (isPlaying && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft(prevTime => prevTime - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsPlaying(false);
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isPlaying, timeLeft]);
  
  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };
  
  const resetMeditation = () => {
    setIsPlaying(false);
    setTimeLeft(meditation.duration * 60);
  };
  
  // Funzione per determinare il colore dell'header in base al titolo della meditazione
  const getHeaderColor = (title: string) => {
    switch(title) {
      case "Respirazione Consapevole":
        return "bg-blue-600";
      case "Body Scan Rilassante":
        return "bg-purple-600";
      case "Radici del Presente":
        return "bg-emerald-600";
      case "Giardino del Cuore":
        return "bg-rose-600";
      default:
        return "bg-accent";
    }
  };
  
  // Funzione per determinare il colore del pulsante di azione
  const getActionButtonColor = (title: string) => {
    switch(title) {
      case "Respirazione Consapevole":
        return "bg-blue-600 hover:bg-blue-700";
      case "Body Scan Rilassante":
        return "bg-purple-600 hover:bg-purple-700";
      case "Radici del Presente":
        return "bg-emerald-600 hover:bg-emerald-700";
      case "Giardino del Cuore":
        return "bg-rose-600 hover:bg-rose-700";
      default:
        return "bg-accent hover:bg-accent/90";
    }
  };
  
  // Ottieni i colori per questa meditazione
  const headerColor = getHeaderColor(meditation.title);
  const actionButtonColor = getActionButtonColor(meditation.title);

  // Definiamo colori diversi per ciascun tipo di meditazione
  const getGradientColor = (title: string) => {
    switch(title) {
      case "Respirazione Consapevole":
        return "from-blue-500 to-blue-700";
      case "Body Scan Rilassante":
        return "from-purple-500 to-purple-700";
      case "Radici del Presente":
        return "from-emerald-500 to-emerald-700";
      case "Giardino del Cuore":
        return "from-rose-500 to-rose-700";
      case "Meditazione della Montagna":
      case "Vette di Serenità":
        return "from-amber-500 to-amber-700";
      case "Meditazione di Autocompassione":
      case "Abbraccio Interiore":
        return "from-indigo-500 to-indigo-700";
      default:
        return "from-indigo-500 to-indigo-700";
    }
  };

  const gradientColor = getGradientColor(meditation.title);
  const bgLight = headerColor.replace('bg-', 'bg-').replace('-600', '-50');
  const borderColor = headerColor.replace('bg-', 'border-').replace('-600', '-200');
  const textColor = headerColor.replace('bg-', 'text-').replace('-600', '-700');

  return (
    <div className="mt-4">
      <Button 
        variant="ghost" 
        className="mb-6 hover:bg-indigo-50 text-indigo-700 group flex items-center"
        onClick={onBack}
      >
        <div className="mr-2 bg-indigo-100 rounded-full p-1 group-hover:bg-indigo-200 transition-colors">
          <i className="ri-arrow-left-line"></i>
        </div> 
        Torna all'elenco
      </Button>
      
      <Card className="overflow-hidden border-none shadow-lg">
        <div className={`h-2 bg-gradient-to-r ${gradientColor}`}></div>
        <CardHeader className={`bg-gradient-to-br ${gradientColor} text-white relative`}>
          {/* Pattern decorativo */}
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMwLTkuOTQtOC4wNi0xOC0xOC0xOFYwYzkuOTQgMCAxOCA4LjA2IDE4IDE4aDEyYzAgOS45NCA4LjA2IDE4IDE4IDE4djEyYy05Ljk0IDAtMTgtOC4wNi0xOC0xOEgzNnoiIGZpbGwtb3BhY2l0eT0iLjEiIGZpbGw9IiNGRkYiLz48L2c+PC9zdmc+')] opacity-10"></div>
          
          <div className="relative z-10">
            <div className="flex items-center">
              <CardTitle className="text-2xl font-bold">
                {meditation.title === "Meditazione della Montagna" ? "Vette di Serenità" : 
                 meditation.title === "Meditazione di Autocompassione" ? "Abbraccio Interiore" : 
                 meditation.title}
              </CardTitle>
              <div className="ml-4 bg-white/20 backdrop-blur-sm text-white text-sm px-3 py-1 rounded-full font-medium flex items-center">
                <i className="ri-time-line mr-1"></i> {meditation.duration} minuti
              </div>
            </div>
            <CardDescription className="text-white/90 mt-2 max-w-xl">
              Migliora la tua consapevolezza e trova il tuo equilibrio interiore con questa meditazione guidata.
            </CardDescription>
          </div>
        </CardHeader>
        
        <CardContent className="p-8">
          <div className={`mb-8 p-6 ${bgLight} border ${borderColor} rounded-lg`}>
            <h3 className={`${textColor} font-bold text-lg mb-3`}>Descrizione</h3>
            <p className="text-neutral-700">{meditation.description}</p>
          </div>
          
          <div className="flex flex-col items-center py-6 px-4 bg-gradient-to-br from-indigo-50 to-blue-50 rounded-xl shadow-inner">
            <div className="text-5xl font-bold mb-6 bg-white rounded-full w-32 h-32 flex items-center justify-center shadow-md">
              {formatTime(timeLeft)}
            </div>
            
            <div className="flex flex-wrap gap-4 justify-center">
              <Button 
                className={`${actionButtonColor} btn-action shadow-md transform hover:scale-105 transition-transform text-lg px-8 py-6 h-auto`}
                onClick={togglePlayPause}
              >
                {isPlaying ? (
                  <div className="flex items-center">
                    <div className="mr-3 bg-white/30 rounded-full p-1.5">
                      <i className="ri-pause-line text-xl"></i>
                    </div>
                    Pausa
                  </div>
                ) : (
                  <div className="flex items-center">
                    <div className="mr-3 bg-white/30 rounded-full p-1.5">
                      <i className="ri-play-line text-xl"></i>
                    </div>
                    {timeLeft === meditation.duration * 60 ? 'Inizia' : 'Riprendi'}
                  </div>
                )}
              </Button>
              
              <Button 
                variant="outline"
                className="border-indigo-200 bg-white text-indigo-700 hover:bg-indigo-50 hover:text-indigo-800 h-auto"
                onClick={resetMeditation}
              >
                <i className="ri-restart-line mr-2"></i> Ricomincia
              </Button>
            </div>
            
            {isPlaying && (
              <div className="w-full mt-6">
                <div className="w-full h-2 bg-indigo-100 rounded-full overflow-hidden mt-4">
                  <div 
                    className={`h-full bg-gradient-to-r ${gradientColor}`} 
                    style={{ width: `${(timeLeft / (meditation.duration * 60)) * 100}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-indigo-600 mt-1">
                  <span>Tempo trascorso</span>
                  <span>Tempo rimanente</span>
                </div>
              </div>
            )}
          </div>
          
          <div className="mt-8 p-6 bg-white rounded-lg border border-neutral-200 shadow-sm">
            <h3 className="font-bold text-lg mb-4 text-indigo-800 flex items-center">
              <i className="ri-information-line mr-2 text-xl"></i> Istruzioni per la meditazione
            </h3>
            <div className="whitespace-pre-line text-neutral-700 leading-relaxed">
              {meditation.content}
            </div>
          </div>
          
          <div className="mt-8 bg-amber-50 border border-amber-200 p-4 rounded-lg flex items-start">
            <div className="text-amber-600 mr-3 mt-1">
              <i className="ri-lightbulb-flash-line text-xl"></i>
            </div>
            <div>
              <h4 className="text-amber-800 font-medium mb-1">Suggerimento</h4>
              <p className="text-amber-700 text-sm">
                Trova un luogo tranquillo e comodo. Siediti con la schiena dritta ma non rigida.
                Ricorda che non esiste un modo "giusto" di meditare - l'obiettivo è semplicemente osservare
                senza giudicare, tornando gentilmente al momento presente ogni volta che la mente vaga.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MeditationPage;
