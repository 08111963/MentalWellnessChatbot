import { type Exercise } from '@shared/schema';

// In-memory exercises data
export const exercises: Exercise[] = [
  // Esercizi CBT (Cognitive Behavioral Therapy)
  {
    id: 1,
    title: "Registro dei Pensieri",
    category: "CBT",
    description: "Identifica e ristruttura i pensieri negativi automatici",
    steps: [
      "Identifica la situazione che ha generato emozioni negative",
      "Annota i pensieri automatici che sono emersi",
      "Identifica le emozioni provate e la loro intensità (1-10)",
      "Cerca prove che supportino questi pensieri",
      "Cerca prove che contraddicano questi pensieri",
      "Sviluppa un pensiero alternativo più equilibrato",
      "Annota come ti senti dopo la ristrutturazione (1-10)"
    ],
    isPremium: false
  },
  {
    id: 2,
    title: "Tecnica delle 3 Colonne",
    category: "CBT",
    description: "Versione semplificata per ristrutturare rapidamente i pensieri distorti",
    steps: [
      "Crea 3 colonne su un foglio: Situazione, Pensiero Negativo, Pensiero Realistico",
      "Nella prima colonna, descrivi brevemente la situazione",
      "Nella seconda, scrivi il pensiero negativo emerso",
      "Nella terza, scrivi un pensiero più realistico e bilanciato",
      "Rileggi il pensiero realistico più volte"
    ],
    isPremium: false
  },
  {
    id: 3,
    title: "Identificazione Distorsioni Cognitive",
    category: "CBT",
    description: "Impara a riconoscere gli schemi di pensiero distorti che alimentano l'ansia",
    steps: [
      "Annota un pensiero disturbante che si presenta frequentemente",
      "Identifica il tipo di distorsione (generalizzazione, catastrofizzazione, lettura mentale, etc.)",
      "Rifletti su come questa distorsione influenza le tue emozioni e comportamenti",
      "Scrivi un pensiero alternativo privo di distorsioni",
      "Pratica il riconoscimento di queste distorsioni nella vita quotidiana"
    ]
  },
  {
    id: 4,
    title: "Esperimento Comportamentale",
    category: "CBT",
    description: "Testa le tue credenze e ipotesi negative attraverso esperimenti pratici",
    steps: [
      "Identifica una credenza negativa che vuoi testare (es. 'Farò una figuraccia alla presentazione')",
      "Progetta un esperimento per testare questa credenza",
      "Predici cosa accadrà secondo la tua credenza negativa",
      "Esegui l'esperimento e raccogli dati oggettivi su quello che accade realmente",
      "Confronta i risultati con la tua previsione e ricava conclusioni",
      "Sviluppa una nuova credenza basata sui dati reali"
    ]
  },
  {
    id: 5,
    title: "Esposizione Graduale",
    category: "CBT",
    description: "Affronta gradualmente le situazioni temute per ridurre l'ansia",
    steps: [
      "Crea una lista di situazioni che eviti a causa dell'ansia",
      "Ordina la lista dalla meno ansiogena (1/10) alla più ansiogena (10/10)",
      "Inizia ad esporti alla situazione meno ansiogena",
      "Rimani nella situazione finché l'ansia non diminuisce",
      "Passa al gradino successivo solo quando il precedente genera poca ansia",
      "Annota i tuoi progressi e celebra i successi"
    ]
  },
  {
    id: 6,
    title: "Pianificazione Attività Positive",
    category: "CBT",
    description: "Contrasta la depressione reintroducendo attività piacevoli nella routine",
    steps: [
      "Crea una lista di attività che ti davano piacere in passato",
      "Pianifica di svolgere almeno una piccola attività positiva ogni giorno",
      "Impegnati a completare l'attività indipendentemente da come ti senti",
      "Dopo ogni attività, annota il tuo livello di soddisfazione e senso di competenza (1-10)",
      "Gradualmente aumenta la frequenza e complessità delle attività",
      "Riconosci e celebra ogni piccolo successo"
    ]
  },
  {
    id: 7,
    title: "Rilassamento Muscolare Progressivo",
    category: "CBT",
    description: "Riduce lo stress contraendo e rilassando sistematicamente i gruppi muscolari",
    steps: [
      "Siediti o sdraiati in una posizione confortevole in un luogo tranquillo",
      "Contrai i muscoli dei piedi per 5 secondi, poi rilassali completamente",
      "Prosegui verso l'alto (polpacci, cosce, addome, mani, braccia, spalle, viso)",
      "Per ogni gruppo muscolare, nota la differenza tra tensione e rilassamento",
      "Respira profondamente durante tutto l'esercizio",
      "Pratica quotidianamente per ottenere benefici duraturi"
    ]
  },
  
  // Esercizi Mindfulness (Consapevolezza)
  {
    id: 8,
    title: "Respirazione 4-7-8",
    category: "Mindfulness",
    description: "Tecnica di respirazione per calmare rapidamente l'ansia",
    steps: [
      "Siediti in posizione comoda con la schiena dritta",
      "Espira completamente attraverso la bocca",
      "Chiudi la bocca e inspira silenziosamente dal naso contando fino a 4",
      "Trattieni il respiro contando fino a 7",
      "Espira completamente dalla bocca, producendo un suono, contando fino a 8",
      "Ripeti il ciclo per almeno 4 volte"
    ]
  },
  {
    id: 9,
    title: "Grounding 5-4-3-2-1",
    category: "Mindfulness",
    description: "Tecnica di radicamento per momenti di ansia acuta o dissociazione",
    steps: [
      "Nota 5 cose che puoi VEDERE intorno a te",
      "Nota 4 cose che puoi TOCCARE o SENTIRE sulla pelle",
      "Nota 3 cose che puoi ASCOLTARE nel tuo ambiente",
      "Nota 2 cose che puoi ODORARE (o profumi che ti piacciono)",
      "Nota 1 cosa che puoi GUSTARE (o un sapore che ti piace)",
      "Respira profondamente e nota come ti senti più presente"
    ]
  },
  {
    id: 10,
    title: "Scansione Corporea",
    category: "Mindfulness",
    description: "Esplora le sensazioni del corpo per aumentare la consapevolezza",
    steps: [
      "Sdraiati in una posizione comoda",
      "Porta l'attenzione alle dita dei piedi e lentamente muoviti verso l'alto",
      "Nota qualsiasi sensazione in ogni parte del corpo senza giudicarla",
      "Se trovi tensione, respira profondamente in quella zona",
      "Continua fino a raggiungere la cima della testa",
      "Termina prendendo consapevolezza del corpo come un tutt'uno"
    ]
  },
  {
    id: 11,
    title: "Meditazione del Respiro",
    category: "Mindfulness",
    description: "Concentrazione sul respiro per calmare la mente e rimanere nel presente",
    steps: [
      "Siediti comodamente con la schiena dritta e gli occhi chiusi o socchiusi",
      "Porta l'attenzione al respiro naturale, senza cercare di controllarlo",
      "Osserva dove senti maggiormente il respiro (narici, petto o addome)",
      "Quando ti accorgi che la mente vaga, riporta gentilmente l'attenzione al respiro",
      "Continua per 5-10 minuti, aumentando gradualmente la durata",
      "Prima di concludere, nota come ti senti rispetto a prima della meditazione"
    ]
  },
  {
    id: 12,
    title: "Camminata Consapevole",
    category: "Mindfulness",
    description: "Pratica mindfulness in movimento, ideale per chi ha difficoltà a stare fermo",
    steps: [
      "Scegli un percorso tranquillo dove puoi camminare indisturbato",
      "Cammina lentamente, sentendo il contatto dei piedi con il terreno",
      "Nota le sensazioni fisiche in tutto il corpo mentre ti muovi",
      "Osserva i pensieri che emergono senza aggrapparti ad essi",
      "Mantieni l'attenzione sulle sensazioni fisiche del camminare",
      "Pratica per almeno 10 minuti, idealmente all'aria aperta"
    ]
  },
  {
    id: 13,
    title: "Mangiare Consapevole",
    category: "Mindfulness",
    description: "Trasforma un pasto quotidiano in un'esperienza di presenza mentale",
    steps: [
      "Scegli un pasto o uno spuntino da consumare senza distrazioni",
      "Osserva l'aspetto, i colori e la forma del cibo prima di iniziare",
      "Nota l'aroma e come stimola l'appetito",
      "Assaggia lentamente, notando la texture e il sapore che si sviluppa",
      "Mastica completamente ogni boccone prima di prenderne un altro",
      "Riconosci sensazioni di fame e sazietà mentre mangi"
    ]
  },
  {
    id: 14,
    title: "Osservazione Pensieri",
    category: "Mindfulness",
    description: "Impara a osservare i pensieri senza identificarti con essi",
    steps: [
      "Siediti comodamente e chiudi gli occhi",
      "Immagina i tuoi pensieri come nuvole nel cielo o foglie che galleggiano su un ruscello",
      "Quando emerge un pensiero, osservalo passare senza aggrapparti ad esso",
      "Se ti ritrovi coinvolto in un pensiero, riconoscilo e torna gentilmente all'osservazione",
      "Pratica il non giudizio verso qualsiasi pensiero emerga",
      "Continua per 10-15 minuti, notando come i pensieri appaiono e scompaiono naturalmente"
    ]
  },

  // Esercizi di Benessere Quotidiano
  {
    id: 15,
    title: "Routine Mattutina del Benessere",
    category: "Benessere",
    description: "Inizia la giornata con un insieme di pratiche che favoriscono il benessere emotivo",
    steps: [
      "Appena sveglio, pratica la gratitudine pensando a 3 cose per cui sei grato oggi",
      "Bevi un bicchiere d'acqua e fai 5 minuti di leggero stretching",
      "Siediti in silenzio per 3-5 minuti facendo respirazione consapevole",
      "Scrivi brevemente le tue intenzioni per la giornata",
      "Evita di controllare dispositivi elettronici per i primi 30 minuti dopo il risveglio"
    ]
  },
  {
    id: 16,
    title: "Creazione Spazio Personale",
    category: "Benessere",
    description: "Crea un ambiente fisico che supporti il tuo benessere emotivo",
    steps: [
      "Identifica un'area della casa che può diventare il tuo 'spazio sereno'",
      "Rimuovi il disordine e gli elementi che creano distrazione o stress",
      "Aggiungi elementi che ti portano calma (cuscini, coperte morbide, piante, etc.)",
      "Incorpora stimoli sensoriali piacevoli (candele profumate, musica rilassante)",
      "Programma regolarmente del tempo da trascorrere in questo spazio"
    ]
  },
  {
    id: 17,
    title: "Diario della Gratitudine",
    category: "Benessere",
    description: "Pratica quotidiana per aumentare la consapevolezza delle cose positive nella vita",
    steps: [
      "Dedica 5 minuti ogni sera prima di dormire",
      "Scrivi 3-5 cose specifiche per cui sei grato/a oggi",
      "Includi anche piccoli dettagli o momenti apparentemente insignificanti",
      "Descrivi perché questi elementi sono importanti per te",
      "Rileggi regolarmente le tue annotazioni passate per apprezzare i pattern positivi"
    ]
  },
  {
    id: 18,
    title: "Pulizia Digitale Settimanale",
    category: "Benessere",
    description: "Riduci lo stress e l'affaticamento mentale causato dal sovraccarico digitale",
    steps: [
      "Programma 30 minuti ogni settimana per questa pratica",
      "Elimina file e app non necessari dal tuo telefono e computer",
      "Disiscriviti da newsletter che non leggi",
      "Organizza le email in cartelle e archivia quelle già gestite",
      "Imposta limiti di tempo per l'uso dei social media",
      "Attiva funzioni 'non disturbare' durante i momenti di riposo"
    ]
  }
];

export function getExerciseById(id: number): Exercise | undefined {
  return exercises.find(ex => ex.id === id);
}

export function getExercisesByCategory(category: string): Exercise[] {
  return exercises.filter(ex => ex.category.toLowerCase() === category.toLowerCase());
}

export function getAllExercises(): Exercise[] {
  return exercises;
}
