/**
 * Modulo di gestione pagamenti Stripe
 * Astrazione che seleziona il provider di pagamento (simulato o reale) in base alla configurazione
 */

import { Request, Response } from 'express';
import { PAYMENT_MODE, STRIPE_CONFIG } from './config';
import * as simulatedPayment from './simulatedPayment';
import * as stripePayment from './stripePayment';

// Prezzi esportati (questi sono gli stessi indipendentemente dal provider)
export const STRIPE_PRICES = {
  MONTHLY: PAYMENT_MODE === 'simulated' ? 'price_monthly_simulated' : STRIPE_CONFIG.PRICES.MONTHLY,
  YEARLY: PAYMENT_MODE === 'simulated' ? 'price_yearly_simulated' : STRIPE_CONFIG.PRICES.YEARLY
};

// URL di checkout diretto per i piani
export const DIRECT_CHECKOUT_URLS = {
  MONTHLY: STRIPE_CONFIG.DIRECT_CHECKOUT_URLS.MONTHLY,
  YEARLY: STRIPE_CONFIG.DIRECT_CHECKOUT_URLS.YEARLY
};

// Reindirizzamento diretto a checkout di abbonamento
export async function redirectToSubscription(req: Request, res: Response) {
  return PAYMENT_MODE === 'simulated'
    ? simulatedPayment.redirectToSubscription(req, res)
    : stripePayment.redirectToSubscription(req, res);
}

// Creazione di una sessione di checkout
export async function createCheckoutSession(req: Request, res: Response) {
  return PAYMENT_MODE === 'simulated'
    ? simulatedPayment.createCheckoutSession(req, res)
    : stripePayment.createCheckoutSession(req, res);
}

// Gestione webhook Stripe
export async function handleStripeWebhook(req: Request, res: Response) {
  return PAYMENT_MODE === 'simulated'
    ? simulatedPayment.handleWebhook(req, res)
    : stripePayment.handleWebhook(req, res);
}

// Verifica sessione di pagamento
export async function verifySession(req: Request, res: Response) {
  return PAYMENT_MODE === 'simulated'
    ? simulatedPayment.verifySession(req, res)
    : stripePayment.verifySession(req, res);
}

// Cancellazione di un abbonamento attivo
export async function cancelSubscription(userId: number, subscriptionId: string | null): Promise<boolean> {
  return PAYMENT_MODE === 'simulated'
    ? simulatedPayment.cancelSubscription(userId, subscriptionId)
    : stripePayment.cancelSubscription(userId, subscriptionId);
}