/**
 * Utilità per la gestione di più piattaforme e domini
 * Questo file contiene funzioni di supporto per gestire l'app su diversi ambienti
 */

import { Request } from 'express';
import { PLATFORM_CONFIG, STRIPE_CONFIG } from './config';

/**
 * Funzione per determinare l'URL base attuale o utilizzare un URL centralizzato per i pagamenti
 * @param req Richiesta HTTP
 * @returns URL base da utilizzare per i reindirizzamenti
 */
export function getBaseUrl(req: Request): string {
  // Se è configurato un URL centralizzato per i pagamenti e l'opzione è abilitata, usalo
  if (PLATFORM_CONFIG.USE_CENTRALIZED_PAYMENTS && PLATFORM_CONFIG.PAYMENT_BASE_URL) {
    return PLATFORM_CONFIG.PAYMENT_BASE_URL;
  }
  
  // Altrimenti, usa l'URL della richiesta corrente
  return `${req.protocol}://${req.get('host')}`;
}

/**
 * Funzione per verificare se un dominio è autorizzato
 * @param domain Nome del dominio da verificare
 * @returns true se il dominio è autorizzato, false altrimenti
 */
export function isAllowedDomain(domain: string): boolean {
  return PLATFORM_CONFIG.ALLOWED_DOMAINS.some(allowed => {
    // Verifica se il dominio termina con il dominio autorizzato
    // Questo permette di gestire sottodomini (es. app.auralis.it corrisponde a auralis.it)
    return domain === allowed || domain.endsWith(`.${allowed}`);
  });
}

/**
 * Genera URL di successo per Stripe Checkout
 * @param req Richiesta HTTP
 * @returns URL completo per il reindirizzamento dopo pagamento riuscito
 */
export function getSuccessUrl(req: Request): string {
  return `${getBaseUrl(req)}${STRIPE_CONFIG.REDIRECT_URLS.SUCCESS}?session_id={CHECKOUT_SESSION_ID}`;
}

/**
 * Genera URL di cancellazione per Stripe Checkout
 * @param req Richiesta HTTP
 * @returns URL completo per il reindirizzamento dopo cancellazione
 */
export function getCancelUrl(req: Request): string {
  return `${getBaseUrl(req)}${STRIPE_CONFIG.REDIRECT_URLS.CANCEL}`;
}

/**
 * Costruisce il parametro di ritorno per i webhook multi-dominio
 * @param req Richiesta HTTP
 * @param path Percorso relativo
 * @returns URL completo
 */
export function getWebhookReturnUrl(req: Request, path: string): string {
  return `${getBaseUrl(req)}${path}`;
}