import { type Exercise } from '@shared/schema';

// Extended Exercise type with translations
interface ExerciseWithTranslations extends Exercise {
  translations?: {
    [lang: string]: {
      title: string;
      description: string;
      steps: string[];
    }
  }
}

// In-memory exercises data
export const exercises: ExerciseWithTranslations[] = [
  // CBT Exercises
  {
    id: 1,
    title: "Restructuring negative thoughts",
    category: "CBT",
    description: "A fundamental CBT exercise to identify and modify automatic negative thoughts.",
    steps: [
      "Identify a recent negative thought that caused you discomfort",
      "Write down this thought and rate how much you believe it (0-100%)",
      "Identify the cognitive distortion present (e.g., catastrophizing, mental filter)",
      "Challenge this thought with questions like: 'What evidence do I have? Is there contrary evidence?'",
      "Develop a more balanced and realistic alternative thought",
      "Rate how much you believe the new thought (0-100%) and notice how your emotions change"
    ],
    isPremium: false,
    translations: {
      "it": {
        title: "Ristrutturazione dei pensieri negativi",
        description: "Un esercizio fondamentale di CBT per identificare e modificare i pensieri negativi automatici.",
        steps: [
          "Identifica un pensiero negativo recente che ti ha causato disagio",
          "Scrivi questo pensiero e valuta quanto ci credi (0-100%)",
          "Identifica la distorsione cognitiva presente (es. catastrofizzazione, filtro mentale)",
          "Sfida questo pensiero con domande come: 'Che prove ho? Ci sono prove contrarie?'",
          "Sviluppa un pensiero alternativo più equilibrato e realistico",
          "Valuta quanto credi al nuovo pensiero (0-100%) e nota come cambiano le tue emozioni"
        ]
      },
      "es": {
        title: "Reestructuración de pensamientos negativos",
        description: "Un ejercicio fundamental de TCC para identificar y modificar pensamientos negativos automáticos.",
        steps: [
          "Identifica un pensamiento negativo reciente que te haya causado malestar",
          "Escribe este pensamiento y evalúa cuánto lo crees (0-100%)",
          "Identifica la distorsión cognitiva presente (ej. catastrofización, filtro mental)",
          "Desafía este pensamiento con preguntas como: '¿Qué evidencia tengo? ¿Hay evidencia contraria?'",
          "Desarrolla un pensamiento alternativo más equilibrado y realista",
          "Evalúa cuánto crees en el nuevo pensamiento (0-100%) y observa cómo cambian tus emociones"
        ]
      },
      "fr": {
        title: "Restructuration des pensées négatives",
        description: "Un exercice fondamental de TCC pour identifier et modifier les pensées négatives automatiques.",
        steps: [
          "Identifiez une pensée négative récente qui vous a causé de l'inconfort",
          "Notez cette pensée et évaluez à quel point vous y croyez (0-100%)",
          "Identifiez la distorsion cognitive présente (ex. catastrophisation, filtre mental)",
          "Contestez cette pensée avec des questions comme: 'Quelles preuves ai-je? Y a-t-il des preuves contraires?'",
          "Développez une pensée alternative plus équilibrée et réaliste",
          "Évaluez à quel point vous croyez à la nouvelle pensée (0-100%) et remarquez comment vos émotions changent"
        ]
      },
      "de": {
        title: "Umstrukturierung negativer Gedanken",
        description: "Eine grundlegende KVT-Übung zur Identifizierung und Änderung automatischer negativer Gedanken.",
        steps: [
          "Identifizieren Sie einen kürzlichen negativen Gedanken, der Ihnen Unbehagen verursacht hat",
          "Schreiben Sie diesen Gedanken auf und bewerten Sie, wie sehr Sie daran glauben (0-100%)",
          "Identifizieren Sie die vorhandene kognitive Verzerrung (z.B. Katastrophisieren, mentaler Filter)",
          "Hinterfragen Sie diesen Gedanken mit Fragen wie: 'Welche Beweise habe ich? Gibt es gegenteilige Beweise?'",
          "Entwickeln Sie einen ausgewogeneren und realistischeren alternativen Gedanken",
          "Bewerten Sie, wie sehr Sie an den neuen Gedanken glauben (0-100%) und bemerken Sie, wie sich Ihre Emotionen verändern"
        ]
      }
    }
  },
  {
    id: 2,
    title: "Emotions diary",
    category: "CBT",
    description: "A structured method to track and analyze the connections between situations, thoughts, and emotions.",
    steps: [
      "Choose a recent situation that triggered intense emotions",
      "Describe the situation objectively (What happened? Where? When? Who was there?)",
      "Identify the emotions felt and rate their intensity (0-100%)",
      "List the automatic thoughts you had at that moment",
      "Identify any behaviors resulting from these emotions",
      "Reflect: how could you have interpreted the situation differently?",
      "Notice patterns that emerge over time as you regularly complete the diary"
    ],
    isPremium: false,
    translations: {
      "it": {
        title: "Diario delle emozioni",
        description: "Un metodo strutturato per monitorare e analizzare le connessioni tra situazioni, pensieri ed emozioni.",
        steps: [
          "Scegli una situazione recente che ha scatenato emozioni intense",
          "Descrivi la situazione in modo oggettivo (Cosa è successo? Dove? Quando? Chi era presente?)",
          "Identifica le emozioni provate e valuta la loro intensità (0-100%)",
          "Elenca i pensieri automatici che hai avuto in quel momento",
          "Identifica eventuali comportamenti derivanti da queste emozioni",
          "Rifletti: come avresti potuto interpretare la situazione in modo diverso?",
          "Nota i modelli che emergono nel tempo mentre completi regolarmente il diario"
        ]
      }
    }
  },
  {
    id: 3,
    title: "Behavioral experiment",
    category: "CBT",
    description: "A practical activity to test the validity of negative thoughts through direct action.",
    steps: [
      "Identify a negative belief that limits your behaviors",
      "Develop an 'experiment' to test this belief in real life",
      "Predict what you think will happen based on your negative belief",
      "Establish how you will measure the results of the experiment",
      "Perform the experiment and document what actually happens",
      "Compare the results with your original prediction",
      "Update your belief based on the real data collected"
    ],
    isPremium: true,
    translations: {
      "it": {
        title: "Esperimento comportamentale",
        description: "Un'attività pratica per testare la validità dei pensieri negativi attraverso l'azione diretta.",
        steps: [
          "Identifica una convinzione negativa che limita i tuoi comportamenti",
          "Sviluppa un 'esperimento' per testare questa convinzione nella vita reale",
          "Prevedi cosa pensi che accadrà in base alla tua convinzione negativa",
          "Stabilisci come misurerai i risultati dell'esperimento",
          "Esegui l'esperimento e documenta ciò che realmente accade",
          "Confronta i risultati con la tua previsione originale",
          "Aggiorna la tua convinzione sulla base dei dati reali raccolti"
        ]
      }
    }
  },
  {
    id: 4,
    title: "Responsibility pie technique",
    category: "CBT",
    description: "Useful for those who tend to take too much responsibility for negative events, it helps develop a more balanced perspective.",
    steps: [
      "Identify a situation for which you feel excessively responsible",
      "Draw a circle that represents 100% of the responsibility",
      "List all factors that contributed to the situation (including external factors, actions of others, circumstances, etc.)",
      "For each factor, assign a 'slice' of the pie proportional to its contribution",
      "Observe how large your 'slice' of responsibility really is",
      "Reflect on the difference between your initial perception and this more balanced view"
    ],
    isPremium: true,
    translations: {
      "it": {
        title: "Tecnica della torta di responsabilità",
        description: "Utile per chi tende ad assumersi troppe responsabilità per eventi negativi, aiuta a sviluppare una prospettiva più equilibrata.",
        steps: [
          "Identifica una situazione per la quale ti senti eccessivamente responsabile",
          "Disegna un cerchio che rappresenta il 100% della responsabilità",
          "Elenca tutti i fattori che hanno contribuito alla situazione (inclusi fattori esterni, azioni di altri, circostanze, ecc.)",
          "Per ogni fattore, assegna una 'fetta' della torta proporzionale al suo contributo",
          "Osserva quanto è grande in realtà la tua 'fetta' di responsabilità",
          "Rifletti sulla differenza tra la tua percezione iniziale e questa visione più equilibrata"
        ]
      }
    }
  },
  {
    id: 5,
    title: "Gradual exposure",
    category: "CBT",
    description: "A technique for gradually facing anxiety-provoking situations, building confidence and reducing avoidance.",
    steps: [
      "Identify a situation or stimulus that you avoid due to anxiety",
      "Create an 'anxiety ladder' with 5-10 steps, from least to most anxiety-provoking",
      "Start by exposing yourself to the first step of the ladder and practice anxiety management techniques",
      "Stay in that situation until anxiety decreases significantly",
      "Move to the next step only when you feel comfortable with the previous one",
      "Continue climbing the ladder gradually, celebrating each progress",
      "Maintain your gains by continuing to regularly face the situations"
    ],
    isPremium: true,
    translations: {
      "it": {
        title: "Esposizione graduale",
        description: "Una tecnica per affrontare gradualmente situazioni che provocano ansia, costruendo fiducia e riducendo l'evitamento.",
        steps: [
          "Identifica una situazione o uno stimolo che eviti a causa dell'ansia",
          "Crea una 'scala dell'ansia' con 5-10 gradini, dal meno al più ansiogeno",
          "Inizia esponendoti al primo gradino della scala e pratica tecniche di gestione dell'ansia",
          "Rimani in quella situazione finché l'ansia non diminuisce significativamente",
          "Passa al gradino successivo solo quando ti senti a tuo agio con quello precedente",
          "Continua a salire la scala gradualmente, celebrando ogni progresso",
          "Mantieni i tuoi guadagni continuando ad affrontare regolarmente le situazioni"
        ]
      }
    }
  },
  {
    id: 6,
    title: "Personal values identification",
    category: "CBT",
    description: "An exercise to clarify what is truly important to you, guiding decisions and behaviors.",
    steps: [
      "Reflect on different areas of life: relationships, work, personal growth, leisure, health, etc.",
      "For each area, identify what is truly important to you (not what you think should be important)",
      "Write why these values are significant in your life",
      "Assess how much your current behaviors align with these values (1-10)",
      "Identify specific actions you could take to live more in line with your values",
      "Choose one action to implement this week to move closer to your values"
    ],
    isPremium: true,
    translations: {
      "it": {
        title: "Identificazione dei valori personali",
        description: "Un esercizio per chiarire ciò che è veramente importante per te, guidando decisioni e comportamenti.",
        steps: [
          "Rifletti su diverse aree della vita: relazioni, lavoro, crescita personale, tempo libero, salute, ecc.",
          "Per ogni area, identifica ciò che è veramente importante per te (non ciò che pensi dovrebbe essere importante)",
          "Scrivi perché questi valori sono significativi nella tua vita",
          "Valuta quanto i tuoi comportamenti attuali sono allineati con questi valori (1-10)",
          "Identifica azioni specifiche che potresti intraprendere per vivere più in linea con i tuoi valori",
          "Scegli un'azione da implementare questa settimana per avvicinarti ai tuoi valori"
        ]
      }
    }
  },
  {
    id: 7,
    title: "Recognizing your achievements",
    category: "CBT",
    description: "An exercise to counter the tendency to focus only on failures, strengthening self-esteem.",
    steps: [
      "Each evening, reflect on your day and identify 3 things you handled well",
      "These 'successes' can be big or small, the important thing is to recognize them",
      "Write down these successes and why they are important to you",
      "Notice if you tend to minimize or devalue these successes (typical thought: 'It doesn't count, anyone could do it')",
      "Practice fully recognizing your merits, as you would with a friend",
      "Revisit your list of successes regularly, especially during times of low self-esteem"
    ],
    isPremium: true,
    translations: {
      "it": {
        title: "Riconoscere i tuoi successi",
        description: "Un esercizio per contrastare la tendenza a concentrarsi solo sui fallimenti, rafforzando l'autostima.",
        steps: [
          "Ogni sera, rifletti sulla tua giornata e identifica 3 cose che hai gestito bene",
          "Questi 'successi' possono essere grandi o piccoli, l'importante è riconoscerli",
          "Scrivi questi successi e perché sono importanti per te",
          "Nota se tendi a minimizzare o svalutare questi successi (pensiero tipico: 'Non conta, chiunque potrebbe farlo')",
          "Pratica il pieno riconoscimento dei tuoi meriti, come faresti con un amico",
          "Rivedi regolarmente la tua lista di successi, specialmente nei momenti di bassa autostima"
        ]
      }
    }
  },
  
  // Mindfulness Exercises
  {
    id: 8,
    title: "Mindful breathing meditation",
    category: "Mindfulness",
    description: "An anchor for the wandering mind, this fundamental practice cultivates presence and awareness.",
    steps: [
      "Find a comfortable position, sitting or lying down",
      "Close your eyes or keep your gaze soft downward",
      "Bring attention to your natural breath, without trying to modify it",
      "Notice the sensations of inhaling and exhaling in the body",
      "When the mind wanders (it's normal!), gently bring it back to the breath",
      "Continue for 5-10 minutes, gradually increasing the duration with practice",
      "At the end, notice how you feel compared to before the practice"
    ],
    isPremium: true,
    translations: {
      "it": {
        title: "Meditazione consapevole sul respiro",
        description: "Un'ancora per la mente vagante, questa pratica fondamentale coltiva presenza e consapevolezza.",
        steps: [
          "Trova una posizione comoda, seduto o sdraiato",
          "Chiudi gli occhi o mantieni lo sguardo dolcemente verso il basso",
          "Porta l'attenzione al tuo respiro naturale, senza cercare di modificarlo",
          "Nota le sensazioni di inspirazione ed espirazione nel corpo",
          "Quando la mente vaga (è normale!), riportala gentilmente al respiro",
          "Continua per 5-10 minuti, aumentando gradualmente la durata con la pratica",
          "Alla fine, nota come ti senti rispetto a prima della pratica"
        ]
      }
    }
  },
  {
    id: 9,
    title: "Mindful body scan",
    category: "Mindfulness",
    description: "A journey through the body that cultivates awareness of physical sensations and deep relaxation.",
    steps: [
      "Lie down in a comfortable position, with your arms at your sides",
      "Close your eyes and bring your attention to your breath for a few minutes",
      "Shift your attention to your feet, noticing any sensations present",
      "Slowly move your attention up through the legs, pelvis, abdomen, chest, back, arms, hands, shoulders, neck, and finally the head",
      "For each area, simply notice the sensations without judgment or reaction",
      "If the mind wanders, gently bring it back to the part of the body where you were",
      "At the end, become aware of the body as a single integrated entity"
    ],
    isPremium: true,
    translations: {
      "it": {
        title: "Scansione corporea consapevole",
        description: "Un viaggio attraverso il corpo che coltiva la consapevolezza delle sensazioni fisiche e il rilassamento profondo.",
        steps: [
          "Sdraiati in una posizione comoda, con le braccia lungo i fianchi",
          "Chiudi gli occhi e porta l'attenzione al respiro per alcuni minuti",
          "Sposta l'attenzione ai piedi, notando le sensazioni presenti",
          "Lentamente sposta l'attenzione verso l'alto attraverso gambe, bacino, addome, petto, schiena, braccia, mani, spalle, collo e infine la testa",
          "Per ogni area, semplicemente nota le sensazioni senza giudizio o reazione",
          "Se la mente vaga, riportala gentilmente alla parte del corpo dove eri",
          "Alla fine, diventa consapevole del corpo come un'unica entità integrata"
        ]
      }
    }
  },
  {
    id: 10,
    title: "Mindful eating",
    category: "Mindfulness",
    description: "Transform a daily activity into a meditative practice, cultivating presence and gratitude.",
    steps: [
      "Choose a simple food (e.g., a grape, an almond, a piece of chocolate)",
      "Observe the food as if seeing it for the first time, noticing colors, shapes, textures",
      "Smell the food and notice what sensations arise",
      "Put the food in your mouth but don't chew right away, notice the taste and texture",
      "Chew slowly and mindfully, noticing changes in flavor and consistency",
      "Notice the process of swallowing and the sensations it leaves in the body",
      "Reflect on the entire process and the chain of events that brought this food to you"
    ],
    isPremium: true,
    translations: {
      "it": {
        title: "Mangiare consapevole",
        description: "Trasformare un'attività quotidiana in una pratica meditativa, coltivando presenza e gratitudine.",
        steps: [
          "Scegli un cibo semplice (ad es. un acino d'uva, una mandorla, un pezzo di cioccolato)",
          "Osserva il cibo come se lo vedessi per la prima volta, notando colori, forme, consistenze",
          "Annusa il cibo e nota quali sensazioni sorgono",
          "Metti il cibo in bocca ma non masticare subito, nota il sapore e la consistenza",
          "Mastica lentamente e consapevolmente, notando i cambiamenti nel sapore e nella consistenza",
          "Nota il processo di deglutizione e le sensazioni che lascia nel corpo",
          "Rifletti sull'intero processo e sulla catena di eventi che ha portato questo cibo a te"
        ]
      }
    }
  },
  {
    id: 11,
    title: "Mindful listening",
    category: "Mindfulness",
    description: "Transform the way you listen to others, cultivating authentic connection and presence.",
    steps: [
      "During your next conversation, commit to giving 100% of your attention",
      "Notice the tendency to formulate responses while the other person is still speaking",
      "Practice listening with genuine curiosity, without interruptions",
      "Observe not just the words, but also the tone, expressions, and body language",
      "When the other person has finished, try summarizing before responding, to verify understanding",
      "Notice how this quality of attention affects the conversation",
      "Reflect afterwards on what you've learned from this type of listening"
    ],
    isPremium: false,
    translations: {
      "it": {
        title: "Ascolto consapevole",
        description: "Trasforma il modo in cui ascolti gli altri, coltivando connessione autentica e presenza.",
        steps: [
          "Durante la tua prossima conversazione, impegnati a dare il 100% della tua attenzione",
          "Nota la tendenza a formulare risposte mentre l'altra persona sta ancora parlando",
          "Pratica l'ascolto con genuina curiosità, senza interruzioni",
          "Osserva non solo le parole, ma anche il tono, le espressioni e il linguaggio del corpo",
          "Quando l'altra persona ha finito, prova a riassumere prima di rispondere, per verificare la comprensione",
          "Nota come questa qualità di attenzione influisce sulla conversazione",
          "Rifletti successivamente su ciò che hai imparato da questo tipo di ascolto"
        ]
      }
    }
  },
  {
    id: 12,
    title: "Mindful walking",
    category: "Mindfulness",
    description: "A meditation in motion that transforms an ordinary activity into an opportunity for presence.",
    steps: [
      "Choose a quiet path where you can walk undisturbed for 10-15 minutes",
      "Stand still, feeling the contact of your feet with the ground",
      "Begin walking at a normal pace, then gradually slow down",
      "Bring attention to the physical sensations of walking: the lifting, moving, placing of each foot",
      "When the mind wanders, gently bring it back to the sensations of walking",
      "Expand awareness to the rest of the body in motion, then to the surrounding environment",
      "At the end, notice if something has changed in your mental or physical state"
    ],
    isPremium: true,
    translations: {
      "it": {
        title: "Camminata consapevole",
        description: "Una meditazione in movimento che trasforma un'attività ordinaria in un'opportunità di presenza.",
        steps: [
          "Scegli un percorso tranquillo dove puoi camminare indisturbato per 10-15 minuti",
          "Fermati in piedi, sentendo il contatto dei piedi con il terreno",
          "Inizia a camminare a un ritmo normale, poi rallenta gradualmente",
          "Porta l'attenzione alle sensazioni fisiche del camminare: il sollevare, muovere, appoggiare di ogni piede",
          "Quando la mente vaga, riportala gentilmente alle sensazioni del camminare",
          "Espandi la consapevolezza al resto del corpo in movimento, poi all'ambiente circostante",
          "Alla fine, nota se qualcosa è cambiato nel tuo stato mentale o fisico"
        ]
      }
    }
  },
  {
    id: 13,
    title: "STOP: one-minute mindfulness practice",
    category: "Mindfulness",
    description: "A brief mindfulness intervention for moments of stress or autopilot.",
    steps: [
      "S - Stop: interrupt whatever you are doing",
      "T - Take a breath: take a deep, conscious breath",
      "O - Observe: notice what is happening in your body, mind, and emotions",
      "P - Proceed: continue with greater awareness and intention",
      "Practice this exercise several times throughout the day, especially during moments of stress",
      "You can use reminders such as phone notifications or visible post-its",
      "Notice how even a brief pause can change the quality of your experience"
    ],
    isPremium: false,
    translations: {
      "it": {
        title: "STOP: pratica di consapevolezza in un minuto",
        description: "Un breve intervento mindfulness per momenti di stress o autopilota.",
        steps: [
          "S - Stop: interrompi qualsiasi cosa stai facendo",
          "T - Take a breath: prendi un respiro profondo e consapevole",
          "O - Observe: osserva cosa sta accadendo nel tuo corpo, mente ed emozioni",
          "P - Proceed: procedi con maggiore consapevolezza e intenzione",
          "Pratica questo esercizio più volte durante il giorno, specialmente nei momenti di stress",
          "Puoi usare promemoria come notifiche sul telefono o post-it visibili",
          "Nota come anche una breve pausa può cambiare la qualità della tua esperienza"
        ]
      },
      "es": {
        title: "STOP: práctica de atención plena en un minuto",
        description: "Una breve intervención de mindfulness para momentos de estrés o piloto automático.",
        steps: [
          "S - Stop (Detente): interrumpe lo que estés haciendo",
          "T - Take a breath (Respira): toma una respiración profunda y consciente",
          "O - Observe (Observa): nota lo que está sucediendo en tu cuerpo, mente y emociones",
          "P - Proceed (Procede): continúa con mayor conciencia e intención",
          "Practica este ejercicio varias veces a lo largo del día, especialmente durante momentos de estrés",
          "Puedes usar recordatorios como notificaciones del teléfono o post-its visibles",
          "Nota cómo incluso una breve pausa puede cambiar la calidad de tu experiencia"
        ]
      },
      "fr": {
        title: "STOP : pratique de pleine conscience en une minute",
        description: "Une brève intervention de pleine conscience pour les moments de stress ou de pilote automatique.",
        steps: [
          "S - Stop (Arrêtez) : interrompez ce que vous êtes en train de faire",
          "T - Take a breath (Respirez) : prenez une respiration profonde et consciente",
          "O - Observe (Observez) : remarquez ce qui se passe dans votre corps, votre esprit et vos émotions",
          "P - Proceed (Poursuivez) : continuez avec une plus grande conscience et intention",
          "Pratiquez cet exercice plusieurs fois tout au long de la journée, en particulier pendant les moments de stress",
          "Vous pouvez utiliser des rappels comme des notifications de téléphone ou des post-its visibles",
          "Remarquez comment même une brève pause peut changer la qualité de votre expérience"
        ]
      },
      "de": {
        title: "STOP: Eine-Minute-Achtsamkeitsübung",
        description: "Eine kurze Achtsamkeitsintervention für Momente von Stress oder Autopilot.",
        steps: [
          "S - Stop (Anhalten): Unterbrechen Sie, was auch immer Sie gerade tun",
          "T - Take a breath (Atmen): Nehmen Sie einen tiefen, bewussten Atemzug",
          "O - Observe (Beobachten): Bemerken Sie, was in Ihrem Körper, Geist und Ihren Emotionen geschieht",
          "P - Proceed (Fortfahren): Fahren Sie mit größerem Bewusstsein und Absicht fort",
          "Üben Sie diese Übung mehrmals im Laufe des Tages, besonders in Momenten von Stress",
          "Sie können Erinnerungen wie Telefonbenachrichtigungen oder sichtbare Post-its verwenden",
          "Bemerken Sie, wie selbst eine kurze Pause die Qualität Ihrer Erfahrung ändern kann"
        ]
      }
    }
  },
  {
    id: 14,
    title: "Loving-kindness practice",
    category: "Mindfulness",
    description: "A meditation that cultivates compassion for oneself and others, transforming relationships.",
    steps: [
      "Find a comfortable position and relax your body with a few deep breaths",
      "Begin by bringing to mind a person you easily and deeply love",
      "Silently offer phrases of well-being such as: 'May you be happy, May you be safe, May you be healthy'",
      "Gradually, extend these phrases toward yourself with the same sincerity",
      "Then toward a neutral person, someone toward whom you have mixed feelings, and finally toward all beings",
      "Notice any resistance without judgment, especially when directing the phrases toward yourself",
      "At the end, rest in the feeling of connection and benevolence created by the practice"
    ],
    isPremium: true,
    translations: {
      "it": {
        title: "Pratica dell'amorevole gentilezza",
        description: "Una meditazione che coltiva la compassione per sé stessi e gli altri, trasformando le relazioni.",
        steps: [
          "Trova una posizione comoda e rilassa il tuo corpo con alcuni respiri profondi",
          "Inizia richiamando alla mente una persona che ami facilmente e profondamente",
          "Offri silenziosamente frasi di benessere come: 'Che tu possa essere felice, che tu possa essere al sicuro, che tu possa essere in salute'",
          "Gradualmente, estendi queste frasi verso te stesso con la stessa sincerità",
          "Poi verso una persona neutrale, qualcuno verso cui hai sentimenti contrastanti, e infine verso tutti gli esseri",
          "Nota qualsiasi resistenza senza giudizio, specialmente quando dirigi le frasi verso te stesso",
          "Alla fine, riposa nella sensazione di connessione e benevolenza creata dalla pratica"
        ]
      }
    }
  },
  
  // Wellness Exercises
  {
    id: 15,
    title: "Gratitude journal",
    category: "Wellness",
    description: "A simple but powerful practice that shifts attention toward what is going well in life.",
    steps: [
      "Each evening, before going to sleep, write down 3-5 things you are grateful for today",
      "Be specific: not just 'my family', but a particular moment or gesture",
      "Include small and simple things that might easily go unnoticed",
      "Explore why you are grateful for each item",
      "Notice the sensations in your body as you reflect on these elements of gratitude",
      "Regularly review your past entries, especially during difficult times",
      "After a few weeks, reflect on how this practice influences your perspective"
    ],
    isPremium: false,
    translations: {
      "it": {
        title: "Diario della gratitudine",
        description: "Una pratica semplice ma potente che sposta l'attenzione verso ciò che va bene nella vita.",
        steps: [
          "Ogni sera, prima di dormire, scrivi 3-5 cose per cui sei grato oggi",
          "Sii specifico: non solo 'la mia famiglia', ma un momento o gesto particolare",
          "Include cose piccole e semplici che potrebbero facilmente passare inosservate",
          "Approfondisci perché sei grato per ciascun elemento",
          "Nota le sensazioni nel corpo mentre rifletti su questi elementi di gratitudine",
          "Rivedi regolarmente le tue annotazioni passate, specialmente nei momenti difficili",
          "Dopo alcune settimane, rifletti su come questa pratica influenzi la tua prospettiva"
        ]
      },
      "es": {
        title: "Diario de gratitud",
        description: "Una práctica simple pero poderosa que dirige la atención hacia lo que va bien en la vida.",
        steps: [
          "Cada noche, antes de dormir, escribe 3-5 cosas por las que estás agradecido hoy",
          "Sé específico: no solo 'mi familia', sino un momento o gesto particular",
          "Incluye cosas pequeñas y simples que podrían pasar fácilmente desapercibidas",
          "Explora por qué estás agradecido por cada elemento",
          "Nota las sensaciones en tu cuerpo mientras reflexionas sobre estos elementos de gratitud",
          "Revisa regularmente tus anotaciones pasadas, especialmente en momentos difíciles",
          "Después de algunas semanas, reflexiona sobre cómo esta práctica influye en tu perspectiva"
        ]
      },
      "fr": {
        title: "Journal de gratitude",
        description: "Une pratique simple mais puissante qui déplace l'attention vers ce qui va bien dans la vie.",
        steps: [
          "Chaque soir, avant de dormir, écrivez 3 à 5 choses pour lesquelles vous êtes reconnaissant aujourd'hui",
          "Soyez spécifique : pas seulement 'ma famille', mais un moment ou un geste particulier",
          "Incluez des choses petites et simples qui pourraient facilement passer inaperçues",
          "Explorez pourquoi vous êtes reconnaissant pour chaque élément",
          "Remarquez les sensations dans votre corps pendant que vous réfléchissez à ces éléments de gratitude",
          "Relisez régulièrement vos notes passées, surtout dans les moments difficiles",
          "Après quelques semaines, réfléchissez à la façon dont cette pratique influence votre perspective"
        ]
      },
      "de": {
        title: "Dankbarkeitstagebuch",
        description: "Eine einfache, aber kraftvolle Übung, die die Aufmerksamkeit auf das lenkt, was im Leben gut läuft.",
        steps: [
          "Schreiben Sie jeden Abend vor dem Schlafengehen 3-5 Dinge auf, für die Sie heute dankbar sind",
          "Seien Sie spezifisch: nicht nur 'meine Familie', sondern ein bestimmter Moment oder eine Geste",
          "Schließen Sie kleine und einfache Dinge ein, die leicht übersehen werden könnten",
          "Erforschen Sie, warum Sie für jedes Element dankbar sind",
          "Beachten Sie die Empfindungen in Ihrem Körper, während Sie über diese Elemente der Dankbarkeit nachdenken",
          "Lesen Sie regelmäßig Ihre vergangenen Einträge, besonders in schwierigen Zeiten",
          "Reflektieren Sie nach einigen Wochen, wie diese Praxis Ihre Perspektive beeinflusst"
        ]
      }
    }
  },
  {
    id: 16,
    title: "Personalized self-care plan",
    category: "Wellness",
    description: "Intentional strategy for integrating rejuvenating activities into daily routine.",
    steps: [
      "List activities that nurture your well-being in different areas: physical, emotional, mental, social, spiritual",
      "Identify activities that require different time commitments: 5 minutes, 30 minutes, an hour or more",
      "Create a weekly plan integrating these activities into your routine",
      "Set reminders or 'appointments with yourself' for these activities",
      "At the end of each week, reflect: did you stick to the plan? How do you feel?",
      "Adjust the plan based on your discoveries, keeping it realistic and sustainable",
      "Remember that consistency is more important than intensity or duration"
    ],
    isPremium: false,
    translations: {
      "it": {
        title: "Piano di auto-cura personalizzato",
        description: "Strategia intenzionale per integrare attività rigeneranti nella routine quotidiana.",
        steps: [
          "Elenca attività che nutrono il tuo benessere in diverse aree: fisica, emotiva, mentale, sociale, spirituale",
          "Identifica attività che richiedono diversi impegni di tempo: 5 minuti, 30 minuti, un'ora o più",
          "Crea un piano settimanale integrando queste attività nella tua routine",
          "Imposta promemoria o 'appuntamenti con te stesso' per queste attività",
          "Alla fine di ogni settimana, rifletti: hai rispettato il piano? Come ti senti?",
          "Adatta il piano in base alle tue scoperte, mantenendolo realistico e sostenibile",
          "Ricorda che la costanza è più importante dell'intensità o della durata"
        ]
      }
    }
  },
  {
    id: 17,
    title: "Mindful pleasant activities",
    category: "Wellness",
    description: "Rediscovery of pleasure in daily activities, countering anhedonia and autopilot.",
    steps: [
      "Create a list of activities that gave you pleasure in the past, even if they now seem less appealing",
      "Choose an activity from the list and dedicate time to it without distractions (no multitasking)",
      "During the activity, use your senses to fully immerse yourself in the experience",
      "Notice when your mind wanders toward worries or evaluations, and gently bring it back to the direct experience",
      "After the activity, reflect: what did you notice that usually escapes you?",
      "Regularly schedule these mindful activities in your week",
      "Gradually, you'll notice an increased ability to experience pleasure and engagement"
    ],
    isPremium: true,
    translations: {
      "it": {
        title: "Attività piacevoli consapevoli",
        description: "Riscoperta del piacere nelle attività quotidiane, contrastando l'anedonia e il pilota automatico.",
        steps: [
          "Crea una lista di attività che ti davano piacere in passato, anche se ora sembrano meno attraenti",
          "Scegli un'attività dalla lista e dedicale tempo senza distrazioni (niente multitasking)",
          "Durante l'attività, usa i tuoi sensi per immergerti completamente nell'esperienza",
          "Nota quando la tua mente vaga verso preoccupazioni o valutazioni, e riportala gentilmente all'esperienza diretta",
          "Dopo l'attività, rifletti: cosa hai notato che di solito ti sfugge?",
          "Programma regolarmente queste attività consapevoli nella tua settimana",
          "Gradualmente, noterai una maggiore capacità di sperimentare piacere e coinvolgimento"
        ]
      }
    }
  },
  {
    id: 18,
    title: "Intentional social connections",
    category: "Wellness",
    description: "Strategy for cultivating meaningful relationships, a fundamental pillar of psychological well-being.",
    steps: [
      "Identify relationships that make you feel supported, understood, and recharged",
      "Plan regular meetings with these people, marking them on your calendar as important appointments",
      "During meetings, practice total presence (limiting distractions like your phone)",
      "Experiment with questions deeper than the usual 'How are you?'",
      "Every day, make a small gesture of connection (a message, a brief call)",
      "Try to balance giving and receiving in your relationships",
      "Regularly reflect on how your social connections affect your well-being"
    ],
    isPremium: false,
    translations: {
      "it": {
        title: "Connessioni sociali intenzionali",
        description: "Strategia per coltivare relazioni significative, un pilastro fondamentale del benessere psicologico.",
        steps: [
          "Identifica le relazioni che ti fanno sentire supportato, compreso e ricaricato",
          "Pianifica incontri regolari con queste persone, segnandoli sul tuo calendario come appuntamenti importanti",
          "Durante gli incontri, pratica la presenza totale (limitando distrazioni come il tuo telefono)",
          "Sperimenta domande più profonde del solito 'Come stai?'",
          "Ogni giorno, fai un piccolo gesto di connessione (un messaggio, una breve chiamata)",
          "Cerca di bilanciare il dare e il ricevere nelle tue relazioni",
          "Rifletti regolarmente su come le tue connessioni sociali influenzano il tuo benessere"
        ]
      }
    }
  }
];

// Helper function to get translated exercise data
export function getTranslatedExercise(exercise: ExerciseWithTranslations, language: string = 'en'): Exercise {
  // Per gli esercizi, i dati originali sono in inglese e le traduzioni sono in altre lingue
  
  // Se non ci sono traduzioni o se la lingua richiesta è inglese, restituisci i dati originali
  if (!exercise.translations || language === 'en') {
    return exercise;
  }
  
  // Se arriviamo qui, si tratta di una richiesta per una lingua diversa dall'inglese
  // Verifica se abbiamo la traduzione per la lingua richiesta
  if (exercise.translations[language]) {
    const translation = exercise.translations[language];
    return {
      ...exercise,
      title: translation.title,
      description: translation.description,
      steps: translation.steps
    };
  }
  
  // Fallback ai dati originali (inglese) se la traduzione richiesta non è disponibile
  return exercise;
}

export function getExerciseById(id: number, language: string = 'en'): Exercise | undefined {
  const exercise = exercises.find(ex => ex.id === id);
  if (!exercise) return undefined;
  
  return getTranslatedExercise(exercise, language);
}

export function getExercisesByCategory(category: string, language: string = 'en'): Exercise[] {
  return exercises
    .filter(ex => ex.category === category)
    .map(ex => getTranslatedExercise(ex, language));
}

export function getAllExercises(language: string = 'en'): Exercise[] {
  return exercises.map(ex => getTranslatedExercise(ex, language));
}

export function getFreeExercises(language: string = 'en'): Exercise[] {
  return exercises
    .filter(ex => !ex.isPremium)
    .map(ex => getTranslatedExercise(ex, language));
}

export function getPremiumExercises(language: string = 'en'): Exercise[] {
  return exercises
    .filter(ex => ex.isPremium)
    .map(ex => getTranslatedExercise(ex, language));
}