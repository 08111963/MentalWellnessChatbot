import express, { type Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  generateChatResponse, 
  generateReflection, 
  analyzeUserMessage,
  generateAIModuleResponse
} from "./openai";
import { domainAuthMiddleware } from "./multiPlatform";
import {
  getAllResourcesHandler,
  getResourceByIdHandler,
  getResourcesByCategoryHandler,
  getResourcesByTagsHandler,
  getPersonalizedResourcesHandler,
  getRecommendationsByMessageHandler,
  getAllCategoriesHandler
} from "./controllers/resource-controller";
import { 
  getPromptByIntent 
} from "./cbt-prompts";
import {
  createCheckoutSession,
  handleStripeWebhook,
  redirectToSubscription,
  verifySession
} from "./stripe";
import { 
  getAllMeditations, 
  getMeditationById,
  getFreeMeditations,
  getPremiumMeditations
} from "./meditation-data-fixed";
import { 
  getAllExercises, 
  getExerciseById, 
  getExercisesByCategory,
  getFreeExercises,
  getPremiumExercises
} from "./exercises-data-fixed";
import { 
  getAllReflections, 
  getReflectionById, 
  getRandomReflection,
  getReflectionsByCategory,
  getFreeReflections,
  getPremiumReflections
} from "./reflections-data";
import { z } from "zod";
import { insertUserSchema } from "@shared/schema";
import {
  getMoodEntriesByUserId,
  getMoodEntryById,
  createMoodEntry,
  updateMoodEntry,
  deleteMoodEntry,
  getMoodStatsByUserId,
  seedMoodData
} from "./mood-data";
import {
  getAllQuotes,
  getQuoteById,
  getRandomQuote,
  getRandomQuoteByCategory,
  getQuotesByCategory,
  quoteCategories
} from "./quotes-data";

interface ChatMessage {
  content: string;
  role: string;
}

// In-memory message history
const chatHistory: Record<string, ChatMessage[]> = {};

export async function registerRoutes(app: Express): Promise<Server> {
  // Aggiungi middleware per verifica domini nelle route sensibili
  const paymentRoutes = [
    '/api/stripe/checkout',
    '/api/stripe/redirect',
    '/api/stripe/webhook',
    '/api/stripe/verify-session',
    '/api/auth/user'
  ];
  
  // Applica middleware solo sulle route sensibili in produzione
  if (process.env.NODE_ENV === 'production') {
    paymentRoutes.forEach(route => {
      app.use(route, domainAuthMiddleware);
    });
  }
  // Chat API
  app.post('/api/chat', async (req, res) => {
    try {
      const { message, sessionId, language } = req.body;
      
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: 'Messaggio non valido' });
      }
      
      const sessionKey = sessionId || 'default';
      const userLanguage = language || 'it'; // Default to Italian if not specified
      
      console.log(`Chat request with language: ${userLanguage}`);
      
      // Check if this is an AI module request
      const isAIModule = sessionKey.startsWith('ai-module-');
      let responseText = '';
      
      if (isAIModule) {
        // Extract module type from session ID (ai-module-relationships, ai-module-writing, etc.)
        const moduleType = sessionKey.replace('ai-module-', '') as 'relationships' | 'writing' | 'relaxation' | 'sleep';
        
        // Generate AI module specific response with language
        responseText = await generateAIModuleResponse(message, moduleType, userLanguage);
        
        // Return the AI module response without analysis
        return res.json({
          message: responseText
        });
      } else {
        // Normal chat flow
        // Initialize chat history if it doesn't exist
        if (!chatHistory[sessionKey]) {
          chatHistory[sessionKey] = [];
        }
        
        // Add user message to history
        chatHistory[sessionKey].push({
          role: 'user',
          content: message
        });
        
        // Analyze user message to determine intent with language
        const analysis = await analyzeUserMessage(message, userLanguage);
        
        // Get appropriate system prompt based on intent and language
        const systemPrompt = getPromptByIntent(analysis.intent, userLanguage);
        
        // Generate response
        responseText = await generateChatResponse(
          chatHistory[sessionKey].slice(-6), // Use last 6 messages for context
          systemPrompt,
          userLanguage
        );
        
        // Add assistant response to history
        chatHistory[sessionKey].push({
          role: 'assistant',
          content: responseText
        });
        
        // Return response with analysis
        return res.json({
          message: responseText,
          analysis
        });
      }
    } catch (error) {
      console.error('Chat API error:', error);
      res.status(500).json({ error: 'Errore del server' });
    }
  });
  
  // Get chat history
  app.get('/api/chat/history', (req, res) => {
    const sessionId = req.query.sessionId as string || 'default';
    res.json(chatHistory[sessionId] || []);
  });
  
  // Meditation routes
  app.get('/api/meditations', (req, res) => {
    const isPremium = req.query.premium === 'true';
    const onlyFree = req.query.free === 'true';
    const language = (req.query.language || 'en') as string;
    
    if (isPremium) {
      res.json(getPremiumMeditations(language));
    } else if (onlyFree) {
      res.json(getFreeMeditations(language));
    } else {
      res.json(getAllMeditations(language));
    }
  });
  
  app.get('/api/meditations/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const language = (req.query.language || 'en') as string;
    
    if (isNaN(id)) {
      return res.status(400).json({ error: 'Invalid ID' });
    }
    
    const meditation = getMeditationById(id, language);
    if (!meditation) {
      return res.status(404).json({ error: 'Meditation not found' });
    }
    
    res.json(meditation);
  });
  
  // Exercise routes
  app.get('/api/exercises', (req, res) => {
    const category = req.query.category as string;
    const isPremium = req.query.premium === 'true';
    const onlyFree = req.query.free === 'true';
    const language = (req.query.language || 'en') as string;
    
    if (isPremium) {
      const exercises = category 
        ? getPremiumExercises(language).filter(ex => ex.category === category) 
        : getPremiumExercises(language);
      res.json(exercises);
    } else if (onlyFree) {
      const exercises = category 
        ? getFreeExercises(language).filter(ex => ex.category === category) 
        : getFreeExercises(language);
      res.json(exercises);
    } else if (category) {
      res.json(getExercisesByCategory(category, language));
    } else {
      res.json(getAllExercises(language));
    }
  });
  
  app.get('/api/exercises/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const language = (req.query.language || 'en') as string;
    
    if (isNaN(id)) {
      return res.status(400).json({ error: 'Invalid ID' });
    }
    
    const exercise = getExerciseById(id, language);
    if (!exercise) {
      return res.status(404).json({ error: 'Exercise not found' });
    }
    
    res.json(exercise);
  });
  
  // Reflection routes
  app.get('/api/reflections', (req, res) => {
    const category = req.query.category as string;
    const isPremium = req.query.premium === 'true';
    const onlyFree = req.query.free === 'true';
    const showAll = req.query.showAll === 'true';
    
    if (showAll) {
      // Mostra tutte le riflessioni, sia premium che gratuite
      res.json(getAllReflections(true));
    } else if (isPremium) {
      res.json(getPremiumReflections());
    } else if (onlyFree) {
      res.json(getFreeReflections());
    } else if (category) {
      res.json(getReflectionsByCategory(category, isPremium));
    } else {
      res.json(getAllReflections(isPremium));
    }
  });
  
  app.get('/api/reflections/random', (req, res) => {
    const isPremium = req.query.premium === 'true';
    res.json(getRandomReflection(isPremium));
  });
  
  app.get('/api/reflections/:id', (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: 'Invalid ID' });
    }
    
    const reflection = getReflectionById(id);
    if (!reflection) {
      return res.status(404).json({ error: 'Reflection not found' });
    }
    
    res.json(reflection);
  });
  
  // Generate a new reflection based on a theme
  app.post('/api/reflections/generate', async (req, res) => {
    try {
      const { theme, previousReflections } = req.body;
      
      if (!theme || typeof theme !== 'string') {
        return res.status(400).json({ error: 'Tema non valido' });
      }
      
      const generatedReflection = await generateReflection(theme, previousReflections || []);
      res.json(generatedReflection);
    } catch (error) {
      console.error('Reflection generation error:', error);
      res.status(500).json({ error: 'Errore del server' });
    }
  });

  // Quotes routes
  app.get('/api/quotes', (req, res) => {
    const category = req.query.category as string;
    
    if (category) {
      res.json(getQuotesByCategory(category));
    } else {
      res.json(getAllQuotes());
    }
  });
  
  app.get('/api/quotes/categories', (req, res) => {
    res.json(quoteCategories);
  });
  
  app.get('/api/quotes/random', (req, res) => {
    const category = req.query.category as string;
    
    if (category) {
      const quote = getRandomQuoteByCategory(category);
      if (!quote) {
        return res.status(404).json({ error: 'Nessuna citazione trovata per questa categoria' });
      }
      res.json(quote);
    } else {
      res.json(getRandomQuote());
    }
  });
  
  app.get('/api/quotes/daily', (req, res) => {
    // Ottenere le preferenze dell'utente dalle query parameters
    const preferredCategories = req.query.categories ? (req.query.categories as string).split(',') : [];
    const mood = req.query.mood as string || '';
    const language = req.query.language as string || 'it'; // Default a italiano se non specificato
    
    // Per generare una citazione "giornaliera", usiamo la data corrente come seed
    // In questo modo, la stessa citazione sarà mostrata per tutto il giorno
    const today = new Date();
    const startOfYear = new Date(today.getFullYear(), 0, 0);
    const diff = (today.getTime() - startOfYear.getTime());
    const oneDay = 1000 * 60 * 60 * 24;
    const dayOfYear = Math.floor(diff / oneDay);
    
    // Otteniamo le citazioni filtrate se ci sono preferenze
    let filteredQuotes = getAllQuotes();
    
    // Se ci sono categorie preferite, filtriamo le citazioni
    if (preferredCategories.length > 0) {
      filteredQuotes = filteredQuotes.filter(quote => 
        quote.categories.some(category => preferredCategories.includes(category))
      );
    }
    
    // Se è specificato un mood, adattiamo la selezione
    if (mood) {
      // Mappa dello stato d'animo alle categorie suggerite
      const moodToCategories: Record<string, string[]> = {
        'happy': ['happiness', 'gratitude'],
        'sad': ['motivation', 'resilience'],
        'anxious': ['peace', 'mindfulness'],
        'stressed': ['mindfulness', 'peace'],
        'neutral': ['growth', 'mindfulness'],
        'motivated': ['motivation', 'growth', 'courage']
      };
      
      // Ottieni le categorie suggerite per il mood
      const suggestedCategories = moodToCategories[mood] || [];
      
      // Se abbiamo categorie suggerite e non avevamo filtrato per categorie preferite
      if (suggestedCategories.length > 0 && preferredCategories.length === 0) {
        // Cerca citazioni che appartengono alle categorie suggerite
        const moodQuotes = filteredQuotes.filter(quote =>
          quote.categories.some(category => suggestedCategories.includes(category))
        );
        
        // Se abbiamo trovato citazioni per il mood, usiamo quelle
        if (moodQuotes.length > 0) {
          filteredQuotes = moodQuotes;
        }
      }
    }
    
    // Se non ci sono citazioni che soddisfano i filtri, usiamo tutte le citazioni
    if (filteredQuotes.length === 0) {
      filteredQuotes = getAllQuotes();
    }
    
    // Usiamo il giorno dell'anno come seed per la selezione, con modulo per evitare overflow
    const seedIndex = dayOfYear % filteredQuotes.length;
    let quote = filteredQuotes[seedIndex];
    
    // Applica la localizzazione alla citazione se richiesto
    if (language !== 'it' && quote.translations && quote.translations[language]) {
      // Crea una copia della citazione con il testo tradotto
      quote = {
        ...quote,
        text: quote.translations[language].text
      };
    }
    
    // Applica la localizzazione alle categorie
    if (language !== 'it') {
      // Creiamo un oggetto per le categorie localizzate, senza cambiare il tipo Quote
      const localizedCategoryNames: Record<string, string> = {};
      
      // Popola l'oggetto con le traduzioni
      quote.categories.forEach(categoryId => {
        const category = quoteCategories.find(c => c.id === categoryId);
        if (category && category.translations && category.translations[language]) {
          localizedCategoryNames[categoryId] = category.translations[language];
        } else {
          localizedCategoryNames[categoryId] = category ? category.name : categoryId;
        }
      });
      
      // Aggiungi le traduzioni delle categorie alla risposta come proprietà separata
      (quote as any).localizedCategoryNames = localizedCategoryNames;
    }
    
    res.json(quote);
  });
  
  app.get('/api/quotes/:id', (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID non valido' });
    }
    
    const quote = getQuoteById(id);
    if (!quote) {
      return res.status(404).json({ error: 'Citazione non trovata' });
    }
    
    res.json(quote);
  });

  // Mood tracking routes
  // Inizializza alcuni dati di esempio (in un ambiente reale, questo sarebbe rimosso)
  seedMoodData(1);

  // Ottieni tutte le entry di umore per un utente
  app.get('/api/mood', (req, res) => {
    const userId = parseInt(req.query.userId as string || '1');
    res.json(getMoodEntriesByUserId(userId));
  });

  // Ottieni una entry specifica
  app.get('/api/mood/:id', (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID non valido' });
    }
    
    const entry = getMoodEntryById(id);
    if (!entry) {
      return res.status(404).json({ error: 'Registrazione non trovata' });
    }
    
    res.json(entry);
  });

  // Crea una nuova registrazione dell'umore
  app.post('/api/mood', (req, res) => {
    try {
      const moodEntry = req.body;
      
      // Validazione base (in produzione useremmo zod)
      if (!moodEntry || typeof moodEntry.score !== 'number' || moodEntry.score < 1 || moodEntry.score > 5) {
        return res.status(400).json({ error: 'Dati umore non validi. Il punteggio deve essere compreso tra 1 e 5.' });
      }
      
      const newEntry = createMoodEntry({
        ...moodEntry,
        userId: moodEntry.userId || 1 // Default userId
      });
      
      res.status(201).json(newEntry);
    } catch (error) {
      console.error('Errore creazione entry umore:', error);
      res.status(500).json({ error: 'Errore del server' });
    }
  });

  // Aggiorna una registrazione dell'umore
  app.put('/api/mood/:id', (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'ID non valido' });
      }
      
      const moodEntry = req.body;
      const updatedEntry = updateMoodEntry(id, moodEntry);
      
      if (!updatedEntry) {
        return res.status(404).json({ error: 'Registrazione non trovata' });
      }
      
      res.json(updatedEntry);
    } catch (error) {
      console.error('Errore aggiornamento entry umore:', error);
      res.status(500).json({ error: 'Errore del server' });
    }
  });

  // Elimina una registrazione dell'umore
  app.delete('/api/mood/:id', (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'ID non valido' });
      }
      
      const success = deleteMoodEntry(id);
      
      if (!success) {
        return res.status(404).json({ error: 'Registrazione non trovata' });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error('Errore eliminazione entry umore:', error);
      res.status(500).json({ error: 'Errore del server' });
    }
  });

  // Statistiche umore
  app.get('/api/mood/stats/user/:userId', (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ error: 'ID utente non valido' });
      }
      
      // Filtri opzionali per intervallo di date
      const dateFrom = req.query.dateFrom ? new Date(req.query.dateFrom as string) : undefined;
      const dateTo = req.query.dateTo ? new Date(req.query.dateTo as string) : undefined;
      
      const stats = getMoodStatsByUserId(userId, dateFrom, dateTo);
      res.json(stats);
    } catch (error) {
      console.error('Errore statistiche umore:', error);
      res.status(500).json({ error: 'Errore del server' });
    }
  });
  
  // Rotte per le risorse raccomandate
  // IMPORTANTE: Ordine di definizione delle route - le più specifiche vanno prima
  
  // Ottieni risorse per categoria
  app.get('/api/resources/category/:category', getResourcesByCategoryHandler);
  
  // Ottieni tutte le categorie disponibili
  app.get('/api/resources/categories', getAllCategoriesHandler);
  
  // Ottieni risorse per tags (POST perché inviamo un array di tag)
  app.post('/api/resources/tags', getResourcesByTagsHandler);
  
  // Ottieni risorse personalizzate
  app.post('/api/resources/personalized', getPersonalizedResourcesHandler);
  
  // Ottieni raccomandazioni in base a un messaggio dell'utente
  app.post('/api/resources/recommend', getRecommendationsByMessageHandler);
  
  // Ottieni tutte le risorse
  app.get('/api/resources', getAllResourcesHandler);
  
  // Ottieni una risorsa per ID
  app.get('/api/resources/:id', getResourceByIdHandler);
  
  // Endpoint per le richieste di supporto
  app.post('/api/support', async (req: Request, res: Response) => {
    try {
      const { name, email, subject, message } = req.body;
      
      if (!name || !email || !subject || !message) {
        return res.status(400).json({ 
          success: false, 
          error: 'Tutti i campi sono obbligatori' 
        });
      }
      
      // In un'implementazione reale, qui potresti:
      // 1. Salvare la richiesta in un database
      // 2. Inviare un'email al team di supporto
      // 3. Inviare un'email di conferma all'utente
      
      // Log della richiesta per scopi di debug
      console.log(`[support-request] Nuova richiesta da ${name} (${email}): ${subject}`);
      
      // Simulazione di un ritardo di elaborazione
      await new Promise(resolve => setTimeout(resolve, 500));
      
      return res.status(200).json({
        success: true,
        message: 'Richiesta di supporto ricevuta con successo'
      });
    } catch (error) {
      console.error('[support-request] Errore:', error);
      return res.status(500).json({
        success: false,
        error: 'Errore durante l\'elaborazione della richiesta'
      });
    }
  });

  // User Authentication Routes
  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      // Validazione dati
      const userSchema = insertUserSchema.extend({
        password: z.string().min(6, "La password deve essere di almeno 6 caratteri"),
        email: z.string().email("Email non valida").optional()
      });
      
      const validationResult = userSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: 'Dati non validi', 
          details: validationResult.error.format() 
        });
      }
      
      // Verifica prima se l'utente esiste già
      const existingUser = await storage.getUserByUsername(validationResult.data.username);
      if (existingUser) {
        console.log(`Tentativo di registrazione con username già esistente: ${validationResult.data.username}`);
        return res.status(409).json({ error: 'Username già in uso' });
      }
      
      // Crea utente
      const user = await storage.createUser(validationResult.data);
      
      // Ritorna solo informazioni sicure (senza password)
      const safeUser = {
        id: user.id,
        username: user.username,
        isPremium: user.isPremium,
        subscriptionPlan: user.subscriptionPlan,
        subscriptionEnd: user.subscriptionEnd
      };
      
      res.status(201).json({
        success: true,
        user: safeUser,
        message: "Registrazione completata con successo"
      });
    } catch (error) {
      console.error('Errore registrazione:', error);
      if (error instanceof Error && error.message === 'Utente già esistente') {
        return res.status(409).json({ error: 'Username già in uso' });
      }
      res.status(500).json({ error: 'Errore di registrazione' });
    }
  });
  
  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: 'Username e password richiesti' });
      }
      
      // Autentica l'utente
      const user = await storage.authenticateUser(username, password);
      
      if (!user) {
        return res.status(401).json({ error: 'Credenziali non valide' });
      }
      
      // Ritorna solo informazioni sicure (senza password)
      const safeUser = {
        id: user.id,
        username: user.username,
        isPremium: user.isPremium,
        subscriptionPlan: user.subscriptionPlan,
        subscriptionEnd: user.subscriptionEnd
      };
      
      res.json({
        success: true,
        user: safeUser,
        message: "Login effettuato con successo"
      });
    } catch (error) {
      console.error('Errore login:', error);
      res.status(500).json({ error: 'Errore di autenticazione' });
    }
  });
  
  app.get('/api/auth/user/:id', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      
      if (isNaN(userId)) {
        return res.status(400).json({ error: 'ID non valido' });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: 'Utente non trovato' });
      }
      
      // Ritorna solo informazioni sicure (senza password)
      const safeUser = {
        id: user.id,
        username: user.username,
        isPremium: user.isPremium,
        subscriptionPlan: user.subscriptionPlan,
        subscriptionEnd: user.subscriptionEnd,
        subscriptionStart: user.subscriptionStart,
        stripeCustomerId: user.stripeCustomerId,
        stripeSubscriptionId: user.stripeSubscriptionId,
        subscriptionStatus: user.subscriptionStatus
      };
      
      res.json({
        success: true,
        user: safeUser
      });
    } catch (error) {
      console.error('Errore recupero utente:', error);
      res.status(500).json({ error: 'Errore del server' });
    }
  });
  
  // Endpoint per la cancellazione dell'abbonamento
  app.post('/api/auth/user/:id/cancel-subscription', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      
      if (isNaN(userId)) {
        return res.status(400).json({ error: 'ID utente non valido' });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: 'Utente non trovato' });
      }
      
      // Utilizza il metodo centralizzato per cancellare l'abbonamento (sia simulato che reale)
      const { cancelSubscription } = await import('./stripe');
      const success = await cancelSubscription(userId, user.stripeSubscriptionId);
      
      if (!success) {
        return res.status(500).json({ error: 'Errore durante la cancellazione dell\'abbonamento' });
      }
      
      // Recupera l'utente aggiornato dopo la cancellazione
      const updatedUser = await storage.getUser(userId);
      
      if (!updatedUser) {
        return res.status(500).json({ error: 'Impossibile aggiornare l\'utente' });
      }
      
      // Ritorna solo informazioni sicure (senza password)
      const safeUser = {
        id: updatedUser.id,
        username: updatedUser.username,
        isPremium: updatedUser.isPremium,
        subscriptionPlan: updatedUser.subscriptionPlan,
        subscriptionEnd: updatedUser.subscriptionEnd,
        subscriptionStart: updatedUser.subscriptionStart,
        stripeCustomerId: updatedUser.stripeCustomerId,
        stripeSubscriptionId: updatedUser.stripeSubscriptionId,
        subscriptionStatus: updatedUser.subscriptionStatus
      };
      
      console.log('Abbonamento cancellato per l\'utente:', safeUser);
      
      res.json({ 
        success: true, 
        message: 'Abbonamento cancellato con successo',
        user: safeUser 
      });
    } catch (error) {
      console.error('Errore nella cancellazione dell\'abbonamento:', error);
      res.status(500).json({ error: 'Errore del server durante la cancellazione dell\'abbonamento' });
    }
  });
  
  // Stripe payment routes - integrazione con il sistema modulare
  app.post('/api/create-checkout-session', createCheckoutSession);
  
  // Route per redirect a abbonamento con parametro piano
  app.get('/api/stripe/redirect-to-subscription', redirectToSubscription);
  
  // Route dirette per checkout con specifici endpoints
  app.get('/api/stripe/checkout/monthly-plan', (req, res) => {
    redirectToSubscription(req, res);
  });
  
  app.get('/api/stripe/checkout/yearly-plan', (req, res) => {
    redirectToSubscription(req, res);
  });
  
  // Nuovo endpoint specifico per l'abbonamento annuale - approccio diretto
  // Endpoint per abbonamento mensile ultra-semplificato
  app.get('/api/monthly-subscription', async (req, res) => {
    try {
      // Utilizziamo l'ID prezzo mensile esistente
      const productPrice = 'price_1R6hX1JiRRPU3UNS4mpg0OMa';
      
      // Importiamo direttamente Stripe qui per evitare problemi
      const Stripe = require('stripe');
      const stripeClient = new Stripe(process.env.STRIPE_SECRET_KEY || '');
      
      const session = await stripeClient.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price: productPrice,
            quantity: 1,
          },
        ],
        mode: 'subscription',
        success_url: `${req.protocol}://${req.get('host')}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.protocol}://${req.get('host')}/subscription`,
      });
      
      console.log('ID sessione mensile:', session.id);
      console.log('URL checkout mensile:', session.url);
      
      // Redirect diretto all'URL di checkout Stripe
      if (session.url) {
        res.redirect(session.url);
      } else {
        res.status(500).send('Errore: URL di checkout non generato');
      }
    } catch (error) {
      console.error('Errore creazione sessione monthly-subscription:', error);
      res.status(500).send('Errore nella creazione della sessione di checkout: ' + 
        (error instanceof Error ? error.message : 'Errore sconosciuto'));
    }
  });
  
  // Endpoint per abbonamento annuale ultra-semplificato
  app.get('/api/yearly-subscription', async (req, res) => {
    try {
      console.log('Creazione sessione abbonamento annuale diretta');
      
      // Importiamo direttamente Stripe qui per evitare problemi
      const Stripe = require('stripe');
      const stripeClient = new Stripe(process.env.STRIPE_SECRET_KEY || '');
      
      // Utilizziamo l'ID prezzo annuale definito nelle costanti
      const { STRIPE_PRICES } = require('./stripe');
      const productPrice = STRIPE_PRICES.YEARLY;
      console.log('Utilizzo ID prezzo annuale:', productPrice);
      
      const session = await stripeClient.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price: productPrice,
            quantity: 1,
          },
        ],
        mode: 'subscription',
        success_url: `${req.protocol}://${req.get('host')}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.protocol}://${req.get('host')}/subscription`,
      });

      console.log('Sessione creata con ID:', session.id);
      console.log('URL di checkout generato:', session.url);
      
      // Redirect diretto all'URL di checkout Stripe
      if (session.url) {
        res.redirect(session.url);
      } else {
        res.status(500).send('Errore: URL di checkout non generato');
      }
    } catch (error) {
      console.error('Errore creazione sessione yearly-subscription:', error);
      res.status(500).send('Errore nella creazione della sessione di checkout: ' + 
        (error instanceof Error ? error.message : 'Errore sconosciuto'));
    }
  });
  
  // Webhook per gestire gli eventi di Stripe - usando il sistema modulare
  app.post('/api/stripe-webhook', handleStripeWebhook);
  
  // Pagamento completato
  app.get('/api/payment-status', (req, res) => {
    const sessionId = req.query.session_id as string;
    // In un'implementazione reale qui verificheresti lo stato della sessione
    res.json({ 
      success: !!sessionId,
      sessionId 
    });
  });
  
  // Verifica sessione Stripe - usando il sistema modulare
  app.get('/api/stripe/verify-session', verifySession);
  
  // Invalidazione sessione di test
  app.post('/api/stripe/invalidate-test-session', (req, res) => {
    const { test_session_id } = req.body;
    
    if (!test_session_id || !test_session_id.startsWith('cs_test_')) {
      return res.status(400).json({ 
        status: 'error',
        message: 'Invalid test session ID' 
      });
    }
    
    console.log('Invalidazione sessione di test:', test_session_id);
    
    // Risposta semplice, la logica importante è già nel client
    return res.json({ 
      status: 'success',
      message: 'Test session invalidated' 
    });
  });
  
  // Endpoint di test per la modalità di pagamento
  app.get('/api/stripe/payment-mode', (req, res) => {
    import('./config').then(({ PAYMENT_MODE }) => {
      res.json({ 
        mode: PAYMENT_MODE,
        isProduction: PAYMENT_MODE === 'production',
        stripe_keys_present: !!process.env.STRIPE_SECRET_KEY && !!process.env.STRIPE_PUBLISHABLE_KEY,
        webhook_secret_present: !!process.env.STRIPE_WEBHOOK_SECRET
      });
    }).catch(error => {
      console.error("Errore nel caricamento del modulo config:", error);
      res.status(500).json({ error: "Errore nel caricamento della configurazione" });
    });
  });
  
  // Endpoint di test per verificare la configurazione completa di pagamento con i nuovi prezzi
  app.get('/api/test/payment-mode', (req, res) => {
    import('./config').then(({ PAYMENT_MODE, STRIPE_CONFIG }) => {
      res.json({ 
        mode: PAYMENT_MODE,
        isProduction: PAYMENT_MODE === 'production',
        stripe_keys_present: !!process.env.STRIPE_SECRET_KEY && !!process.env.STRIPE_PUBLISHABLE_KEY,
        webhook_secret_present: !!process.env.STRIPE_WEBHOOK_SECRET,
        prices: {
          monthly: STRIPE_CONFIG.PRICES.MONTHLY,
          yearly: STRIPE_CONFIG.PRICES.YEARLY
        }
      });
    }).catch(error => {
      console.error("Errore nel caricamento del modulo config:", error);
      res.status(500).json({ error: "Errore nel caricamento della configurazione" });
    });
  });

  // Endpoint di test per la configurazione completa di Stripe
  app.get('/api/stripe/test-config', (req, res) => {
    try {
      import('./config').then(({ PAYMENT_MODE, STRIPE_CONFIG, SIMULATION_CONFIG }) => {
        res.json({ 
          mode: PAYMENT_MODE,
          isProduction: PAYMENT_MODE === 'production',
          stripe_keys: {
            secret_key_present: !!process.env.STRIPE_SECRET_KEY,
            publishable_key_present: !!process.env.STRIPE_PUBLISHABLE_KEY,
            webhook_secret_present: !!process.env.STRIPE_WEBHOOK_SECRET
          },
          prices: {
            stripe: {
              monthly: STRIPE_CONFIG.PRICES.MONTHLY,
              yearly: STRIPE_CONFIG.PRICES.YEARLY
            },
            simulation: {
              monthly: SIMULATION_CONFIG.PRICES.MONTHLY,
              yearly: SIMULATION_CONFIG.PRICES.YEARLY
            },
            display: {
              monthly: PAYMENT_MODE === 'production' ? '€4.99/month' : `€${SIMULATION_CONFIG.PRICES.MONTHLY}/month`,
              yearly: PAYMENT_MODE === 'production' ? '€39.99/year' : `€${SIMULATION_CONFIG.PRICES.YEARLY}/year`
            }
          },
          checkout_urls: STRIPE_CONFIG.DIRECT_CHECKOUT_URLS,
          webhook_endpoints: {
            main: '/api/stripe-webhook'
          }
        });
      }).catch(error => {
        console.error("Errore nel caricamento del modulo config:", error);
        res.status(500).json({ error: "Errore nel caricamento della configurazione" });
      });
    } catch (error) {
      console.error("Errore nell'endpoint test-config:", error);
      res.status(500).json({ error: "Errore nell'elaborazione della richiesta" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
