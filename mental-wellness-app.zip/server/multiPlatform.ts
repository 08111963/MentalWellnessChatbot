/**
 * Supporto per implementazioni multi-piattaforma
 * Questo file contiene le funzioni necessarie per far funzionare l'app su più domini
 */

import express, { Request, Response, NextFunction } from 'express';
import { PLATFORM_CONFIG } from './config';
import { isAllowedDomain } from './platformUtils';

/**
 * Middleware per controllare l'origine della richiesta
 * Verifica che il dominio richiedente sia nell'elenco dei domini autorizzati
 */
export function domainAuthMiddleware(req: Request, res: Response, next: NextFunction) {
  const origin = req.headers.origin;
  const referer = req.headers.referer;
  const host = req.headers.host;
  
  // In ambiente di sviluppo o locale, accetta tutte le richieste
  if (process.env.NODE_ENV === 'development') {
    return next();
  }

  // Se non ci sono informazioni sull'origine, controlla l'host
  if (!origin && !referer) {
    if (host && isAllowedDomain(host)) {
      return next();
    }
  }
  
  // Controlla l'origine della richiesta
  if (origin) {
    try {
      const originDomain = new URL(origin).hostname;
      if (isAllowedDomain(originDomain)) {
        return next();
      }
    } catch (e) {
      console.error('Errore nel parsing dell\'origine:', e);
    }
  }
  
  // Controlla il referer
  if (referer) {
    try {
      const refererDomain = new URL(referer).hostname;
      if (isAllowedDomain(refererDomain)) {
        return next();
      }
    } catch (e) {
      console.error('Errore nel parsing del referer:', e);
    }
  }
  
  // Se nessuna delle verifiche ha avuto successo, rifiuta la richiesta
  res.status(403).json({
    error: 'Dominio non autorizzato',
    message: 'Questa API può essere utilizzata solo dai domini autorizzati'
  });
}

/**
 * Middleware per configurare i CORS per domini multipli
 */
export function setupMultiDomainCors(app: express.Express) {
  // Configura CORS per domini multipli autorizzati
  app.use((req: Request, res: Response, next: NextFunction) => {
    const origin = req.headers.origin;
    
    // Se l'origine è un dominio autorizzato, imposta l'header di risposta
    if (origin && typeof origin === 'string') {
      try {
        const originDomain = new URL(origin).hostname;
        if (isAllowedDomain(originDomain)) {
          res.header('Access-Control-Allow-Origin', origin);
          res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
          res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
          res.header('Access-Control-Allow-Credentials', 'true');
        }
      } catch (e) {
        console.error('Errore nel parsing dell\'origine per CORS:', e);
      }
    }
    
    // Gestisci le richieste OPTIONS preflightate
    if (req.method === 'OPTIONS') {
      return res.status(200).end();
    }
    
    next();
  });
}