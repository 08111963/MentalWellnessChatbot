import { type Meditation } from '@shared/schema';

// In-memory meditation data
export const meditations: Meditation[] = [
  {
    id: 1,
    title: "Respirazione Consapevole",
    duration: 5,
    description: "Un breve esercizio di respirazione per calmare la mente e ridurre lo stress immediato.",
    content: `Trova una posizione comoda, seduta o sdraiata.

Chiudi gli occhi e porta l'attenzione al tuo respiro.

Inspira lentamente contando fino a 4, senti l'aria che riempie i polmoni.

Trattieni il respiro per un momento.

Espira lentamente contando fino a 6, lasciando andare ogni tensione.

Ripeti questo ciclo per 5 minuti, mantenendo l'attenzione sul flusso del respiro.

Se la mente vaga, gentilmente riportala al respiro senza giudizio.`
  },
  {
    id: 2,
    title: "Body Scan Rilassante",
    duration: 10,
    description: "Esplorazione guidata delle sensazioni corporee per rilassamento profondo e maggiore consapevolezza.",
    content: `Sdraiati in una posizione comoda, con le braccia lungo i fianchi e le gambe leggermente divaricate.

Chiudi gli occhi e porta l'attenzione al tuo respiro per qualche momento.

Sposta l'attenzione ai piedi. Nota qualsiasi sensazione: calore, peso, leggerezza o formicolio.

Lentamente, sposta l'attenzione alle caviglie, poi ai polpacci, alle ginocchia, e così via risalendo tutto il corpo.

Per ogni parte, osserva semplicemente le sensazioni presenti, senza giudizio o necessità di cambiarle.

Se noti tensione in qualche area, immagina che il respiro possa fluire in quella zona, aiutandola a rilassarsi.

Completa il percorso fino alla testa, poi prendi un momento per sentire il corpo nella sua interezza.

Lentamente, riporta l'attenzione al respiro, poi all'ambiente circostante, e quando sei pronto, apri gli occhi.`
  },
  {
    id: 3,
    title: "Radici del Presente",
    duration: 8,
    description: "Tecnica per riportare la mente al momento presente durante stati di ansia o stress.",
    content: `Trova una posizione comoda e chiudi gli occhi.

Nota 5 cose che puoi vedere (se hai gli occhi chiusi, immagina di osservarle).

Riconosci 4 cose che puoi toccare o sentire sulla pelle.

Identifica 3 cose che puoi udire in questo momento.

Nota 2 cose che puoi odorare (o immagina profumi che ti piacciono).

Riconosci 1 cosa che puoi gustare (o immagina un sapore piacevole).

Ora porta tutta l'attenzione al tuo respiro, facendo respiri profondi e lenti.

Con ogni respiro, senti come diventi sempre più presente e ancorato a questo momento.`
  },
  {
    id: 4,
    title: "Giardino del Cuore",
    duration: 12,
    description: "Pratica per coltivare compassione verso se stessi e gli altri.",
    content: `Trova una posizione comoda e chiudi gli occhi.

Inizia portando l'attenzione al tuo respiro, facendo qualche respiro profondo.

Porta l'attenzione al centro del petto, la zona del cuore.

Ripeti mentalmente: "Che io possa essere felice. Che io possa essere in salute. Che io possa essere al sicuro. Che io possa vivere con facilità."

Senti queste parole risuonare dentro di te mentre continui a respirare tranquillamente.

Ora pensa a una persona cara e ripeti: "Che tu possa essere felice. Che tu possa essere in salute. Che tu possa essere al sicuro. Che tu possa vivere con facilità."

Estendi questi pensieri a una persona neutrale, qualcuno che conosci ma verso cui non hai particolari sentimenti.

Poi, se ti senti pronto, estendi questi pensieri anche verso qualcuno con cui hai delle difficoltà.

Infine, estendi questi pensieri a tutti gli esseri viventi: "Che tutti possano essere felici. Che tutti possano essere in salute. Che tutti possano essere al sicuro. Che tutti possano vivere con facilità."

Concludi portando di nuovo l'attenzione al tuo respiro.`
  }
];

export function getMeditationById(id: number): Meditation | undefined {
  return meditations.find(med => med.id === id);
}

export function getAllMeditations(): Meditation[] {
  return meditations;
}
