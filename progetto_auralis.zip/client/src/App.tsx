import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import ChatPage from "@/pages/ChatPage";
import MeditationPage from "@/pages/MeditationPage";
import ExercisesPage from "@/pages/ExercisesPage";
import ReflectionsPage from "@/pages/ReflectionsPage";
import MoodPage from "@/pages/MoodPage";
import AIModulesPage from "@/pages/AIModulesPage";
import SubscriptionPage from "@/pages/SubscriptionPage";
import SimplePaymentPage from "@/pages/SimplePaymentPage";
import MockStripeCheckoutPage from "@/pages/MockStripeCheckoutPage";
import PaymentSuccessPage from "@/pages/PaymentSuccessPage";
import AdminPage from "@/pages/AdminPage";
import ResourcesPage from "@/pages/ResourcesPage";
import GuidaPage from "@/pages/GuidaPage";
import AppGuidePage from "@/pages/AppGuidePage";
import SafeAppGuidePage from "@/pages/SafeAppGuidePage";
import TermsPage from "@/pages/TermsPage";
import ManageSubscriptionPage from "@/pages/ManageSubscriptionPage";
import SimpleManageSubscriptionPage from "@/pages/SimpleManageSubscriptionPage";
import QRCodePage from "@/pages/QRCodePage";
import SupportPage from "@/pages/SupportPage";
import { useEffect, useState } from "react";
import ScrollToTop from "@/components/ScrollToTop";
import ImageOptimizer from "@/components/ImageOptimizer";
import { AuthProvider } from "@/lib/auth-context";
import { StripeProvider } from "@/lib/stripe-context";
import { initHomeNavigation, navigateToHome, isProblematicPage } from "@/lib/home-navigation";
import SimpleLanguageSelector from "@/components/SimpleLanguageSelector";
import LanguageDebug from "@/components/LanguageDebug";
import SEOOptimizer from "@/components/SEOOptimizer";
import { Route, Switch } from "wouter";

// Router ottimizzato usando Wouter per migliorare la performance di navigazione
function AppRouter() {
  // Quando ci troviamo sulla home page, possiamo inviare un evento
  const HomeWithEvents = () => {
    useEffect(() => {
      const event = new CustomEvent("route-changed", { detail: { path: "/" } });
      window.dispatchEvent(event);
    }, []);
    
    return <HomePage />;
  };

  return (
    <>
      <ScrollToTop />
      <Switch>
        <Route path="/" component={HomeWithEvents} />
        <Route path="/chat" component={ChatPage} />
        <Route path="/meditation" component={MeditationPage} />
        <Route path="/exercises" component={ExercisesPage} />
        <Route path="/reflections" component={ReflectionsPage} />
        <Route path="/mood" component={MoodPage} />
        <Route path="/ai-modules" component={AIModulesPage} />
        <Route path="/subscription" component={SubscriptionPage} />
        <Route path="/premium" component={SubscriptionPage} />
        <Route path="/simple-payment" component={SimplePaymentPage} />
        <Route path="/payment-success" component={PaymentSuccessPage} />
        <Route path="/manage-subscription" component={SimpleManageSubscriptionPage} />
        <Route path="/admin" component={AdminPage} />
        <Route path="/resources" component={ResourcesPage} />
        <Route path="/app-guide" component={SafeAppGuidePage} />
        <Route path="/guida" component={SafeAppGuidePage} />
        <Route path="/qrcode" component={QRCodePage} />
        <Route path="/download" component={QRCodePage} />
        <Route path="/support" component={SupportPage} />
        <Route path="/terms" component={TermsPage} />
        <Route path="/privacy" component={TermsPage} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  // Inizializza il sistema di navigazione home alla prima esecuzione dell'app
  useEffect(() => {
    // Inizializza il nostro sistema di navigazione specializzato
    initHomeNavigation();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <StripeProvider>
          <AppRouter />
          <Toaster />
          {/* Selettore di lingua fisso nell'angolo in alto a destra - ora gestisce automaticamente la visibilità */}
          <div className="fixed top-4 right-4 z-[9999]">
            <SimpleLanguageSelector />
          </div>
          {/* Debug nascosto, attivo solo in console */}
          <LanguageDebug />
          {/* Ottimizzatore di immagini per migliorare SEO e performance */}
          <ImageOptimizer />
          {/* Ottimizzatore SEO per migliorare la visibilità sui motori di ricerca */}
          <SEOOptimizer />

        </StripeProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
