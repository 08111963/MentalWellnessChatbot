import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

// Componente di debug per visualizzare lo stato delle traduzioni
export default function LanguageDebug() {
  const { t, i18n } = useTranslation();
  const [translations, setTranslations] = useState<{[key: string]: string}>({});
  
  useEffect(() => {
    // Raccogliamo alcuni valori tradotti per debug
    const translationKeys = [
      'app.name',
      'app.tagline',
      'navigation.home',
      'navigation.chat',
      'common.back',
      'subscription.premium'
    ];
    
    const translatedValues = translationKeys.reduce((acc, key) => {
      acc[key] = t(key);
      return acc;
    }, {} as {[key: string]: string});
    
    setTranslations(translatedValues);
    
    // Log info solo su console
    console.log('--- LANGUAGE DEBUG ---');
    console.log('i18n.language:', i18n.language);
    console.log('i18n.languages:', i18n.languages);
    console.log('i18n.isInitialized:', i18n.isInitialized);
    console.log('localStorage i18nextLng:', localStorage.getItem('i18nextLng'));
    console.log('Translated values:', translatedValues);
    console.log('-------------------');
    
  }, [t, i18n.language]);
  
  // Non renderizziamo nulla a video
  return null;
}