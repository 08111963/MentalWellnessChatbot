import React, { useState, useEffect } from 'react';

interface OptimizedImageProps {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  className?: string;
  priority?: boolean;
  sizes?: string;
  objectFit?: 'contain' | 'cover' | 'fill' | 'none' | 'scale-down';
  quality?: number;
  loading?: 'lazy' | 'eager';
  // SEO attributes
  title?: string;
  description?: string;
  // Arte progressiva
  placeholder?: 'blur' | 'empty';
  blurDataURL?: string;
  // Webp options
  useWebp?: boolean;
  fallbackFormat?: 'jpg' | 'jpeg' | 'png' | 'gif';
}

/**
 * Funzione di supporto per generare URL WebP
 */
function getWebPUrl(src: string): string {
  // Se l'URL è già WebP, ritornalo direttamente
  if (src.toLowerCase().endsWith('.webp')) {
    return src;
  }
  
  // Altrimenti, gestisci solo URL interni 
  // Aggiungiamo un parametro per la CDN o per un eventuale server-side middleware
  if (src.startsWith('/')) {
    // Rimuovi l'estensione esistente se presente
    const baseSrc = src.replace(/\.[^/.]+$/, '');
    return `${baseSrc}.webp`;
  }
  
  // Per URL esterni non manipoliamo il formato
  return src;
}

/**
 * Funzione per gestire il fallback delle immagini
 * Prova diverse varianti del percorso delle immagini in caso di errore
 */
function getFallbackImageUrl(src: string): string {
  // Se l'URL è assoluto, usa direttamente l'immagine di fallback
  if (src.startsWith('http')) {
    return '/app-image.svg';
  }
  
  // Varianti da provare in caso di errore
  if (src.includes('meditation-')) {
    // Prova senza il trattino (meditation1.svg invece di meditation-1.svg)
    return src.replace('meditation-', 'meditation');
  } else if (src.includes('meditation')) {
    // Usa l'immagine dell'app come fallback
    return '/app-image.svg';
  }
  
  // Fallback finale
  return '/app-image.svg';
}

/**
 * Funzione per generare un placeholder di colore solido
 */
function generateColorPlaceholder(width: number = 100, height: number = 100, color: string = '#f0f0f0'): string {
  return `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 ${width} ${height}'%3E%3Crect width='${width}' height='${height}' fill='${color.replace('#', '%23')}'/%3E%3C/svg%3E`;
}

/**
 * Componente avanzato per ottimizzare le immagini con supporto per WebP,
 * lazy loading progressivo, e attributi SEO migliorati.
 */
export const OptimizedImage: React.FC<OptimizedImageProps> = ({
  src,
  alt,
  width,
  height,
  className = '',
  priority = false,
  sizes,
  objectFit,
  quality = 80,
  loading,
  title,
  description,
  placeholder = 'empty',
  blurDataURL,
  useWebp = true,
  fallbackFormat = 'jpg'
}) => {
  // Stato per tracciare quando l'immagine è caricata
  const [isLoaded, setIsLoaded] = useState(false);
  
  // Stato per gestire l'URL del placeholder
  const [placeholderUrl, setPlaceholderUrl] = useState<string | null>(null);
  
  // Determina l'URL dell'immagine WebP se richiesto
  const webpSrc = useWebp ? getWebPUrl(src) : null;
  
  // Genera lo stile in base all'object-fit e altre proprietà
  const imageStyle: React.CSSProperties = {
    objectFit: objectFit,
    opacity: isLoaded ? 1 : 0,
    transition: 'opacity 0.5s ease-in-out',
    // Se abbiamo un blur placeholder, mostriamolo come sfondo prima del caricamento
    backgroundImage: !isLoaded && placeholderUrl ? `url(${placeholderUrl})` : 'none',
    backgroundSize: 'cover',
    backgroundPosition: 'center'
  };
  
  // Carica il placeholder appropriato
  useEffect(() => {
    if (placeholder === 'blur') {
      if (blurDataURL) {
        setPlaceholderUrl(blurDataURL);
      } else {
        // Genera un placeholder semplice basato su dimensioni dell'immagine
        setPlaceholderUrl(generateColorPlaceholder(width, height));
      }
    }
  }, [placeholder, blurDataURL, width, height]);
  
  // Gestisci il caricamento dell'immagine
  const handleLoad = () => {
    setIsLoaded(true);
  };
  
  // Stato per gestire l'errore dell'immagine
  const [imgSrc, setImgSrc] = useState(src);
  
  // Gestisci l'errore dell'immagine
  const handleError = () => {
    console.error(`Errore nel caricamento dell'immagine: ${imgSrc}`);
    // Usa la funzione di fallback per trovare un'alternativa
    const fallbackSrc = getFallbackImageUrl(imgSrc);
    if (fallbackSrc !== imgSrc) {
      console.log(`Provo con immagine alternativa: ${fallbackSrc}`);
      setImgSrc(fallbackSrc);
    } else {
      // Se siamo già al fallback finale, impostiamo come caricata
      setIsLoaded(true);
    }
  };
  
  // Scegli tra WebP o immagine originale
  const renderImage = () => (
    <img 
      src={imgSrc}
      alt={alt}
      width={width}
      height={height}
      sizes={sizes}
      loading={loading || (priority ? "eager" : "lazy")}
      decoding="async"
      className={className}
      style={imageStyle}
      title={title || alt} // SEO: Usa title per aiutare con SEO
      onLoad={handleLoad}
      onError={handleError}
      // Gli attributi data aiutano crawler specifici e snippet ricci
      data-description={description}
    />
  );
  
  // Se non usiamo WebP, renderizza direttamente l'immagine
  if (!useWebp || !webpSrc) {
    return renderImage();
  }
  
  // Se usiamo WebP, usa il pattern <picture> con fallback
  return (
    <picture>
      <source srcSet={webpSrc} type="image/webp" />
      <source srcSet={src} type={`image/${fallbackFormat}`} />
      {renderImage()}
    </picture>
  );
};

/**
 * Interfaccia estesa per ResponsivePicture con attributi SEO e ottimizzazione
 */
interface ResponsivePictureProps {
  src: string;
  alt: string;
  sources: Array<{
    srcSet: string;
    media?: string;
    type?: string;
  }>;
  width?: number;
  height?: number;
  className?: string;
  imgClassName?: string;
  priority?: boolean;
  sizes?: string;
  objectFit?: 'contain' | 'cover' | 'fill' | 'none' | 'scale-down';
  title?: string;
  description?: string;
  loading?: 'lazy' | 'eager';
  // Arte progressiva
  placeholder?: 'blur' | 'empty';
  blurDataURL?: string;
  // SEO
  fetchPriority?: 'high' | 'low' | 'auto';
}

/**
 * Componente avanzato per implementare il pattern picture per servire diverse
 * risoluzioni di immagini in base ai dispositivi, con supporto migliorato
 * per SEO, caricamento progressivo e ottimizzazioni prestazionali.
 */
export const ResponsivePicture: React.FC<ResponsivePictureProps> = ({
  src,
  alt,
  sources,
  width,
  height,
  className = '',
  imgClassName = '',
  priority = false,
  sizes,
  objectFit,
  title,
  description,
  loading,
  placeholder = 'empty',
  blurDataURL,
  fetchPriority
}) => {
  // Stato per tracciare quando l'immagine è caricata
  const [isLoaded, setIsLoaded] = useState(false);
  
  // Stato per gestire l'URL del placeholder
  const [placeholderUrl, setPlaceholderUrl] = useState<string | null>(null);
  
  // Genera lo stile in base all'object-fit e altre proprietà
  const imageStyle: React.CSSProperties = {
    objectFit: objectFit,
    opacity: isLoaded ? 1 : 0,
    transition: 'opacity 0.5s ease-in-out',
    // Se abbiamo un blur placeholder, mostriamolo come sfondo prima del caricamento
    backgroundImage: !isLoaded && placeholderUrl ? `url(${placeholderUrl})` : 'none',
    backgroundSize: 'cover',
    backgroundPosition: 'center'
  };
  
  // Carica il placeholder appropriato
  useEffect(() => {
    if (placeholder === 'blur') {
      if (blurDataURL) {
        setPlaceholderUrl(blurDataURL);
      } else {
        // Genera un placeholder semplice basato su dimensioni dell'immagine
        setPlaceholderUrl(generateColorPlaceholder(width, height));
      }
    }
  }, [placeholder, blurDataURL, width, height]);
  
  // Gestisci il caricamento dell'immagine
  const handleLoad = () => {
    setIsLoaded(true);
  };
  
  // Stato per gestire l'errore dell'immagine
  const [imgSrc, setImgSrc] = useState(src);
  
  // Gestisci l'errore dell'immagine
  const handleError = () => {
    console.error(`Errore nel caricamento dell'immagine: ${imgSrc}`);
    // Usa la funzione di fallback per trovare un'alternativa
    const fallbackSrc = getFallbackImageUrl(imgSrc);
    if (fallbackSrc !== imgSrc) {
      console.log(`Provo con immagine alternativa: ${fallbackSrc}`);
      setImgSrc(fallbackSrc);
    } else {
      // Se siamo già al fallback finale, impostiamo come caricata
      setIsLoaded(true);
    }
  };
  
  return (
    <picture className={className}>
      {/* Aggiungi le sorgenti specificate dall'utente */}
      {sources.map((source, index) => (
        <source 
          key={index}
          srcSet={source.srcSet}
          media={source.media}
          type={source.type}
          sizes={sizes}
        />
      ))}
      
      {/* Immagine di fallback con supporto per caricamento progressivo e SEO */}
      <img 
        src={imgSrc}
        alt={alt}
        width={width}
        height={height}
        sizes={sizes}
        loading={loading || (priority ? "eager" : "lazy")}
        decoding="async"
        className={imgClassName}
        style={imageStyle}
        title={title || alt} // SEO: Usa title per aiutare con SEO
        onLoad={handleLoad}
        onError={handleError}
        // Attributi SEO e prestazioni aggiuntivi
        data-description={description}
        fetchPriority={fetchPriority}
      />
    </picture>
  );
};