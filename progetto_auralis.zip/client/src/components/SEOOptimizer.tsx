import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'wouter';

// Componente per ottimizzare le pagine principali dell'app per i motori di ricerca
const SEOOptimizer: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [location] = useLocation();
  const currentLanguage = i18n.language;

  useEffect(() => {
    // Gestione dinamica del titolo della pagina e della descrizione
    let pageTitle = '';
    let pageDescription = '';
    let pageKeywords = 'benessere mentale, app salute mentale, supporto psicologico, meditazione, CBT';

    // Determinazione del titolo e descrizione in base alla pagina
    switch (true) {
      case location === '/':
        pageTitle = t('app.name') + ' - ' + t('app.tagline');
        pageDescription = t('seo.home.description', 'Supporto personalizzato per il benessere mentale con tecniche di mindfulness e CBT per migliorare la tua salute mentale quotidiana.');
        pageKeywords += ', supporto salute mentale, meditazione guidata';
        break;
      case location === '/meditations':
        pageTitle = t('meditations.title') + ' | ' + t('app.name');
        pageDescription = t('seo.meditations.description', 'Meditazioni guidate per ridurre stress, ansia e migliorare il sonno. Pratiche di mindfulness accessibili a tutti per il benessere mentale quotidiano.');
        pageKeywords += ', meditazione guidata, mindfulness, riduzione stress, ansia';
        break;
      case location === '/exercises':
        pageTitle = t('exercises.title') + ' | ' + t('app.name');
        pageDescription = t('seo.exercises.description', 'Esercizi di terapia cognitivo-comportamentale (CBT) per affrontare ansia, stress e pensieri negativi. Migliora il tuo benessere mentale giorno dopo giorno.');
        pageKeywords += ', esercizi CBT, terapia cognitivo comportamentale, gestione ansia';
        break;
      case location === '/resources':
        pageTitle = t('resources.title') + ' | ' + t('app.name');
        pageDescription = t('seo.resources.description', 'Risorse per il benessere mentale, articoli informativi e strumenti pratici per migliorare la tua salute psicologica e gestire lo stress quotidiano.');
        pageKeywords += ', risorse benessere, articoli salute mentale, strumenti psicologici';
        break;
      case location === '/subscription':
        pageTitle = t('subscription.title') + ' | ' + t('app.name');
        pageDescription = t('seo.subscription.description', 'Accedi a contenuti premium per il tuo benessere mentale. Abbonamento mensile o annuale con accesso illimitato a tutte le funzionalità avanzate.');
        pageKeywords += ', abbonamento premium, contenuti benessere, servizi psicologici online';
        break;
      default:
        // Titolo e descrizione predefiniti per altre pagine
        pageTitle = t('app.name');
        pageDescription = t('app.description', 'Supporto psicologico personalizzato con CBT, meditazioni guidate e strumenti per il benessere mentale.');
    }

    // Aggiorna i meta tag dinamicamente
    document.title = pageTitle;

    // Aggiorna la descrizione
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', pageDescription);

    // Aggiorna le parole chiave
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', pageKeywords);

    // Aggiorna i meta tag per la lingua
    document.documentElement.setAttribute('lang', currentLanguage);

  }, [location, t, currentLanguage, i18n.language]);

  return null; // Questo componente non renderizza nulla visibilmente
};

export default SEOOptimizer;