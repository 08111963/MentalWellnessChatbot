import React, { useState, useEffect } from 'react';
import { type TabType } from '@/lib/types';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'wouter';
import { isProblematicPage } from '@/lib/home-navigation';

interface TabNavigationProps {
  activeTab: TabType;
}

const TabNavigation: React.FC<TabNavigationProps> = ({ activeTab }) => {
  const { t, i18n } = useTranslation();
  const [language, setLanguage] = useState(i18n.language);
  const [, setLocation] = useLocation();
  const isInProblematicPage = isProblematicPage();
  
  // Funzione di navigazione ottimizzata con Wouter
  const navigateTo = (path: string) => {
    // Se andiamo alla home e siamo in una pagina problematica, forza il refresh
    if (path === '/' && isInProblematicPage) {
      sessionStorage.setItem('force_home_navigation', 'true');
      window.location.href = '/';
      return;
    }
    
    // Per tutte le altre pagine, utilizza il router per navigazione veloce
    setLocation(path);
  };
  
  // Forza il rendering quando la lingua cambia
  useEffect(() => {
    const handleLanguageChange = () => {
      setLanguage(i18n.language);
      console.log("Language changed in TabNavigation:", i18n.language);
    };
    
    i18n.on('languageChanged', handleLanguageChange);
    
    return () => {
      i18n.off('languageChanged', handleLanguageChange);
    };
  }, [i18n]);
  
  return (
    <div className="mb-6">
      <nav className="flex border-b border-neutral-200 overflow-x-auto pb-1">
        <button 
          onClick={() => navigateTo('/chat')}
          className={`whitespace-nowrap ${activeTab === 'chat' 
            ? 'text-primary border-b-2 border-primary font-medium' 
            : 'text-neutral-500 hover:text-neutral-700'} px-4 py-2 text-sm mr-4`}
        >
          {t('navigation.chat', 'Chat')}
        </button>
        <button 
          onClick={() => navigateTo('/exercises')}
          className={`whitespace-nowrap ${activeTab === 'exercises' 
            ? 'text-primary border-b-2 border-primary font-medium' 
            : 'text-neutral-500 hover:text-neutral-700'} px-4 py-2 text-sm mr-4`}
        >
          {t('navigation.exercises', 'Esercizi')}
        </button>
        <button 
          onClick={() => navigateTo('/meditation')}
          className={`whitespace-nowrap ${activeTab === 'meditation' 
            ? 'text-primary border-b-2 border-primary font-medium' 
            : 'text-neutral-500 hover:text-neutral-700'} px-4 py-2 text-sm mr-4`}
        >
          {t('navigation.meditation', 'Meditazione')}
        </button>
        <button 
          onClick={() => navigateTo('/ai-modules')}
          className={`whitespace-nowrap ${activeTab === 'ai-modules' 
            ? 'text-primary border-b-2 border-primary font-medium' 
            : 'text-neutral-500 hover:text-neutral-700'} px-4 py-2 text-sm mr-4`}
        >
          {t('navigation.aiModules', 'AI Moduli')}
        </button>
        <button 
          onClick={() => navigateTo('/reflections')}
          className={`whitespace-nowrap ${activeTab === 'reflections' 
            ? 'text-primary border-b-2 border-primary font-medium' 
            : 'text-neutral-500 hover:text-neutral-700'} px-4 py-2 text-sm mr-4`}
        >
          {t('navigation.reflections', 'Riflessioni')}
        </button>
        <button 
          onClick={() => navigateTo('/mood')}
          className={`whitespace-nowrap ${activeTab === 'mood' 
            ? 'text-primary border-b-2 border-primary font-medium' 
            : 'text-neutral-500 hover:text-neutral-700'} px-4 py-2 text-sm`}
        >
          <span className="flex items-center">
            {t('navigation.mood', 'Umore')}
            <i className="ri-vip-crown-fill text-amber-300 ml-1 text-xs"></i>
          </span>
        </button>
      </nav>
    </div>
  );
};

export default TabNavigation;
