import React, { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Card, CardContent } from '@/components/ui/card';

interface QRCodeComponentProps {
  variant?: 'button' | 'icon' | 'inline';
  size?: number;
  className?: string;
}

const QRCodeComponent: React.FC<QRCodeComponentProps> = ({ 
  variant = 'button',
  size = 200,
  className = '' 
}) => {
  const { t } = useTranslation();
  const [currentUrl, setCurrentUrl] = useState<string>('');
  const [open, setOpen] = useState(false);

  useEffect(() => {
    // Imposta l'URL corrente quando il componente viene montato
    setCurrentUrl(window.location.origin);
  }, []);

  const handleShare = async () => {
    if (typeof navigator !== 'undefined' && 'share' in navigator) {
      try {
        await navigator.share({
          title: t('qrcode.share_title', 'Auralis - Benessere mentale'),
          text: t('qrcode.share_text', 'Scarica l\'app Auralis per il tuo benessere mentale!'),
          url: currentUrl,
        });
        console.log('Contenuto condiviso con successo');
      } catch (error) {
        console.error('Errore nella condivisione:', error);
      }
    } else {
      setOpen(true);
    }
  };

  const renderButton = () => (
    <Button 
      variant="outline" 
      onClick={handleShare}
      className={`flex items-center px-3 py-1.5 text-sm bg-white text-purple-600 hover:text-white hover:bg-purple-600 border border-purple-500 font-medium rounded-md shadow-sm ${className}`}
    >
      <span className="mr-2">📱</span>
      {t('qrcode.button_text', 'Scarica App')}
    </Button>
  );

  const renderIcon = () => (
    <Button 
      variant="ghost" 
      size="sm" 
      onClick={handleShare}
      className={`p-2 min-w-0 h-auto rounded-full ${className}`}
    >
      📱
    </Button>
  );

  const renderInline = () => (
    <div className={`cursor-pointer ${className}`} onClick={() => setOpen(true)}>
      <QRCodeSVG value={currentUrl} size={size} />
    </div>
  );

  return (
    <>
      {variant === 'button' && renderButton()}
      {variant === 'icon' && renderIcon()}
      {variant === 'inline' && renderInline()}
      
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t('qrcode.dialog_title', 'Scarica la nostra App')}</DialogTitle>
            <DialogDescription>
              {t('qrcode.dialog_description', 'Scansiona questo codice QR con il tuo dispositivo mobile per accedere all\'app')}
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center justify-center p-6">
            <Card className="w-auto p-4 bg-white shadow-lg">
              <CardContent className="p-0 flex items-center justify-center">
                <QRCodeSVG 
                  value={currentUrl} 
                  size={250}
                  includeMargin={true}
                  bgColor={"#ffffff"}
                  fgColor={"#000000"}
                  level={"H"}
                  imageSettings={{
                    src: "/favicon.svg",
                    x: undefined,
                    y: undefined,
                    height: 40,
                    width: 40,
                    excavate: true,
                  }}
                />
              </CardContent>
            </Card>
            <p className="text-center mt-4 text-sm text-muted-foreground">
              {t('qrcode.instructions', 'Punta la fotocamera del tuo smartphone verso il codice QR per aprire l\'app nel browser del tuo dispositivo')}
            </p>
            <div className="flex flex-col sm:flex-row gap-2 mt-4">
              <Button 
                className="w-full" 
                onClick={() => navigator.clipboard.writeText(currentUrl)}
              >
                {t('qrcode.copy_link', 'Copia Link')}
              </Button>
              {typeof navigator !== 'undefined' && 'share' in navigator && (
                <Button 
                  className="w-full" 
                  variant="outline" 
                  onClick={handleShare}
                >
                  {t('qrcode.share', 'Condividi')}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default QRCodeComponent;