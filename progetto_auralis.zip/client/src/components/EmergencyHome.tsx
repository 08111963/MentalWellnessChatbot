import React from 'react';
import { useLocation } from 'wouter';
import { isProblematicPage } from '@/lib/home-navigation';

interface EmergencyHomeButtonProps {
  className?: string;
  discreet?: boolean;
}

export function EmergencyHomeButton({ className = "", discreet = false }: EmergencyHomeButtonProps) {
  const [_, setLocation] = useLocation();
  const isInProblematicPage = isProblematicPage();
  
  const handleHomeNavigation = () => {
    // Se siamo in una pagina problematica, forza un refresh completo
    if (isInProblematicPage) {
      // Imposta un flag nel sessionStorage per indicare che questa è una navigazione forzata
      sessionStorage.setItem('force_home_navigation', 'true');
      // Usa il metodo più diretto possibile
      window.location.replace('/');
      return;
    }
    
    // Altrimenti usa il router per navigazione veloce
    setLocation('/');
  };
  
  if (discreet) {
    return (
      <div className={`flex justify-end mb-4 ${className}`}>
        <button 
          className="px-3 py-1.5 bg-purple-600 text-white text-sm rounded-md font-medium hover:bg-purple-700 shadow-md inline-flex items-center"
          onClick={handleHomeNavigation}
          title="Torna alla Home"
        >
          <i className="ri-home-4-line mr-1.5"></i> Home
        </button>
      </div>
    );
  }
  
  return (
    <div className={`${className}`}>
      <button 
        className="px-3 py-1.5 bg-purple-600 text-white text-sm rounded-md font-medium hover:bg-purple-700 shadow-md inline-flex items-center"
        onClick={handleHomeNavigation}
      >
        <i className="ri-home-4-line mr-1.5"></i> Home
      </button>
    </div>
  );
}