import React from 'react';
import { Button } from '@/components/ui/button';

// Definizione del tipo per compatibilità
export type TourType = 'homepage' | 'chat' | 'exercises' | 'meditation' | 'reflections' | 'mood';

// Componente vuoto che non fa nulla - il tour è stato rimosso
export function OnboardingTour() {
  return null;
}

// Bottone di guida che non fa nulla - il tour è stato rimosso
export function TourButton() {
  return (
    <Button 
      variant="outline" 
      size="sm" 
      className="flex items-center gap-1 bg-violet-50 text-violet-600 border-violet-200 hover:bg-violet-100"
    >
      <i className="ri-question-line"></i>
      Guida
    </Button>
  );
}