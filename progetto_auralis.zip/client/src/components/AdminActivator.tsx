import React, { useState, useCallback, useEffect } from 'react';
import { useAuth } from '@/lib/auth-context';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';

export function AdminActivator() {
  const [clickCount, setClickCount] = useState(0);
  const { isAdmin, setAdmin } = useAuth();
  const { toast } = useToast();
  const { i18n } = useTranslation();
  
  // Funzione generica per attivare l'admin mode
  const activateAdmin = useCallback(() => {
    if (!isAdmin) {
      // Attiva la modalità admin
      setAdmin(true);
      
      // Salva anche manualmente nel localStorage per sicurezza
      localStorage.setItem('auralis_is_admin', 'true');
      console.log('Stato admin attivato da click sul copyright e salvato nel localStorage');
      
      // Mostra un toast di conferma
      const isCurrentEnglish = i18n.language === 'en';
      
      toast({
        title: isCurrentEnglish ? "Admin Mode activated" : "Modalità Admin attivata",
        description: isCurrentEnglish ? "You now have access to all premium content" : "Ora hai accesso a tutti i contenuti premium",
        variant: "default",
      });
      
      // Reset del contatore
      setClickCount(0);
    }
  }, [isAdmin, setAdmin, toast, i18n.language]);
  
  // Gestore per click
  const handleClick = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    console.log("AdminActivator click, current count:", clickCount, "language:", i18n.language);
    // Incrementa il contatore dei clic
    const newCount = clickCount + 1;
    setClickCount(newCount);
    
    // Se l'utente ha cliccato 5 volte e non è già admin
    if (newCount >= 5 && !isAdmin) {
      activateAdmin();
    }
    
    // Reset del contatore dopo 3 secondi di inattività
    const timer = setTimeout(() => {
      setClickCount(0);
    }, 3000);
    
    return () => clearTimeout(timer);
  }, [clickCount, isAdmin, activateAdmin]);
  
  // Gestore per tastiera
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleClick(e as unknown as React.MouseEvent);
    }
  }, [handleClick]);
  
  return (
    <span 
      onClick={handleClick}
      onKeyDown={handleKeyDown}
      className="inline-block cursor-pointer select-none px-1 text-neutral-500 hover:text-neutral-400 transition-colors"
      style={{ 
        userSelect: 'none', 
        WebkitUserSelect: 'none',
        touchAction: 'manipulation'
      }}
      title="Copyright"
      role="button"
      tabIndex={0}
      aria-label="Copyright symbol"
    >
      ©
    </span>
  );
}

export default AdminActivator;