import React, { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/auth-context';
import { useTranslation } from 'react-i18next';

interface AdminAuthDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAuthenticate: (success: boolean) => void;
}

export function AdminAuthDialog({ open, onOpenChange, onAuthenticate }: AdminAuthDialogProps) {
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const { adminPassword } = useAuth();
  const { t, i18n } = useTranslation();
  const isEnglish = i18n.language === 'en';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Verifica della password con quella definita nel context
    if (password === adminPassword) {
      toast({
        title: isEnglish ? "Login successful" : "Accesso riuscito",
        description: isEnglish ? "You have logged in as an administrator." : "Hai effettuato l'accesso come amministratore.",
        variant: "default",
      });
      onAuthenticate(true);
    } else {
      toast({
        title: isEnglish ? "Login failed" : "Accesso fallito",
        description: isEnglish ? "The password entered is incorrect." : "La password inserita non è corretta.",
        variant: "destructive",
      });
      onAuthenticate(false);
    }
    
    setIsSubmitting(false);
    setPassword('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isEnglish ? 'Administrator Access' : 'Accesso Amministratore'}
          </DialogTitle>
          <DialogDescription>
            {isEnglish 
              ? 'Only authorized administrators can access this area.'
              : 'Solo gli amministratori autorizzati possono accedere a questa area.'}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="password">
                {isEnglish ? 'Administrator Password' : 'Password di amministrazione'}
              </Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={isEnglish ? 'Enter administrator password' : 'Inserisci la password di amministrazione'}
                autoComplete="current-password"
                required
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {isEnglish ? 'Cancel' : 'Annulla'}
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting 
                ? (isEnglish ? 'Verifying...' : 'Verifica in corso...') 
                : (isEnglish ? 'Login' : 'Accedi')}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}