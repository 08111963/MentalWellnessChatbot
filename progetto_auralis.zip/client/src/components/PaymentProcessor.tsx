import { useState } from 'react';
import { Button } from './ui/button';
import { useStripe } from '../lib/stripe-context';
import { useToast } from '../hooks/use-toast';

interface PaymentProcessorProps {
  priceId: string;
  buttonText: string | React.ReactNode;
  className?: string;
  variant?: 'default' | 'outline' | 'secondary' | 'destructive' | 'ghost' | 'link';
}

export function PaymentProcessor({ 
  priceId, 
  buttonText, 
  className = '', 
  variant = 'default' 
}: PaymentProcessorProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const { createCheckoutSession, isLoading, error, subscription } = useStripe();
  const { toast } = useToast();

  const handlePayment = async () => {
    setIsProcessing(true);
    console.log('Avvio processo di pagamento per:', priceId);
    
    try {
      console.log('Chiamata a createCheckoutSession con ID:', priceId);
      const url = await createCheckoutSession(priceId);
      console.log('URL ricevuto:', url);
      
      if (url) {
        toast({
          title: "Reindirizzamento",
          description: "Stai per essere reindirizzato alla pagina di pagamento",
        });
        console.log('Reindirizzamento a:', url);
        
        // Reindirizza direttamente alla pagina di checkout
        window.location.assign(url);
      } else {
        console.error('URL di pagamento non ricevuto');
        toast({
          title: "Errore",
          description: "Non è stato possibile creare la sessione di pagamento",
          variant: "destructive"
        });
      }
    } catch (err) {
      console.error("Errore dettagliato pagamento:", err);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'elaborazione del pagamento",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Se c'è un errore nel context di Stripe
  if (error) {
    return (
      <Button
        disabled
        variant="outline"
        className={`${className} opacity-60`}
      >
        Servizio non disponibile
      </Button>
    );
  }

  return (
    <Button
      onClick={handlePayment}
      disabled={isProcessing || isLoading}
      variant={variant}
      className={className}
    >
      {isProcessing ? (
        <span className="flex items-center">
          <i className="ri-loader-4-line animate-spin mr-2"></i>
          Elaborazione...
        </span>
      ) : buttonText}
    </Button>
  );
}