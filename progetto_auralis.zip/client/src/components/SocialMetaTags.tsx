import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Exercise, Meditation, Reflection } from '@/lib/types';

// Definizione del tipo Resource, mantenuto localmente per evitare dipendenze circolari
interface Resource {
  id: number;
  title: string;
  description: string;
  type: string;
  tags?: string[];
  url?: string;
  imageUrl?: string;
  isPremium: boolean;
  category: string;
  estimatedTime?: string;
  relevanceScore?: number;
  content?: string;
}

interface SocialMetaTagsProps {
  title?: string;
  description?: string;
  imageUrl?: string;
  url?: string;
  type?: 'website' | 'article';
  publishedTime?: string;
  modifiedTime?: string;
  authorName?: string;
  contentType?: 'meditation' | 'exercise' | 'reflection' | 'resource' | 'website';
  contentObject?: Meditation | Exercise | Reflection | Resource;
}

/**
 * Componente che gestisce i meta tag per social media in modo dinamico
 * Permette di ottimizzare ogni pagina singolarmente per i social
 */
export const SocialMetaTags: React.FC<SocialMetaTagsProps> = ({
  title,
  description,
  imageUrl = '/app-image.png',
  url,
  type = 'website',
  publishedTime,
  modifiedTime,
  authorName = 'Auralis',
  contentType,
  contentObject
}) => {
  const { t, i18n } = useTranslation();
  const currentLanguage = i18n.language;
  const baseUrl = 'https://auralis.replit.app';
  
  // Determina titolo e descrizione in base al contenuto
  let finalTitle = title;
  let finalDescription = description;
  let finalImageUrl = imageUrl;
  
  // Se abbiamo un oggetto di contenuto, estraiamo le informazioni più rilevanti
  if (contentObject && contentType) {
    switch (contentType) {
      case 'meditation':
        const meditation = contentObject as Meditation;
        finalTitle = finalTitle || `${meditation.title} | ${t('meditation.title')} | Auralis`;
        finalDescription = finalDescription || meditation.description;
        break;
      case 'exercise':
        const exercise = contentObject as Exercise;
        finalTitle = finalTitle || `${exercise.title} | ${t('exercises.title')} | Auralis`;
        finalDescription = finalDescription || exercise.description;
        break;
      case 'reflection':
        const reflection = contentObject as Reflection;
        finalTitle = finalTitle || `${reflection.prompt} | ${t('reflections.title')} | Auralis`;
        finalDescription = finalDescription || reflection.prompt;
        break;
      case 'resource':
        const resource = contentObject as Resource;
        finalTitle = finalTitle || `${resource.title} | ${t('resources.title')} | Auralis`;
        finalDescription = finalDescription || resource.description;
        break;
    }
  }
  
  // Valori di default se non sono stati specificati
  finalTitle = finalTitle || t('app.name') + ' - ' + t('app.tagline');
  finalDescription = finalDescription || t('app.description', 'Supporto psicologico personalizzato con CBT, meditazioni guidate e strumenti per il benessere mentale.');
  
  // Determina l'URL corrente e l'URL canonico
  const pathname = window.location.pathname;
  const currentUrl = url || `${baseUrl}${pathname}`;
  
  // Gestione precisa dell'URL canonico per multi-lingua
  let canonicalUrl = '';
  
  // La versione italiana è considerata la principale per impostazione predefinita
  if (currentLanguage === 'it') {
    // Per italiano (lingua principale) utilizziamo l'URL senza parametri
    canonicalUrl = currentUrl;
  } else {
    // Per altre lingue, l'URL canonico include il parametro della lingua
    canonicalUrl = `${currentUrl}?lng=${currentLanguage}`;
  }
  
  // Rimuove eventuali meta tag esistenti per evitare duplicati
  const cleanupMetaTags = () => {
    // Rimuove i meta tag OpenGraph
    document.querySelectorAll('meta[property^="og:"]').forEach(el => el.remove());
    
    // Rimuove i meta tag Twitter
    document.querySelectorAll('meta[name^="twitter:"]').forEach(el => el.remove());
    
    // Rimuove il canonical esistente
    document.querySelectorAll('link[rel="canonical"]').forEach(el => el.remove());
    
    // Rimuove gli alternate hreflang
    document.querySelectorAll('link[rel="alternate"][hreflang]').forEach(el => el.remove());
    
    // Rimuove i meta di cache-control (per evitare conflitti)
    document.querySelectorAll('meta[http-equiv="Cache-Control"]').forEach(el => el.remove());
    
    // Preserviamo il viewport originale se esiste
    const existingViewport = document.querySelector('meta[name="viewport"]');
    if (existingViewport) {
      existingViewport.setAttribute('content', 'width=device-width, initial-scale=1, maximum-scale=5, viewport-fit=cover');
    }
    
    // Rimuove theme-color (colore della barra dei browser mobile)
    document.querySelectorAll('meta[name="theme-color"]').forEach(el => el.remove());
  };
  
  // Crea e aggiunge un meta tag
  const createMetaTag = (attrs: Record<string, string>) => {
    const meta = document.createElement('meta');
    Object.entries(attrs).forEach(([key, value]) => {
      meta.setAttribute(key, value);
    });
    document.head.appendChild(meta);
  };
  
  // Crea e aggiunge un link tag
  const createLinkTag = (attrs: Record<string, string>) => {
    const link = document.createElement('link');
    Object.entries(attrs).forEach(([key, value]) => {
      link.setAttribute(key, value);
    });
    document.head.appendChild(link);
  };
  
  // Crea un link tag di preload con attributo 'as'
  const createPreloadLink = (href: string, as: string) => {
    const link = document.createElement('link');
    link.setAttribute('rel', 'preload');
    link.setAttribute('href', href);
    link.setAttribute('as', as);
    document.head.appendChild(link);
  };

  useEffect(() => {
    // Pulisce i meta tag esistenti
    cleanupMetaTags();
    
    // Aggiorna il titolo della pagina
    document.title = finalTitle;
    
    // Meta tag OpenGraph di base
    createMetaTag({ property: 'og:title', content: finalTitle });
    createMetaTag({ property: 'og:description', content: finalDescription });
    createMetaTag({ property: 'og:type', content: type });
    createMetaTag({ property: 'og:url', content: canonicalUrl });
    createMetaTag({ property: 'og:image', content: `${baseUrl}${finalImageUrl}` });
    createMetaTag({ property: 'og:site_name', content: 'Auralis' });
    createMetaTag({ property: 'og:locale', content: currentLanguage === 'it' ? 'it_IT' : 'en_US' });
    
    // Meta tag OpenGraph aggiuntivi per articoli
    if (type === 'article') {
      if (publishedTime) {
        createMetaTag({ property: 'article:published_time', content: publishedTime });
      }
      if (modifiedTime) {
        createMetaTag({ property: 'article:modified_time', content: modifiedTime });
      }
      if (authorName) {
        createMetaTag({ property: 'article:author', content: authorName });
      }
      
      // Aggiungiamo anche tag per il contentType come sezione
      if (contentType) {
        createMetaTag({ property: 'article:section', content: contentType });
      }
    }
    
    // Aggiungi altre versioni linguistiche come alternative
    createMetaTag({ property: 'og:locale:alternate', content: currentLanguage === 'it' ? 'en_US' : 'it_IT' });
    
    // Meta tag Twitter
    createMetaTag({ name: 'twitter:card', content: 'summary_large_image' });
    createMetaTag({ name: 'twitter:title', content: finalTitle });
    createMetaTag({ name: 'twitter:description', content: finalDescription });
    createMetaTag({ name: 'twitter:image', content: `${baseUrl}${finalImageUrl}` });
    createMetaTag({ name: 'twitter:url', content: canonicalUrl });
    
    // Meta tag per il controllo della cache e la compatibilità
    createMetaTag({ name: 'viewport', content: 'width=device-width, initial-scale=1, maximum-scale=5, viewport-fit=cover' });
    createMetaTag({ name: 'theme-color', content: '#8A65F0' }); // Colore principale dell'app
    createMetaTag({ 'http-equiv': 'X-UA-Compatible', content: 'IE=edge' });
    
    // Meta tag cache - aiuta nella gestione delle versioni e nelle prestazioni
    if (contentType === 'meditation' || contentType === 'exercise' || contentType === 'resource') {
      // Contenuto non frequentemente aggiornato - può essere memorizzato nella cache più a lungo
      createMetaTag({ 'http-equiv': 'Cache-Control', content: 'max-age=86400, public' }); // 24 ore
    } else {
      // Contenuto dinamico - cache più breve
      createMetaTag({ 'http-equiv': 'Cache-Control', content: 'max-age=3600, public' }); // 1 ora
    }
    
    // URL canonico
    createLinkTag({ rel: 'canonical', href: canonicalUrl });
    
    // Link di preconnessione e prefetch per migliorare le prestazioni
    // Preconnessione alle CDN e API essenziali
    createLinkTag({ rel: 'preconnect', href: 'https://fonts.googleapis.com' });
    
    // Aggiunta manuale dell'attributo crossorigin
    const fontsCrossOrigin = document.createElement('link');
    fontsCrossOrigin.setAttribute('rel', 'preconnect');
    fontsCrossOrigin.setAttribute('href', 'https://fonts.gstatic.com');
    fontsCrossOrigin.setAttribute('crossorigin', '');
    document.head.appendChild(fontsCrossOrigin);
    
    // Preload delle risorse critiche usando il metodo specializzato
    if (finalImageUrl && finalImageUrl !== '/app-image.png') {
      createPreloadLink(`${baseUrl}${finalImageUrl}`, 'image');
    } else {
      // Se non è specificata un'immagine personalizzata, preload dell'immagine predefinita
      createPreloadLink(`${baseUrl}/app-image.png`, 'image');
    }
    
    // Attributi hreflang per SEO multilingua - ottimizzati per riflettere la politica dei canonici
    // Versione italiana - senza parametri lng per la lingua principale
    createLinkTag({ rel: 'alternate', hreflang: 'it', href: `${baseUrl}${pathname}` });
    
    // Versione inglese - con parametro lng
    createLinkTag({ rel: 'alternate', hreflang: 'en', href: `${baseUrl}${pathname}?lng=en` });
    
    // Versione x-default - utilizziamo la versione italiana come default
    createLinkTag({ rel: 'alternate', hreflang: 'x-default', href: `${baseUrl}${pathname}` });
    
    // Pulizia al momento di smontare il componente
    return () => {
      // Non ripuliamo i meta tag quando il componente viene smontato perché
      // potrebbero essere utili per l'indicizzazione anche quando il componente non è più attivo
    };
  }, [finalTitle, finalDescription, canonicalUrl, type, contentType, contentObject, currentLanguage]);

  // Questo componente non renderizza nulla
  return null;
};

export default SocialMetaTags;