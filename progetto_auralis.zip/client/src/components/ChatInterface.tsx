import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useChat } from '@/hooks/useChat';
import { type ChatMessage, type Suggestion } from '@/lib/types';
import { useAuth } from '@/lib/auth-context';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';
import { useTranslation } from 'react-i18next';
import { useStripe } from '@/lib/stripe-context';

// I suggerimenti verranno importati in base alla lingua

// Non abbiamo più bisogno di memorizzare lo stato dei suggerimenti
// in quanto viene calcolato automaticamente in base ai messaggi presenti

const ChatInterface: React.FC = () => {
  // Definizione stati e riferimenti
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [language, setLanguage] = useState('');
  
  // Hooks per autenticazione, notifiche e traduzione
  const { isAdmin, hasReachedRequestLimit, incrementDailyUsageCount, dailyUsageCount } = useAuth();
  const { toast } = useToast();
  const { t, i18n } = useTranslation();
  const { isSubscriptionActive } = useStripe();
  
  // Custom hook per la chat
  const { messages, isLoading, sendMessage, resetChat } = useChat();
  
  // Memorizza la lingua corrente
  useEffect(() => {
    setLanguage(i18n.language);
  }, [i18n.language]);
  
  // Gestisce il cambio di lingua
  useEffect(() => {
    // Funzione per gestire il cambio lingua
    const handleLanguageChange = () => {
      console.log("Language changed in ChatInterface:", i18n.language);
      
      // Quando la lingua cambia, resetta la chat
      resetChat();
      
      // Notifica all'utente del cambio di lingua e reset della chat
      toast({
        title: t('chat.languageChanged', 'Lingua cambiata'),
        description: t('chat.chatReset', 'La chat è stata resettata per utilizzare la nuova lingua.'),
      });
    };
    
    // Ascolta l'evento di cambio lingua
    i18n.on('languageChanged', handleLanguageChange);
    
    // Pulizia dell'effetto
    return () => {
      i18n.off('languageChanged', handleLanguageChange);
    };
  }, [i18n, resetChat, toast, t]);
  
  // Suggerimenti basati sulla lingua corrente
  const DEFAULT_SUGGESTIONS: Suggestion[] = [
    { id: '1', text: t('chat.suggestions.anxiety', 'Come posso gestire l\'ansia?') },
    { id: '2', text: t('chat.suggestions.breathing', 'Suggerisci un esercizio di respirazione') },
    { id: '3', text: t('chat.suggestions.sleep', 'Aiutami a dormire meglio') },
    { id: '4', text: t('chat.suggestions.overwhelmed', 'Mi sento sopraffatto') },
    { id: '5', text: t('chat.suggestions.mood', 'Come posso migliorare il mio umore?') },
    { id: '6', text: t('chat.suggestions.negative', 'Consigli per combattere i pensieri negativi') },
    { id: '7', text: t('chat.suggestions.relaxation', 'Tecniche di rilassamento rapide') },
    { id: '8', text: t('chat.suggestions.stress', 'Come affrontare una situazione stressante') },
    { id: '9', text: t('chat.suggestions.selfesteem', 'Esercizio per l\'autostima') },
    { id: '10', text: t('chat.suggestions.panic', 'Strategie per gestire il panico') }
  ];
  
  // I suggerimenti sono sempre visibili
  const showSuggestions = true;
  
  // Funzione per scrollare al fondo della chat
  const scrollToBottom = useCallback(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  }, [messagesEndRef]);
  
  // Effect per lo scroll automatico quando cambiano i messaggi
  useEffect(() => {
    // Eseguiamo lo scroll immediatamente
    scrollToBottom();
    
    // E poi con un piccolo ritardo per assicurarci che il contenuto sia stato renderizzato completamente
    const timeoutId = setTimeout(scrollToBottom, 100);
    
    return () => clearTimeout(timeoutId);
  }, [messages, scrollToBottom]);
  
  // Effect per scrollare automaticamente anche dopo il caricamento completo dei componenti
  useEffect(() => {
    // Scroll dopo il rendering completo
    const timeoutId = setTimeout(scrollToBottom, 500);
    return () => clearTimeout(timeoutId);
  }, [scrollToBottom]);
  
  // Funzione per resettare la chat
  const handleResetChat = useCallback(() => {
    resetChat();
  }, [resetChat]);

  // Handler per l'invio del messaggio dal form
  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    
    // Ottieni lo stato di abbonamento attivo
    const hasPremium = isSubscriptionActive();
    console.log("Chat - Abbonamento attivo:", hasPremium);
    
    // Controllo se l'utente ha raggiunto il limite giornaliero (solo per non abbonati e non admin)
    if (!isAdmin && !hasPremium && hasReachedRequestLimit) {
      toast({
        title: t('chat.toast.limitTitle', "Limite giornaliero raggiunto"),
        description: t('chat.toast.limitDescription', "Hai raggiunto il limite di utilizzo giornaliero di 3 richieste. Passa al piano premium per continuare."),
        variant: "destructive"
      });
      return;
    }
    
    if (inputValue.trim() && !isLoading) {
      // Incrementiamo il contatore delle richieste solo se non è un admin e non ha premium
      if (!isAdmin && !hasPremium) {
        incrementDailyUsageCount();
      }
      
      // Invia il messaggio
      sendMessage(inputValue);
      setInputValue('');
      
      // Scorri alla fine dopo l'invio del messaggio
      scrollToBottom();
      // Assicuriamoci che scorra anche dopo che la risposta è arrivata
      setTimeout(scrollToBottom, 500);
    }
  }, [inputValue, isLoading, sendMessage, isAdmin, hasReachedRequestLimit, incrementDailyUsageCount, toast, scrollToBottom, t, isSubscriptionActive]);
  
  // Handler per la selezione di un suggerimento
  const handleSelectSuggestion = useCallback((suggestion: string) => {
    // Ottieni lo stato di abbonamento attivo
    const hasPremium = isSubscriptionActive();
    console.log("Chat Suggestion - Abbonamento attivo:", hasPremium);
    
    // Controllo se l'utente ha raggiunto il limite giornaliero (solo per non abbonati e non admin)
    if (!isAdmin && !hasPremium && hasReachedRequestLimit) {
      toast({
        title: t('chat.toast.limitTitle', "Limite giornaliero raggiunto"),
        description: t('chat.toast.limitDescription', "Hai raggiunto il limite di utilizzo giornaliero di 3 richieste. Passa al piano premium per continuare."),
        variant: "destructive"
      });
      return;
    }
    
    if (!isLoading) {
      // Incrementiamo il contatore delle richieste solo se non è un admin e non ha premium
      if (!isAdmin && !hasPremium) {
        incrementDailyUsageCount();
      }
      
      // Invia il messaggio selezionato
      sendMessage(suggestion);
      
      // Scorri alla fine dopo l'invio del messaggio
      scrollToBottom();
      // Assicuriamoci che scorra anche dopo che la risposta è arrivata
      setTimeout(scrollToBottom, 500);
    }
  }, [isLoading, sendMessage, isAdmin, hasReachedRequestLimit, incrementDailyUsageCount, toast, scrollToBottom, t, isSubscriptionActive]);

  // Determina se mostrare il banner dei limiti
  const hasPremium = isSubscriptionActive();
  console.log("Chat UI - Abbonamento attivo:", hasPremium);
  
  return (
    <>
      {/* Banner informativo sul limite di utilizzo - mostra solo se non admin e non premium */}
      {!isAdmin && !hasPremium && (
        <div className={`mb-4 p-3 rounded-lg shadow-md bg-white border ${hasReachedRequestLimit ? 'border-rose-200' : 'border-teal-200'}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className={`rounded-full w-8 h-8 flex items-center justify-center ${hasReachedRequestLimit ? 'bg-rose-100 text-rose-600' : 'bg-teal-100 text-teal-600'}`}>
                <i className={hasReachedRequestLimit ? 'ri-error-warning-line' : 'ri-information-line'}></i>
              </div>
              <div className="ml-3">
                <h3 className={`text-sm font-medium ${hasReachedRequestLimit ? 'text-rose-800' : 'text-teal-800'}`}>
                  {hasReachedRequestLimit 
                    ? t('chat.limit.reached', "Limite giornaliero raggiunto") 
                    : t('chat.limit.counter', "{{count}}/3 richieste utilizzate oggi", { count: dailyUsageCount })}
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  {hasReachedRequestLimit 
                    ? t('chat.limit.subscribe', "Abbonati per richieste illimitate") 
                    : t('chat.limit.freeUsers', "Gli utenti gratuiti hanno 3 richieste al giorno")}
                </p>
              </div>
            </div>
            <Link to="/subscription">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white shadow-sm text-xs h-8">
                {hasReachedRequestLimit 
                  ? t('chat.limit.unlock', "Sblocca accesso") 
                  : t('chat.limit.upgrade', "Passa a Premium")}
              </Button>
            </Link>
          </div>
        </div>
      )}
      
      {/* Banner premium per utenti abbonati */}
      {!isAdmin && hasPremium && (
        <div className="mb-4 p-3 rounded-lg shadow-md bg-white border border-purple-200">
          <div className="flex items-center">
            <div className="rounded-full w-8 h-8 flex items-center justify-center bg-purple-100 text-purple-600">
              <i className="ri-vip-crown-fill"></i>
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-purple-800">
                {t('chat.premium.title', "Accesso Premium Illimitato")}
              </h3>
              <p className="text-xs text-gray-500 mt-0.5">
                {t('chat.premium.description', "Grazie per essere un utente premium! Puoi inviare richieste illimitate.")}
              </p>
            </div>
          </div>
        </div>
      )}
      
      <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-md overflow-hidden mb-6 border border-teal-100">
        <div className="p-4 bg-gradient-to-r from-teal-500 to-cyan-500 text-white">
          <h2 className="font-bold mb-1 text-lg flex items-center">
            <i className="ri-chat-smile-3-line mr-2"></i>
            {t('chat.title', 'Supporto Cognitivo-Comportamentale')}
          </h2>
          <p className="text-sm opacity-90 text-teal-50">{t('chat.subtitle', 'Parliamo di cosa ti preoccupa oggi')}</p>
        </div>
        
        {/* Chat Messages Container */}
        <div className="p-2 h-80 overflow-y-auto flex flex-col space-y-2 bg-gradient-to-b from-teal-50/40 to-white/80 scrollbar-thin scrollbar-thumb-teal-200 scrollbar-track-transparent">
          {messages.map((message) => (
            <div 
              key={message.id} 
              className={`flex items-start ${message.role === 'user' ? 'justify-end' : ''}`}
            >
              {message.role === 'assistant' && (
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-teal-500 to-cyan-500 flex-shrink-0 flex items-center justify-center text-white text-xs shadow-sm">
                  <i className="ri-robot-line text-sm"></i>
                </div>
              )}
              
              <div className={`${message.role === 'user' 
                ? 'mr-2 bg-gradient-to-r from-teal-500 to-teal-600 text-white rounded-tr-none shadow-md' 
                : 'ml-2 bg-white text-neutral-800 rounded-tl-none shadow-sm border border-teal-100/60'} 
                p-3 rounded-lg max-w-xs sm:max-w-md text-sm`}
              >
                <p className="whitespace-pre-wrap leading-relaxed">{message.content}</p>
              </div>
              
              {message.role === 'user' && (
                <div className="w-8 h-8 rounded-full bg-teal-100 flex-shrink-0 flex items-center justify-center text-xs shadow-sm">
                  <i className="ri-user-line text-teal-600 text-sm"></i>
                </div>
              )}
            </div>
          ))}
          
          {/* Bot is typing indicator */}
          {isLoading && (
            <div className="flex items-start">
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-teal-500 to-cyan-500 flex-shrink-0 flex items-center justify-center text-white text-xs shadow-sm">
                <i className="ri-robot-line text-sm"></i>
              </div>
              <div className="ml-2 bg-white p-3 rounded-lg rounded-tl-none text-sm shadow-sm border border-teal-100/60">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 rounded-full bg-teal-400 animate-pulse"></div>
                  <div className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                  <div className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                </div>
              </div>
            </div>
          )}
          
          {/* Elemento per lo scroll automatico - posizionato alla fine */}
          <div ref={messagesEndRef} className="h-0 w-full mt-1" />
        </div>
        
        {/* Chat Input and Actions */}
        <div className="border-t border-teal-100 py-2 px-3 bg-white">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-medium text-teal-700">
              {messages.length > 1 
                ? t('chat.messageCount', "{{count}} messaggi", { count: messages.length - 1 }) 
                : t('chat.startConversation', 'Inizia una conversazione')}
            </h3>
            
            {/* Pulsante di reset visibile solo se ci sono messaggi (oltre al benvenuto) */}
            {messages.length > 1 && (
              <Button
                onClick={handleResetChat}
                variant="outline" 
                size="sm"
                className="text-xs text-rose-600 border-rose-200 hover:bg-rose-50 h-7 text-[11px] shadow-sm"
              >
                <i className="ri-delete-bin-line mr-1"></i>
                {t('chat.resetButton', 'Reset Chat')}
              </Button>
            )}
          </div>
          
          <form onSubmit={handleSubmit} className="flex items-center mt-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={t('chat.inputPlaceholder', "Scrivi un messaggio...")}
              className="chat-input flex-grow rounded-r-none border-teal-200 focus:border-teal-400 focus:ring-teal-400 focus:ring-1 text-sm h-10 shadow-sm"
              disabled={isLoading}
              autoComplete="off"
            />
            <Button 
              type="submit" 
              className="bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white rounded-l-none h-10 px-4 shadow-sm"
              disabled={isLoading || !inputValue.trim()}
            >
              <i className="ri-send-plane-fill mr-1"></i>
              <span className="text-sm">{t('chat.sendButton', 'Invia')}</span>
            </Button>
          </form>
        </div>
      </div>
      
      {/* Suggerimenti integrati direttamente in ChatInterface */}
      {showSuggestions && (
        <div className="suggestions-chips mb-8 bg-white/70 backdrop-blur-sm rounded-xl p-4 border border-teal-100 shadow-md">
          <h3 className="text-sm font-bold text-teal-800 mb-3 flex items-center">
            <i className="ri-lightbulb-line mr-2 text-teal-600"></i>
            {t('chat.suggestionsTitle', 'Suggerimenti per iniziare')}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[200px] overflow-y-auto pr-1">
            {DEFAULT_SUGGESTIONS.map((suggestion) => (
              <button
                key={suggestion.id}
                onClick={() => handleSelectSuggestion(suggestion.text)}
                className="bg-gradient-to-r from-white to-teal-50 border border-teal-100 text-teal-800 text-sm py-3 px-4 rounded-lg hover:shadow-md hover:border-teal-200 transition-all shadow-sm flex items-center"
                disabled={isLoading}
              >
                <span className="mr-2 text-teal-500 flex-shrink-0">
                  <i className="ri-question-line"></i>
                </span>
                <span className="text-left">{suggestion.text}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </>
  );
};

export default ChatInterface;
