import React, { useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';

export function AdminPanel() {
  const { isAdmin, setAdmin, adminPassword, setAdminPassword } = useAuth();
  const [newPassword, setNewPassword] = useState('');
  const { toast } = useToast();
  const { t, i18n } = useTranslation();
  const isEnglish = i18n.language === 'en';

  const handlePasswordChange = () => {
    if (newPassword.trim().length < 3) {
      toast({
        title: isEnglish ? "Password too short" : "Password troppo corta",
        description: isEnglish ? "The password must contain at least 3 characters" : "La password deve contenere almeno 3 caratteri",
        variant: "destructive",
      });
      return;
    }
    
    setAdminPassword(newPassword);
    setNewPassword('');
    
    toast({
      title: isEnglish ? "Password updated" : "Password aggiornata",
      description: isEnglish ? "The new password has been saved successfully" : "La nuova password è stata salvata con successo",
      variant: "default",
    });
  };

  return (
    <Card className="w-full max-w-md mx-auto mt-4 mb-8 bg-neutral-50 border-amber-500">
      <CardHeader className="bg-gradient-to-r from-amber-500 to-amber-600 text-white">
        <CardTitle className="flex items-center">
          <i className="ri-admin-fill mr-2"></i> {isEnglish ? 'Administration Panel' : 'Pannello di Amministrazione'}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6 pb-4">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="admin-toggle" className="text-sm font-medium">
                {isEnglish ? 'Admin Mode' : 'Modalità Admin'}
              </Label>
              <p className="text-xs text-neutral-500 mt-1">
                {isEnglish 
                  ? 'Administrator mode with access to all premium content' 
                  : 'Modalità amministratore con accesso a tutti i contenuti premium'}
              </p>
            </div>
            <Switch
              id="admin-toggle"
              checked={isAdmin}
              onCheckedChange={setAdmin}
            />
          </div>
          
          <div className="space-y-3 border-t border-neutral-200 pt-4 mt-2">
            <Label htmlFor="admin-password" className="text-sm font-medium">
              {isEnglish ? 'Change Admin Password' : 'Cambia Password Admin'}
            </Label>
            <p className="text-xs text-neutral-500 mb-3">
              {isEnglish ? 'Current password: ' : 'Password attuale: '} 
              <span className="font-mono">{adminPassword}</span>
            </p>
            <div className="flex gap-2">
              <Input
                id="admin-password"
                type="text"
                placeholder={isEnglish ? 'New password' : 'Nuova password'}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="flex-1"
              />
              <Button 
                onClick={handlePasswordChange}
                className="bg-amber-500 hover:bg-amber-600"
                size="sm"
              >
                {isEnglish ? 'Save' : 'Salva'}
              </Button>
            </div>
            <p className="text-xs text-neutral-500 mt-1">
              {isEnglish 
                ? 'The password will be saved on your device and will remain valid even after you close your browser.' 
                : 'La password verrà salvata sul dispositivo e rimarrà valida anche dopo aver chiuso il browser.'}
            </p>
          </div>
          
          <div className="bg-blue-50 border border-blue-100 rounded-md p-3 mt-2">
            <p className="text-sm text-blue-800">
              <i className="ri-information-line mr-1"></i> 
              <strong>{isEnglish ? 'Tip:' : 'Suggerimento:'}</strong> 
              {isEnglish 
                ? ' You can activate admin mode at any time by clicking 5 times on the copyright symbol in the footer.' 
                : ' Puoi attivare la modalità admin in qualsiasi momento cliccando 5 volte sul simbolo copyright nel footer.'}
            </p>
          </div>

          <div className="pt-2 mt-4 border-t border-neutral-200">
            <p className="text-xs text-neutral-500 text-center italic">
              Auralis - {isEnglish ? 'Administration Panel Version 1.0' : 'Pannello Amministrativo Versione 1.0'}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}