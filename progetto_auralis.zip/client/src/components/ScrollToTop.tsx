import { useEffect, useState } from 'react';

/**
 * Componente che si assicura che la pagina inizi sempre dall'alto 
 * quando si naviga tra diverse rotte
 */
export function ScrollToTop() {
  const [location, setLocation] = useState(window.location.pathname);
  
  // Monitora i cambiamenti di percorso con più listener
  useEffect(() => {
    const handleRouteChange = () => {
      setLocation(window.location.pathname);
    };
    
    // Monitora diversi eventi che potrebbero indicare un cambio di route
    window.addEventListener('popstate', handleRouteChange);
    window.addEventListener('route-changed', handleRouteChange);
    
    // Intercetta anche i click sui link
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const link = target.closest('a');
      if (link && link.getAttribute('href')?.startsWith('/')) {
        // Aggiorna lo stato senza aspettare il cambio effettivo di URL
        setTimeout(handleRouteChange, 0);
      }
    };
    
    document.addEventListener('click', handleClick);
    
    return () => {
      window.removeEventListener('popstate', handleRouteChange);
      window.removeEventListener('route-changed', handleRouteChange);
      document.removeEventListener('click', handleClick);
    };
  }, []);

  useEffect(() => {
    // Funzione per forzare lo scroll all'inizio in vari modi
    const scrollToTopForce = () => {
      // Attenzione particolare alla homepage
      const isHomePage = window.location.pathname === '/';
      
      // Usa smooth scroll solo per pagine interne, non per la home
      const scrollBehavior: ScrollBehavior = isHomePage ? 'auto' : 'smooth';
      
      // Cerca e scorre all'elemento con id="page-top"
      const pageTopEl = document.getElementById('page-top');
      if (pageTopEl) {
        pageTopEl.scrollIntoView({ behavior: 'auto', block: 'start' });
      }
      
      // Metodo base con priorità
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: 'auto'  // Usiamo 'auto' invece di 'smooth' per un effetto immediato
      });
      
      // Safari e vecchi browser
      document.body.scrollTop = 0;
      // Chrome, Firefox, IE e Opera
      document.documentElement.scrollTop = 0;
      
      // Forza il reset dello scroll anche per elementi annidati
      Array.from(document.querySelectorAll('.page-container')).forEach(el => {
        if (el instanceof HTMLElement) {
          el.scrollTop = 0;
        }
      });
      
      // Forza lo scroll anche per l'app-root
      const appRoot = document.getElementById('root');
      if (appRoot instanceof HTMLElement) {
        appRoot.scrollTop = 0;
      }
      
      // Forza lo scroll per qualsiasi elemento overflow
      Array.from(document.querySelectorAll('*')).forEach(el => {
        if (el instanceof HTMLElement && 
            (getComputedStyle(el).overflow === 'auto' || 
             getComputedStyle(el).overflow === 'scroll')) {
          el.scrollTop = 0;
        }
      });
    };

    // Esegui immediatamente al cambio di route
    scrollToTopForce();
    
    // Esegui dopo il rendering iniziale con timeout più lungo e intervalli più frequenti
    // Usiamo una serie di timeout a tempi diversi per assicurarci che funzioni
    const timeoutIds = [
      setTimeout(() => scrollToTopForce(), 0),
      setTimeout(() => scrollToTopForce(), 50),
      setTimeout(() => scrollToTopForce(), 100),
      setTimeout(() => scrollToTopForce(), 200), 
      setTimeout(() => scrollToTopForce(), 300),
      setTimeout(() => scrollToTopForce(), 500),
      setTimeout(() => scrollToTopForce(), 1000)
    ];
    
    // Inoltre, esegui dopo il caricamento completo della pagina
    const loadHandler = () => {
      scrollToTopForce();
      // Anche dopo il caricamento, facciamo altri tentativi
      setTimeout(scrollToTopForce, 100);
      setTimeout(scrollToTopForce, 300);
      setTimeout(scrollToTopForce, 500);
    };
    
    window.addEventListener('load', loadHandler);

    // Reset più aggressivo per la homepage
    if (location === '/') {
      // Se siamo nella homepage, forziamo lo scroll anche dopo che la pagina è stata caricata
      for (let i = 1; i <= 10; i++) {
        timeoutIds.push(setTimeout(() => scrollToTopForce(), i * 200));
      }
    }

    return () => {
      timeoutIds.forEach(id => clearTimeout(id));
      window.removeEventListener('load', loadHandler);
    };
  }, [location]);

  return null;
}

export default ScrollToTop;