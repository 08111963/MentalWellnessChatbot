import React, { useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { Button } from '@/components/ui/button';
import HamburgerMenu from '@/components/HamburgerMenu';
import AuthDialog from '@/components/AuthDialog';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'wouter';
import { isProblematicPage } from '@/lib/home-navigation';

interface SimpleHeaderProps {
  title?: string;
}

// Header semplificato senza selettori di lingua per la pagina di gestione abbonamenti
const SimpleHeader: React.FC<SimpleHeaderProps> = ({ title }) => {
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [location, setLocation] = useLocation();
  const isHomePage = location === '/';
  const { isAuthenticated, logout } = useAuth();
  const { t } = useTranslation();
  const isInProblematicPage = isProblematicPage();
  
  // Funzione ottimizzata per tornare alla home
  const handleHomeClick = (e: React.MouseEvent) => {
    e.preventDefault();
    
    // Se siamo in una pagina problematica, forza il refresh
    if (isInProblematicPage) {
      sessionStorage.setItem('force_home_navigation', 'true');
      window.location.href = '/';
      return;
    }
    
    // Altrimenti usa il router per navigazione veloce
    setLocation('/');
  };
  
  const handleLogout = () => {
    logout();
    // Refresh necessario per aggiornare lo stato dopo il logout
    window.location.reload();
  };
  
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-5xl mx-auto px-4 py-4 flex justify-between items-center">
        {/* Logo e nome */}
        <div className="flex items-center space-x-2">
          {isHomePage ? (
            <>
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <i className="ri-mental-health-line text-white text-xl"></i>
              </div>
              <h1 className="font-nunito font-bold text-2xl text-neutral-800">
                {title || "Auralis"}
              </h1>
            </>
          ) : (
            <a 
              href="/" 
              className="flex items-center space-x-2 transition-transform hover:scale-105"
              onClick={handleHomeClick}
              aria-label="Torna alla Home"
            >
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <i className="ri-mental-health-line text-white text-xl"></i>
              </div>
              <h1 className="font-nunito font-bold text-2xl text-neutral-800">
                {title || "Auralis"}
              </h1>
            </a>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          {/* Pulsante Home visibile solo quando non siamo nella home */}
          {!isHomePage && (
            <a 
              href="/"
              className="px-3 py-1.5 bg-purple-600 text-white text-sm rounded-md font-medium hover:bg-purple-700 shadow-md inline-flex items-center" 
              onClick={handleHomeClick}
              aria-label="Torna alla Home"
            >
              <i className="ri-home-4-line mr-1.5"></i> Home
            </a>
          )}
          
          {/* Pulsante Login/Logout */}
          {isAuthenticated ? (
            <Button 
              variant="outline" 
              size="sm"
              className="px-3 py-1.5 border-indigo-500 text-indigo-600 hover:bg-indigo-50"
              onClick={handleLogout}
            >
              <i className="ri-logout-box-line mr-1.5"></i> {t('auth.logout')}
            </Button>
          ) : (
            <Button 
              variant="outline" 
              size="sm"
              className="px-3 py-1.5 border-indigo-500 text-indigo-600 hover:bg-indigo-50"
              onClick={() => setAuthDialogOpen(true)}
            >
              <i className="ri-login-box-line mr-1.5"></i> {t('auth.login')}
            </Button>
          )}
          
          {/* Hamburger Menu */}
          <HamburgerMenu />
          
          {/* Dialog di Autenticazione */}
          <AuthDialog 
            open={authDialogOpen} 
            onOpenChange={setAuthDialogOpen} 
          />
        </div>
      </div>
    </header>
  );
};

export default SimpleHeader;