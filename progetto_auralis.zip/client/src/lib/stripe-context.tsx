import React, { createContext, useContext, ReactNode, useState, useEffect } from 'react';
import { useAuth } from './auth-context';

interface SubscriptionStatus {
  isActive: boolean;
  plan: 'monthly' | 'yearly' | null;
  expiresAt: Date | null;
  customerId: string | null;
  subscriptionId: string | null;
}

interface StripeContextType {
  isLoading: boolean;
  error: string | null;
  subscription: SubscriptionStatus;
  createCheckoutSession: (priceId: string) => Promise<string | null>;
  verifySubscription: (sessionId?: string) => Promise<SubscriptionStatus>;
  isSubscriptionActive: () => boolean;
}

const StripeContext = createContext<StripeContextType | undefined>(undefined);

const SUBSCRIPTION_KEY = 'guida_subscription';
const SESSION_ID_KEY = 'auralis_session_id'; // La chiave deve corrispondere a quella usata in PaymentSuccessPage.tsx

export function StripeProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth(); // Ottenere l'utente dall'auth context
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [subscription, setSubscription] = useState<SubscriptionStatus>(() => {
    try {
      // Priorità 0: Utente autenticato con abbonamento presente dal database
      if (user && user.isPremium) {
        console.log('Utente autenticato con abbonamento premium dal database:', user);
        
        // Calcola la data di scadenza
        let expiresAt: Date | null = null;
        if (user.subscriptionEnd) {
          expiresAt = new Date(user.subscriptionEnd);
        } else if (user.subscriptionStart) {
          expiresAt = new Date(user.subscriptionStart);
          if (user.subscriptionPlan === 'yearly') {
            expiresAt.setFullYear(expiresAt.getFullYear() + 1);
          } else {
            expiresAt.setMonth(expiresAt.getMonth() + 1);
          }
        }
        
        return {
          isActive: user.isPremium,
          plan: user.subscriptionPlan as 'monthly' | 'yearly' | null,
          expiresAt: expiresAt,
          customerId: user.stripeCustomerId || null,
          subscriptionId: user.stripeSubscriptionId || null
        };
      }
      
      // Priorità 1: Verifica se esiste lo stato di abbonamento standard
      const savedSubscription = localStorage.getItem(SUBSCRIPTION_KEY);
      if (savedSubscription) {
        const parsed = JSON.parse(savedSubscription);
        // Converti la stringa di data in oggetto Date
        if (parsed.expiresAt) {
          parsed.expiresAt = new Date(parsed.expiresAt);
        }
        console.log('Trovate informazioni abbonamento in formato standard:', parsed);
        return parsed;
      }
      
      // Priorità 2: Verifica il formato auralis_ (usato nella pagina di successo)
      const isPremium = localStorage.getItem('auralis_premium') === 'true';
      const plan = localStorage.getItem('auralis_plan') as 'monthly' | 'yearly' | null;
      const subscriptionId = localStorage.getItem('auralis_subscription_id');
      const customerId = localStorage.getItem('auralis_customer_id');
      const subscriptionDateStr = localStorage.getItem('auralis_subscription_date');
      const sessionId = localStorage.getItem(SESSION_ID_KEY);
      
      // Salva l'ID della sessione se è disponibile
      if (sessionId) {
        console.log('Trovato ID sessione salvato:', sessionId);
      }
      
      if (isPremium && plan && subscriptionId) {
        console.log('Trovate informazioni abbonamento in formato auralis_');
        
        // Calcola data di scadenza basata sul piano
        let expiresAt: Date | null = null;
        if (subscriptionDateStr) {
          const startDate = new Date(subscriptionDateStr);
          expiresAt = new Date(startDate);
          
          if (plan === 'yearly') {
            expiresAt.setFullYear(startDate.getFullYear() + 1);
          } else {
            expiresAt.setMonth(startDate.getMonth() + 1);
          }
        }
        
        // Crea oggetto abbonamento e salvalo anche nel formato standard
        const subscription: SubscriptionStatus = {
          isActive: true,
          plan,
          expiresAt,
          customerId,
          subscriptionId
        };
        
        // Salva nel formato standard per future sessioni
        localStorage.setItem(SUBSCRIPTION_KEY, JSON.stringify(subscription));
        
        return subscription;
      }
    } catch (e) {
      console.error('Errore nel parsing della sottoscrizione salvata:', e);
    }
    
    // Stato predefinito se non c'è niente in localStorage
    return {
      isActive: false,
      plan: null,
      expiresAt: null,
      customerId: null,
      subscriptionId: null
    };
  });

  const createCheckoutSession = async (priceId: string): Promise<string | null> => {
    setIsLoading(true);
    setError(null);
    console.log('Stripe context: creazione sessione per priceId:', priceId);

    try {
      console.log('Stripe context: invio richiesta API...');
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ priceId }),
      });

      console.log('Stripe context: risposta ricevuta, status:', response.status);
      
      if (!response.ok) {
        console.error('Stripe context: risposta non valida. Status:', response.status);
        let errorMessage = 'Errore durante la creazione della sessione di pagamento';
        
        try {
          const errorData = await response.json();
          console.error('Stripe context: dettagli errore:', errorData);
          errorMessage = errorData.message || errorMessage;
        } catch (e) {
          console.error('Stripe context: impossibile analizzare la risposta di errore');
        }
        
        throw new Error(errorMessage);
      }

      console.log('Stripe context: analisi risposta...');
      const data = await response.json();
      console.log('Stripe context: dati ricevuti:', data);
      
      if (!data.url) {
        console.error('Stripe context: URL mancante nella risposta');
        throw new Error('URL di checkout mancante nella risposta');
      }
      
      return data.url;
    } catch (err) {
      console.error('Errore Stripe completo:', err);
      setError(err instanceof Error ? err.message : "Si è verificato un errore durante l'elaborazione del pagamento");
      return null;
    } finally {
      console.log('Stripe context: operazione completata');
      setIsLoading(false);
    }
  };

  // Verifica se l'abbonamento è attivo
  const isSubscriptionActive = (): boolean => {
    // Debug dettagliato
    console.log('STRIPE DEBUG - subscription:', subscription);
    console.log('STRIPE DEBUG - isActive:', subscription.isActive);
    console.log('STRIPE DEBUG - expiresAt:', subscription.expiresAt);
    
    // Controlla se l'utente è in localStorage
    const userJson = localStorage.getItem('auralis_user');
    const isUserLoggedIn = userJson !== null;
    
    // Se l'utente non è loggato, l'abbonamento non può essere attivo
    if (!isUserLoggedIn) {
      console.log('STRIPE DEBUG - Utente non autenticato, abbonamento inattivo');
      return false;
    }
    
    // Controlla se l'utente è admin
    const isAdmin = localStorage.getItem('auralis_admin') === 'true';
    if (isAdmin) {
      console.log('STRIPE DEBUG - Utente in modalità admin, abbonamento attivo');
      return true;
    }
    
    // Sistema legacy per retrocompatibilità
    const legacyPremium = localStorage.getItem('auralis_premium') === 'true';
    console.log('STRIPE DEBUG - legacyPremium:', legacyPremium);
    
    // Se non c'è un abbonamento o expiresAt è null, proviamo con il sistema legacy
    if (!subscription.isActive || !subscription.expiresAt) {
      return legacyPremium && isUserLoggedIn; // Deve essere sia premium che loggato
    }
    
    // Se la data di scadenza è nel futuro, l'abbonamento è attivo
    const isActive = new Date() < subscription.expiresAt;
    console.log('STRIPE DEBUG - Risultato controllo date:', isActive);
    
    return (isActive || legacyPremium) && isUserLoggedIn; // Ritorna true se uno dei due sistemi indica un abbonamento attivo E l'utente è loggato
  };
  
  // Funzione per verificare lo stato dell'abbonamento
  const verifySubscription = async (sessionId?: string): Promise<SubscriptionStatus> => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Se viene passato un sessionId, lo salviamo per future richieste
      if (sessionId) {
        console.log('Salvataggio session_id:', sessionId);
        localStorage.setItem(SESSION_ID_KEY, sessionId);
      }
      
      // Recuperiamo il session_id salvato
      const lastKnownSession = sessionId || localStorage.getItem(SESSION_ID_KEY);
      
      // Se non abbiamo un ID sessione da nessuna parte, verifichiamo se c'è un abbonamento 
      // già salvato nel localStorage e lo utilizziamo direttamente senza contattare il server
      if (!lastKnownSession) {
        const savedSubscription = localStorage.getItem(SUBSCRIPTION_KEY);
        if (savedSubscription) {
          try {
            const parsedSubscription = JSON.parse(savedSubscription);
            // Converti la stringa di data in oggetto Date se necessario
            if (parsedSubscription.expiresAt && typeof parsedSubscription.expiresAt === 'string') {
              parsedSubscription.expiresAt = new Date(parsedSubscription.expiresAt);
            }
            
            // Verifica se l'abbonamento è ancora valido in base alla data di scadenza
            if (parsedSubscription.isActive && parsedSubscription.expiresAt && new Date() < new Date(parsedSubscription.expiresAt)) {
              console.log('Trovato abbonamento valido nel localStorage, lo utilizzo senza contattare il server:', parsedSubscription);
              setSubscription(parsedSubscription);
              return parsedSubscription;
            }
          } catch (e) {
            console.error('Errore nel parsing della sottoscrizione salvata:', e);
          }
        }
      }
      
      let url = '/api/stripe/verify-session';
      
      // Costruisci l'URL con i parametri appropriati
      const params = new URLSearchParams();
      if (lastKnownSession) {
        params.append('session_id', lastKnownSession);
      }
      
      // Aggiungi i parametri all'URL se ce ne sono
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
      
      console.log('Verifica abbonamento, URL:', url);
      const response = await fetch(url);
      
      if (!response.ok) {
        console.error('Errore verifica sottoscrizione. Status:', response.status);
        
        // Se la verifica fallisce, restituiamo lo stato corrente
        return subscription;
      }
      
      const data = await response.json();
      console.log('Risposta verifica abbonamento:', data);
      
      // Se lo stato non è success, non è una sottoscrizione valida
      if (data.status !== 'success') {
        console.warn('Verifica sottoscrizione: stato non valido', data);
        
        // Se lo stato è inactive, resettiamo l'abbonamento SOLO se non avevamo una sessione in localStorage
        // Questo impedisce di perdere lo stato dell'abbonamento durante il cambio lingua
        if (data.status === 'inactive' && !localStorage.getItem(SUBSCRIPTION_KEY)) {
          console.log('Abbonamento non attivo e nessun dato salvato, resetto stato');
          const inactiveSubscription: SubscriptionStatus = {
            isActive: false,
            plan: null,
            expiresAt: null,
            customerId: null,
            subscriptionId: null
          };
          
          // Aggiorniamo lo stato e salviamo in localStorage
          setSubscription(inactiveSubscription);
          localStorage.setItem(SUBSCRIPTION_KEY, JSON.stringify(inactiveSubscription));
          
          // Rimuoviamo anche ogni legacy storage che potrebbe interferire
          localStorage.removeItem('auralis_premium');
          localStorage.removeItem('auralis_plan');
          localStorage.removeItem('auralis_subscription_id');
          localStorage.removeItem('auralis_customer_id');
          localStorage.removeItem('auralis_subscription_date');
          // NON rimuoviamo SESSION_ID_KEY qui per mantenere consistenza
          
          return inactiveSubscription;
        }
        
        return subscription;
      }
      
      // Calcoliamo la data di scadenza in base al piano
      const now = new Date();
      const expiresAt = new Date(now);
      
      if (data.plan === 'yearly') {
        expiresAt.setFullYear(now.getFullYear() + 1);
      } else {
        expiresAt.setMonth(now.getMonth() + 1);
      }
      
      // Creiamo il nuovo stato di abbonamento
      const newSubscription: SubscriptionStatus = {
        isActive: true,
        plan: data.plan,
        expiresAt,
        customerId: data.customer_id || null,
        subscriptionId: data.subscription_id || null
      };
      
      console.log('Abbonamento verificato e attivo:', newSubscription);
      
      // Se c'è un session_id nella risposta, lo salviamo
      if (data.session_id) {
        localStorage.setItem(SESSION_ID_KEY, data.session_id);
      }
      
      // Salviamo anche i dati nel vecchio formato per retrocompatibilità
      localStorage.setItem('auralis_premium', 'true');
      localStorage.setItem('auralis_plan', data.plan);
      if (data.subscription_id) {
        localStorage.setItem('auralis_subscription_id', data.subscription_id);
      }
      if (data.customer_id) {
        localStorage.setItem('auralis_customer_id', data.customer_id);
      }
      localStorage.setItem('auralis_subscription_date', new Date().toISOString());
      
      // Aggiorniamo lo stato e salviamo in localStorage
      setSubscription(newSubscription);
      localStorage.setItem(SUBSCRIPTION_KEY, JSON.stringify(newSubscription));
      
      return newSubscription;
    } catch (err) {
      console.error('Errore durante la verifica della sottoscrizione:', err);
      setError(err instanceof Error ? err.message : 'Errore durante la verifica della sottoscrizione');
      return subscription;
    } finally {
      setIsLoading(false);
    }
  };
  
  // Aggiorna la sottoscrizione quando cambia l'utente
  useEffect(() => {
    if (user && user.isPremium) {
      console.log('Utente autenticato con abbonamento premium, aggiornamento stato:', user);
      
      // Calcola la data di scadenza
      let expiresAt: Date | null = null;
      if (user.subscriptionEnd) {
        expiresAt = new Date(user.subscriptionEnd);
      } else if (user.subscriptionStart) {
        expiresAt = new Date(user.subscriptionStart);
        if (user.subscriptionPlan === 'yearly') {
          expiresAt.setFullYear(expiresAt.getFullYear() + 1);
        } else {
          expiresAt.setMonth(expiresAt.getMonth() + 1);
        }
      }
      
      const newSubscription: SubscriptionStatus = {
        isActive: user.isPremium,
        plan: user.subscriptionPlan as 'monthly' | 'yearly' | null,
        expiresAt: expiresAt,
        customerId: user.stripeCustomerId || null,
        subscriptionId: user.stripeSubscriptionId || null
      };
      
      // Aggiorna lo stato
      setSubscription(newSubscription);
      
      // Aggiorna il localStorage
      localStorage.setItem(SUBSCRIPTION_KEY, JSON.stringify(newSubscription));
      
      // Aggiorna anche il formato legacy
      localStorage.setItem('auralis_premium', 'true');
      if (user.subscriptionPlan) {
        localStorage.setItem('auralis_plan', user.subscriptionPlan);
      }
      if (user.stripeSubscriptionId) {
        localStorage.setItem('auralis_subscription_id', user.stripeSubscriptionId);
      }
      if (user.stripeCustomerId) {
        localStorage.setItem('auralis_customer_id', user.stripeCustomerId);
      }
      if (user.subscriptionStart) {
        localStorage.setItem('auralis_subscription_date', new Date(user.subscriptionStart).toISOString());
      }
    }
  }, [user]);

  // Verifica abbonamento all'avvio
  useEffect(() => {
    // Verifica con il server se c'è un abbonamento attivo
    const checkSubscription = async () => {
      console.log('Verifico abbonamento all\'avvio...');
      
      // Controlliamo se è in corso un cambio di lingua
      const isLanguageChange = localStorage.getItem('language_change_in_progress') === 'true';
      
      if (isLanguageChange) {
        console.log('Rilevato cambio lingua in corso, utilizzo dati di backup se presenti');
        
        // Rimuoviamo il flag per evitare falsi positivi in futuro
        localStorage.removeItem('language_change_in_progress');
        
        // Recuperiamo il backup dell'ID sessione e dell'abbonamento
        const sessionIdBackup = localStorage.getItem('auralis_session_id_backup');
        const subscriptionBackup = localStorage.getItem('guida_subscription_backup');
        
        if (sessionIdBackup) {
          console.log('Trovato backup dell\'ID sessione, lo ripristino:', sessionIdBackup);
          localStorage.setItem(SESSION_ID_KEY, sessionIdBackup);
          localStorage.removeItem('auralis_session_id_backup');
        }
        
        if (subscriptionBackup) {
          console.log('Trovato backup dei dati abbonamento, li ripristino');
          localStorage.setItem(SUBSCRIPTION_KEY, subscriptionBackup);
          localStorage.removeItem('guida_subscription_backup');
          
          try {
            // Aggiorniamo direttamente lo stato dell'abbonamento dal backup
            const parsedSubscription = JSON.parse(subscriptionBackup);
            
            // Converti la stringa di data in oggetto Date se necessario
            if (parsedSubscription.expiresAt && typeof parsedSubscription.expiresAt === 'string') {
              parsedSubscription.expiresAt = new Date(parsedSubscription.expiresAt);
            }
            
            console.log('Ripristino abbonamento da backup:', parsedSubscription);
            setSubscription(parsedSubscription);
            
            // Ricreiamo anche i dati legacy
            if (parsedSubscription.isActive) {
              localStorage.setItem('auralis_premium', 'true');
              
              if (parsedSubscription.plan) {
                localStorage.setItem('auralis_plan', parsedSubscription.plan);
              }
              
              if (parsedSubscription.subscriptionId) {
                localStorage.setItem('auralis_subscription_id', parsedSubscription.subscriptionId);
              }
              
              if (parsedSubscription.customerId) {
                localStorage.setItem('auralis_customer_id', parsedSubscription.customerId);
              }
              
              if (parsedSubscription.expiresAt) {
                // Calcoliamo la data di inizio (un mese o un anno prima della scadenza)
                const startDate = new Date(parsedSubscription.expiresAt);
                if (parsedSubscription.plan === 'yearly') {
                  startDate.setFullYear(startDate.getFullYear() - 1);
                } else {
                  startDate.setMonth(startDate.getMonth() - 1);
                }
                localStorage.setItem('auralis_subscription_date', startDate.toISOString());
              }
            }
            
            // Non è necessario verificare ancora con il server
            return;
          } catch (e) {
            console.error('Errore nel ripristino dei dati di abbonamento dal backup:', e);
          }
        }
      }
      
      // Recuperiamo il session_id salvato
      const lastKnownSession = localStorage.getItem(SESSION_ID_KEY);
      
      // Rimuoviamo solo le sessioni di test SCADUTE all'avvio, ma solo se non è un cambio lingua
      if (lastKnownSession) {
        if (lastKnownSession.startsWith('cs_test_')) {
          console.log('Rilevata sessione di test:', lastKnownSession);
          
          // Prima di rimuovere la sessione, verifichiamo se è ancora valida
          try {
            // Dobbiamo verificare che lastKnownSession sia una stringa valida
            if (typeof lastKnownSession === 'string' && lastKnownSession.length > 0) {
              const response = await fetch(`/api/stripe/verify-session?session_id=${encodeURIComponent(lastKnownSession)}`);
              const data = await response.json();
              
              if (data.status === 'success') {
                console.log('La sessione di test è ancora valida, la mantengo');
                // La sessione è valida, continuiamo con la verifica
              } else {
                console.log('La sessione di test non è più valida, la rimuovo');
                localStorage.removeItem(SESSION_ID_KEY);
                // Non continuiamo con la verifica poiché la sessione non è valida
                return;
              }
            } else {
              console.log('Session ID non trovato o non valido, continuo con la verifica standard');
            }
          } catch (err) {
            console.error('Errore nella verifica della sessione di test:', err);
            // In caso di errore, manteniamo la sessione per sicurezza
          }
        } 
        console.log('Verifico abbonamento con session_id salvato:', lastKnownSession);

        // Verifica abbonamento con il server passando l'ID di sessione
        if (typeof lastKnownSession === 'string') {
          await verifySubscription(lastKnownSession);
        } else {
          await verifySubscription();
        }
      } else {
        // Verifica abbonamento con il server senza ID sessione
        await verifySubscription();
      }
    };
    
    checkSubscription();
    
    // Se c'è un abbonamento in localStorage, verifichiamo che sia ancora attivo
    if (subscription.isActive) {
      // Se non è più attivo, resettiamo lo stato
      if (!isSubscriptionActive()) {
        console.log('Abbonamento locale scaduto, resetto');
        setSubscription({
          isActive: false,
          plan: null,
          expiresAt: null,
          customerId: null,
          subscriptionId: null
        });
        localStorage.removeItem(SUBSCRIPTION_KEY);
        
        // Rimuoviamo anche ogni legacy storage che potrebbe interferire
        localStorage.removeItem('auralis_premium');
        localStorage.removeItem('auralis_plan');
        localStorage.removeItem('auralis_subscription_id');
        localStorage.removeItem('auralis_customer_id');
        localStorage.removeItem('auralis_subscription_date');
        // NON rimuoviamo SESSION_ID_KEY qui per mantenere consistenza dopo il cambio lingua
      }
    }
  }, []);

  return (
    <StripeContext.Provider
      value={{
        isLoading,
        error,
        subscription,
        createCheckoutSession,
        verifySubscription,
        isSubscriptionActive
      }}
    >
      {children}
    </StripeContext.Provider>
  );
}

export function useStripe() {
  const context = useContext(StripeContext);
  if (context === undefined) {
    throw new Error("useStripe deve essere utilizzato all'interno di un StripeProvider");
  }
  return context;
}