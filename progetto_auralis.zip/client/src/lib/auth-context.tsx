import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { getDailyUsage, incrementDailyUsage, hasReachedDailyLimit } from './usage-limits';
import { useToast } from '@/hooks/use-toast';

// Tipo per l'utente
interface User {
  id: number;
  username: string;
  isPremium: boolean;
  subscriptionPlan?: string | null;
  subscriptionEnd?: string | null;
  subscriptionStart?: string | null;
  stripeCustomerId?: string | null;
  stripeSubscriptionId?: string | null;
  subscriptionStatus?: string | null;
}

interface AuthContextType {
  isAuthenticated: boolean;
  isAdmin: boolean;
  adminPassword: string;
  dailyUsageCount: number;
  hasReachedRequestLimit: boolean;
  user: User | null;
  incrementDailyUsageCount: () => number;
  login: (user: User) => void;
  logout: () => void;
  loginWithCredentials: (username: string, password: string) => Promise<boolean>;
  register: (userData: RegisterData) => Promise<{ success: boolean; error?: string }>;
  cancelSubscription: () => Promise<boolean>;
  setAdmin: (value: boolean) => void;
  setAdminPassword: (password: string) => void;
}

interface RegisterData {
  username: string;
  password: string;
  email?: string;
  name?: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Chiavi per salvare le informazioni nel localStorage
const ADMIN_PASSWORD_KEY = 'auralis_admin_password';
const ADMIN_STATUS_KEY = 'auralis_is_admin';
const AUTH_USER_KEY = 'auralis_user';

// Funzione helper per recuperare lo stato admin dal localStorage
function getAdminStatusFromStorage(): boolean {
  try {
    const status = localStorage.getItem(ADMIN_STATUS_KEY);
    return status === 'true';
  } catch (e) {
    console.error('Errore nel recuperare lo stato admin:', e);
    return false;
  }
}

// Funzione helper per salvare lo stato admin nel localStorage
function saveAdminStatusToStorage(isAdmin: boolean): void {
  try {
    localStorage.setItem(ADMIN_STATUS_KEY, isAdmin ? 'true' : 'false');
    console.log('Stato admin salvato:', isAdmin);
  } catch (e) {
    console.error('Errore nel salvare lo stato admin:', e);
  }
}

// Funzione helper per recuperare l'utente dal localStorage
function getUserFromStorage(): User | null {
  try {
    const userData = localStorage.getItem(AUTH_USER_KEY);
    if (userData) {
      return JSON.parse(userData);
    }
    return null;
  } catch (e) {
    console.error('Errore nel recuperare l\'utente dal localStorage:', e);
    return null;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  // Inizializza stato utente dal localStorage
  const [user, setUser] = useState<User | null>(getUserFromStorage);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(!!getUserFromStorage());
  
  // Inizializza isAdmin dal localStorage
  const [isAdmin, setIsAdminState] = useState<boolean>(getAdminStatusFromStorage());
  
  // Stato per tenere traccia dell'utilizzo giornaliero
  const [dailyUsageCount, setDailyUsageCount] = useState(() => getDailyUsage());
  
  // Stato per tenere traccia del raggiungimento del limite
  const [hasReachedRequestLimit, setHasReachedRequestLimit] = useState(() => hasReachedDailyLimit());
  
  // Aggiorniamo il conteggio dell'utilizzo giornaliero ogni volta che il componente viene montato
  useEffect(() => {
    const currentUsage = getDailyUsage();
    setDailyUsageCount(currentUsage);
    setHasReachedRequestLimit(hasReachedDailyLimit());
    
    // Aggiorniamo il conteggio ogni minuto per gestire il cambio di giorno
    const interval = setInterval(() => {
      const updatedUsage = getDailyUsage();
      setDailyUsageCount(updatedUsage);
      setHasReachedRequestLimit(hasReachedDailyLimit());
    }, 60000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Carica la password salvata, o usa quella predefinita
  const [adminPassword, setAdminPasswordState] = useState<string>(() => {
    try {
      const savedPassword = localStorage.getItem(ADMIN_PASSWORD_KEY);
      return savedPassword || 'admin1313';
    } catch (e) {
      console.error('Errore nel recuperare password admin:', e);
      return 'admin1313';
    }
  });
  
  // Salva la password quando cambia
  useEffect(() => {
    try {
      localStorage.setItem(ADMIN_PASSWORD_KEY, adminPassword);
    } catch (e) {
      console.error('Errore nel salvare password admin:', e);
    }
  }, [adminPassword]);

  // Assicuriamoci che lo stato admin sia sincronizzato con il localStorage
  useEffect(() => {
    // Aggiorna lo stato React quando lo stato nel localStorage cambia
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === ADMIN_STATUS_KEY) {
        setIsAdminState(e.newValue === 'true');
      } else if (e.key === AUTH_USER_KEY) {
        try {
          if (e.newValue) {
            const userData = JSON.parse(e.newValue);
            setUser(userData);
            setIsAuthenticated(true);
          } else {
            setUser(null);
            setIsAuthenticated(false);
          }
        } catch (error) {
          console.error('Errore parsing localStorage user:', error);
        }
      }
    };

    // Aggiungi event listener per cambiamenti nel localStorage
    window.addEventListener('storage', handleStorageChange);

    // Rimuovi event listener quando il componente viene smontato
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  // Funzione per accedere con un utente
  const login = (userData: User) => {
    setUser(userData);
    setIsAuthenticated(true);
    try {
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(userData));
      
      // Se l'utente ha un abbonamento premium, aggiorna anche i dati di Stripe nel localStorage
      if (userData.isPremium) {
        console.log('Utente premium rilevato, sincronizzando dati abbonamento dal database');
        
        // Calcola data di scadenza
        let expiresAt: Date | null = null;
        if (userData.subscriptionEnd) {
          expiresAt = new Date(userData.subscriptionEnd);
        } else if (userData.subscriptionStart) {
          // Se abbiamo solo la data di inizio, calcoliamo la scadenza
          expiresAt = new Date(userData.subscriptionStart);
          if (userData.subscriptionPlan === 'yearly') {
            expiresAt.setFullYear(expiresAt.getFullYear() + 1);
          } else {
            expiresAt.setMonth(expiresAt.getMonth() + 1);
          }
        }
        
        // Crea oggetto subscription per il formato standard
        const subscription = {
          isActive: userData.isPremium,
          plan: userData.subscriptionPlan as 'monthly' | 'yearly' | null,
          expiresAt: expiresAt,
          customerId: userData.stripeCustomerId || null,
          subscriptionId: userData.stripeSubscriptionId || null
        };
        
        // Salva nel formato standard
        localStorage.setItem('guida_subscription', JSON.stringify(subscription));
        
        // Salva anche nel formato legacy per retrocompatibilità
        localStorage.setItem('auralis_premium', 'true');
        if (userData.subscriptionPlan) {
          localStorage.setItem('auralis_plan', userData.subscriptionPlan);
        }
        if (userData.stripeSubscriptionId) {
          localStorage.setItem('auralis_subscription_id', userData.stripeSubscriptionId);
        }
        if (userData.stripeCustomerId) {
          localStorage.setItem('auralis_customer_id', userData.stripeCustomerId);
        }
        if (userData.subscriptionStart) {
          localStorage.setItem('auralis_subscription_date', new Date(userData.subscriptionStart).toISOString());
        }
      }
    } catch (e) {
      console.error('Errore nel salvare l\'utente nel localStorage:', e);
    }
  };
  
  // Funzione per disconnettersi
  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    
    try {
      // Rimuovi i dati utente
      localStorage.removeItem(AUTH_USER_KEY);
      
      // IMPORTANTE: Rimuoviamo TUTTI i dati dell'abbonamento per motivi di sicurezza
      console.log('Logout: rimuovo completamente i dati dell\'abbonamento');
      
      // Rimuovi il formato standard
      localStorage.removeItem('guida_subscription');
      
      // Rimuovi il formato legacy
      localStorage.removeItem('auralis_premium');
      localStorage.removeItem('auralis_plan');
      localStorage.removeItem('auralis_subscription_id');
      localStorage.removeItem('auralis_customer_id');
      localStorage.removeItem('auralis_subscription_date');
      localStorage.removeItem('auralis_session_id');
      
      // Rimuovi eventuali backup
      localStorage.removeItem('guida_subscription_backup');
      localStorage.removeItem('auralis_session_id_backup');
      
      // Forza un ricaricamento della pagina per assicurarsi che tutti i componenti vengano ripristinati
      // e che ogni stato memorizzato in memoria venga resettato
      setTimeout(() => {
        window.location.href = '/';
      }, 100);
    } catch (e) {
      console.error('Errore nel rimuovere l\'utente dal localStorage:', e);
    }
  };
  
  // Funzione per accedere con credenziali
  const loginWithCredentials = async (username: string, password: string): Promise<boolean> => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error('Errore login:', errorData);
        return false;
      }
      
      const data = await response.json();
      if (data.success && data.user) {
        login(data.user);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Errore durante il login:', error);
      return false;
    }
  };
  
  // Funzione per registrare un nuovo utente
  const register = async (userData: RegisterData): Promise<{ success: boolean; error?: string }> => {
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error('Errore registrazione:', errorData);
        
        // Verifica se è un errore di username già esistente
        if (response.status === 409) {
          return { success: false, error: 'username_exists' };
        }
        
        return { success: false, error: 'general_error' };
      }
      
      const data = await response.json();
      if (data.success && data.user) {
        login(data.user);
        return { success: true };
      }
      
      return { success: false, error: 'general_error' };
    } catch (error) {
      console.error('Errore durante la registrazione:', error);
      return { success: false, error: 'server_error' };
    }
  };
  
  // Funzione per cancellare l'abbonamento
  const cancelSubscription = async (): Promise<boolean> => {
    if (!user || !user.id) {
      console.error('Impossibile cancellare l\'abbonamento: utente non autenticato');
      return false;
    }
    
    try {
      // Invia una richiesta per cancellare l'abbonamento
      const response = await fetch(`/api/auth/user/${user.id}/cancel-subscription`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        console.error('Errore nella cancellazione dell\'abbonamento:', response.status);
        return false;
      }
      
      const data = await response.json();
      
      if (data.success && data.user) {
        // Aggiorna lo stato utente locale con i nuovi dati
        login(data.user);
        
        // Rimuovi i dati dell'abbonamento dal localStorage
        localStorage.removeItem('auralis_premium');
        localStorage.removeItem('auralis_plan');
        localStorage.removeItem('auralis_subscription_id');
        localStorage.removeItem('auralis_customer_id');
        localStorage.removeItem('auralis_subscription_date');
        localStorage.removeItem('auralis_session_id');
        localStorage.removeItem('guida_subscription');
        
        console.log('Abbonamento cancellato con successo');
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Errore durante la cancellazione dell\'abbonamento:', error);
      return false;
    }
  };
  
  // Funzione setAdmin aggiornata per salvare lo stato nel localStorage
  const setAdmin = (value: boolean) => {
    setIsAdminState(value);
    saveAdminStatusToStorage(value);
  };
  
  const setAdminPassword = (password: string) => {
    if (password && password.trim() !== '') {
      setAdminPasswordState(password.trim());
    }
  };
  
  // Funzione per incrementare l'utilizzo giornaliero
  const incrementDailyUsageCount = (): number => {
    const newCount = incrementDailyUsage();
    setDailyUsageCount(newCount);
    // Aggiorna anche lo stato del limite
    setHasReachedRequestLimit(hasReachedDailyLimit());
    return newCount;
  };

  // Debug dello stato al mount del componente
  useEffect(() => {
    console.log('AuthProvider montato, stato admin:', isAdmin);
    console.log('Stato admin nel localStorage:', getAdminStatusFromStorage());
  }, [isAdmin]);
  
  // Effect per sincronizzare i dati dell'utente dal server
  useEffect(() => {
    // Se l'utente è autenticato, sincronizziamo i dati di abbonamento
    // indipendentemente dallo stato premium corrente
    if (isAuthenticated && user) {
      const syncUserData = async () => {
        try {
          console.log('Sincronizzazione dati utente dal server...');
          
          // Prima verifichiamo se ci sono dati di sessione Stripe validi nel localStorage
          const sessionId = localStorage.getItem('auralis_session_id');
          if (sessionId) {
            console.log('Trovato session_id nel localStorage, verifico abbonamento Stripe...');
            // Verifica la sessione di Stripe prima
            try {
              const stripeResponse = await fetch(`/api/stripe/verify-session?session_id=${sessionId}`);
              const stripeData = await stripeResponse.json();
              console.log('Risposta verifica sessione Stripe:', stripeData);
              
              if (stripeData.status === 'success') {
                console.log('Sessione Stripe valida, richiedo aggiornamento dati utente...');
              }
            } catch (stripeError) {
              console.error('Errore verifica Stripe:', stripeError);
            }
          }
          
          // Poi verifichiamo i dati utente
          const response = await fetch(`/api/auth/user/${user.id}`);
          
          if (!response.ok) {
            console.error('Errore durante la sincronizzazione dei dati utente:', response.status);
            return;
          }
          
          const data = await response.json();
          
          if (data.success && data.user) {
            // Aggiorna lo stato dell'utente solo se i dati sono cambiati
            if (data.user.isPremium !== user.isPremium || 
                data.user.subscriptionPlan !== user.subscriptionPlan ||
                data.user.subscriptionEnd !== user.subscriptionEnd ||
                data.user.stripeCustomerId !== user.stripeCustomerId ||
                data.user.stripeSubscriptionId !== user.stripeSubscriptionId) {
              console.log('Dati utente aggiornati dal server:', data.user);
              login(data.user);
              
              // Se l'utente è premium, aggiorniamo anche lo stato nel localStorage
              if (data.user.isPremium) {
                console.log('Utente premium, aggiorno stato nel localStorage');
                localStorage.setItem('auralis_premium', 'true');
                if (data.user.subscriptionPlan) {
                  localStorage.setItem('auralis_plan', data.user.subscriptionPlan);
                }
                if (data.user.stripeSubscriptionId) {
                  localStorage.setItem('auralis_subscription_id', data.user.stripeSubscriptionId);
                }
                if (data.user.stripeCustomerId) {
                  localStorage.setItem('auralis_customer_id', data.user.stripeCustomerId);
                }
                if (data.user.subscriptionStart) {
                  localStorage.setItem('auralis_subscription_date', new Date(data.user.subscriptionStart).toISOString());
                }
              }
            }
          }
        } catch (error) {
          console.error('Errore durante la sincronizzazione dei dati utente:', error);
        }
      };
      
      // Esegui la sincronizzazione all'avvio
      syncUserData();
      
      // Imposta un intervallo per sincronizzare i dati ogni 5 minuti (più frequente)
      const interval = setInterval(syncUserData, 5 * 60 * 1000);
      
      return () => clearInterval(interval);
    }
  }, [isAuthenticated, user]);

  return (
    <AuthContext.Provider 
      value={{ 
        isAuthenticated, 
        isAdmin,
        adminPassword,
        dailyUsageCount,
        hasReachedRequestLimit,
        user,
        incrementDailyUsageCount,
        login, 
        logout,
        loginWithCredentials,
        register,
        cancelSubscription,
        setAdmin,
        setAdminPassword
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}