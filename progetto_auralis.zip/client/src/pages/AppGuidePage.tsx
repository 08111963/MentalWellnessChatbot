import React, { useEffect, useState, useMemo, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { useLocation } from 'wouter';
import { ScrollArea } from "@/components/ui/scroll-area";
import { ArrowLeft, Info, BookOpen, Check, Crown, Globe, LifeBuoy, Search, Sparkles } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Interfaccia per le sezioni della guida
interface GuideSection {
  id: string;
  title: string;
  content: React.ReactNode;
}

export function AppGuidePage() {
  const { i18n, t } = useTranslation();
  const [error, setError] = useState<string | null>(null);
  const [, navigate] = useLocation();
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  
  // Hardcoded guide content for English with section anchors
  const englishGuide = `<div id="overview"></div>
# Complete Guide to the Auralis App

## Introduction

Welcome to Auralis – your personal companion for mental wellbeing. This comprehensive guide will walk you through all the features and functions available in our application, helping you make the most of your journey toward improved mental health and wellness.

## Getting Started

### Creating Your Account
To access all features of Auralis, start by creating an account:
1. Tap the login/register button in the top right corner
2. Enter your username and password
3. Complete the registration by accepting our terms of service
4. Once registered, you'll have immediate access to all free features

### Navigating the App
Auralis is designed with intuitive navigation:
- The **bottom navigation bar** provides quick access to main sections
- The **hamburger menu** (≡) in the top right gives access to all features and settings
- The **home button** will always take you back to the main dashboard

### Accessing the App on Multiple Devices
You can access your Auralis account from any device by:
- Using the QR code feature (from the "Scarica App" section in the menu)
- Logging in with your account credentials on any browser

## Core Features Explained

### Home Dashboard
The home dashboard is your central hub, providing:
- Quick access to your most used tools
- Daily inspiration quotes customized to your preferences
- Activity summaries and insights
- Personalized recommendations based on your usage patterns

### Chat Support (Chat Assistente)
Our AI-powered chat assistant is designed to provide psychological support through CBT-based conversations:

**How to Use:**
1. Navigate to the Chat section from the bottom bar or menu
2. Type your message in the text field at the bottom
3. Press "Send" to start or continue the conversation
4. Use the suggested topics for guidance when you're not sure where to start

**Features:**
- Private, judgment-free conversations
- Evidence-based cognitive behavioral therapy approaches
- Memory of previous interactions for contextual support
- Ability to reset the conversation when needed

**Limitations:**
- Free users are limited to 3 conversations per day
- Premium users enjoy unlimited conversations

### Meditation Modules (Meditazione)
Our meditation section offers guided sessions for relaxation and mindfulness:

**How to Access:**
1. Tap "Meditation" in the bottom navigation or menu
2. Browse the available meditation modules by category or length
3. Select a meditation session to view details
4. Press "Play" to begin the guided session

**Features:**
- Diverse meditation categories (sleep, anxiety, stress, focus, etc.)
- Various session lengths (5-30 minutes)
- Background sounds and calming visuals
- Progress tracking

**Meditation Categories:**
- **Mindfulness** - Present-moment awareness practices
- **Breathing** - Techniques to reduce stress through breath control
- **Body Scan** - Progressive relaxation methods
- **Sleep** - Calming practices to improve sleep quality
- **Anxiety Relief** - Sessions specifically designed to reduce anxiety
- **Gratitude** - Practices to cultivate thankfulness and positive outlook

### CBT Exercises (Esercizi)
Evidence-based cognitive behavioral therapy exercises to improve mental health:

**How to Access:**
1. Select "Exercises" from the navigation menu
2. Browse exercises by category (anxiety, depression, stress, etc.)
3. Tap on an exercise to view instructions and benefits
4. Follow the step-by-step guidance

**Features:**
- Detailed instructions for each exercise
- Progress tracking
- Personal notes section
- Completion marking
- Timer for timed exercises

**Exercise Categories:**
- **Thought challenging** - Identify and reframe negative thought patterns
- **Behavioral activation** - Increase engagement in positive activities
- **Exposure techniques** - Gradually face fears in a controlled manner
- **Relaxation training** - Methods to physically and mentally relax
- **Problem-solving** - Structured approaches to tackle challenges
- **Mindfulness practices** - Exercises to increase present awareness

### Daily Reflections (Riflessioni)
Thoughtful prompts and inspirational content to encourage personal growth:

**How to Access:**
1. Navigate to "Reflections" in the menu
2. View the daily reflection displayed on the screen
3. Optional: Journal your thoughts in response to the reflection

**Features:**
- Daily updated content
- Saving favorite reflections
- Journal capability
- Themed reflections based on your interests

### Mood Tracking (Monitoraggio dell'umore)
Monitor and analyze your emotional wellbeing over time:

**How to Use:**
1. Navigate to the "Mood" section
2. Select your current mood from the available options
3. Add notes about what influenced your mood (optional)
4. View your mood patterns in the analysis section

**Features:**
- Quick mood recording
- Detailed notes capability
- Visual graphs showing patterns
- Insights and correlations
- Export capabilities (premium)

### AI Modules (Moduli AI)
Specialized artificial intelligence tools for specific mental health needs:

**Available Modules:**
- **Sleep Improvement** - Analyze sleep patterns and provide customized suggestions
- **Stress Management** - Identify stressors and develop coping strategies
- **Confidence Building** - Exercises and feedback to improve self-esteem
- **Relationship Helper** - Communication strategies and conflict resolution
- **Habit Formation** - Create and maintain positive habits
- **Personal Growth** - Set and track goals for mental wellness

**How to Use:**
1. Select "AI Modules" from the menu
2. Choose a specific module based on your needs
3. Follow the interactive guidance provided
4. Receive personalized recommendations

### Resources Library (Risorse)
A curated collection of articles, videos, and practical materials:

**How to Access:**
1. Tap on "Resources" in the menu
2. Browse categories or use the search function
3. Filter by type (article, video, audio, etc.)
4. Save favorites for later access

**Features:**
- Expert-created content
- Categorized for easy navigation
- Bookmarking functionality
- Reading time estimates
- Offline access (premium)

## Premium Features

Auralis offers a premium subscription that enhances your experience with:

### Premium Benefits
- **Unlimited chat conversations** - No daily limits
- **Complete exercise library** - Access all CBT exercises
- **Full meditation collection** - Including extended and specialized sessions
- **Advanced mood analytics** - Detailed insights and export options
- **Unlimited AI module access** - Use all specialized tools without restrictions
- **Exclusive premium content** - Access to in-depth guides and resources
- **Ad-free experience** - Uninterrupted usage
- **Priority content updates** - Be the first to access new features

### Subscription Options
- **Monthly Plan**: €4.99/month with easy cancellation
- **Annual Plan**: €39.99/year (saving over 30%)
- All subscriptions include a 7-day free trial

### Managing Your Subscription
To manage your subscription:
1. Access your profile from the menu
2. Select "Manage Subscription"
3. View your current plan, renewal date, and options to change or cancel

## Personalization Options

### Language Settings
Auralis supports multiple languages:
- Italian (default)
- English
- Spanish
- French
- German

To change your language:
1. Tap the language selector in the top corner of the screen
2. Choose your preferred language from the dropdown

### Theme and Appearance
While Auralis currently uses a light theme by default, you can:
- Adjust text size through your device accessibility settings
- Use your device's dark mode to modify the appearance

### Notifications
Control how and when Auralis reminds you:
1. Access settings through your profile
2. Toggle notifications for:
   - Daily reflection reminders
   - Meditation practice suggestions
   - Mood check-in prompts
   - Content updates

## Troubleshooting & Support

### Common Issues
- **App not loading**: Ensure you have a stable internet connection
- **Content not displaying**: Try refreshing the page or restarting the app
- **Login problems**: Use the password reset option or contact support

### Getting Help
For assistance with any aspect of Auralis:
- Email: help@auralis.app
- In-app: Use the "Contact Support" option in the menu
- Response time: Typically within 24 hours

## Privacy & Security

Your privacy is our priority. Auralis ensures:
- **Data encryption** for all personal information
- **No third-party sharing** of your conversations or usage data
- **GDPR compliance** with data protection regulations
- **Local storage** of sensitive information where possible

## Tips for Maximum Benefit

1. **Use regularly** - Mental wellness benefits from consistent practice
2. **Try different features** - Explore various tools to find what works best for you
3. **Track your progress** - Regular mood logging provides valuable insights
4. **Combine approaches** - For example, pair meditation with CBT exercises
5. **Set reminders** - Schedule regular check-ins with yourself
6. **Be patient** - Mental wellness improvement takes time

We hope this guide helps you get the most from Auralis as you progress on your wellness journey. Remember that mental health is a continuous process, and we're here to support you every step of the way.`;
  
  // Hardcoded guide content for Italian
  const italianGuide = `# Guida Completa all'App Auralis

## Introduzione

Benvenuto in Auralis – il tuo compagno personale per il benessere mentale. Questa guida completa ti accompagnerà attraverso tutte le funzionalità disponibili nella nostra applicazione, aiutandoti a sfruttare al meglio il tuo percorso verso una migliore salute mentale e benessere.

## Iniziare

### Creazione del tuo Account
Per accedere a tutte le funzionalità di Auralis, inizia creando un account:
1. Tocca il pulsante di accesso/registrazione nell'angolo in alto a destra
2. Inserisci il tuo nome utente e password
3. Completa la registrazione accettando i nostri termini di servizio
4. Una volta registrato, avrai immediatamente accesso a tutte le funzionalità gratuite

### Navigazione nell'App
Auralis è progettata con una navigazione intuitiva:
- La **barra di navigazione inferiore** fornisce accesso rapido alle sezioni principali
- Il **menu hamburger** (≡) in alto a destra dà accesso a tutte le funzionalità e impostazioni
- Il **pulsante home** ti riporterà sempre alla dashboard principale

### Accesso all'App su Più Dispositivi
Puoi accedere al tuo account Auralis da qualsiasi dispositivo:
- Utilizzando la funzione codice QR (dalla sezione "Scarica App" nel menu)
- Accedendo con le credenziali del tuo account su qualsiasi browser

## Funzionalità Principali Spiegate

### Dashboard Home
La dashboard home è il tuo hub centrale, che fornisce:
- Accesso rapido agli strumenti più utilizzati
- Citazioni di ispirazione quotidiana personalizzate in base alle tue preferenze
- Riepiloghi delle attività e approfondimenti
- Raccomandazioni personalizzate basate sui tuoi modelli di utilizzo

### Supporto Chat (Chat Assistente)
Il nostro assistente chat basato sull'intelligenza artificiale è progettato per fornire supporto psicologico attraverso conversazioni basate sulla CBT:

**Come Utilizzare:**
1. Naviga alla sezione Chat dalla barra inferiore o dal menu
2. Digita il tuo messaggio nel campo di testo in basso
3. Premi "Invia" per iniziare o continuare la conversazione
4. Utilizza gli argomenti suggeriti per orientarti quando non sei sicuro da dove iniziare

**Caratteristiche:**
- Conversazioni private, senza giudizio
- Approcci di terapia cognitivo-comportamentale basati su evidenze
- Memoria delle interazioni precedenti per un supporto contestuale
- Possibilità di reimpostare la conversazione quando necessario

**Limitazioni:**
- Gli utenti gratuiti sono limitati a 3 conversazioni al giorno
- Gli utenti premium godono di conversazioni illimitate

### Moduli di Meditazione (Meditazione)
La nostra sezione di meditazione offre sessioni guidate per il rilassamento e la consapevolezza:

**Come Accedere:**
1. Tocca "Meditazione" nella navigazione inferiore o nel menu
2. Sfoglia i moduli di meditazione disponibili per categoria o lunghezza
3. Seleziona una sessione di meditazione per visualizzare i dettagli
4. Premi "Play" per iniziare la sessione guidata

**Caratteristiche:**
- Diverse categorie di meditazione (sonno, ansia, stress, concentrazione, ecc.)
- Varie lunghezze di sessione (5-30 minuti)
- Suoni di sottofondo e visuali calmanti
- Monitoraggio dei progressi

**Categorie di Meditazione:**
- **Mindfulness** - Pratiche di consapevolezza del momento presente
- **Respirazione** - Tecniche per ridurre lo stress attraverso il controllo del respiro
- **Body Scan** - Metodi di rilassamento progressivo
- **Sonno** - Pratiche calmanti per migliorare la qualità del sonno
- **Sollievo dall'Ansia** - Sessioni specificamente progettate per ridurre l'ansia
- **Gratitudine** - Pratiche per coltivare la riconoscenza e una prospettiva positiva

### Esercizi CBT (Esercizi)
Esercizi di terapia cognitivo-comportamentale basati su evidenze per migliorare la salute mentale:

**Come Accedere:**
1. Seleziona "Esercizi" dal menu di navigazione
2. Sfoglia gli esercizi per categoria (ansia, depressione, stress, ecc.)
3. Tocca un esercizio per visualizzare istruzioni e benefici
4. Segui la guida passo-passo

**Caratteristiche:**
- Istruzioni dettagliate per ogni esercizio
- Monitoraggio dei progressi
- Sezione per note personali
- Marcatura di completamento
- Timer per esercizi temporizzati

**Categorie di Esercizi:**
- **Sfida ai pensieri** - Identificare e reinterpretare modelli di pensiero negativi
- **Attivazione comportamentale** - Aumentare il coinvolgimento in attività positive
- **Tecniche di esposizione** - Affrontare gradualmente le paure in modo controllato
- **Allenamento al rilassamento** - Metodi per rilassarsi fisicamente e mentalmente
- **Problem-solving** - Approcci strutturati per affrontare le sfide
- **Pratiche di mindfulness** - Esercizi per aumentare la consapevolezza del presente

### Riflessioni Quotidiane (Riflessioni)
Spunti di riflessione e contenuti ispiratori per incoraggiare la crescita personale:

**Come Accedere:**
1. Naviga a "Riflessioni" nel menu
2. Visualizza la riflessione quotidiana mostrata sullo schermo
3. Opzionale: Annota i tuoi pensieri in risposta alla riflessione

**Caratteristiche:**
- Contenuti aggiornati quotidianamente
- Salvataggio delle riflessioni preferite
- Capacità di tenere un diario
- Riflessioni tematiche basate sui tuoi interessi

### Monitoraggio dell'Umore (Monitoraggio dell'umore)
Monitora e analizza il tuo benessere emotivo nel tempo:

**Come Utilizzare:**
1. Naviga alla sezione "Umore"
2. Seleziona il tuo umore attuale dalle opzioni disponibili
3. Aggiungi note su ciò che ha influenzato il tuo umore (opzionale)
4. Visualizza i tuoi modelli di umore nella sezione di analisi

**Caratteristiche:**
- Registrazione rapida dell'umore
- Capacità di aggiungere note dettagliate
- Grafici visivi che mostrano i modelli
- Approfondimenti e correlazioni
- Capacità di esportazione (premium)

### Moduli AI (Moduli AI)
Strumenti di intelligenza artificiale specializzati per esigenze specifiche di salute mentale:

**Moduli Disponibili:**
- **Miglioramento del Sonno** - Analizza i modelli di sonno e fornisce suggerimenti personalizzati
- **Gestione dello Stress** - Identifica i fattori di stress e sviluppa strategie di coping
- **Rafforzamento della Fiducia** - Esercizi e feedback per migliorare l'autostima
- **Aiuto Relazionale** - Strategie di comunicazione e risoluzione dei conflitti
- **Formazione di Abitudini** - Crea e mantieni abitudini positive
- **Crescita Personale** - Imposta e monitora obiettivi per il benessere mentale

**Come Utilizzare:**
1. Seleziona "Moduli AI" dal menu
2. Scegli un modulo specifico in base alle tue esigenze
3. Segui la guida interattiva fornita
4. Ricevi raccomandazioni personalizzate

### Biblioteca Risorse (Risorse)
Una collezione curata di articoli, video e materiali pratici:

**Come Accedere:**
1. Tocca "Risorse" nel menu
2. Sfoglia le categorie o utilizza la funzione di ricerca
3. Filtra per tipo (articolo, video, audio, ecc.)
4. Salva i preferiti per accedervi in seguito

**Caratteristiche:**
- Contenuti creati da esperti
- Categorizzati per una facile navigazione
- Funzionalità di segnalibro
- Stime del tempo di lettura
- Accesso offline (premium)

## Funzionalità Premium

Auralis offre un abbonamento premium che migliora la tua esperienza con:

### Benefici Premium
- **Conversazioni chat illimitate** - Nessun limite giornaliero
- **Biblioteca completa di esercizi** - Accesso a tutti gli esercizi CBT
- **Collezione completa di meditazioni** - Incluse sessioni estese e specializzate
- **Analisi avanzate dell'umore** - Approfondimenti dettagliati e opzioni di esportazione
- **Accesso illimitato ai moduli AI** - Utilizza tutti gli strumenti specializzati senza restrizioni
- **Contenuti premium esclusivi** - Accesso a guide approfondite e risorse
- **Esperienza senza pubblicità** - Utilizzo ininterrotto
- **Aggiornamenti prioritari dei contenuti** - Sii il primo ad accedere alle nuove funzionalità

### Opzioni di Abbonamento
- **Piano Mensile**: €4,99/mese con facile cancellazione
- **Piano Annuale**: €39,99/anno (risparmio oltre il 30%)
- Tutti gli abbonamenti includono una prova gratuita di 7 giorni

### Gestione del tuo Abbonamento
Per gestire il tuo abbonamento:
1. Accedi al tuo profilo dal menu
2. Seleziona "Gestisci Abbonamento"
3. Visualizza il tuo piano attuale, la data di rinnovo e le opzioni per modificare o cancellare

## Opzioni di Personalizzazione

### Impostazioni Lingua
Auralis supporta più lingue:
- Italiano (predefinito)
- Inglese
- Spagnolo
- Francese
- Tedesco

Per cambiare la tua lingua:
1. Tocca il selettore di lingua nell'angolo superiore dello schermo
2. Scegli la tua lingua preferita dal menu a tendina

### Tema e Aspetto
Mentre Auralis attualmente utilizza un tema chiaro per impostazione predefinita, puoi:
- Regolare la dimensione del testo attraverso le impostazioni di accessibilità del tuo dispositivo
- Utilizzare la modalità scura del tuo dispositivo per modificare l'aspetto

### Notifiche
Controlla come e quando Auralis ti ricorda:
1. Accedi alle impostazioni attraverso il tuo profilo
2. Attiva/disattiva le notifiche per:
   - Promemoria di riflessione quotidiana
   - Suggerimenti per la pratica di meditazione
   - Promemoria per il check-in dell'umore
   - Aggiornamenti dei contenuti

## Risoluzione dei Problemi e Supporto

### Problemi Comuni
- **App che non si carica**: Assicurati di avere una connessione internet stabile
- **Contenuti che non vengono visualizzati**: Prova ad aggiornare la pagina o riavviare l'app
- **Problemi di accesso**: Utilizza l'opzione di reimpostazione della password o contatta il supporto

### Ottenere Aiuto
Per assistenza con qualsiasi aspetto di Auralis:
- Email: aiuto@auralis.app
- Nell'app: Utilizza l'opzione "Contatta Supporto" nel menu
- Tempo di risposta: In genere entro 24 ore

## Privacy e Sicurezza

La tua privacy è la nostra priorità. Auralis garantisce:
- **Crittografia dei dati** per tutte le informazioni personali
- **Nessuna condivisione con terzi** delle tue conversazioni o dati di utilizzo
- **Conformità al GDPR** con le normative sulla protezione dei dati
- **Archiviazione locale** delle informazioni sensibili ove possibile

## Consigli per il Massimo Beneficio

1. **Usa regolarmente** - Il benessere mentale trae beneficio dalla pratica costante
2. **Prova diverse funzionalità** - Esplora vari strumenti per trovare ciò che funziona meglio per te
3. **Monitora i tuoi progressi** - La registrazione regolare dell'umore fornisce preziosi insight
4. **Combina gli approcci** - Ad esempio, abbina la meditazione agli esercizi CBT
5. **Imposta promemoria** - Programma regolari check-in con te stesso
6. **Sii paziente** - Il miglioramento del benessere mentale richiede tempo

Speriamo che questa guida ti aiuti a ottenere il massimo da Auralis mentre progredisci nel tuo percorso di benessere. Ricorda che la salute mentale è un processo continuo, e siamo qui per supportarti in ogni passo del cammino.`;

  useEffect(() => {
    try {
      setIsLoading(true);
      setError(null);
      
      console.log(`Loading guide content for language: ${i18n.language}`);
      
      // Use hardcoded content based on language
      const content = i18n.language === 'it' ? italianGuide : englishGuide;
      
      setGuideContent(content);
      console.log("Guide content loaded successfully");
      setIsLoading(false);
    } catch (error) {
      console.error('Error setting guide content:', error);
      setError(i18n.language === 'it' 
        ? 'Errore nel caricamento del contenuto della guida. Riprova più tardi.' 
        : 'Error loading guide content. Please try again later.');
      setIsLoading(false);
    }
  }, [i18n.language]);
  
  // Second useEffect to handle the addition of anchor IDs when content is loaded
  useEffect(() => {
    if (!guideContent || isLoading) return;
    
    // Aggiungi gli anchor ID dopo che il contenuto è stato renderizzato
    const addAnchorsToContent = () => {
      console.log("Adding anchor IDs to guide content...");
      
      const content = document.querySelector('.guide-content');
      if (!content) {
        console.error('Guide content not found');
        return;
      }
      
      // Ottieni i titoli principali nel contenuto
      const headings = content.querySelectorAll('h1, h2');
      console.log(`Found ${headings.length} headings in guide content`);
      
      // Mappatura di sezioni da trovare nel testo
      const sectionKeywords = {
        'overview': i18n.language === 'it' ? 'Guida Completa' : 'Complete Guide',
        'features': i18n.language === 'it' ? 'Funzionalità Principali' : 'Core Features',
        'premium': i18n.language === 'it' ? 'Funzionalità Premium' : 'Premium Features',
        'support': i18n.language === 'it' ? 'Risoluzione dei Problemi' : 'Troubleshooting'
      };
      
      // Trova i heading che corrispondono a ciascuna sezione e aggiungi ID
      headings.forEach((heading, index) => {
        const text = heading.textContent || '';
        
        // Primo titolo è sempre l'overview
        if (index === 0) {
          heading.id = 'section-overview';
          console.log(`Added ID section-overview to first heading: "${text}"`);
        }
        
        // Cerca altre corrispondenze
        Object.entries(sectionKeywords).forEach(([id, keyword]) => {
          if (text.includes(keyword)) {
            heading.id = `section-${id}`;
            console.log(`Added ID section-${id} to heading: "${text}"`);
          }
        });
      });
    };
    
    // Esegui dopo breve ritardo per assicurarsi che il DOM sia aggiornato
    setTimeout(addAnchorsToContent, 300);
    
  }, [guideContent, isLoading, i18n.language]);

  // Parse markdown to HTML (enhanced conversion)
  const renderMarkdown = (markdown: string) => {
    if (!markdown) return '';
    
    // Convert headers
    let html = markdown
      .replace(/^# (.*$)/gim, '<h1 class="text-3xl font-bold mt-8 mb-4 text-purple-800">$1</h1>')
      .replace(/^## (.*$)/gim, '<h2 class="text-2xl font-bold mt-7 mb-3 text-purple-700">$1</h2>')
      .replace(/^### (.*$)/gim, '<h3 class="text-xl font-bold mt-6 mb-2 text-purple-600">$1</h3>')
      .replace(/^#### (.*$)/gim, '<h4 class="text-lg font-bold mt-5 mb-2 text-purple-500">$1</h4>')
      .replace(/^##### (.*$)/gim, '<h5 class="text-base font-bold mt-4 mb-1 text-purple-400">$1</h5>')
      .replace(/^###### (.*$)/gim, '<h6 class="text-sm font-bold mt-3 mb-1 text-purple-300">$1</h6>');
    
    // Convert bold text
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold">$1</strong>');
    
    // Convert italic text
    html = html.replace(/\*(.*?)\*/g, '<em class="italic">$1</em>');
    
    // Convert line breaks
    html = html.replace(/\n\n/g, '</p><p class="my-3">');
    html = html.replace(/\n(?!\n)/g, '<br>');
    
    // Convert numbered lists
    html = html.replace(/^(\d+)\. (.*$)/gim, '<li class="ml-5 my-1"><span class="font-medium text-purple-600">$1.</span> $2</li>');
    
    // Convert bullet lists
    html = html.replace(/^- (.*$)/gim, '<li class="ml-5 my-1 flex items-start"><span class="text-purple-500 mr-2">•</span><span>$1</span></li>');
    
    // Clean up lists
    html = html.replace(/<\/li>\s*<br><li/g, '</li><li');
    
    // Wrap lists in <ul> tags
    html = html.replace(/<li(.*?)>(.*?)<\/li>/g, function(match) {
      if (match.indexOf('<ul') === -1 && match.indexOf('<ol') === -1) {
        if (match.indexOf('<span class="font-medium text-purple-600">') !== -1) {
          return '<ol class="list-decimal my-3 pl-2 space-y-2">' + match + '</ol>';
        } else {
          return '<ul class="list-disc my-3 pl-2 space-y-2">' + match + '</ul>';
        }
      }
      return match;
    });
    
    // Merge adjacent lists of the same type
    html = html.replace(/<\/ul><ul[^>]*>/g, '');
    html = html.replace(/<\/ol><ol[^>]*>/g, '');
    
    // Convert horizontal rule
    html = html.replace(/^---$/gim, '<hr class="my-6 border-t border-purple-200">');
    
    // Wrap in paragraph tags if it doesn't start with a recognized HTML tag
    if (!html.startsWith('<h') && !html.startsWith('<ul') && !html.startsWith('<ol') && !html.startsWith('<p')) {
      html = '<p class="my-3">' + html + '</p>';
    }
    
    // Disabilita tutti i link impliciti impedendo che email o URL diventino cliccabili
    html = html.replace(/(href=["'][^"']*["'])/g, 'onClick="event.preventDefault()" $1');
    
    // Aggiungi un event handler globale per prevenire la navigazione standard
    const script = `
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        const guideContent = document.querySelector('.guide-content');
        if (guideContent) {
          guideContent.addEventListener('click', function(event) {
            // Se è un link, impedisci l'azione predefinita
            if (event.target.tagName === 'A' || event.target.closest('a')) {
              event.preventDefault();
            }
          });
        }
      });
    </script>
    `;
    
    html += script;
    
    return html;
  };

  // Determine the title of the guide based on language
  const guideTitle = i18n.language === 'it' 
    ? t('app.guide.title', 'Guida App') 
    : t('app.guide.title', 'App Guide');

  // Define tab sections for quick navigation
  const tabSections = [
    { 
      id: 'overview', 
      title: i18n.language === 'it' ? 'Panoramica' : 'Overview',
      icon: <BookOpen className="h-4 w-4 mr-1" />
    },
    { 
      id: 'features', 
      title: i18n.language === 'it' ? 'Funzionalità' : 'Features',
      icon: <Sparkles className="h-4 w-4 mr-1" /> 
    },
    { 
      id: 'premium', 
      title: i18n.language === 'it' ? 'Premium' : 'Premium',
      icon: <Crown className="h-4 w-4 mr-1" /> 
    },
    { 
      id: 'support', 
      title: i18n.language === 'it' ? 'Supporto' : 'Support',
      icon: <LifeBuoy className="h-4 w-4 mr-1" /> 
    }
  ];

  // Bypass ScrollArea component and add our own scrolling
  const scrollToSection = (sectionId: string) => {
    // Aggiungi punti di riferimento con ID nel contenuto appena renderizzato
    const addAnchors = () => {
      console.log("Adding anchors to guide content...");
      
      // Ottieni i titoli principali nel contenuto
      const content = document.querySelector('.guide-content');
      if (!content) {
        console.error('Guide content not found');
        return;
      }
      
      // Mappatura di sezioni agli indici approssimativi dei titoli principali (h1, h2)
      const headings = content.querySelectorAll('h1, h2');
      const anchors: Record<string, Element | null> = {
        'overview': headings[0] || null,  // Primo titolo
        'features': headings[1] || null,  // Secondo titolo principale
        'premium': null,                 // Cercheremo "Premium" o "Funzionalità Premium"
        'support': null                  // Cercheremo "Support" o "Troubleshooting"
      };
      
      // Cerca titoli specifici per le sezioni premium e support
      headings.forEach(heading => {
        const text = heading.textContent || '';
        if (text.includes('Premium')) {
          anchors['premium'] = heading;
        } else if (text.includes('Troubleshooting') || text.includes('Risoluzione')) {
          anchors['support'] = heading;
        }
      });
      
      // Aggiungi ID direttamente agli elementi per riferimento più semplice
      Object.entries(anchors).forEach(([id, element]) => {
        if (element) {
          element.id = `section-${id}`;
          console.log(`Added anchor ID section-${id} to:`, element.textContent);
        }
      });
    };
    
    // Esegui solo una volta quando il contenuto è caricato
    if (!document.getElementById('section-overview')) {
      addAnchors();
    }
    
    // Trova l'elemento target in base all'ID di sezione
    const targetId = `section-${sectionId}`;
    const targetElement = document.getElementById(targetId);
    
    if (targetElement) {
      console.log(`Scrolling to section ${sectionId} (element #${targetId})`);
      
      // Usa il metodo scrollIntoView nativo che funziona anche in contenitori con overflow
      targetElement.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
      
      return;
    }
    
    // Fallback a posizioni fisse se gli anchor non sono trovati
    console.log(`Anchor for ${sectionId} not found, using fixed positions`);
    
    // Get the ScrollArea component's scrollable element
    const scrollAreaElement = document.querySelector('.scroll-area-viewport');
    if (!scrollAreaElement) {
      console.error('Scroll area element not found');
      return;
    }
    
    // Posizioni di fallback
    const fixedPositions: Record<string, number> = {
      'overview': 0,
      'features': i18n.language === 'it' ? 350 : 300,
      'premium': i18n.language === 'it' ? 2500 : 2200,
      'support': i18n.language === 'it' ? 3500 : 3200
    };
    
    console.log(`Using fallback position for ${sectionId}: ${fixedPositions[sectionId] || 0}`);
    
    // Usa scrollTop diretto per un risultato immediato
    (scrollAreaElement as HTMLElement).scrollTop = fixedPositions[sectionId] || 0;
  };

  return (
    <div className="container mx-auto p-4 max-w-4xl mb-16">
      <div className="flex items-center mb-4">
        <Button 
          variant="ghost" 
          size="icon" 
          className="mr-2"
          onClick={() => navigate('/')}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-purple-800">{guideTitle}</h1>
          <p className="text-sm text-neutral-500">
            {i18n.language === 'it' 
              ? 'Guida completa all\'utilizzo di Auralis' 
              : 'Complete guide to using Auralis'}
          </p>
        </div>
      </div>
      
      <Separator className="mb-4" />
      
      <div className="bg-blue-50 p-4 rounded-lg mb-6 flex items-start">
        <Info className="h-5 w-5 text-blue-500 mt-0.5 mr-3 flex-shrink-0" />
        <p className="text-sm text-blue-700">
          {i18n.language === 'it'
            ? 'Questa guida è disponibile in italiano e inglese e si adatta automaticamente alla lingua selezionata.'
            : 'This guide is available in Italian and English and automatically adapts to your selected language.'}
        </p>
      </div>
      
      {/* Quick navigation tabs */}
      <div className="sticky top-0 z-10 bg-white pb-2 shadow-sm rounded mb-4">
        <div className="p-2 bg-purple-50 rounded-lg">
          <div className="flex items-center mb-2">
            <Search className="h-4 w-4 text-purple-500 mr-2" />
            <span className="text-sm font-medium text-purple-700">
              {i18n.language === 'it' ? 'Naviga Sezioni' : 'Navigate Sections'}
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {tabSections.map((section) => (
              <Button 
                key={section.id}
                variant="outline" 
                size="sm"
                onClick={() => scrollToSection(section.id)}
                className="border-purple-300 hover:bg-purple-100 hover:text-purple-800 text-purple-700 flex items-center"
              >
                {section.icon}
                {section.title}
              </Button>
            ))}
          </div>
        </div>
      </div>
      
      <ScrollArea className="h-[calc(100vh-280px)] pr-4">
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-purple-600"></div>
            <span className="ml-3 text-neutral-600">
              {i18n.language === 'it' ? 'Caricamento...' : 'Loading...'}
            </span>
          </div>
        ) : error ? (
          <div className="flex flex-col justify-center items-center h-64 text-red-500">
            <p>{error}</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => window.location.reload()}
            >
              {i18n.language === 'it' ? 'Riprova' : 'Try Again'}
            </Button>
          </div>
        ) : guideContent ? (
          <div className="guide-content">
            <div 
              className="prose prose-purple max-w-none text-neutral-800"
              dangerouslySetInnerHTML={{ __html: renderMarkdown(guideContent) }}
            />
            
            {/* Anchors are now embedded directly in the markdown files */}
            
            {/* Bottom Footer with quick links */}
            <div className="mt-12 p-6 bg-purple-50 rounded-lg border border-purple-100">
              <h3 className="text-lg font-bold text-purple-700 mb-3">
                {i18n.language === 'it' ? 'Collegamenti Rapidi' : 'Quick Links'}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  className="w-full justify-start border-purple-300 hover:bg-purple-100"
                  onClick={() => navigate('/chat')}
                >
                  <i className="ri-chat-3-line mr-2 text-purple-600"></i>
                  {i18n.language === 'it' ? 'Vai alla Chat' : 'Go to Chat'}
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start border-purple-300 hover:bg-purple-100"
                  onClick={() => navigate('/meditation')}
                >
                  <i className="ri-emotion-happy-line mr-2 text-purple-600"></i>
                  {i18n.language === 'it' ? 'Esplora Meditazioni' : 'Explore Meditations'}
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start border-purple-300 hover:bg-purple-100"
                  onClick={() => navigate('/exercises')}
                >
                  <i className="ri-mental-health-line mr-2 text-purple-600"></i>
                  {i18n.language === 'it' ? 'Prova Esercizi' : 'Try Exercises'}
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start border-purple-300 hover:bg-purple-100"
                  onClick={() => navigate('/subscription')}
                >
                  <i className="ri-vip-crown-line mr-2 text-purple-600"></i>
                  {i18n.language === 'it' ? 'Scopri Premium' : 'Discover Premium'}
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex justify-center items-center h-64">
            <p>{t('app.guide.noContent', 'No guide content available.')}</p>
          </div>
        )}
      </ScrollArea>
    </div>
  );
}

export default AppGuidePage;