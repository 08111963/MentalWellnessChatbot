import React, { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '../lib/auth-context';
import { Button } from '../components/ui/button';
import Header from '../components/Header';
import { ScrollToTop } from '../components/ScrollToTop';
import { Check, ArrowRight, Calendar, Zap, CreditCard } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useStripe } from '@/lib/stripe-context';

interface SubscriptionData {
  plan: string;
  session_id: string;
  customer_id: string;
  subscription_id: string | null;
  customer_email: string | null;
}

export default function PaymentSuccessPage() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [subscriptionData, setSubscriptionData] = useState<SubscriptionData | null>(null);
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const { toast } = useToast();
  const { verifySubscription } = useStripe(); // Utilizziamo il contesto Stripe

  useEffect(() => {
    // Estrai l'ID di sessione e il piano dall'URL
    const params = new URLSearchParams(window.location.search);
    const sessionId = params.get('session_id');
    const planFromUrl = params.get('plan'); // Può essere 'monthly' o 'yearly'
    
    if (!sessionId) {
      setError('Nessuna sessione valida trovata.');
      setLoading(false);
      return;
    }
    
    setSessionId(sessionId);
    
    // Aggiunge ritardo simulato per rendere l'esperienza più realistica
    setTimeout(() => {
      // Verifica la sessione con l'API
      const verifySession = async () => {
        try {
          console.log('Verifica della sessione:', sessionId);
          const response = await fetch(`/api/stripe/verify-session?session_id=${sessionId}`);
          
          // Gestisce errori HTTP
          if (!response.ok) {
            const errorData = await response.json().catch(() => ({ message: 'Errore sconosciuto' }));
            console.error('Errore risposta API:', response.status, errorData);
            throw new Error(errorData.message || `Errore ${response.status}: Verifica sessione fallita`);
          }
          
          // Analizza la risposta
          const data = await response.json();
          console.log('Risposta verifica sessione:', data);
          
          if (data.status === 'success') {
            // Utilizza i dati dalla risposta, con fallback al piano dall'URL se necessario
            const finalPlan = data.plan || planFromUrl || 'monthly';
            
            // Salviamo i dettagli della sottoscrizione
            setSubscriptionData({
              ...data,
              plan: finalPlan
            });
            
            // IMPORTANTE: Utilizza il contesto Stripe per verificare e aggiornare l'abbonamento
            // Questo utilizzerà il nuovo formato di storage ed è compatibile con PremiumContent
            console.log('Verifico abbonamento tramite contesto Stripe...');
            const subscriptionResult = await verifySubscription(sessionId);
            console.log('Risultato verifica abbonamento:', subscriptionResult);
            
            // Manteniamo anche il vecchio sistema per retrocompatibilità
            // Impostazioni di localStorage - chiavi più descrittive
            localStorage.setItem('auralis_premium', 'true');
            localStorage.setItem('auralis_plan', finalPlan);
            localStorage.setItem('auralis_subscription_id', data.subscription_id || sessionId);
            localStorage.setItem('auralis_customer_id', data.customer_id || 'customer_sim');
            localStorage.setItem('auralis_subscription_date', new Date().toISOString());
            
            // Salva l'ID della sessione per future verifiche
            // Questo permette al contesto Stripe di mantenere lo stato dell'abbonamento anche dopo il riavvio
            localStorage.setItem('auralis_session_id', sessionId);
            console.log('ID sessione salvato per future verifiche:', sessionId);
            
            // Imposta il flag per indicare che è appena stato effettuato l'abbonamento
            // (usato dal componente SubscriptionStatus per mostrare un messaggio di benvenuto)
            localStorage.setItem('just_subscribed', 'true');
            
            // Se c'è un'email, la salviamo anche
            if (data.customer_email) {
              localStorage.setItem('auralis_email', data.customer_email);
            }
            
            // Effettuiamo login se non già fatto
            login();
            
            toast({
              title: "Abbonamento attivato",
              description: `Il tuo abbonamento premium ${finalPlan === 'yearly' ? 'annuale' : 'mensile'} è stato attivato con successo!`,
            });
            
            // Registriamo evento di successo - in produzione qui invieremmo evento analytics
            console.log(`Abbonamento ${finalPlan} attivato con successo`);
            
            setLoading(false);
          } else {
            setError(data.message || 'Verifica sessione fallita');
            setLoading(false);
          }
        } catch (error) {
          console.error('Errore dettagliato verifica sessione:', error);
          
          // Mostriamo un toast di errore
          toast({
            title: "Errore",
            description: "Si è verificato un errore nella verifica del pagamento",
            variant: "destructive"
          });
          
          // Impostiamo lo stato di errore
          setError("Si è verificato un errore durante la verifica del pagamento. Riprova o contatta l'assistenza.");
          setLoading(false);
          
          // In uno scenario reale, qui invieremmo il report dell'errore a un sistema di monitoraggio
        }
      };
      
      // Chiamiamo la funzione di verifica
      verifySession();
    }, 1500); // Ritardo di 1.5 secondi per simulare il tempo di elaborazione
  }, [login, toast, verifySubscription]);

  const handleContinue = () => {
    // Assicuriamoci che il redirect funzioni sempre
    window.location.href = '/';
  };
  
  const handleManageSubscription = () => {
    // Naviga alla pagina di gestione abbonamento
    window.location.href = '/manage-subscription';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50 flex flex-col items-center justify-center">
        <div className="text-center p-8">
          <div className="w-16 h-16 rounded-full bg-amber-100 mx-auto flex items-center justify-center mb-4">
            <div className="w-8 h-8 border-4 border-amber-400 border-t-amber-600 rounded-full animate-spin"></div>
          </div>
          <h1 className="text-2xl font-bold text-amber-800 mb-2">Conferma pagamento in corso...</h1>
          <p className="text-amber-600">Stiamo verificando lo stato del tuo pagamento.</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
        <ScrollToTop />
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="w-16 h-16 rounded-full bg-red-100 mx-auto flex items-center justify-center mb-4">
            <i className="ri-error-warning-line text-3xl text-red-500"></i>
          </div>
          <h1 className="text-2xl font-bold text-red-800 mb-4">Si è verificato un problema</h1>
          <p className="text-neutral-600 mb-8 max-w-md mx-auto">{error}</p>
          <Button onClick={() => window.location.href = '/subscription'} className="bg-amber-600 hover:bg-amber-700">
            Torna alla pagina di abbonamento
          </Button>
        </div>
      </div>
    );
  }

  const plan = subscriptionData?.plan || localStorage.getItem('auralis_plan') || 'monthly';
  const isAnnual = plan === 'yearly';

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      <ScrollToTop />
      <Header />
      
      <div className="container mx-auto px-4 py-12 max-w-2xl">
        <div className="w-20 h-20 rounded-full bg-emerald-100 mx-auto flex items-center justify-center mb-6">
          <Check className="w-10 h-10 text-emerald-600" />
        </div>
        
        <h1 className="text-3xl font-bold text-emerald-800 mb-4 text-center">Abbonamento attivato con successo!</h1>
        
        <p className="text-neutral-600 mb-8 text-center">
          Grazie per esserti abbonato ad Auralis Premium! Ora hai accesso illimitato a tutti i contenuti e le funzionalità esclusive.
        </p>
        
        {/* Dettagli abbonamento */}
        <div className="bg-white p-6 rounded-xl shadow-sm mb-6 border border-emerald-100">
          <h2 className="text-lg font-semibold text-emerald-700 mb-4 flex items-center">
            <CreditCard className="mr-2 h-5 w-5" /> Dettagli del tuo abbonamento
          </h2>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-neutral-600">Piano</span>
              <span className="font-medium text-emerald-700">{isAnnual ? 'Annuale' : 'Mensile'}</span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-neutral-600">Stato</span>
              <span className="px-2 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-medium">Attivo</span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-neutral-600">Prossimo rinnovo</span>
              <span className="font-medium text-neutral-700">
                {isAnnual 
                  ? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toLocaleDateString('it-IT')
                  : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('it-IT')
                }
              </span>
            </div>
            
            {subscriptionData?.subscription_id && (
              <div className="flex justify-between items-center py-2">
                <span className="text-neutral-600">ID Abbonamento</span>
                <span className="font-mono text-xs text-neutral-500">{subscriptionData.subscription_id.slice(0, 10)}...</span>
              </div>
            )}
          </div>
        </div>
        
        {/* Vantaggi premium */}
        <div className="bg-white p-6 rounded-xl shadow-sm mb-8 border border-emerald-100">
          <h2 className="text-lg font-semibold text-emerald-700 mb-4 flex items-center">
            <Zap className="mr-2 h-5 w-5" /> Il tuo abbonamento include:
          </h2>
          
          <ul className="space-y-3">
            <li className="flex items-start">
              <div className="flex-shrink-0 w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center mr-3 mt-0.5">
                <Check className="h-3 w-3 text-emerald-600" />
              </div>
              <p className="text-neutral-700">Accesso completo a tutti gli esercizi CBT avanzati</p>
            </li>
            <li className="flex items-start">
              <div className="flex-shrink-0 w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center mr-3 mt-0.5">
                <Check className="h-3 w-3 text-emerald-600" />
              </div>
              <p className="text-neutral-700">Sblocco di tutte le meditazioni guidate</p>
            </li>
            <li className="flex items-start">
              <div className="flex-shrink-0 w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center mr-3 mt-0.5">
                <Check className="h-3 w-3 text-emerald-600" />
              </div>
              <p className="text-neutral-700">Nessun limite giornaliero alle richieste</p>
            </li>
            <li className="flex items-start">
              <div className="flex-shrink-0 w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center mr-3 mt-0.5">
                <Check className="h-3 w-3 text-emerald-600" />
              </div>
              <p className="text-neutral-700">Accesso immediato ai nuovi contenuti premium</p>
            </li>
            <li className="flex items-start">
              <div className="flex-shrink-0 w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center mr-3 mt-0.5">
                <Check className="h-3 w-3 text-emerald-600" />
              </div>
              <p className="text-neutral-700">Supporto prioritario</p>
            </li>
          </ul>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={handleContinue}
            className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white px-8 py-6 rounded-full shadow"
            size="lg"
          >
            Inizia a esplorare <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
          
          <Button 
            onClick={handleManageSubscription}
            variant="outline"
            className="border-amber-200 text-amber-800 hover:bg-amber-50 px-6"
            size="lg"
          >
            <Calendar className="mr-2 h-4 w-4" /> Gestisci abbonamento
          </Button>
        </div>
        
        <p className="text-sm text-neutral-500 mt-8 text-center">
          {sessionId && <>ID transazione: {sessionId?.slice(0, 8)}...</>} • Piano: {isAnnual ? 'Annuale' : 'Mensile'} • Hai domande? <a href="#" className="text-amber-600 hover:underline">Contattaci</a>
        </p>
      </div>
    </div>
  );
}