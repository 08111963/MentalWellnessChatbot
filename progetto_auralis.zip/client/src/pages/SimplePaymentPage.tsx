import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Loader2, Info, AlertTriangle, CheckCircle } from 'lucide-react';
import { useAuth } from "@/lib/auth-context";
import { useTranslation } from 'react-i18next';

/**
 * Pagina di pagamento semplificata che simula pagamenti senza Stripe
 * Questo approccio usa localStorage per simulare un'iscrizione
 */
export default function SimplePaymentPage() {
  const [loading, setLoading] = useState<string | null>(null);
  const [, navigate] = useLocation();
  const auth = useAuth();
  const { t } = useTranslation();

  const handleSimulateSubscription = (plan: 'monthly' | 'yearly') => {
    // Indica quale piano è in caricamento
    setLoading(plan);
    
    // Simuliamo direttamente l'impostazione dell'utente come premium
    localStorage.setItem('auralis_premium', 'true');
    localStorage.setItem('auralis_plan', plan);
    localStorage.setItem('auralis_subscription_id', `subscription_${Date.now()}`);
    localStorage.setItem('auralis_customer_id', `customer_${Date.now()}`);
    localStorage.setItem('auralis_subscription_date', new Date().toISOString());
    
    // Simuliamo un breve ritardo di caricamento
    setTimeout(() => {
      navigate('/payment-success?session_id=test_session_' + Date.now() + 
              '&plan=' + plan + 
              '&customer_id=customer_' + Date.now() + 
              '&subscription_id=subscription_' + Date.now());
    }, 1500);
  };
  
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-purple-50 to-white">
      <div className="mx-auto w-full max-w-4xl px-4 py-8">
        <header className="mb-6 text-center">
          <Link href="/">
            <a className="inline-block mb-8">
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-700 to-indigo-600 bg-clip-text text-transparent">
                Auralis <span className="font-light">Premium</span>
              </h1>
            </a>
          </Link>
          
          <h2 className="text-xl font-medium text-neutral-700 mb-2">
            {t('simplePayment.title')}
          </h2>
          <p className="text-neutral-600">
            {t('simplePayment.subtitle')}
          </p>
        </header>
        
        {/* Login notice */}
        <div className={`p-4 rounded-lg mb-6 ${auth.isAuthenticated ? 'bg-green-50 border border-green-200' : 'bg-amber-50 border border-amber-200'}`}>
          {auth.isAuthenticated 
            ? <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2" />
                <div>
                  <p className="text-green-800 font-medium">
                    {t('subscriptionPage.alreadyLoggedIn')}
                  </p>
                </div>
              </div>
            : <div className="flex items-start">
                <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 mr-2" />
                <div>
                  <p className="text-amber-800 font-medium">
                    {t('subscriptionPage.loginRequired')}
                  </p>
                  <p className="text-amber-700 text-sm mt-1">
                    {t('subscriptionPage.loginRequiredDetails')}
                  </p>
                </div>
              </div>
          }
        </div>
        
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <div className="bg-white p-6 rounded-lg shadow-lg border border-amber-100">
            <h3 className="font-bold text-2xl bg-gradient-to-r from-amber-700 to-amber-600 bg-clip-text text-transparent mb-3">{t('simplePayment.yearlyPlan')}</h3>
            <div className="mb-4">
              <span className="text-3xl font-bold text-amber-900">{t('simplePayment.yearlyPrice')}</span>
              <span className="text-amber-700 ml-2">{t('subscription.perYear')}</span>
            </div>
            <p className="text-amber-600 mb-6">{t('simplePayment.yearlyDescription')}</p>
            
            <button 
              onClick={() => handleSimulateSubscription('yearly')}
              disabled={loading !== null}
              className="block w-full p-4 text-center bg-amber-500 hover:bg-amber-600 text-white rounded-md font-semibold transition-colors disabled:opacity-70"
            >
              {loading === 'yearly' ? (
                <span className="flex items-center justify-center">
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" /> {t('simplePayment.processing')}
                </span>
              ) : t('simplePayment.subscribeYearly')}
            </button>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md border border-neutral-200">
            <h3 className="font-bold text-xl text-neutral-700 mb-3">{t('simplePayment.monthlyPlan')}</h3>
            <div className="mb-4">
              <span className="text-2xl font-bold text-neutral-800">{t('simplePayment.monthlyPrice')}</span>
              <span className="text-neutral-600 ml-2">{t('subscription.perMonth')}</span>
            </div>
            <p className="text-neutral-600 mb-6">{t('simplePayment.monthlyDescription')}</p>
            
            <button 
              onClick={() => handleSimulateSubscription('monthly')}
              disabled={loading !== null}
              className="block w-full p-4 text-center bg-white border border-neutral-300 text-neutral-700 hover:bg-neutral-50 rounded-md font-medium transition-colors disabled:opacity-70"
            >
              {loading === 'monthly' ? (
                <span className="flex items-center justify-center">
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" /> {t('simplePayment.processing')}
                </span>
              ) : t('simplePayment.subscribeMonthly')}
            </button>
          </div>
        </div>
        
        <div className="mb-6 text-center">
          <Link href="/">
            <a className="inline-flex items-center text-neutral-600 hover:text-purple-600">
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              {t('simplePayment.backToHome')}
            </a>
          </Link>
        </div>
        
        <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-md border border-purple-100 mb-8">
          <h3 className="text-xl font-bold text-center text-purple-900 mb-4">{t('simplePayment.faqTitle')}</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-bold text-purple-800 mb-1">{t('simplePayment.faqSubscriptionQuestion')}</h4>
              <p className="text-neutral-700">{t('simplePayment.faqSubscriptionAnswer')}</p>
            </div>
            <div>
              <h4 className="font-bold text-purple-800 mb-1">{t('simplePayment.faqCancellationQuestion')}</h4>
              <p className="text-neutral-700">{t('simplePayment.faqCancellationAnswer')}</p>
            </div>
          </div>
        </div>
        
        <div className="text-center text-sm text-neutral-500">
          <p>© 2025 Auralis. {t('simplePayment.footer')}</p>
        </div>
      </div>
    </div>
  );
}