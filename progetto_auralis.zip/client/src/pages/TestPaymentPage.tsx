import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { toast } from '@/hooks/use-toast';

/**
 * Pagina di test di pagamento per verificare e simulare il processo di abbonamento
 * Questa pagina è pensata per testare il flusso senza dipendere dall'integrazione Stripe
 */
export default function TestPaymentPage() {
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  
  // Funzione per simulare il completamento del pagamento
  const simulatePayment = (plan: 'monthly' | 'yearly') => {
    setLoading(true);
    
    setTimeout(() => {
      // Simuliamo il pagamento completato
      localStorage.setItem('auralis_premium', 'true');
      localStorage.setItem('auralis_plan', plan);
      
      toast({
        title: "Abbonamento attivato",
        description: `Il tuo abbonamento ${plan === 'monthly' ? 'mensile' : 'annuale'} è stato attivato con successo!`,
        variant: "default",
      });
      
      setLoading(false);
      
      // Redirezione alla pagina di successo
      setLocation('/payment-success?mode=simulated');
    }, 1500);
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-purple-50 to-white">
      <div className="container max-w-7xl mx-auto px-4 py-8">
        <header className="text-center mb-10">
          <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-purple-700 to-indigo-600 bg-clip-text text-transparent">
            Modalità di Test
          </h1>
          <p className="text-lg text-neutral-600">
            Questa pagina consente di simulare il processo di abbonamento
          </p>
        </header>
        
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Card className="p-6 border border-amber-200 shadow-md relative overflow-hidden">
            <div className="z-10 relative">
              <h2 className="text-2xl font-bold text-amber-800 mb-3">Piano Mensile</h2>
              <div className="mb-4">
                <span className="text-3xl font-bold">€4,99</span>
                <span className="text-neutral-600 ml-2">/mese</span>
              </div>
              <ul className="mb-6 space-y-2">
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                  </svg>
                  Accesso illimitato a tutti i contenuti
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                  </svg>
                  Cancella in qualsiasi momento
                </li>
              </ul>
              <Button 
                className="w-full bg-amber-500 hover:bg-amber-600 text-white" 
                onClick={() => simulatePayment('monthly')}
                disabled={loading}
              >
                {loading ? 'Elaborazione...' : 'Attiva Piano Mensile'}
              </Button>
            </div>
            <div className="absolute top-0 right-0 w-40 h-40 -translate-y-1/2 translate-x-1/2 bg-amber-100 rounded-full opacity-50"></div>
          </Card>
          
          <Card className="p-6 border border-purple-200 shadow-lg relative overflow-hidden">
            <div className="absolute top-0 left-0 bg-purple-600 text-white text-xs px-3 py-1 rounded-br-md">
              Consigliato
            </div>
            <div className="z-10 relative">
              <h2 className="text-2xl font-bold text-purple-800 mb-3">Piano Annuale</h2>
              <div className="mb-4">
                <span className="text-3xl font-bold">€39,99</span>
                <span className="text-neutral-600 ml-2">/anno</span>
              </div>
              <div className="mb-2 bg-purple-100 text-purple-800 text-sm py-1 px-2 rounded-md inline-block">
                Risparmia il 33%
              </div>
              <ul className="mb-6 space-y-2">
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                  </svg>
                  Accesso illimitato a tutti i contenuti
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                  </svg>
                  Equivalente a €3,33 al mese
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                  </svg>
                  Accesso prioritario alle nuove funzionalità
                </li>
              </ul>
              <Button 
                className="w-full bg-purple-600 hover:bg-purple-700 text-white" 
                onClick={() => simulatePayment('yearly')}
                disabled={loading}
              >
                {loading ? 'Elaborazione...' : 'Attiva Piano Annuale'}
              </Button>
            </div>
            <div className="absolute bottom-0 right-0 w-40 h-40 translate-y-1/3 translate-x-1/3 bg-purple-100 rounded-full opacity-50"></div>
          </Card>
        </div>
        
        <div className="mt-8 text-center">
          <Button variant="link" onClick={() => setLocation('/')}>
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
            </svg>
            Torna alla home
          </Button>
        </div>
        
        <div className="mt-10 max-w-3xl mx-auto bg-white/50 backdrop-blur-sm p-6 rounded-lg border border-neutral-200 shadow-sm">
          <h3 className="text-xl font-semibold text-center mb-4 text-purple-800">Informazioni sul Test</h3>
          <p className="text-neutral-700 mb-4">
            Questa è una pagina di simulazione del pagamento. Utilizzala per testare il flusso di abbonamento senza effettuare 
            transazioni reali. Tutti i dati dell'abbonamento saranno salvati localmente nel browser.
          </p>
          <div className="bg-amber-50 border border-amber-200 p-3 rounded-md text-amber-700 text-sm">
            <strong>Nota:</strong> In un'applicazione reale, questa pagina non esisterebbe e i pagamenti sarebbero elaborati 
            tramite Stripe o un altro processore di pagamenti sicuro.
          </div>
        </div>
      </div>
    </div>
  );
}