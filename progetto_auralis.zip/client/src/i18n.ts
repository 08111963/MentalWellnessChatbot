import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Carica direttamente i file di traduzione (senza backend)
import translationIT from '../../public/locales/it/translation.json';
import translationEN from '../../public/locales/en/translation.json';

// Risorse di traduzione statiche
const resources = {
  it: {
    translation: translationIT
  },
  en: {
    translation: translationEN
  }
};

i18n
  // Rileva la lingua del browser
  .use(LanguageDetector)
  // Passa l'i18n all'istanza react-i18next
  .use(initReactI18next)
  // Inizializza i18next
  .init({
    resources, // Risorse di traduzione precaricate
    fallbackLng: 'en', // Lingua predefinita (inglese)
    supportedLngs: ['it', 'en'], // Lingue supportate: solo italiano e inglese
    debug: true, // Attiva debug per vedere messaggi di console
    
    interpolation: {
      escapeValue: false, // non necessario per React
    },
    
    // Priorità di rilevamento della lingua
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage'],
    },
    
    react: {
      useSuspense: false, // Disabilita suspense per evitare problemi
    },
  });

console.log('i18n initialized with resources:', Object.keys(resources));

export default i18n;