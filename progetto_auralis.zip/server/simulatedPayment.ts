/**
 * Servizio di pagamento simulato
 * Implementa funzionalità simulate per test senza dipendere da Stripe
 */

import { Request, Response } from 'express';
import { SIMULATION_CONFIG } from './config';

// Interfaccia per i dati della sessione simulata
export interface SimulatedSession {
  id: string;
  created: number;
  plan: 'monthly' | 'yearly';
  customerId: string;
  subscriptionId: string;
  status: 'complete' | 'cancelled';
  amount: number;
  currency: string;
}

// Storage in-memory per le sessioni simulate
const sessions: Record<string, SimulatedSession> = {};

/**
 * Crea una sessione di pagamento simulata
 * @param planType Tipo di piano ('monthly' o 'yearly')
 * @returns ID della sessione creata
 */
export function createSimulatedSession(planType: 'monthly' | 'yearly'): string {
  const sessionId = `sim_session_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const customerId = `sim_customer_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const subscriptionId = `sim_subscription_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  
  const amount = planType === 'monthly' 
    ? SIMULATION_CONFIG.PRICES.MONTHLY 
    : SIMULATION_CONFIG.PRICES.YEARLY;
  
  sessions[sessionId] = {
    id: sessionId,
    created: Date.now(),
    plan: planType,
    customerId,
    subscriptionId,
    status: 'complete',
    amount,
    currency: 'eur'
  };
  
  return sessionId;
}

/**
 * Ottiene una sessione simulata
 * @param sessionId ID della sessione
 * @returns Dati della sessione o null se non trovata
 */
export function getSimulatedSession(sessionId: string): SimulatedSession | null {
  return sessions[sessionId] || null;
}

/**
 * Handler per creare una sessione di checkout simulata
 */
export function createCheckoutSession(req: Request, res: Response) {
  try {
    const { priceId } = req.body;
    
    if (!priceId) {
      return res.status(400).json({ message: 'ID prezzo non fornito' });
    }
    
    // Determina il tipo di piano in base all'ID del prezzo
    const isPriceMonthly = priceId.includes('monthly') || priceId.toLowerCase().includes('month');
    const planType = isPriceMonthly ? 'monthly' : 'yearly';
    
    // Crea una sessione simulata
    const sessionId = createSimulatedSession(planType);
    
    // URL di successo con il sessionId come parametro
    const successUrl = `${req.protocol}://${req.get('host')}/payment-success?session_id=${sessionId}&plan=${planType}`;
    
    // Rispondi con l'URL di reindirizzamento
    return res.json({ url: successUrl });
  } catch (error) {
    console.error('Errore simulazione checkout:', error);
    res.status(500).json({ 
      message: 'Errore durante la creazione della sessione di checkout simulata', 
      error: error instanceof Error ? error.message : 'Errore sconosciuto' 
    });
  }
}

/**
 * Handler per reindirizzare a una pagina di abbonamento simulata
 */
export function redirectToSubscription(req: Request, res: Response) {
  try {
    // Ottieni il piano dai query params (plan=monthly o plan=yearly)
    const plan = req.query.plan as string; 
    
    if (!plan || (plan !== 'monthly' && plan !== 'yearly')) {
      return res.status(400).json({ message: 'Piano non valido. Utilizzare plan=monthly o plan=yearly' });
    }
    
    const planType = plan;
    console.log(`Redirecting to ${planType} subscription`);
    
    // Crea una sessione simulata
    const sessionId = createSimulatedSession(planType);
    
    // Costruisci l'URL di successo
    const successUrl = `${req.protocol}://${req.get('host')}/payment-success?session_id=${sessionId}&plan=${planType}`;
    
    console.log(`Redirecting to ${successUrl}`);
    
    // Reindirizza alla pagina di successo
    res.redirect(successUrl);
  } catch (error) {
    console.error('Errore reindirizzamento simulato:', error);
    res.status(500).json({ 
      message: 'Errore durante il reindirizzamento alla pagina di checkout simulata', 
      error: error instanceof Error ? error.message : 'Errore sconosciuto' 
    });
  }
}

/**
 * Handler per verificare lo stato di una sessione simulata
 */
export function verifySession(req: Request, res: Response) {
  try {
    const sessionId = req.query.session_id as string;
    const lastKnownSessionId = req.query.last_known_session as string;
    
    // CORREZIONE: Rifiuta esplicitamente le sessioni di test
    // Controlla se la sessione attuale è una sessione di test
    if (sessionId && sessionId.startsWith('cs_test_')) {
      console.log('simulatedPayment.verifySession: Rilevata sessione di test nel parametro session_id, rifiuto:', sessionId);
      return res.status(200).json({
        status: 'inactive',
        message: 'Sessione di test rifiutata'
      });
    }
    
    // Controlla se la sessione precedente era una sessione di test
    if (lastKnownSessionId && lastKnownSessionId.startsWith('cs_test_')) {
      console.log('simulatedPayment.verifySession: Rilevata sessione di test nel parametro last_known_session, rifiuto:', lastKnownSessionId);
      return res.status(200).json({
        status: 'inactive',
        message: 'Sessione di test rifiutata'
      });
    }
    
    // Se non viene fornito un session_id, significa che stiamo verificando se l'utente
    // ha un abbonamento attivo senza un ID specifico.
    // In questo caso, restituiamo inactive per indicare che non c'è un abbonamento attivo
    if (!sessionId && !lastKnownSessionId) {
      console.log('simulatedPayment.verifySession: Nessun session_id fornito, restituisco stato inactive');
      return res.status(200).json({ 
        status: 'inactive',
        message: 'Nessun abbonamento attivo trovato'
      });
    }
    
    // Usa sessionId se disponibile, altrimenti lastKnownSessionId
    const idToCheck = sessionId || lastKnownSessionId;
    
    const session = getSimulatedSession(idToCheck);
    
    if (!session) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Sessione simulata non trovata' 
      });
    }
    
    // Simula il processo di pagamento (aggiungendo un passaggio extra)
    // In una implementazione reale questo verifica il pagamento con Stripe
    const paymentSuccessful = idToCheck.includes('sim_session');
    
    if (!paymentSuccessful) {
      return res.status(400).json({
        status: 'error',
        message: 'Il pagamento simulato non è stato completato correttamente'
      });
    }
    
    // Aggiorna lo stato interno della sessione se necessario
    if (session.status !== 'complete') {
      session.status = 'complete';
      console.log(`Sessione ${idToCheck} aggiornata a 'complete'`);
    }
    
    // Aggiungiamo un ritardo simulato per rendere l'esperienza più realistica
    setTimeout(() => {
      // Simula i campi che verrebbero restituiti da Stripe
      res.json({
        status: 'success',
        plan: session.plan,
        session_id: session.id,
        customer_id: session.customerId,
        subscription_id: session.subscriptionId,
        customer_email: 'utente@example.com',
        amount: session.amount,
        currency: session.currency,
        created: session.created,
        payment_status: 'paid'
      });
    }, Math.min(500, Math.random() * 1000)); // Ritardo casuale fino a 500ms
  } catch (error) {
    console.error('Errore verifica sessione simulata:', error);
    res.status(500).json({ 
      status: 'error',
      message: error instanceof Error ? error.message : 'Errore verifica sessione' 
    });
  }
}

/**
 * Funzione per cancellare un abbonamento simulato
 */
export async function cancelSubscription(userId: number, subscriptionId: string | null): Promise<boolean> {
  try {
    console.log(`Tentativo di cancellare l'abbonamento simulato ${subscriptionId} per l'utente ${userId}`);
    
    // Aggiornamento dello stato dell'utente nel database
    const { storage } = await import('./storage');
    const updatedUser = await storage.updateUserSubscription(userId, {
      isPremium: false,
      subscriptionStatus: 'cancelled',
      // Manteniamo gli altri dati per riferimento storico
    });
    
    if (updatedUser) {
      console.log(`Abbonamento simulato cancellato con successo per l'utente ${userId} nel database`);
      return true;
    } else {
      console.error(`Errore nell'aggiornamento dello stato dell'abbonamento simulato nel database per l'utente ${userId}`);
      return false;
    }
  } catch (error) {
    console.error(`Errore durante la cancellazione dell'abbonamento simulato:`, error);
    return false;
  }
}

/**
 * Webhook handler simulato
 */
export function handleWebhook(req: Request, res: Response) {
  try {
    // Estrai i dati dal body della richiesta
    const event = req.body;
    
    console.log('Webhook simulato ricevuto:', event?.type || 'unknown event');
    
    // Puoi simulare diversi tipi di eventi
    if (event && event.type) {
      switch (event.type) {
        case 'checkout.session.completed':
          console.log('Simulazione: Checkout completato con successo');
          // Qui potresti attivare altre funzionalità del sistema
          break;
        case 'customer.subscription.updated':
          console.log('Simulazione: Abbonamento aggiornato');
          break;
        case 'customer.subscription.deleted':
          console.log('Simulazione: Abbonamento cancellato');
          break;
        default:
          console.log(`Simulazione: Evento ${event.type} non gestito`);
      }
    }
    
    // Aggiungiamo un ritardo realistico per la simulazione (100-300ms)
    setTimeout(() => {
      // Sempre ritorna un successo in formato standard Stripe
      res.status(200).json({ received: true });
    }, 100 + Math.random() * 200);
  } catch (error) {
    console.error('Errore nella gestione del webhook simulato:', error);
    res.status(400).json({ 
      error: {
        message: error instanceof Error ? error.message : 'Errore nel webhook simulato'
      }
    });
  }
}