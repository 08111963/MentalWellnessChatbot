/**
 * Servizio di pagamento Stripe
 * Implementazione reale delle funzionalità di pagamento con Stripe
 * Aggiornato per supportare la distribuzione multi-piattaforma
 */

import { Request, Response } from 'express';
import Stripe from 'stripe';
import { STRIPE_CONFIG, PAYMENT_MODE } from './config';
import { storage } from './storage';
import { getBaseUrl, getSuccessUrl, getCancelUrl } from './platformUtils';

// Inizializzazione di Stripe con la chiave segreta
const stripeSecretKey = STRIPE_CONFIG.SECRET_KEY;
const stripe = new Stripe(stripeSecretKey);

/**
 * Funzione per creare una sessione di checkout Stripe
 */
export async function createCheckoutSession(req: Request, res: Response) {
  try {
    console.log('Richiesta di creazione sessione Stripe ricevuta:', req.body);
    const { priceId, userId } = req.body;
    
    if (!priceId) {
      console.log('Errore: ID prezzo non fornito');
      return res.status(400).json({ message: 'ID prezzo non fornito' });
    }
    
    // Verifica che l'userId sia fornito - OBBLIGATORIO
    if (!userId) {
      console.error('Errore: userId mancante nella richiesta di abbonamento');
      return res.status(401).json({ 
        message: 'Autenticazione richiesta: È necessario effettuare l\'accesso prima di sottoscrivere un abbonamento.',
        redirectTo: '/?openAuth=true'
      });
    }

    console.log('ID del prezzo ricevuto:', priceId);
    console.log('ID utente:', userId);
    
    // Crea la configurazione di base per la sessione
    const sessionConfig: Stripe.Checkout.SessionCreateParams = {
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      locale: 'en', // Forza la lingua inglese per il checkout
      success_url: `${req.protocol}://${req.get('host')}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.protocol}://${req.get('host')}/subscription`,
      metadata: {
        userId: userId.toString()
      }
    };
    
    console.log('Aggiunto userId ai metadati della sessione:', userId);
      
    // Importa la funzione storage per verificare l'utente
    try {
      const { storage } = await import('./storage');
      const user = await storage.getUser(parseInt(userId.toString()));
      
      // Se l'utente ha già un ID cliente su Stripe, riutilizziamolo
      if (user && user.stripeCustomerId) {
        sessionConfig.customer = user.stripeCustomerId;
        console.log('Riutilizzo cliente Stripe esistente:', user.stripeCustomerId);
      }
    } catch (err) {
      console.warn('Impossibile verificare l\'utente, continuo senza associare customer:', err);
    }
    
    // Crea una sessione di checkout con Stripe usando l'ID prezzo passato
    const session = await stripe.checkout.sessions.create(sessionConfig);

    console.log('Sessione creata:', session.id);
    console.log('URL di checkout:', session.url);

    // Restituisci l'URL di checkout
    return res.json({ url: session.url });
  } catch (error) {
    console.error('Errore Stripe:', error);
    
    res.status(500).json({ 
      message: 'Errore durante la creazione della sessione di checkout', 
      error: error instanceof Error ? error.message : 'Errore sconosciuto' 
    });
  }
}

/**
 * Funzione per reindirizzare direttamente a una pagina di abbonamento
 */
export async function redirectToSubscription(req: Request, res: Response) {
  try {
    const plan = req.query.plan as string; // 'monthly' o 'yearly'
    if (!plan || (plan !== 'monthly' && plan !== 'yearly')) {
      return res.status(400).json({ message: 'Piano non valido. Specificare "monthly" o "yearly".' });
    }
    
    // Ottieni l'ID utente dalla query string - OBBLIGATORIO
    const userId = req.query.userId as string;
    console.log('redirectToSubscription: piano=', plan, 'userId=', userId);
    
    // Verifica che l'userId sia fornito
    if (!userId) {
      console.error('Errore: userId mancante nella richiesta di abbonamento');
      return res.status(401).json({ 
        message: 'Autenticazione richiesta: È necessario effettuare l\'accesso prima di sottoscrivere un abbonamento.',
        redirectTo: '/?openAuth=true'
      });
    }
    
    const priceId = plan === 'monthly' ? STRIPE_CONFIG.PRICES.MONTHLY : STRIPE_CONFIG.PRICES.YEARLY;
    
    // Forziamo l'inglese per il checkout di Stripe
    
    // Crea la configurazione di base per la sessione
    const sessionConfig: Stripe.Checkout.SessionCreateParams = {
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      locale: 'en', // Forza la lingua inglese per il checkout
      success_url: `${req.protocol}://${req.get('host')}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.protocol}://${req.get('host')}/subscription`,
      metadata: {
        userId: userId.toString()
      }
    };
    
    // Crea una sessione di checkout con Stripe
    const session = await stripe.checkout.sessions.create(sessionConfig);

    // Redirezione diretta alla pagina Stripe
    if (session.url) {
      res.redirect(session.url);
    } else {
      res.status(500).send('Errore: URL di checkout non generato');
    }
  } catch (error) {
    console.error('Errore reindirizzamento Stripe:', error);
    res.status(500).json({ 
      message: 'Errore durante il reindirizzamento alla pagina di checkout', 
      error: error instanceof Error ? error.message : 'Errore sconosciuto' 
    });
  }
}

/**
 * Funzione per gestire i webhook di Stripe
 */
export async function handleWebhook(req: Request, res: Response) {
  const endpointSecret = STRIPE_CONFIG.WEBHOOK_SECRET;
  const sig = req.headers['stripe-signature'] as string | undefined;
  
  try {
    let event;
    
    if (endpointSecret && sig) {
      // Verifica la firma del webhook quando il secret è configurato
      try {
        event = stripe.webhooks.constructEvent(
          (req as any).rawBody || req.body, 
          sig, 
          endpointSecret
        );
        console.log('✓ Webhook Stripe verificato con successo');
      } catch (err) {
        console.error('❌ Errore verifica firma webhook:', err);
        return res.status(400).send(`Webhook Error: ${err instanceof Error ? err.message : 'Unknown error'}`);
      }
    } else {
      // Modalità di sviluppo o test - accetta il payload senza verifica della firma
      console.log('⚠️ Webhook ricevuto senza verifica (STRIPE_WEBHOOK_SECRET non configurato)');
      if (!sig) {
        console.log('⚠️ Header stripe-signature mancante nella richiesta');
      }
      
      // In ambienti di produzione, dovresti considerare la possibilità di rifiutare
      // le richieste webhook non verificate
      if (PAYMENT_MODE === 'production') {
        console.warn('⚠️ Si consiglia di configurare STRIPE_WEBHOOK_SECRET per l\'ambiente di produzione');
      }
      
      event = req.body;
    }
    
    // Gestisci diversi tipi di eventi
    switch (event.type) {
      case 'checkout.session.completed':
        const session = event.data.object;
        console.log('Checkout completato, sessione ID:', session.id);
        
        // Verifica che il pagamento sia stato effettivamente completato
        if (session.payment_status === 'paid') {
          // Nel caso di abbonamento
          if (session.subscription) {
            // Ottieni i dettagli dell'abbonamento
            const subscription = await stripe.subscriptions.retrieve(session.subscription);
            console.log('Abbonamento attivato:', subscription.id);
            
            // Determina il tipo di piano
            const isAnnual = subscription.items.data.some(item => {
              return item.price.recurring?.interval === 'year';
            });
            const plan = isAnnual ? 'yearly' : 'monthly';
            
            // Calcoliamo la data di scadenza basata sul piano
            const startDate = new Date();
            const endDate = new Date(startDate);
            if (plan === 'yearly') {
              endDate.setFullYear(startDate.getFullYear() + 1);
            } else {
              endDate.setMonth(startDate.getMonth() + 1);
            }
            
            // Log dettagli abbonamento
            console.log('Abbonamento attivato:', {
              plan,
              subscriptionId: subscription.id,
              customerId: session.customer
            });
            
            // Verifica se la sessione ha metadati con userId
            let userId = null;
            if (session.metadata && session.metadata.userId) {
              userId = parseInt(session.metadata.userId as string);
              console.log('Trovato userId nei metadati della sessione:', userId);
            }
            
            const customerId = typeof session.customer === 'string' ? session.customer : null;
            
            // Aggiorna l'utente se abbiamo un ID utente o un ID cliente
            if (userId || customerId) {
              try {
                const { storage } = await import('./storage');
                
                if (userId) {
                  // Aggiorna l'utente con le informazioni dell'abbonamento
                  const updatedUser = await storage.updateUserSubscription(userId, {
                    isPremium: true,
                    subscriptionPlan: plan,
                    stripeCustomerId: customerId as string,
                    stripeSubscriptionId: subscription.id,
                    subscriptionStart: startDate,
                    subscriptionEnd: endDate,
                    subscriptionStatus: 'active'
                  });
                  
                  console.log('Webhook: Abbonamento utente aggiornato nel database:', updatedUser);
                } else if (customerId) {
                  // Cerca l'utente per ID cliente
                  const user = await storage.getUserByStripeCustomerId(customerId);
                  
                  if (user) {
                    // Aggiorna l'utente esistente
                    const updatedUser = await storage.updateUserSubscription(user.id, {
                      isPremium: true,
                      subscriptionPlan: plan,
                      stripeSubscriptionId: subscription.id,
                      subscriptionStart: startDate,
                      subscriptionEnd: endDate,
                      subscriptionStatus: 'active'
                    });
                    
                    console.log('Webhook: Abbonamento utente aggiornato nel database:', updatedUser);
                  } else {
                    console.log('Webhook: Nessun utente trovato per il customer ID:', customerId);
                  }
                }
              } catch (err) {
                console.error('Webhook: Errore nell\'aggiornamento dell\'utente:', err);
              }
            } else {
              console.log('Webhook: Nessun userId o customerId trovato per la sessione');
            }
          }
        }
        break;
        
      // Altri casi per gestire eventi diversi
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted':
      case 'invoice.payment_succeeded':
      case 'invoice.payment_failed':
        console.log(`Evento Stripe ricevuto: ${event.type}`);
        break;
        
      default:
        console.log(`Evento Stripe non gestito: ${event.type}`);
    }

    res.json({ received: true });
  } catch (error) {
    console.error('Errore webhook Stripe:', error);
    res.status(400).json({ webhook_error: error instanceof Error ? error.message : 'Errore webhook' });
  }
}

/**
 * Funzione per cancellare un abbonamento esistente
 */
export async function cancelSubscription(userId: number, subscriptionId: string | null): Promise<boolean> {
  try {
    console.log(`Tentativo di cancellare l'abbonamento ${subscriptionId} per l'utente ${userId}`);
    
    // Se abbiamo un ID abbonamento e siamo in ambiente di produzione, lo cancelliamo su Stripe
    if (subscriptionId && PAYMENT_MODE === 'production' && !subscriptionId.startsWith('sub_simulated')) {
      await stripe.subscriptions.update(subscriptionId, {
        cancel_at_period_end: true,
      });
      console.log(`Abbonamento ${subscriptionId} impostato per la cancellazione alla fine del periodo corrente su Stripe`);
    } else {
      console.log(`Abbonamento simulato o modalità di sviluppo, nessuna azione richiesta su Stripe`);
    }
    
    // Aggiornamento dello stato dell'utente nel database
    const updatedUser = await storage.updateUserSubscription(userId, {
      isPremium: false,
      subscriptionStatus: 'cancelled',
      // Manteniamo gli altri dati per riferimento storico
    });
    
    if (updatedUser) {
      console.log(`Abbonamento cancellato con successo per l'utente ${userId} nel database`);
      return true;
    } else {
      console.error(`Errore nell'aggiornamento dello stato dell'abbonamento nel database per l'utente ${userId}`);
      return false;
    }
  } catch (error) {
    console.error(`Errore durante la cancellazione dell'abbonamento:`, error);
    return false;
  }
}

/**
 * Funzione per verificare lo stato di una sessione
 */
export async function verifySession(req: Request, res: Response) {
  try {
    const sessionId = req.query.session_id as string;
    const lastKnownSessionId = req.query.last_known_session as string;
    
    // Verifica se stiamo usando una chiave API di test di Stripe
    const isUsingTestKey = STRIPE_CONFIG.SECRET_KEY.startsWith('sk_test_');
    
    // Per risolvere il problema dell'attivazione del piano premium senza pagamento,
    // Rifiutiamo SEMPRE le vecchie sessioni di test nel parametro last_known_session
    if (lastKnownSessionId && lastKnownSessionId.startsWith('cs_test_')) {
      console.log('verifySession: Rilevata sessione di test nel parametro last_known_session, rifiuto:', lastKnownSessionId);
      return res.status(200).json({
        status: 'inactive',
        message: 'Sessione di test scaduta, è necessario effettuare un nuovo pagamento'
      });
    }
    
    // Verifichiamo le sessioni di test principali (non last_known) solo se stiamo usando API di test
    if (!isUsingTestKey) {
      // CORREZIONE: Rifiuta esplicitamente le sessioni di test quando NON siamo in ambiente di test
      // Controlla se la sessione attuale è una sessione di test
      if (sessionId && sessionId.startsWith('cs_test_')) {
        console.log('verifySession: Rilevata sessione di test nel parametro session_id, rifiuto:', sessionId);
        return res.status(200).json({
          status: 'inactive',
          message: 'Sessione di test rifiutata'
        });
      }
    } else {
      console.log('verifySession: Accettando sessioni di test attive poiché stiamo usando la chiave API di test di Stripe');
    }
    
    // Se abbiamo un sessionId, lo usiamo direttamente
    if (sessionId) {
      console.log('verifySession: Verifico sessione con ID:', sessionId);
      
      // Recupera le informazioni sulla sessione da Stripe
      const session = await stripe.checkout.sessions.retrieve(sessionId);
      
      if (!session) {
        return res.status(404).json({ 
          status: 'error',
          message: 'Sessione non trovata' 
        });
      }
      
      // Verifica lo stato del pagamento
      if (session.payment_status !== 'paid') {
        return res.status(400).json({ 
          status: 'error',
          message: 'Pagamento non completato' 
        });
      }
      
      // Verifica il tipo di piano abbonamento
      let plan = 'monthly';
      let subscriptionId = null;
      let customerId = typeof session.customer === 'string' ? session.customer : session.customer_details?.email || 'unknown';
      
      if (session.subscription && typeof session.subscription === 'string') {
        const subscription = await stripe.subscriptions.retrieve(session.subscription);
        subscriptionId = subscription.id;
        const isAnnual = subscription.items.data.some((item: any) => {
          return item.price.recurring?.interval === 'year';
        });
        
        plan = isAnnual ? 'yearly' : 'monthly';
      }
      
      // Calcoliamo la data di scadenza basata sul piano
      const startDate = new Date();
      const endDate = new Date(startDate);
      if (plan === 'yearly') {
        endDate.setFullYear(startDate.getFullYear() + 1);
      } else {
        endDate.setMonth(startDate.getMonth() + 1);
      }
      
      // Cerca se l'utente è associato a questa sessione tramite metadati
      let userId = null;
      if (session.metadata && session.metadata.userId) {
        userId = parseInt(session.metadata.userId as string);
        console.log('Trovato userId nei metadati della sessione:', userId);
      }
      
      // Se abbiamo un utente, aggiorniamo il suo stato di abbonamento nel database
      if (userId) {
        try {
          const { storage } = await import('./storage');
          
          // Aggiorna l'utente con le informazioni dell'abbonamento
          const updatedUser = await storage.updateUserSubscription(userId, {
            isPremium: true,
            subscriptionPlan: plan,
            stripeCustomerId: customerId as string,
            stripeSubscriptionId: subscriptionId as string,
            subscriptionStart: startDate,
            subscriptionEnd: endDate,
            subscriptionStatus: 'active'
          });
          
          console.log('Abbonamento utente aggiornato nel database:', updatedUser);
        } catch (err) {
          console.warn('Errore nell\'aggiornamento dell\'utente:', err);
          // Continua comunque, poiché il localStorage sarà aggiornato
        }
      } else if (customerId) {
        // Se non abbiamo trovato l'utente nei metadati ma abbiamo un customer ID,
        // cerchiamo se esiste un utente con questo customer ID
        try {
          const { storage } = await import('./storage');
          const user = await storage.getUserByStripeCustomerId(customerId as string);
          
          if (user) {
            console.log('Trovato utente con stripeCustomerId:', user.id);
            
            // Aggiorna l'utente con le informazioni dell'abbonamento
            const updatedUser = await storage.updateUserSubscription(user.id, {
              isPremium: true,
              subscriptionPlan: plan,
              stripeSubscriptionId: subscriptionId as string,
              subscriptionStart: startDate,
              subscriptionEnd: endDate,
              subscriptionStatus: 'active'
            });
            
            console.log('Abbonamento utente aggiornato nel database:', updatedUser);
            userId = user.id;
          }
        } catch (err) {
          console.warn('Errore nella ricerca dell\'utente per customerId:', err);
        }
      }
      
      // Restituisce successo e informazioni sul piano
      return res.json({
        status: 'success',
        plan,
        session_id: sessionId,
        customer_id: customerId,
        subscription_id: subscriptionId,
        customer_email: session.customer_details?.email,
        amount: session.amount_total,
        userId: userId, // Aggiungiamo l'ID utente alla risposta
        expiresAt: endDate.toISOString() // Aggiungiamo la data di scadenza
      });
    } 
    // Se abbiamo un lastKnownSessionId, proviamo a usare quello
    else if (lastKnownSessionId) {
      console.log('verifySession: Utilizzo last_known_session:', lastKnownSessionId);
      
      try {
        // Recupera le informazioni sulla sessione da Stripe
        const session = await stripe.checkout.sessions.retrieve(lastKnownSessionId);
        
        if (session && session.payment_status === 'paid') {
          // Verifica il tipo di piano abbonamento
          let plan = 'monthly';
          let subscriptionId = null;
          let customerId = typeof session.customer === 'string' ? session.customer : session.customer_details?.email || 'unknown';
          
          if (session.subscription && typeof session.subscription === 'string') {
            const subscription = await stripe.subscriptions.retrieve(session.subscription);
            subscriptionId = subscription.id;
            const isAnnual = subscription.items.data.some((item: any) => {
              return item.price.recurring?.interval === 'year';
            });
            
            plan = isAnnual ? 'yearly' : 'monthly';
          }
          
          // Calcoliamo la data di scadenza basata sul piano
          const startDate = new Date();
          const endDate = new Date(startDate);
          if (plan === 'yearly') {
            endDate.setFullYear(startDate.getFullYear() + 1);
          } else {
            endDate.setMonth(startDate.getMonth() + 1);
          }
          
          // Cerca se l'utente è associato a questa sessione tramite metadati
          let userId = null;
          if (session.metadata && session.metadata.userId) {
            userId = parseInt(session.metadata.userId as string);
            console.log('Trovato userId nei metadati della sessione:', userId);
          }
          
          // Se abbiamo un utente, aggiorniamo il suo stato di abbonamento nel database
          if (userId) {
            try {
              const { storage } = await import('./storage');
              
              // Aggiorna l'utente con le informazioni dell'abbonamento
              const updatedUser = await storage.updateUserSubscription(userId, {
                isPremium: true,
                subscriptionPlan: plan,
                stripeCustomerId: customerId as string,
                stripeSubscriptionId: subscriptionId as string,
                subscriptionStart: startDate,
                subscriptionEnd: endDate,
                subscriptionStatus: 'active'
              });
              
              console.log('Abbonamento utente aggiornato nel database:', updatedUser);
            } catch (err) {
              console.warn('Errore nell\'aggiornamento dell\'utente:', err);
              // Continua comunque, poiché il localStorage sarà aggiornato
            }
          } else if (customerId) {
            // Se non abbiamo trovato l'utente nei metadati ma abbiamo un customer ID,
            // cerchiamo se esiste un utente con questo customer ID
            try {
              const { storage } = await import('./storage');
              const user = await storage.getUserByStripeCustomerId(customerId as string);
              
              if (user) {
                console.log('Trovato utente con stripeCustomerId:', user.id);
                
                // Aggiorna l'utente con le informazioni dell'abbonamento
                const updatedUser = await storage.updateUserSubscription(user.id, {
                  isPremium: true,
                  subscriptionPlan: plan,
                  stripeSubscriptionId: subscriptionId as string,
                  subscriptionStart: startDate,
                  subscriptionEnd: endDate,
                  subscriptionStatus: 'active'
                });
                
                console.log('Abbonamento utente aggiornato nel database:', updatedUser);
                userId = user.id;
              }
            } catch (err) {
              console.warn('Errore nella ricerca dell\'utente per customerId:', err);
            }
          }
          
          // Restituisce successo e informazioni sul piano
          return res.json({
            status: 'success',
            plan,
            session_id: lastKnownSessionId,
            customer_id: customerId,
            subscription_id: subscriptionId,
            customer_email: session.customer_details?.email,
            amount: session.amount_total,
            userId: userId, // Aggiungiamo l'ID utente alla risposta
            expiresAt: endDate.toISOString() // Aggiungiamo la data di scadenza
          });
        }
      } catch (err) {
        console.error('Errore nel recupero della sessione salvata:', err);
        // Continuiamo con il flusso normale se non riusciamo a recuperare la sessione
      }
    }
    
    // Se arriviamo qui, non abbiamo una sessione valida
    console.log('verifySession: Nessun session_id valido fornito, restituisco stato inactive');
    return res.status(200).json({ 
      status: 'inactive',
      message: 'Nessun abbonamento attivo trovato' 
    });
  } catch (error) {
    console.error('Errore verifica sessione Stripe:', error);
    res.status(500).json({ 
      status: 'error',
      message: error instanceof Error ? error.message : 'Errore verifica sessione' 
    });
  }
}