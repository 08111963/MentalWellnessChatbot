export interface QuoteCategory {
  id: string;
  name: string;
  translations?: {
    [key: string]: string;
  };
}

export interface Quote {
  id: number;
  text: string; // Italian text (default)
  author: string;
  categories: string[];
  translations?: {
    [key: string]: {
      text: string;
    };
  };
}

// Categorie di citazioni per il benessere mentale con traduzioni
export const quoteCategories: QuoteCategory[] = [
  { 
    id: 'mindfulness', 
    name: 'Mindfulness',
    translations: {
      en: 'Mindfulness',
      es: 'Atención plena',
      fr: 'Pleine conscience',
      de: 'Achtsamkeit'
    } 
  },
  { 
    id: 'resilience', 
    name: 'Resilienza',
    translations: {
      en: 'Resilience',
      es: 'Resiliencia',
      fr: 'Résilience',
      de: 'Resilienz'
    } 
  },
  { 
    id: 'growth', 
    name: 'Crescita Personale',
    translations: {
      en: 'Personal Growth',
      es: 'Crecimiento Personal',
      fr: 'Développement Personnel',
      de: 'Persönliches Wachstum'
    } 
  },
  { 
    id: 'happiness', 
    name: 'Felicità',
    translations: {
      en: 'Happiness',
      es: 'Felicidad',
      fr: 'Bonheur',
      de: 'Glück'
    } 
  },
  { 
    id: 'courage', 
    name: 'Coraggio',
    translations: {
      en: 'Courage',
      es: 'Valor',
      fr: 'Courage',
      de: 'Mut'
    } 
  },
  { 
    id: 'peace', 
    name: 'Pace Interiore',
    translations: {
      en: 'Inner Peace',
      es: 'Paz Interior',
      fr: 'Paix Intérieure',
      de: 'Innerer Frieden'
    } 
  },
  { 
    id: 'motivation', 
    name: 'Motivazione',
    translations: {
      en: 'Motivation',
      es: 'Motivación',
      fr: 'Motivation',
      de: 'Motivation'
    } 
  },
  { 
    id: 'gratitude', 
    name: 'Gratitudine',
    translations: {
      en: 'Gratitude',
      es: 'Gratitud',
      fr: 'Gratitude',
      de: 'Dankbarkeit'
    } 
  },
];

// Raccolta di citazioni sul benessere mentale con traduzioni
export const quotes: Quote[] = [
  {
    id: 1,
    text: "La pace arriva quando smetti di lottare contro i tuoi pensieri e impari ad accettarli.",
    author: "Thich Nhat Hanh",
    categories: ['mindfulness', 'peace'],
    translations: {
      en: {
        text: "Peace comes when you stop struggling against your thoughts and learn to accept them."
      },
      es: {
        text: "La paz llega cuando dejas de luchar contra tus pensamientos y aprendes a aceptarlos."
      },
      fr: {
        text: "La paix arrive quand vous cessez de lutter contre vos pensées et apprenez à les accepter."
      },
      de: {
        text: "Frieden kommt, wenn du aufhörst, gegen deine Gedanken zu kämpfen und lernst, sie zu akzeptieren."
      }
    }
  },
  {
    id: 2,
    text: "Non puoi fermare le onde, ma puoi imparare a cavalcarle.",
    author: "Jon Kabat-Zinn",
    categories: ['mindfulness', 'resilience'],
    translations: {
      en: {
        text: "You can't stop the waves, but you can learn to surf."
      },
      es: {
        text: "No puedes detener las olas, pero puedes aprender a surfear."
      },
      fr: {
        text: "Vous ne pouvez pas arrêter les vagues, mais vous pouvez apprendre à surfer."
      },
      de: {
        text: "Du kannst die Wellen nicht aufhalten, aber du kannst lernen zu surfen."
      }
    }
  },
  {
    id: 3,
    text: "Il tuo valore non diminuisce in base all'incapacità di qualcuno di vederlo.",
    author: "Brené Brown",
    categories: ['resilience', 'growth'],
    translations: {
      en: {
        text: "Your worth doesn't decrease based on someone's inability to see it."
      },
      es: {
        text: "Tu valor no disminuye por la incapacidad de alguien para verlo."
      },
      fr: {
        text: "Votre valeur ne diminue pas en fonction de l'incapacité de quelqu'un à la voir."
      },
      de: {
        text: "Dein Wert nimmt nicht ab, weil jemand nicht in der Lage ist, ihn zu sehen."
      }
    }
  },
  {
    id: 4,
    text: "La felicità non è qualcosa di pronto all'uso. Deriva dalle tue azioni.",
    author: "Dalai Lama",
    categories: ['happiness', 'growth'],
    translations: {
      en: {
        text: "Happiness is not something ready-made. It comes from your own actions."
      },
      es: {
        text: "La felicidad no es algo prefabricado. Proviene de tus propias acciones."
      },
      fr: {
        text: "Le bonheur n'est pas quelque chose de prêt à l'emploi. Il vient de vos propres actions."
      },
      de: {
        text: "Glück ist nichts Vorgefertigtes. Es kommt von deinen eigenen Handlungen."
      }
    }
  },
  {
    id: 5,
    text: "Il coraggio non è l'assenza di paura, ma piuttosto la valutazione che qualcos'altro è più importante della paura.",
    author: "Ambrose Redmoon",
    categories: ['courage', 'resilience'],
    translations: {
      en: {
        text: "Courage is not the absence of fear, but rather the judgment that something else is more important than fear."
      },
      es: {
        text: "El coraje no es la ausencia de miedo, sino el juicio de que algo más es más importante que el miedo."
      },
      fr: {
        text: "Le courage n'est pas l'absence de peur, mais plutôt le jugement que quelque chose d'autre est plus important que la peur."
      },
      de: {
        text: "Mut ist nicht die Abwesenheit von Angst, sondern vielmehr die Einschätzung, dass etwas anderes wichtiger ist als Angst."
      }
    }
  },
  {
    id: 6,
    text: "La vera meditazione è entrare in contatto con la vita presente in ogni momento.",
    author: "Thich Nhat Hanh",
    categories: ['mindfulness', 'peace'],
    translations: {
      en: {
        text: "The true meditation is to be in touch with life in every moment."
      },
      es: {
        text: "La verdadera meditación es estar en contacto con la vida en cada momento."
      },
      fr: {
        text: "La vraie méditation est d'être en contact avec la vie à chaque instant."
      },
      de: {
        text: "Die wahre Meditation ist, in jedem Moment mit dem Leben in Kontakt zu sein."
      }
    }
  },
  {
    id: 7,
    text: "Tratta i pensieri come ospiti che vengono e vanno, non come padroni a cui obbedire.",
    author: "Rumi",
    categories: ['mindfulness', 'peace'],
    translations: {
      en: {
        text: "Treat thoughts as guests who come and go, not as masters to obey."
      },
      es: {
        text: "Trata los pensamientos como invitados que van y vienen, no como amos a los que obedecer."
      },
      fr: {
        text: "Traitez les pensées comme des invités qui vont et viennent, pas comme des maîtres à obéir."
      },
      de: {
        text: "Behandle Gedanken wie Gäste, die kommen und gehen, nicht wie Herren, denen man gehorchen muss."
      }
    }
  },
  {
    id: 8,
    text: "Non puoi controllare tutto. A volte devi rilassarti e avere fede che le cose andranno bene.",
    author: "Eckhart Tolle",
    categories: ['peace', 'resilience'],
    translations: {
      en: {
        text: "You can't control everything. Sometimes you need to relax and have faith that things will work out."
      },
      es: {
        text: "No puedes controlarlo todo. A veces debes relajarte y tener fe en que las cosas saldrán bien."
      },
      fr: {
        text: "Vous ne pouvez pas tout contrôler. Parfois, vous devez vous détendre et avoir confiance que les choses vont s'arranger."
      },
      de: {
        text: "Du kannst nicht alles kontrollieren. Manchmal musst du dich entspannen und darauf vertrauen, dass alles gut wird."
      }
    }
  },
  {
    id: 9,
    text: "Cresci attraverso ciò che attraversi.",
    author: "Anonimo",
    categories: ['growth', 'resilience'],
    translations: {
      en: {
        text: "Grow through what you go through."
      },
      es: {
        text: "Crece a través de lo que atraviesas."
      },
      fr: {
        text: "Grandis à travers ce que tu traverses."
      },
      de: {
        text: "Wachse durch das, was du durchmachst."
      }
    }
  },
  {
    id: 10,
    text: "La pratica della gratitudine può trasformare qualsiasi situazione.",
    author: "Melody Beattie",
    categories: ['gratitude', 'happiness'],
    translations: {
      en: {
        text: "The practice of gratitude can transform any situation."
      },
      es: {
        text: "La práctica de la gratitud puede transformar cualquier situación."
      },
      fr: {
        text: "La pratique de la gratitude peut transformer n'importe quelle situation."
      },
      de: {
        text: "Die Praxis der Dankbarkeit kann jede Situation verwandeln."
      }
    }
  },
  {
    id: 11,
    text: "L'autenticità è la pratica quotidiana di lasciare andare chi pensiamo di dover essere e abbracciare chi siamo realmente.",
    author: "Brené Brown",
    categories: ['growth', 'mindfulness'],
    translations: {
      en: {
        text: "Authenticity is the daily practice of letting go of who we think we're supposed to be and embracing who we are."
      },
      es: {
        text: "La autenticidad es la práctica diaria de soltar quién creemos que debemos ser y abrazar quiénes somos realmente."
      },
      fr: {
        text: "L'authenticité est la pratique quotidienne de laisser aller qui nous pensons devoir être et d'embrasser qui nous sommes vraiment."
      },
      de: {
        text: "Authentizität ist die tägliche Praxis, loszulassen, wer wir glauben sein zu müssen, und anzunehmen, wer wir wirklich sind."
      }
    }
  },
  {
    id: 12,
    text: "La resilienza non riguarda il rimbalzare. Riguarda il navigare e adattarsi ai cambiamenti della vita.",
    author: "Eric Greitens",
    categories: ['resilience', 'growth'],
    translations: {
      en: {
        text: "Resilience isn't about bouncing back. It's about navigating and adapting to life's changes."
      },
      es: {
        text: "La resiliencia no se trata de recuperarse. Se trata de navegar y adaptarse a los cambios de la vida."
      },
      fr: {
        text: "La résilience ne consiste pas à rebondir. Il s'agit de naviguer et de s'adapter aux changements de la vie."
      },
      de: {
        text: "Resilienz geht nicht ums Zurückfedern. Es geht darum, durch die Veränderungen des Lebens zu navigieren und sich anzupassen."
      }
    }
  },
  {
    id: 13,
    text: "La gratitudine trasforma ciò che abbiamo in abbastanza.",
    author: "Anonimo",
    categories: ['gratitude', 'happiness'],
    translations: {
      en: {
        text: "Gratitude transforms what we have into enough."
      },
      es: {
        text: "La gratitud transforma lo que tenemos en suficiente."
      },
      fr: {
        text: "La gratitude transforme ce que nous avons en suffisance."
      },
      de: {
        text: "Dankbarkeit verwandelt das, was wir haben, in genug."
      }
    }
  },
  {
    id: 14,
    text: "La vera forza sta nel riconoscere quando hai bisogno di aiuto.",
    author: "Anonimo",
    categories: ['resilience', 'courage'],
    translations: {
      en: {
        text: "True strength lies in recognizing when you need help."
      },
      es: {
        text: "La verdadera fuerza está en reconocer cuando necesitas ayuda."
      },
      fr: {
        text: "La vraie force réside dans la reconnaissance du moment où vous avez besoin d'aide."
      },
      de: {
        text: "Wahre Stärke liegt darin, zu erkennen, wann man Hilfe braucht."
      }
    }
  },
  {
    id: 15,
    text: "Ciò a cui resisti, persiste. Ciò che accetti, trasforma.",
    author: "Carl Jung",
    categories: ['mindfulness', 'growth'],
    translations: {
      en: {
        text: "What you resist, persists. What you accept, transforms."
      },
      es: {
        text: "Lo que resistes, persiste. Lo que aceptas, se transforma."
      },
      fr: {
        text: "Ce à quoi vous résistez, persiste. Ce que vous acceptez, transforme."
      },
      de: {
        text: "Was du bekämpfst, bleibt bestehen. Was du akzeptierst, verändert sich."
      }
    }
  },
  {
    id: 16,
    text: "La mente è come l'acqua. Quando è agitata, diventa difficile vedere. Quando è calma, tutto diventa chiaro.",
    author: "Proverbio Zen",
    categories: ['mindfulness', 'peace'],
    translations: {
      en: {
        text: "The mind is like water. When it's turbulent, it's difficult to see. When it's calm, everything becomes clear."
      },
      es: {
        text: "La mente es como el agua. Cuando está agitada, es difícil ver. Cuando está tranquila, todo se vuelve claro."
      },
      fr: {
        text: "L'esprit est comme l'eau. Quand il est agité, il est difficile de voir. Quand il est calme, tout devient clair."
      },
      de: {
        text: "Der Geist ist wie Wasser. Wenn es unruhig ist, ist es schwer zu sehen. Wenn es ruhig ist, wird alles klar."
      }
    }
  },
  {
    id: 17,
    text: "L'autocura non è egoismo. Non puoi versare da una tazza vuota.",
    author: "Anonimo",
    categories: ['mindfulness', 'growth'],
    translations: {
      en: {
        text: "Self-care is not selfish. You cannot pour from an empty cup."
      },
      es: {
        text: "El autocuidado no es egoísmo. No puedes servir de una taza vacía."
      },
      fr: {
        text: "Prendre soin de soi n'est pas égoïste. On ne peut pas verser d'une tasse vide."
      },
      de: {
        text: "Selbstfürsorge ist nicht egoistisch. Du kannst nicht aus einer leeren Tasse ausschenken."
      }
    }
  },
  {
    id: 18,
    text: "Non aspettare che passi la tempesta, impara a danzare sotto la pioggia.",
    author: "Vivian Greene",
    categories: ['resilience', 'happiness']
  },
  {
    id: 19,
    text: "Il miglior uso della vita è amare. Il miglior modo di amare è con consapevolezza. La migliore espressione di consapevolezza è la compassione.",
    author: "Thich Nhat Hanh",
    categories: ['mindfulness', 'peace']
  },
  {
    id: 20,
    text: "Ogni giorno è una nuova opportunità per cambiare la tua vita.",
    author: "Anonimo",
    categories: ['motivation', 'growth']
  },
  {
    id: 21,
    text: "Sei il protagonista della tua storia. Scrivi un buon capitolo oggi.",
    author: "Anonimo",
    categories: ['motivation', 'growth']
  },
  {
    id: 22,
    text: "Le cose più importanti nella vita non sono cose.",
    author: "Anthony J. D'Angelo",
    categories: ['gratitude', 'happiness']
  },
  {
    id: 23,
    text: "Sii più forte delle tue scuse.",
    author: "Anonimo",
    categories: ['motivation', 'courage']
  },
  {
    id: 24,
    text: "La vita non è ciò che ti accade, ma come reagisci a ciò che ti accade.",
    author: "Epitteto",
    categories: ['resilience', 'mindfulness']
  },
  {
    id: 25,
    text: "Respira. Lascia andare. Ricorda chi sei.",
    author: "Anonimo",
    categories: ['mindfulness', 'peace']
  },
  {
    id: 26,
    text: "Il sorriso che invii ritorna a te.",
    author: "Proverbio indiano",
    categories: ['happiness', 'gratitude']
  },
  {
    id: 27,
    text: "La gentilezza è un linguaggio che il sordo può udire e il cieco può vedere.",
    author: "Mark Twain",
    categories: ['happiness', 'gratitude']
  },
  {
    id: 28,
    text: "Il cambiamento è difficile all'inizio, disordinato nel mezzo e glorioso alla fine.",
    author: "Robin Sharma",
    categories: ['growth', 'resilience']
  },
  {
    id: 29,
    text: "Non puoi tornare indietro e cambiare l'inizio, ma puoi iniziare dove sei e cambiare il finale.",
    author: "C.S. Lewis",
    categories: ['motivation', 'growth']
  },
  {
    id: 30,
    text: "Ogni emozione arriva per insegnarti qualcosa. Ascoltala con curiosità invece che con paura.",
    author: "Anonimo",
    categories: ['mindfulness', 'growth']
  }
];

// Funzione per ottenere una citazione casuale
export function getRandomQuote(): Quote {
  const randomIndex = Math.floor(Math.random() * quotes.length);
  return quotes[randomIndex];
}

// Funzione per ottenere una citazione casuale di una categoria specifica
export function getRandomQuoteByCategory(categoryId: string): Quote | null {
  const categoryQuotes = quotes.filter(quote => 
    quote.categories.includes(categoryId)
  );
  
  if (categoryQuotes.length === 0) {
    return null;
  }
  
  const randomIndex = Math.floor(Math.random() * categoryQuotes.length);
  return categoryQuotes[randomIndex];
}

// Funzione per ottenere una citazione in base all'ID
export function getQuoteById(id: number): Quote | undefined {
  return quotes.find(quote => quote.id === id);
}

// Funzione per ottenere tutte le citazioni
export function getAllQuotes(): Quote[] {
  return quotes;
}

// Funzione per ottenere le citazioni per categoria
export function getQuotesByCategory(categoryId: string): Quote[] {
  return quotes.filter(quote => quote.categories.includes(categoryId));
}