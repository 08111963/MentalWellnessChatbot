import { Resource } from '../shared/schema';

// Interface for resources with translations
interface ResourceWithTranslations extends Omit<Resource, 'title' | 'description' | 'content'> {
  translations: {
    [lang: string]: {
      title: string;
      description: string;
      content?: string;
    }
  }
}

// Creates default content HTML based on language
const createContentHTML = (resource: any, language: string = 'it'): string => {
  const isItalian = language === 'it';
  
  // Get translated values
  const title = resource.translations?.[language]?.title || resource.translations?.['it']?.title || '';
  const description = resource.translations?.[language]?.description || resource.translations?.['it']?.description || '';
  
  if (isItalian) {
    return `
      <h2>${title}</h2>
      <p class="lead">${description}</p>
      
      <h3>Panoramica</h3>
      <p>Questa risorsa su ${title.toLowerCase()} è pensata per aiutarti nel tuo percorso di benessere mentale.</p>
      
      <h3>Perché è importante</h3>
      <p>${description}</p>
      
      <h3>Punti chiave</h3>
      <ul>
        <li>Comprendi i tuoi pensieri e le tue emozioni</li>
        <li>Sviluppa strategie efficaci per affrontare situazioni difficili</li>
        <li>Pratica regolarmente per migliorare la tua resilienza</li>
        <li>Riconosci i progressi che fai nel tempo</li>
      </ul>
      
      <h3>Consigli pratici</h3>
      <p>La costanza è fondamentale. Dedica almeno 10 minuti al giorno a questa pratica per vedere risultati significativi nel tempo.</p>
      
      <h3>Nota importante</h3>
      <p>Ricorda che questa risorsa è pensata come supporto complementare e non sostituisce il consulto con professionisti della salute mentale.</p>
    `;
  } else {
    return `
      <h2>${title}</h2>
      <p class="lead">${description}</p>
      
      <h3>Overview</h3>
      <p>This resource on ${title.toLowerCase()} is designed to help you in your mental wellness journey.</p>
      
      <h3>Why it's important</h3>
      <p>${description}</p>
      
      <h3>Key points</h3>
      <ul>
        <li>Understand your thoughts and emotions</li>
        <li>Develop effective strategies to handle difficult situations</li>
        <li>Practice regularly to improve your resilience</li>
        <li>Recognize the progress you make over time</li>
      </ul>
      
      <h3>Practical tips</h3>
      <p>Consistency is key. Dedicate at least 10 minutes daily to this practice to see significant results over time.</p>
      
      <h3>Important note</h3>
      <p>Remember that this resource is intended as complementary support and does not replace consultation with mental health professionals.</p>
    `;
  }
}

// Transforms multilingual resources to single-language resources
function getTranslatedResource(resource: ResourceWithTranslations, language: string = 'it'): Resource {
  // Default to Italian if the requested language is not available
  const fallbackLang = 'it';
  const lang = resource.translations[language] ? language : fallbackLang;
  
  return {
    id: resource.id,
    title: resource.translations[lang].title,
    description: resource.translations[lang].description,
    type: resource.type,
    tags: resource.tags,
    url: resource.url,
    imageUrl: resource.imageUrl,
    isPremium: resource.isPremium,
    category: resource.category,
    estimatedTime: resource.estimatedTime,
    relevanceScore: resource.relevanceScore,
    content: resource.translations[lang].content || createContentHTML(resource, lang)
  };
}

// Apply translations to all resources and create proper content
const applyContentToResources = (resources: ResourceWithTranslations[], language: string = 'it'): Resource[] => {
  return resources.map(resource => {
    return getTranslatedResource(resource, language);
  });
};

export const resources: Resource[] = applyContentToResources([
  {
    id: 1,
    title: "Tecniche di respirazione per l'ansia",
    description: "Impara 5 tecniche di respirazione efficaci per gestire gli attacchi d'ansia e ridurre lo stress quotidiano.",
    type: "exercise",
    tags: ["ansia", "respirazione", "rapido", "stress"],
    url: "/exercises/3", // ID di un esercizio correlato
    imageUrl: "/images/resources/breathing.svg",
    isPremium: true,
    category: "ansia",
    estimatedTime: "5 min",
    relevanceScore: 8,
    content: createContentHTML({
      title: "Tecniche di respirazione per l'ansia",
      description: "Impara 5 tecniche di respirazione efficaci per gestire gli attacchi d'ansia e ridurre lo stress quotidiano."
    })
  },
  {
    id: 2,
    title: "Comprensione e gestione della depressione",
    description: "Un articolo completo che spiega le cause della depressione e strategie efficaci per affrontarla.",
    type: "article",
    tags: ["depressione", "informativo", "CBT", "terapia"],
    url: "https://www.fondazioneveronesi.it/magazine/articoli/neuroscienze/depressione-curare-presto-e-bene",
    imageUrl: "/images/resources/depression.svg",
    isPremium: true,
    category: "depressione",
    estimatedTime: "12 min",
    relevanceScore: 7
  },
  {
    id: 3,
    title: "Meditazione guidata per il sonno",
    description: "Una meditazione rilassante progettata per aiutarti ad addormentarti più facilmente.",
    type: "meditation",
    tags: ["sonno", "rilassamento", "meditazione", "audio"],
    url: "/meditation/5", // ID di una meditazione correlata
    imageUrl: "/images/resources/sleep.svg",
    isPremium: true,
    category: "sonno",
    estimatedTime: "15 min",
    relevanceScore: 9
  },
  {
    id: 4,
    title: "Riconoscere e gestire i pensieri negativi",
    description: "Esercizio pratico basato sulla CBT per identificare e trasformare i pensieri negativi.",
    type: "exercise",
    tags: ["pensieri", "CBT", "negatività", "pratico"],
    url: "/exercises/7", // ID di un esercizio correlato
    imageUrl: "/images/resources/thoughts.svg",
    isPremium: true,
    category: "depressione",
    estimatedTime: "10 min",
    relevanceScore: 8
  },
  {
    id: 5,
    title: "Le migliori app per la mindfulness",
    description: "Una selezione delle 5 migliori app gratuite per praticare la mindfulness quotidianamente.",
    type: "article",
    tags: ["mindfulness", "app", "tecnologia", "pratica quotidiana"],
    url: "https://www.stateofmind.it/2016/03/app-mindfulness-psicologia/",
    imageUrl: "/images/resources/mindfulness_apps.svg",
    isPremium: true,
    category: "mindfulness",
    estimatedTime: "8 min",
    relevanceScore: 6
  },
  {
    id: 6,
    title: "Gestire il panico: strategie immediate",
    description: "Metodi rapidi ed efficaci per gestire gli attacchi di panico quando si presentano.",
    type: "exercise",
    tags: ["panico", "emergenza", "rapido", "tecniche"],
    url: "/exercises/11", // ID di un esercizio correlato
    imageUrl: "/images/resources/panic.svg",
    isPremium: false,
    category: "ansia",
    estimatedTime: "3 min",
    relevanceScore: 10
  },
  {
    id: 7,
    title: "Migliorare le relazioni attraverso la comunicazione",
    description: "Tecniche e consigli per migliorare la comunicazione e le relazioni interpersonali.",
    type: "video",
    tags: ["relazioni", "comunicazione", "sociale", "empatia"],
    url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ", // Link a un video YouTube
    imageUrl: "/images/resources/communication.svg",
    isPremium: true,
    category: "relazioni",
    estimatedTime: "18 min",
    relevanceScore: 7
  },
  {
    id: 8,
    title: "La pratica della gratitudine quotidiana",
    description: "Come iniziare un diario della gratitudine e i suoi benefici scientificamente provati.",
    type: "article",
    tags: ["gratitudine", "positività", "abitudini", "benessere"],
    url: "https://www.psicologi-italia.it/benessere-psicologico/mente-positiva/gratitudine-la-via-per-il-benessere.html",
    imageUrl: "/images/resources/gratitude.svg",
    isPremium: false,
    category: "mindfulness",
    estimatedTime: "7 min",
    relevanceScore: 6
  },
  {
    id: 9,
    title: "Tecniche di rilassamento muscolare progressivo",
    description: "Un metodo passo-passo per rilassare il corpo e la mente attraverso il rilassamento muscolare.",
    type: "exercise",
    tags: ["rilassamento", "stress", "corpo", "tensione"],
    url: "/exercises/15", // ID di un esercizio correlato
    imageUrl: "/images/resources/muscle_relaxation.svg",
    isPremium: true,
    category: "stress",
    estimatedTime: "15 min",
    relevanceScore: 7
  },
  {
    id: 10,
    title: "Il potere dell'autocompassione",
    description: "Perché l'autocompassione è fondamentale per il benessere mentale e come praticarla.",
    type: "article",
    tags: ["autocompassione", "gentilezza", "autostima", "benessere"],
    url: "https://www.stateofmind.it/2017/02/auto-compassione-sofferenza/",
    imageUrl: "/images/resources/self_compassion.svg",
    isPremium: true,
    category: "autostima",
    estimatedTime: "9 min",
    relevanceScore: 8
  },
  {
    id: 11,
    title: "Body scan meditation",
    description: "Meditazione guidata per aumentare la consapevolezza corporea e ridurre lo stress.",
    type: "meditation",
    tags: ["meditazione", "corpo", "consapevolezza", "rilassamento"],
    url: "/meditation/9", // ID di una meditazione correlata
    imageUrl: "/images/resources/body_scan.svg",
    isPremium: true,
    category: "mindfulness",
    estimatedTime: "12 min",
    relevanceScore: 6
  },
  {
    id: 12,
    title: "Superare il perfezionismo",
    description: "Come riconoscere e superare il perfezionismo dannoso per la salute mentale.",
    type: "article",
    tags: ["perfezionismo", "ansia", "autostima", "produttività"],
    url: "https://www.stateofmind.it/2017/12/perfezionismo-psicologia-clinica/",
    imageUrl: "/images/resources/perfectionism.svg",
    isPremium: false,
    category: "ansia",
    estimatedTime: "10 min",
    relevanceScore: 7
  },
  {
    id: 13,
    title: "Mindful eating: mangiare consapevolmente",
    description: "Un approccio consapevole all'alimentazione per migliorare la relazione con il cibo.",
    type: "exercise",
    tags: ["alimentazione", "mindfulness", "consapevolezza", "benessere"],
    url: "/exercises/20", // ID di un esercizio correlato
    imageUrl: "/images/resources/mindful_eating.svg",
    isPremium: true,
    category: "mindfulness",
    estimatedTime: "8 min",
    relevanceScore: 5
  },
  {
    id: 14,
    title: "Comprendere il disturbo d'ansia generalizzato",
    description: "Sintomi, cause e trattamenti del disturbo d'ansia generalizzato spiegati in modo chiaro.",
    type: "article",
    tags: ["ansia", "disturbo", "terapia", "informativo"],
    url: "https://www.stateofmind.it/2014/06/disturbo-ansia-generalizzato-dag/",
    imageUrl: "/images/resources/anxiety.svg",
    isPremium: false,
    category: "ansia",
    estimatedTime: "11 min",
    relevanceScore: 8
  },
  {
    id: 15,
    title: "Esercizio delle 5 cose",
    description: "Un semplice esercizio di mindfulness per ancorarsi al presente in momenti di stress.",
    type: "exercise",
    tags: ["mindfulness", "stress", "semplice", "presente"],
    url: "/exercises/25", // ID di un esercizio correlato
    imageUrl: "/images/resources/five_senses.svg",
    isPremium: false,
    category: "ansia",
    estimatedTime: "3 min",
    relevanceScore: 9
  },
  {
    id: 16,
    title: "Tecniche avanzate di rilassamento per lo stress",
    description: "Un percorso dettagliato per affrontare lo stress cronico con tecniche basate sulla mindfulness.",
    type: "course",
    tags: ["stress", "mindfulness", "rilassamento", "avanzato"],
    url: "/courses/stress-management",
    imageUrl: "/images/resources/advanced_relaxation.svg",
    isPremium: true,
    category: "stress",
    estimatedTime: "45 min",
    relevanceScore: 9
  },
  {
    id: 17,
    title: "Migliorare l'autostima: percorso strutturato",
    description: "Un programma completo in 7 giorni per aumentare l'autostima e la fiducia in se stessi.",
    type: "program",
    tags: ["autostima", "fiducia", "crescita personale", "esercizi"],
    url: "/programs/self-esteem",
    imageUrl: "/images/resources/self_esteem_program.svg",
    isPremium: true,
    category: "autostima",
    estimatedTime: "7 giorni",
    relevanceScore: 10
  },
  {
    id: 18,
    title: "Comunicazione efficace nelle relazioni",
    description: "Strumenti pratici per migliorare la comunicazione nelle relazioni personali e professionali.",
    type: "course",
    tags: ["relazioni", "comunicazione", "ascolto attivo", "empatia"],
    url: "/courses/effective-communication",
    imageUrl: "/images/resources/communication_course.svg",
    isPremium: true,
    category: "relazioni",
    estimatedTime: "30 min",
    relevanceScore: 8
  },
  {
    id: 19,
    title: "Disturbi del sonno: terapia cognitivo comportamentale",
    description: "Un approccio basato sulla CBT per trattare l'insonnia e migliorare la qualità del sonno.",
    type: "program",
    tags: ["sonno", "insonnia", "CBT", "routine"],
    url: "/programs/sleep-cbt",
    imageUrl: "/images/resources/sleep_therapy.svg",
    isPremium: true,
    category: "sonno",
    estimatedTime: "14 giorni",
    relevanceScore: 9
  },
  {
    id: 20,
    title: "Depressione e pensiero positivo",
    description: "Come ristrutturare i pensieri negativi e coltivare un atteggiamento più positivo verso la vita.",
    type: "workshop",
    tags: ["depressione", "pensiero positivo", "CBT", "ristrutturazione cognitiva"],
    url: "/workshops/positive-thinking",
    imageUrl: "/images/resources/positive_thinking.svg",
    isPremium: true,
    category: "depressione",
    estimatedTime: "60 min",
    relevanceScore: 9
  },
  /* SONNO - risorse aggiuntive */
  {
    id: 21,
    title: "Routine serale per un sonno migliore",
    description: "Crea una routine serale efficace per migliorare la qualità del tuo sonno e addormentarti più facilmente.",
    type: "guide",
    tags: ["sonno", "routine", "relax", "abitudini"],
    url: "/guides/evening-routine",
    imageUrl: "/images/resources/sleep_routine.svg",
    isPremium: true,
    category: "sonno",
    estimatedTime: "8 min",
    relevanceScore: 8
  },
  {
    id: 22,
    title: "Meditazione per combattere l'insonnia",
    description: "Una meditazione specifica per chi soffre di insonnia e ha difficoltà ad addormentarsi.",
    type: "meditation",
    tags: ["sonno", "insonnia", "meditazione", "rilassamento"],
    url: "/meditation/sleep-advanced",
    imageUrl: "/images/resources/sleep_meditation.svg",
    isPremium: true,
    category: "sonno",
    estimatedTime: "15 min",
    relevanceScore: 9
  },
  {
    id: 23,
    title: "Tecniche di rilassamento progressivo per dormire",
    description: "Un metodo scientifico per rilassare il corpo e prepararlo al sonno attraverso il rilassamento muscolare.",
    type: "exercise",
    tags: ["sonno", "rilassamento", "muscolare", "tecnica"],
    url: "/exercises/progressive-sleep",
    imageUrl: "/images/resources/muscle_sleep.svg",
    isPremium: false,
    category: "sonno",
    estimatedTime: "10 min",
    relevanceScore: 7
  },
  /* RELAZIONI - risorse aggiuntive */
  {
    id: 24,
    title: "Ascolto attivo nelle relazioni",
    description: "Come migliorare le relazioni personali attraverso tecniche di ascolto attivo ed empatia.",
    type: "course",
    tags: ["relazioni", "ascolto", "empatia", "comunicazione"],
    url: "/courses/active-listening",
    imageUrl: "/images/resources/active_listening.svg",
    isPremium: true,
    category: "relazioni",
    estimatedTime: "25 min",
    relevanceScore: 8
  },
  {
    id: 25,
    title: "Gestire i conflitti in modo costruttivo",
    description: "Strategie efficaci per trasformare i conflitti in opportunità di crescita nelle relazioni.",
    type: "workshop",
    tags: ["relazioni", "conflitti", "problem-solving", "crescita"],
    url: "/workshops/conflict-management",
    imageUrl: "/images/resources/conflict_resolution.svg",
    isPremium: true,
    category: "relazioni",
    estimatedTime: "30 min",
    relevanceScore: 9
  },
  {
    id: 26,
    title: "Relazioni sane: riconoscere i segnali",
    description: "Come identificare dinamiche relazionali sane e quelle potenzialmente dannose.",
    type: "article",
    tags: ["relazioni", "salute mentale", "confini", "rispetto"],
    url: "/articles/healthy-relationships",
    imageUrl: "/images/resources/healthy_relationships.svg",
    isPremium: false,
    category: "relazioni",
    estimatedTime: "12 min",
    relevanceScore: 7
  },
  /* AUTOSTIMA - risorse aggiuntive */
  {
    id: 27,
    title: "Diario dell'autostima: esercizi quotidiani",
    description: "Un programma di 21 giorni con esercizi pratici per aumentare gradualmente l'autostima.",
    type: "program",
    tags: ["autostima", "esercizi", "diario", "abitudini"],
    url: "/programs/self-esteem-journal",
    imageUrl: "/images/resources/esteem_journal.svg",
    isPremium: true,
    category: "autostima",
    estimatedTime: "21 giorni",
    relevanceScore: 9
  },
  {
    id: 28,
    title: "Superare l'autocritica distruttiva",
    description: "Tecniche per riconoscere e modificare il dialogo interno negativo e l'autocritica eccessiva.",
    type: "workshop",
    tags: ["autostima", "autocritica", "dialogo interno", "compassione"],
    url: "/workshops/overcoming-self-criticism",
    imageUrl: "/images/resources/self_critic.svg",
    isPremium: true,
    category: "autostima",
    estimatedTime: "45 min",
    relevanceScore: 8
  },
  {
    id: 29,
    title: "Autostima e immagine corporea",
    description: "Come sviluppare un rapporto più sano con il proprio corpo e migliorare l'autostima.",
    type: "guide",
    tags: ["autostima", "corpo", "immagine", "accettazione"],
    url: "/guides/body-image",
    imageUrl: "/images/resources/body_acceptance.svg",
    isPremium: false,
    category: "autostima",
    estimatedTime: "15 min",
    relevanceScore: 7
  },
  /* DEPRESSIONE - risorse aggiuntive */
  {
    id: 30,
    title: "Attività piacevoli per combattere la depressione",
    description: "Una guida pratica per pianificare e inserire attività piacevoli nella routine quotidiana per combattere i sintomi depressivi.",
    type: "exercise",
    tags: ["depressione", "attività", "piacere", "umore"],
    url: "/exercises/pleasant-activities",
    imageUrl: "/images/resources/pleasant_activities.svg",
    isPremium: false,
    category: "depressione",
    estimatedTime: "12 min",
    relevanceScore: 8
  },
  {
    id: 31,
    title: "Meditazione guidata per la depressione",
    description: "Una meditazione specifica per periodi di basso tono dell'umore che aiuta a coltivare compassione verso se stessi.",
    type: "meditation",
    tags: ["depressione", "meditazione", "compassione", "accettazione"],
    url: "/meditation/depression-healing",
    imageUrl: "/images/resources/depression_meditation.svg",
    isPremium: true,
    category: "depressione",
    estimatedTime: "18 min",
    relevanceScore: 9
  },
  /* MINDFULNESS - risorse aggiuntive */
  {
    id: 32,
    title: "Mindfulness e quotidianità",
    description: "Come integrare la pratica della mindfulness nei piccoli momenti quotidiani per ridurre lo stress e aumentare la consapevolezza.",
    type: "guide",
    tags: ["mindfulness", "quotidiano", "consapevolezza", "momenti"],
    url: "/guides/daily-mindfulness",
    imageUrl: "/images/resources/daily_mindfulness.svg",
    isPremium: true,
    category: "mindfulness",
    estimatedTime: "10 min",
    relevanceScore: 7
  },
  {
    id: 36,
    title: "Mindfulness per principianti",
    description: "Un percorso introduttivo alla pratica della mindfulness con esercizi fondamentali per iniziare.",
    type: "course",
    tags: ["mindfulness", "principianti", "meditazione", "fondamenti"],
    url: "/courses/mindfulness-beginners",
    imageUrl: "/images/resources/mindfulness_beginners.svg",
    isPremium: false,
    category: "mindfulness",
    estimatedTime: "30 min",
    relevanceScore: 8
  },
  {
    id: 37,
    title: "Meditazione di consapevolezza avanzata",
    description: "Tecniche avanzate di mindfulness per chi ha già esperienza con la meditazione e vuole approfondire la pratica.",
    type: "meditation",
    tags: ["mindfulness", "avanzata", "meditazione", "consapevolezza"],
    url: "/meditation/advanced-mindfulness",
    imageUrl: "/images/resources/advanced_mindfulness.svg",
    isPremium: true,
    category: "mindfulness",
    estimatedTime: "25 min",
    relevanceScore: 9
  },
  {
    id: 38,
    title: "Mindfulness nella natura",
    description: "Come utilizzare l'ambiente naturale per approfondire la tua pratica di consapevolezza e presenza mentale.",
    type: "guide",
    tags: ["mindfulness", "natura", "ambiente", "presente"],
    url: "/guides/nature-mindfulness",
    imageUrl: "/images/resources/nature_mindfulness.svg",
    isPremium: false,
    category: "mindfulness",
    estimatedTime: "15 min",
    relevanceScore: 7
  },
  /* STRESS - risorse aggiuntive */
  {
    id: 33,
    title: "Gestione delle crisi di stress acuto",
    description: "Tecniche rapide ed efficaci per gestire i momenti di stress intenso e improvviso.",
    type: "exercise",
    tags: ["stress", "crisi", "acuto", "emergenza"],
    url: "/exercises/acute-stress",
    imageUrl: "/images/resources/acute_stress.svg",
    isPremium: true,
    category: "stress",
    estimatedTime: "8 min",
    relevanceScore: 9
  },
  {
    id: 34,
    title: "Organizzazione e pianificazione anti-stress",
    description: "Metodi pratici per organizzare impegni e responsabilità in modo da ridurre lo stress quotidiano.",
    type: "workshop",
    tags: ["stress", "organizzazione", "pianificazione", "tempo"],
    url: "/workshops/stress-planning",
    imageUrl: "/images/resources/stress_planning.svg",
    isPremium: false,
    category: "stress",
    estimatedTime: "25 min",
    relevanceScore: 7
  },
  {
    id: 35,
    title: "Stress e alimentazione",
    description: "La relazione tra alimentazione e stress: cibi da prediligere e abitudini da evitare.",
    type: "article",
    tags: ["stress", "alimentazione", "nutrizione", "benessere"],
    url: "/articles/stress-nutrition",
    imageUrl: "/images/resources/stress_nutrition.svg",
    isPremium: true,
    category: "stress",
    estimatedTime: "15 min",
    relevanceScore: 6
  }
]);

// Il campo content è già stato aggiunto a tutte le risorse tramite la funzione applyContentToResources

// Funzione per ottenere tutte le risorse
export function getAllResources(): Resource[] {
  return resources;
}

// Funzione per ottenere le risorse per categoria
export function getResourcesByCategory(category: string): Resource[] {
  console.log(`Cercando risorse per categoria: ${category}`);
  const filteredResources = resources.filter(resource => 
    resource.category.toLowerCase() === category.toLowerCase()
  );
  console.log(`Trovate ${filteredResources.length} risorse per la categoria ${category}`);
  return filteredResources;
}

// Funzione per ottenere le risorse per tipo
export function getResourcesByType(type: string): Resource[] {
  return resources.filter(resource => resource.type === type);
}

// Funzione per ottenere le risorse premium
export function getPremiumResources(): Resource[] {
  return resources.filter(resource => resource.isPremium);
}

// Funzione per ottenere le risorse gratuite
export function getFreeResources(): Resource[] {
  return resources.filter(resource => !resource.isPremium);
}

// Funzione per ottenere una singola risorsa per ID
export function getResourceById(id: number): Resource | undefined {
  return resources.find(resource => resource.id === id);
}

// Funzione per ottenere risorse consigliate in base a tag specifici
export function getResourcesByTags(tags: string[]): Resource[] {
  return resources.filter(resource => 
    resource.tags?.some(tag => tags.includes(tag))
  ).sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));
}

// Funzione avanzata per ottenere risorse personalizzate in base a vari parametri
export function getPersonalizedResources(params: {
  userId?: number;
  categories?: string[];
  tags?: string[];
  excludeTypes?: string[];
  onlyPremium?: boolean;
  limit?: number;
}): Resource[] {
  let filtered = [...resources];
  
  // Filtra per categorie se specificate
  if (params.categories && params.categories.length > 0) {
    filtered = filtered.filter(resource => 
      params.categories?.includes(resource.category)
    );
  }
  
  // Filtra per tag se specificati
  if (params.tags && params.tags.length > 0) {
    filtered = filtered.filter(resource => 
      resource.tags?.some(tag => params.tags?.includes(tag))
    );
  }
  
  // Escludi certi tipi se specificati
  if (params.excludeTypes && params.excludeTypes.length > 0) {
    filtered = filtered.filter(resource => 
      !params.excludeTypes?.includes(resource.type)
    );
  }
  
  // Filtra per premium se specificato
  if (params.onlyPremium !== undefined) {
    filtered = filtered.filter(resource => resource.isPremium === params.onlyPremium);
  }
  
  // Ordina per punteggio di rilevanza
  filtered.sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));
  
  // Limita i risultati se specificato
  if (params.limit && params.limit > 0) {
    filtered = filtered.slice(0, params.limit);
  }
  
  return filtered;
}