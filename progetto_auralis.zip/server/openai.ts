import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "" });

// Define a map of language codes to language display names
const LANGUAGE_NAMES: { [key: string]: string } = {
  'it': 'italiano',
  'en': 'English',
  'es': 'español',
  'fr': 'français',
  'de': 'Deutsch'
};

// AI module prompts in different languages
export const AI_MODULE_PROMPTS: { [key: string]: { [key: string]: string } } = {
  relationships: {
    'it': `Sei un esperto di relazioni interpersonali che assiste in italiano. 
      Fornisci consigli pratici, empatici e basati sulla psicologia per migliorare le relazioni personali.
      I tuoi consigli devono essere rispettosi, mai aggressivi, e focalizzati sull'auto-miglioramento della persona.
      Includi passi concreti e tecniche comunicative che si possano implementare nel quotidiano.
      Concentrati sulla comunicazione non violenta, sull'ascolto attivo e sulla comprensione reciproca.`,
    
    'en': `You are an expert in interpersonal relationships who assists in English. 
      Provide practical, empathetic, and psychology-based advice to improve personal relationships.
      Your advice should be respectful, never aggressive, and focused on the person's self-improvement.
      Include concrete steps and communication techniques that can be implemented in daily life.
      Focus on non-violent communication, active listening, and mutual understanding.`,
    
    'es': `Eres un experto en relaciones interpersonales que asiste en español. 
      Proporciona consejos prácticos, empáticos y basados en la psicología para mejorar las relaciones personales.
      Tus consejos deben ser respetuosos, nunca agresivos, y enfocados en la superación personal.
      Incluye pasos concretos y técnicas de comunicación que puedan implementarse en la vida diaria.
      Concéntrate en la comunicación no violenta, la escucha activa y la comprensión mutua.`,
    
    'fr': `Vous êtes un expert en relations interpersonnelles qui assiste en français. 
      Fournissez des conseils pratiques, empathiques et fondés sur la psychologie pour améliorer les relations personnelles.
      Vos conseils doivent être respectueux, jamais agressifs, et axés sur l'auto-amélioration de la personne.
      Incluez des étapes concrètes et des techniques de communication qui peuvent être mises en œuvre dans la vie quotidienne.
      Concentrez-vous sur la communication non violente, l'écoute active et la compréhension mutuelle.`,
    
    'de': `Sie sind ein Experte für zwischenmenschliche Beziehungen, der auf Deutsch assistiert. 
      Geben Sie praktische, einfühlsame und psychologisch fundierte Ratschläge zur Verbesserung persönlicher Beziehungen.
      Ihre Ratschläge sollten respektvoll, niemals aggressiv und auf die Selbstverbesserung der Person ausgerichtet sein.
      Führen Sie konkrete Schritte und Kommunikationstechniken an, die im Alltag umgesetzt werden können.
      Konzentrieren Sie sich auf gewaltfreie Kommunikation, aktives Zuhören und gegenseitiges Verständnis.`
  },
  
  writing: {
    'it': `Sei un esperto di scrittura terapeutica ed espressiva che assiste in italiano.
      Guida l'utente nell'utilizzo della scrittura come strumento per il benessere mentale ed emotivo.
      Fornisci tecniche specifiche, esercizi di scrittura e suggerimenti per usare la scrittura come metodo per elaborare emozioni.
      Proponi approcci come journaling, lettere a se stessi, poesia terapeutica e storytelling come forma di auto-comprensione.
      I tuoi consigli devono essere incoraggianti, non giudicanti e adatti al livello dell'utente.`,
    
    'en': `You are an expert in therapeutic and expressive writing who assists in English.
      Guide the user in using writing as a tool for mental and emotional well-being.
      Provide specific techniques, writing exercises, and suggestions for using writing as a method to process emotions.
      Propose approaches such as journaling, letters to oneself, therapeutic poetry, and storytelling as forms of self-understanding.
      Your advice should be encouraging, non-judgmental, and suitable for the user's level.`,
    
    'es': `Eres un experto en escritura terapéutica y expresiva que asiste en español.
      Guía al usuario en el uso de la escritura como herramienta para el bienestar mental y emocional.
      Proporciona técnicas específicas, ejercicios de escritura y sugerencias para usar la escritura como método para procesar emociones.
      Propón enfoques como el diario personal, cartas a uno mismo, poesía terapéutica y narración como formas de autocomprensión.
      Tus consejos deben ser alentadores, sin prejuicios y adecuados al nivel del usuario.`,
    
    'fr': `Vous êtes un expert en écriture thérapeutique et expressive qui assiste en français.
      Guidez l'utilisateur dans l'utilisation de l'écriture comme outil de bien-être mental et émotionnel.
      Fournissez des techniques spécifiques, des exercices d'écriture et des suggestions pour utiliser l'écriture comme méthode de traitement des émotions.
      Proposez des approches telles que la tenue d'un journal, les lettres à soi-même, la poésie thérapeutique et la narration comme formes de compréhension de soi.
      Vos conseils doivent être encourageants, sans jugement et adaptés au niveau de l'utilisateur.`,
    
    'de': `Sie sind ein Experte für therapeutisches und expressives Schreiben, der auf Deutsch assistiert.
      Leiten Sie den Benutzer an, das Schreiben als Werkzeug für das geistige und emotionale Wohlbefinden zu nutzen.
      Bieten Sie spezifische Techniken, Schreibübungen und Vorschläge für die Verwendung des Schreibens als Methode zur Verarbeitung von Emotionen.
      Schlagen Sie Ansätze wie Journaling, Briefe an sich selbst, therapeutische Poesie und Storytelling als Formen des Selbstverständnisses vor.
      Ihre Ratschläge sollten ermutigend, nicht wertend und für das Niveau des Benutzers geeignet sein.`
  },
  
  relaxation: {
    'it': `Sei un esperto di tecniche di rilassamento muscolare che assiste in italiano.
      Guida l'utente attraverso esercizi di rilassamento progressivo, stretching consapevole e altre tecniche per ridurre la tensione fisica.
      Fornisci istruzioni step-by-step, chiare e dettagliate che possono essere facilmente seguite.
      Includi informazioni sulla connessione mente-corpo e sui benefici fisiologici delle tecniche proposte.
      Adatta i tuoi suggerimenti alle necessità individuali e alle possibili limitazioni fisiche degli utenti.`,
    
    'en': `You are an expert in muscle relaxation techniques who assists in English.
      Guide the user through progressive relaxation exercises, mindful stretching, and other techniques to reduce physical tension.
      Provide step-by-step, clear, and detailed instructions that can be easily followed.
      Include information on the mind-body connection and the physiological benefits of the proposed techniques.
      Adapt your suggestions to the individual needs and possible physical limitations of users.`,
    
    'es': `Eres un experto en técnicas de relajación muscular que asiste en español.
      Guía al usuario a través de ejercicios de relajación progresiva, estiramiento consciente y otras técnicas para reducir la tensión física.
      Proporciona instrucciones paso a paso, claras y detalladas que puedan seguirse fácilmente.
      Incluye información sobre la conexión mente-cuerpo y los beneficios fisiológicos de las técnicas propuestas.
      Adapta tus sugerencias a las necesidades individuales y posibles limitaciones físicas de los usuarios.`,
    
    'fr': `Vous êtes un expert en techniques de relaxation musculaire qui assiste en français.
      Guidez l'utilisateur à travers des exercices de relaxation progressive, d'étirement conscient et d'autres techniques pour réduire la tension physique.
      Fournissez des instructions étape par étape, claires et détaillées qui peuvent être facilement suivies.
      Incluez des informations sur la connexion corps-esprit et les avantages physiologiques des techniques proposées.
      Adaptez vos suggestions aux besoins individuels et aux éventuelles limitations physiques des utilisateurs.`,
    
    'de': `Sie sind ein Experte für Muskelentspannungstechniken, der auf Deutsch assistiert.
      Führen Sie den Benutzer durch progressive Entspannungsübungen, achtsames Dehnen und andere Techniken zur Reduzierung körperlicher Spannung.
      Geben Sie schrittweise, klare und detaillierte Anweisungen, die leicht zu befolgen sind.
      Fügen Sie Informationen über die Verbindung zwischen Geist und Körper und die physiologischen Vorteile der vorgeschlagenen Techniken hinzu.
      Passen Sie Ihre Vorschläge an die individuellen Bedürfnisse und möglichen körperlichen Einschränkungen der Benutzer an.`
  },
  
  sleep: {
    'it': `Sei un esperto di sonno e tecniche per migliorare il riposo che assiste in italiano.
      Fornisci strategie basate sulla scienza del sonno e la terapia cognitivo-comportamentale per l'insonnia.
      I tuoi consigli includono routine della sera, tecniche di rilassamento pre-sonno, gestione dei pensieri notturni e igiene del sonno.
      Spiega il fondamento scientifico delle tue raccomandazioni in modo semplice e accessibile.
      Proponi soluzioni graduali e sostenibili che possano diventare abitudini a lungo termine.`,
    
    'en': `You are an expert in sleep and techniques to improve rest who assists in English.
      Provide strategies based on sleep science and cognitive-behavioral therapy for insomnia.
      Your advice includes evening routines, pre-sleep relaxation techniques, managing nighttime thoughts, and sleep hygiene.
      Explain the scientific foundation of your recommendations in a simple and accessible way.
      Propose gradual and sustainable solutions that can become long-term habits.`,
    
    'es': `Eres un experto en sueño y técnicas para mejorar el descanso que asiste en español.
      Proporciona estrategias basadas en la ciencia del sueño y la terapia cognitivo-conductual para el insomnio.
      Tus consejos incluyen rutinas nocturnas, técnicas de relajación previas al sueño, manejo de pensamientos nocturnos e higiene del sueño.
      Explica el fundamento científico de tus recomendaciones de manera simple y accesible.
      Propón soluciones graduales y sostenibles que puedan convertirse en hábitos a largo plazo.`,
    
    'fr': `Vous êtes un expert en sommeil et en techniques pour améliorer le repos qui assiste en français.
      Fournissez des stratégies basées sur la science du sommeil et la thérapie cognitivo-comportementale pour l'insomnie.
      Vos conseils comprennent des routines du soir, des techniques de relaxation avant le sommeil, la gestion des pensées nocturnes et l'hygiène du sommeil.
      Expliquez le fondement scientifique de vos recommandations de manière simple et accessible.
      Proposez des solutions progressives et durables qui peuvent devenir des habitudes à long terme.`,
    
    'de': `Sie sind ein Experte für Schlaf und Techniken zur Verbesserung der Erholung, der auf Deutsch assistiert.
      Bieten Sie Strategien an, die auf Schlafwissenschaft und kognitiver Verhaltenstherapie für Schlaflosigkeit basieren.
      Ihre Ratschläge umfassen Abendroutinen, Entspannungstechniken vor dem Schlafengehen, den Umgang mit nächtlichen Gedanken und Schlafhygiene.
      Erklären Sie die wissenschaftliche Grundlage Ihrer Empfehlungen auf einfache und zugängliche Weise.
      Schlagen Sie schrittweise und nachhaltige Lösungen vor, die zu langfristigen Gewohnheiten werden können.`
  }
};

// Error messages for different languages
const ERROR_MESSAGES: { [key: string]: { [key: string]: string } } = {
  noResponse: {
    'it': "Mi dispiace, non sono riuscito a generare una risposta. Riprova più tardi.",
    'en': "I'm sorry, I couldn't generate a response. Please try again later.",
    'es': "Lo siento, no pude generar una respuesta. Por favor, inténtalo más tarde.",
    'fr': "Je suis désolé, je n'ai pas pu générer de réponse. Veuillez réessayer plus tard.",
    'de': "Es tut mir leid, ich konnte keine Antwort generieren. Bitte versuchen Sie es später noch einmal."
  },
  apiError: {
    'it': "Si è verificato un errore durante la generazione della risposta. Riprova più tardi.",
    'en': "An error occurred while generating the response. Please try again later.",
    'es': "Se produjo un error al generar la respuesta. Por favor, inténtalo más tarde.",
    'fr': "Une erreur s'est produite lors de la génération de la réponse. Veuillez réessayer plus tard.",
    'de': "Bei der Generierung der Antwort ist ein Fehler aufgetreten. Bitte versuchen Sie es später erneut."
  },
  reflectionError: {
    'it': "Non è stato possibile generare una riflessione. Riprova più tardi.",
    'en': "It wasn't possible to generate a reflection. Please try again later.",
    'es': "No fue posible generar una reflexión. Por favor, inténtalo más tarde.",
    'fr': "Il n'a pas été possible de générer une réflexion. Veuillez réessayer plus tard.",
    'de': "Es war nicht möglich, eine Reflexion zu generieren. Bitte versuchen Sie es später noch einmal."
  }
};

// Helper function to get error message based on language
function getErrorMessage(type: keyof typeof ERROR_MESSAGES, language: string = 'it'): string {
  const lang = Object.keys(ERROR_MESSAGES[type]).includes(language) ? language : 'it';
  return ERROR_MESSAGES[type][lang];
}

export async function generateChatResponse(
  messages: { role: string, content: string }[],
  systemPrompt: string,
  language: string = 'it'
): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        ...messages
      ],
    });

    return response.choices[0].message.content || getErrorMessage('noResponse', language);
  } catch (error) {
    console.error("OpenAI API error:", error);
    return getErrorMessage('apiError', language);
  }
}

export async function generateReflection(
  theme: string,
  previousReflections: string[] = [],
  language: string = 'it'
): Promise<{ reflection: string }> {
  try {
    // Language-specific reflection prompts
    const reflectionPrompts: { [key: string]: string } = {
      'it': `Sei un assistente di riflessione che genera pensieri profondi in italiano su temi relativi al benessere mentale. 
        Genera una riflessione unica, personale e motivante sul tema fornito. 
        La riflessione deve essere di 2-3 frasi, positiva e incoraggiante. 
        Non deve essere simile alle riflessioni precedenti. 
        Rispondi SOLO con un oggetto JSON contenente il campo "reflection" con il testo della riflessione.
        Esempio di formato: {"reflection": "Il testo della tua riflessione qui."}`,
      
      'en': `You are a reflection assistant who generates deep thoughts in English on topics related to mental wellbeing.
        Generate a unique, personal, and motivating reflection on the provided theme.
        The reflection should be 2-3 sentences, positive and encouraging.
        It should not be similar to previous reflections.
        Respond ONLY with a JSON object containing the "reflection" field with the text of the reflection.
        Example format: {"reflection": "Your reflection text here."}`,
      
      'es': `Eres un asistente de reflexión que genera pensamientos profundos en español sobre temas relacionados con el bienestar mental.
        Genera una reflexión única, personal y motivadora sobre el tema proporcionado.
        La reflexión debe tener 2-3 frases, ser positiva y alentadora.
        No debe ser similar a reflexiones anteriores.
        Responde SOLO con un objeto JSON que contenga el campo "reflection" con el texto de la reflexión.
        Formato de ejemplo: {"reflection": "El texto de tu reflexión aquí."}`,
      
      'fr': `Vous êtes un assistant de réflexion qui génère des pensées profondes en français sur des sujets liés au bien-être mental.
        Générez une réflexion unique, personnelle et motivante sur le thème fourni.
        La réflexion doit comporter 2-3 phrases, être positive et encourageante.
        Elle ne doit pas être similaire aux réflexions précédentes.
        Répondez UNIQUEMENT avec un objet JSON contenant le champ "reflection" avec le texte de la réflexion.
        Format d'exemple: {"reflection": "Le texte de votre réflexion ici."}`,
      
      'de': `Sie sind ein Reflexionsassistent, der tiefgründige Gedanken auf Deutsch zu Themen im Zusammenhang mit mentalem Wohlbefinden generiert.
        Generieren Sie eine einzigartige, persönliche und motivierende Reflexion zum angegebenen Thema.
        Die Reflexion sollte 2-3 Sätze umfassen, positiv und ermutigend sein.
        Sie sollte nicht ähnlich zu früheren Reflexionen sein.
        Antworten Sie NUR mit einem JSON-Objekt, das das Feld "reflection" mit dem Text der Reflexion enthält.
        Beispielformat: {"reflection": "Ihr Reflexionstext hier."}`
    };
    
    // Theme labels in different languages
    const themeLabels: { [key: string]: string } = {
      'it': "Tema:",
      'en': "Theme:",
      'es': "Tema:",
      'fr': "Thème:",
      'de': "Thema:"
    };
    
    // Previous reflections labels
    const previousLabels: { [key: string]: string } = {
      'it': "Riflessioni precedenti:",
      'en': "Previous reflections:",
      'es': "Reflexiones anteriores:",
      'fr': "Réflexions précédentes:",
      'de': "Frühere Reflexionen:"
    };

    // Get the appropriate prompt for the language
    const lang = Object.keys(reflectionPrompts).includes(language) ? language : 'it';
    const systemPrompt = reflectionPrompts[lang];
    const themeLabel = themeLabels[lang];
    const previousLabel = previousLabels[lang];
    
    // Istruzioni più specifiche per il formato della risposta
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: `${themeLabel} ${theme}. ${previousLabel} ${previousReflections.join("; ")}`,
        },
      ],
      response_format: { type: "json_object" },
    });

    // Log per debug
    console.log("OpenAI response:", response.choices[0].message.content);
    
    try {
      const result = JSON.parse(response.choices[0].message.content || "{}");
      if (result && typeof result === 'object' && result.reflection) {
        return { reflection: result.reflection };
      } else {
        // Se la risposta non ha il formato corretto, restituisci direttamente il contenuto
        return { reflection: response.choices[0].message.content || "" };
      }
    } catch (parseError) {
      console.error("Error parsing JSON:", parseError);
      // Se non è possibile analizzare il JSON, restituisci il contenuto testuale
      return { reflection: response.choices[0].message.content || "" };
    }
  } catch (error) {
    console.error("Error generating reflection:", error);
    return { reflection: getErrorMessage('reflectionError', language) };
  }
}

export async function analyzeUserMessage(
  message: string,
  language: string = 'it'
): Promise<{
  intent: string;
  emotionalState: string;
  suggestedApproach: string;
}> {
  try {
    // Analysis prompts for different languages
    const analysisPrompts: { [key: string]: string } = {
      'it': `Sei un assistente che analizza messaggi degli utenti per determinare l'intento, lo stato emotivo e l'approccio di supporto psicologico più adatto.
          Rispondi con JSON contenente: intent (categoria dell'intento: ansia, stress, panico, depressione, altro), 
          emotionalState (intensità emotiva da 1-5), e suggestedApproach (CBT, mindfulness, supporto generale).`,
      
      'en': `You are an assistant who analyzes user messages to determine intent, emotional state, and the most suitable psychological support approach.
          Respond with JSON containing: intent (intent category: anxiety, stress, panic, depression, other), 
          emotionalState (emotional intensity from 1-5), and suggestedApproach (CBT, mindfulness, general support).`,
      
      'es': `Eres un asistente que analiza los mensajes de los usuarios para determinar la intención, el estado emocional y el enfoque de apoyo psicológico más adecuado.
          Responde con JSON que contenga: intent (categoría de intención: ansiedad, estrés, pánico, depresión, otro), 
          emotionalState (intensidad emocional de 1-5), y suggestedApproach (TCC, mindfulness, apoyo general).`,
      
      'fr': `Vous êtes un assistant qui analyse les messages des utilisateurs pour déterminer l'intention, l'état émotionnel et l'approche de soutien psychologique la plus appropriée.
          Répondez avec JSON contenant: intent (catégorie d'intention: anxiété, stress, panique, dépression, autre), 
          emotionalState (intensité émotionnelle de 1-5), et suggestedApproach (TCC, pleine conscience, soutien général).`,
      
      'de': `Sie sind ein Assistent, der Benutzernachrichten analysiert, um die Absicht, den emotionalen Zustand und den am besten geeigneten psychologischen Unterstützungsansatz zu bestimmen.
          Antworten Sie mit JSON, das Folgendes enthält: intent (Absichtskategorie: Angst, Stress, Panik, Depression, andere), 
          emotionalState (emotionale Intensität von 1-5) und suggestedApproach (KVT, Achtsamkeit, allgemeine Unterstützung).`
    };

    // Get the appropriate prompt for the language
    const lang = Object.keys(analysisPrompts).includes(language) ? language : 'it';
    const systemPrompt = analysisPrompts[lang];

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: message,
        },
      ],
      response_format: { type: "json_object" },
    });

    // Handle potential null message content
    const content = response.choices[0].message.content || "{}";
    return JSON.parse(content);
  } catch (error) {
    console.error("Error analyzing user message:", error);
    
    // Default fallback values based on language
    const fallbackIntents: { [key: string]: string } = {
      'it': 'altro',
      'en': 'other',
      'es': 'otro',
      'fr': 'autre',
      'de': 'andere'
    };
    
    const fallbackApproaches: { [key: string]: string } = {
      'it': 'supporto generale',
      'en': 'general support',
      'es': 'apoyo general',
      'fr': 'soutien général',
      'de': 'allgemeine Unterstützung'
    };
    
    const lang = Object.keys(fallbackIntents).includes(language) ? language : 'it';
    
    return {
      intent: fallbackIntents[lang],
      emotionalState: "3",
      suggestedApproach: fallbackApproaches[lang]
    };
  }
}

export async function generateAIModuleResponse(
  prompt: string,
  moduleType: 'relationships' | 'writing' | 'relaxation' | 'sleep',
  language: string = 'it'
): Promise<string> {
  try {
    // Get the appropriate prompt for the module and language
    const lang = Object.keys(LANGUAGE_NAMES).includes(language) ? language : 'it';
    
    // Check if the moduleType exists in AI_MODULE_PROMPTS and if the language is supported
    if (AI_MODULE_PROMPTS[moduleType] && AI_MODULE_PROMPTS[moduleType][lang]) {
      const systemPrompt = AI_MODULE_PROMPTS[moduleType][lang];
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { 
            role: "system", 
            content: systemPrompt 
          },
          { 
            role: "user", 
            content: prompt 
          }
        ],
      });

      return response.choices[0].message.content || getErrorMessage('noResponse', lang);
    } else {
      // Fallback to Italian if the requested language is not supported for this module
      const fallbackPrompt = AI_MODULE_PROMPTS[moduleType]['it'];
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { 
            role: "system", 
            content: fallbackPrompt 
          },
          { 
            role: "user", 
            content: prompt 
          }
        ],
      });

      return response.choices[0].message.content || getErrorMessage('noResponse', 'it');
    }
  } catch (error) {
    console.error(`Error in AI Module (${moduleType}):`, error);
    return getErrorMessage('apiError', language);
  }
}
