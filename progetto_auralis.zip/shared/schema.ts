import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isPremium: boolean("is_premium").default(false).notNull(),
  subscriptionStart: timestamp("subscription_start"),
  subscriptionEnd: timestamp("subscription_end"),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  subscriptionStatus: text("subscription_status"), // 'active', 'canceled', 'past_due', 'trialing', etc.
  subscriptionPlan: text("subscription_plan"), // 'monthly', 'yearly'
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  content: text("content").notNull(),
  role: text("role").notNull(), // "user" or "assistant"
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const meditation = pgTable("meditation", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  duration: integer("duration").notNull(), // in minutes
  description: text("description").notNull(),
  content: text("content").notNull(),
  isPremium: boolean("is_premium").default(false).notNull(),
});

export const exercises = pgTable("exercises", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(), // "CBT", "mindfulness", etc.
  description: text("description").notNull(),
  steps: jsonb("steps").notNull(),
  isPremium: boolean("is_premium").default(false).notNull(),
});

export const reflections = pgTable("reflections", {
  id: serial("id").primaryKey(),
  prompt: text("prompt").notNull(),
  category: text("category").notNull(),
  isPremium: boolean("is_premium").default(false).notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isPremium: true,
  subscriptionStart: true,
  subscriptionEnd: true,
  stripeCustomerId: true,
  stripeSubscriptionId: true,
  subscriptionStatus: true,
  subscriptionPlan: true,
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  userId: true,
  content: true,
  role: true,
});

export const insertMeditationSchema = createInsertSchema(meditation).pick({
  title: true,
  duration: true,
  description: true,
  content: true,
  isPremium: true,
});

export const insertExerciseSchema = createInsertSchema(exercises).pick({
  title: true,
  category: true,
  description: true,
  steps: true,
  isPremium: true,
});

export const insertReflectionSchema = createInsertSchema(reflections).pick({
  prompt: true,
  category: true,
  isPremium: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type Meditation = typeof meditation.$inferSelect;
export type InsertMeditation = z.infer<typeof insertMeditationSchema>;

export type Exercise = typeof exercises.$inferSelect;
export type InsertExercise = z.infer<typeof insertExerciseSchema>;

export type Reflection = typeof reflections.$inferSelect;
export type InsertReflection = z.infer<typeof insertReflectionSchema>;

// Schema per il monitoraggio dell'umore
export const moodEntries = pgTable("mood_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  date: timestamp("date").defaultNow(),
  score: integer("score").notNull(), // Valore da 1 a 5
  notes: text("notes"),
  activities: text("activities").array(), // Attività associate all'umore
  emotions: text("emotions").array(), // Emozioni specifiche provate
  triggerEvents: text("trigger_events"), // Eventi scatenanti per l'umore
  sleepQuality: integer("sleep_quality"), // Opzionale, qualità del sonno (1-5)
  energyLevel: integer("energy_level"), // Opzionale, livello energia (1-5)
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).pick({
  userId: true,
  date: true,
  score: true,
  notes: true, 
  activities: true,
  emotions: true,
  triggerEvents: true,
  sleepQuality: true,
  energyLevel: true,
});

export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;

// Schema per le risorse personalizzate consigliate
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // 'article', 'video', 'exercise', 'meditation', 'book', 'app', 'website'
  tags: text("tags").array(),
  url: text("url"),
  imageUrl: text("image_url"),
  isPremium: boolean("is_premium").default(false).notNull(),
  category: text("category").notNull(), // ansia, depressione, stress, sonno, relazioni, etc.
  estimatedTime: text("estimated_time"),
  relevanceScore: integer("relevance_score"), // punteggio di rilevanza per l'utente (1-10)
  content: text("content"), // contenuto HTML della risorsa
});

export const insertResourceSchema = createInsertSchema(resources).pick({
  title: true,
  description: true,
  type: true,
  tags: true,
  url: true,
  imageUrl: true,
  isPremium: true,
  category: true,
  estimatedTime: true,
  relevanceScore: true,
  content: true,
});

export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;

// Tabella di associazione tra utenti e risorse raccomandate
export const userResources = pgTable("user_resources", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  resourceId: integer("resource_id").references(() => resources.id).notNull(),
  recommended: timestamp("recommended").defaultNow(), // quando è stata raccomandata
  viewed: boolean("viewed").default(false), // se l'utente ha visualizzato la risorsa
  viewedAt: timestamp("viewed_at"), // quando l'utente ha visualizzato la risorsa
  saved: boolean("saved").default(false), // se l'utente ha salvato la risorsa
});

export const insertUserResourceSchema = createInsertSchema(userResources).pick({
  userId: true,
  resourceId: true,
  viewed: true,
  viewedAt: true,
  saved: true,
});

export type UserResource = typeof userResources.$inferSelect;
export type InsertUserResource = z.infer<typeof insertUserResourceSchema>;

// Schema per le transazioni Stripe
export const stripeTransactions = pgTable("stripe_transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  stripeSessionId: text("stripe_session_id").notNull(),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  amount: integer("amount"), // Importo in centesimi
  currency: text("currency").default("eur"),
  status: text("status").notNull(), // 'completed', 'failed', 'pending'
  type: text("type").notNull(), // 'subscription', 'one-time'
  plan: text("plan"), // 'monthly', 'yearly', etc.
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  metadata: jsonb("metadata"), // Eventuali metadati aggiuntivi
});

export const insertStripeTransactionSchema = createInsertSchema(stripeTransactions).pick({
  userId: true,
  stripeSessionId: true,
  stripeCustomerId: true,
  stripeSubscriptionId: true,
  amount: true,
  currency: true,
  status: true,
  type: true,
  plan: true,
  metadata: true,
});

export type StripeTransaction = typeof stripeTransactions.$inferSelect;
export type InsertStripeTransaction = z.infer<typeof insertStripeTransactionSchema>;
